# Action Items: Carrie and Howard Berends - InnVestAI

**Date:** 2025-09-16
**Extracted:** 2026-02-05 14:46:48

---

- Meeting cadence established
	- Tuesdays 5:30 ET (main weekly call - 1.5 hours)
	- Thursdays 5:30 ET (quick catchup - 30-45 min)
- Carrie joining Thursday 1:30 PT call for logo feedback session
	- Team must provide logo feedback before then
	- Mark must send one-pager requirements
- Future priorities post-conference:
	- Website improvements (currently bare bones intentionally)
	- Go-to-market strategy development (nothing currently planned)
	- Client feedback loops and beta testing preparation
- Invoice handling through Drew (no company bank account yet)