# Action Items: Call Howard<>Jean-François

**Date:** 2026-02-12
**Extracted:** 2026-02-12 14:54:31

---

- Jean will reconnect when ready to hire (post-MVP)
- Howard offered to help with PoC or coding if needed
- Both agreed to stay in regular contact
- Jean will be heads-down on MVP development
- Howard to check in periodically for updates