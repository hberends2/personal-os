# Action Items: LLC separation strategy with Diane and Mark conflict resolution

**Date:** 2025-11-25
**Extracted:** 2026-02-05 14:54:33

---

- Tonight’s call with team announcement
- Schedule meeting with CBRE Benchmarker team (VP Paul + data team)
- Execute new LLC with remaining three partners after Mark separation
- Review updated valuation page UX changes before sharing with others