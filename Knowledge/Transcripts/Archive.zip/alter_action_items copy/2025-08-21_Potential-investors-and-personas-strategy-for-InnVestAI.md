# Action Items: Potential investors and personas strategy for InnVestAI

**Date:** 2025-08-21
**Extracted:** 2026-02-05 14:46:48

---

- Discuss Mike Sherbin opportunity on tonight’s team call
- Schedule introductory call: Howard, note-taker, and Mike for next week
- Meet with Carlos Rodriguez Jr. tomorrow to propose investment arrangement