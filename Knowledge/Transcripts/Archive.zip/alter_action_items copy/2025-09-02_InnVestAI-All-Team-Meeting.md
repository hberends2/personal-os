# Action Items: InnVestAI All Team Meeting

**Date:** 2025-09-02
**Extracted:** 2026-02-05 14:46:48

---

- Drew: Set up OneNote weekly tracking structure
- Diane: Complete investor deck by Sunday, prepare economics presentation for Driftwood
- Howard: Finalize 6-12 month roadmap PowerPoint by tomorrow, review AI PRD documentation
- Vinod: Update technology progress list, resolve staging database connectivity
- Drew: Send $400 Venmo payment for Sharik, coordinate messaging strategy before future investor calls
- All: Review LLC agreement sections, provide input on real-world scenario testing for agreement