# Action Items - 2025-11-13 Potential Mark removal and InnVestAI company strategy with Howard and Vinod

- Howard & Vinod: LLC agreement review meeting at 5:30 today
	- Raise objections to Mark’s sales role and salary structure
	- Avoid direct confrontation with Mark until strategy finalized
- All: Multi-day consideration period for Mark situation, no immediate decision
- Diane: Provide detailed Driftwood arrangement documentation (next 2 weeks)
- Team: Legal consultation on Delaware law and separation risks (owner/timing TBD)
- Diane: Unavailable next 2 days (Kroger budget work), Miami all week through Thanksgiving
- Consideration: New parent LLC setup in Delaware (timeline dependent on decision)
- Howard: $12,500 check delivery today (1 month coverage)
