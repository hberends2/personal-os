# Action Items - 2025-12-01 Howard + Diane

- Howard: Cancel Tuesday 10am call
- Howard: Call with Mike Skiba (tomorrow 10:30am)
- Howard: Jessica consultation (Thursday) - company structure advice
- Howard: Mike Tanner go-to-market strategy session (Thursday)
- Howard: Sherben discussion (tomorrow 5:30pm) - settlement and equity terms
- Howard: Reach out to Carlos at Driftwood this week
- Howard: Submit expense report for $2k travel costs
- All: Review LLC structure and get signed ASAP after legal consultation
- All: Mark Woodworth discovery call (Friday) - maintain despite legal concerns
