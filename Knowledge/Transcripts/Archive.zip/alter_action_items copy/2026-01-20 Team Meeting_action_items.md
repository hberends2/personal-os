# Action Items - 2026-01-20 Team Meeting

- Vinod coordination call scheduled (need to confirm timing with all parties)
- Google Workspace setup at $7/person for operational efficiency
- Working session scheduled for Monday, January 26th at 11:00 AM
	- Howard to demonstrate current proof of concept
	- Diane to present updated pitch deck developed with uncle’s GTM expertise
	- Prepare materials for February 3rd Sloan Dean conversation
- Set up call next Monday 11:00 (from notes)
- Vinod: need Git and logo files (from notes)
- Contact: msherban23@gmail.com (from notes)
