# Action Items: InnVestAI All Team Meeting

**Date:** 2025-09-23
**Extracted:** 2026-02-05 14:46:48

---

- Howard: Review budget projections and provide feedback
- Diane: Finalize LLC operating agreement language (buy/sell, drag-along provisions)
- Drew: Complete product testing feedback via video walkthrough
- Mark: Send consolidated one-pager content to Carrie
- Carrie: Deliver updated logo options and one-pager draft
- Team: Begin systematic MVP testing after initial bug fixes