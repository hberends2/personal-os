# Action Items: Coordination Call

**Date:** 2025-04-29
**Extracted:** 2026-02-05 14:46:48

---

- Vinod to:
	- Review new data format from Drew
	- Begin coding model logic
	- Create database tables
- Diana to:
	- Test hotel underwriting with new model
	- Work on marketing/fundraising materials
- Future meetings scheduled for Mondays at 1:30
- Howard to create Jira features focused on MVP requirements

Chat with meeting transcript: https://notes.granola.ai/d/0cb1ffae-ea3f-485f-8eee-9ed2968a8168