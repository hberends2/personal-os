# Action Items: Introduction & POC demo

**Date:** 2025-07-28
**Extracted:** 2026-02-05 14:46:48

---

- Howard will share document with hotel industry terminology definitions
- Development team to review PRDs (all available except waterfall feature)
- Focus on extracting financial data from PDFs for MVP/v1
- Howard available for business questions during development

Chat with meeting transcript: https://notes.granola.ai/d/3c098df2-d1ae-44c1-944a-bbd6b91a9297