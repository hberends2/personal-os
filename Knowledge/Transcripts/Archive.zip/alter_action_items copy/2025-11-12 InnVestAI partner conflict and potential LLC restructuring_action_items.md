# Action Items - 2025-11-12 InnVestAI partner conflict and potential LLC restructuring

- Wait and observe situation before major decisions
- Howard to message Drew privately about Diane’s financial needs
- Possible quick call with Drew to discuss options
- Avoid including Mark or Diane in financial discussion thread
