# Action Items: Book a Meeting with Jean (Howard Berends)

**Date:** 2026-01-27
**Extracted:** 2026-02-05 14:54:33

---

- Jean considering offsite with founders and advisors this weekend
- Will update early next week on next steps
- Discussion topics for offsite:
	- Timing decisions
	- Candidate personality/profile fit (including Howard)