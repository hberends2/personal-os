# Action Items: Book a Meeting with Jean (Howard Berends)

**Date:** 2025-12-22
**Extracted:** 2026-02-05 14:54:33

---

- Jean deciding on bringing in product co-founder within 2-3 weeks
- Target team alignment by mid-January
- Plan: 3 months to build MVP, then raise funding
- Reconnect after Christmas for deeper dive
- Howard to prepare ideas/bullet points based on past experience