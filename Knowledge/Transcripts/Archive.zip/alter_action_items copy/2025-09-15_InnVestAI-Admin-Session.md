# Action Items: InnVestAI Admin Session

**Date:** 2025-09-15
**Extracted:** 2026-02-05 14:46:48

---

- Howard: Clean up business vision slide, research Yardi/MRI hospitality modules
- Drew: Research and produce market-rate safe note agreement
- Team: Get safe note to Carlos by end of week (delayed from today)
- Howard: Try Google Gemini for infographic creation
- 5:30 call tomorrow to finalize safe note if needed