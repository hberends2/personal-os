# Action Items: InnVestAI All Team Meeting

**Date:** 2025-09-04
**Extracted:** 2026-02-05 14:46:48

---

- Drew: Schedule LARC integration meeting with Howard/Vinod (Monday)
- Diane/Howard: Budget review meeting (tomorrow noon)
- Drew/Mark/Diane: Customer/investor pitch deck discussion (Monday)
- Howard: Complete formula documentation cleanup (tomorrow morning)
- Vinod: Find immigration attorney for LLC compliance review
- Team: Monthly budget breakdown for next 6-12 months