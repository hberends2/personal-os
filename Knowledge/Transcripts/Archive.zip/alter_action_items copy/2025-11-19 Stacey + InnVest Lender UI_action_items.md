# Action Items - 2025-11-19 Stacey + InnVest Lender UI

- Stacey will check feasibility of hotel team pilot while other AI pilot runs
- Howard to refine lender-specific version of MVP
- Potential collaboration on white label solution for Western Alliance
- Follow-up in coming months as MVP develops
