# Action Items: Visa and company structure strategy with attorney consultation planning

**Date:** 2025-06-09
**Extracted:** 2026-02-05 14:46:48

---

- Complete proof of concept for Excel comparison
- Form analyst advisory committee
- Get testimonials from industry experts
- Schedule call with attorney to clarify remaining visa questions
- Consider scheduling demos with potential strategic partners
- Develop formal marketing plan
- Target 20 potential users/investors