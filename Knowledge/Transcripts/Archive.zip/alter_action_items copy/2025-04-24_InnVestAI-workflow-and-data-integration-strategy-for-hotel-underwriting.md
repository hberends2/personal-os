# Action Items: InnVestAI workflow and data integration strategy for hotel underwriting

**Date:** 2025-04-24
**Extracted:** 2026-02-05 14:46:48

---

- Clean up and distribute CapEx assumptions template
- Schedule follow-up meeting for Wednesday/Thursday
- Review room data emails from previous night
- Continue discussions on projection methodology

Chat with meeting transcript: https://notes.granola.ai/d/6f4267b8-1b17-4825-88b7-549de5903378