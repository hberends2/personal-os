# Action Items: InnVestAI All Team Meeting

**Date:** 2025-09-09
**Extracted:** 2026-02-05 14:46:48

---

- Drew & Mark: Complete investor pitch deck by next Tuesday (consult Howard on pricing)
- Drew: Finalize monthly budget breakdown by Thursday morning
- Howard: Research hotel transaction velocity data
- Team: Join interactive deck demo Thursday (first 30 minutes of call)
- Howard: Attend LARC Industry Outlook webinar Thursday