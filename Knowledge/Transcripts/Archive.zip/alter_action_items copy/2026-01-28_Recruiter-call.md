# Action Items: Recruiter call

**Date:** 2026-01-28
**Extracted:** 2026-02-05 14:54:33

---

- Recruiter sending resume consent form and detailed job description
- Platform Services VP role specifically recommended over Data Platform VP
- Lightbox recently acquired 11 companies requiring platform integration
- Role aligns with Howard’s Real Page acquisition integration experience
- Compensation expected to exceed previous RedIQ package