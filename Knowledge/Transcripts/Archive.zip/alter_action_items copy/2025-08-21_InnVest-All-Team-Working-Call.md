# Action Items: InnVest All Team Working Call

**Date:** 2025-08-21
**Extracted:** 2026-02-05 14:46:48

---

- First investor secured: $50K via SAFE note from friend/family round
- Diane continuing LLC formation process
- Action items:
	- Vinod: Formula validation testing tomorrow with Howard
	- Howard: Review PRDs, verify KPI card requirements, meet with Carrie about potential graphics support
	- Team: Review AI terminology diagram Diane will reshare for Tuesday discussion