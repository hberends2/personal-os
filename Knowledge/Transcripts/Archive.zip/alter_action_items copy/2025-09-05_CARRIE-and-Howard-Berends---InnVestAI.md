# Action Items: CARRIE and Howard Berends - InnVestAI

**Date:** 2025-09-05
**Extracted:** 2026-02-05 14:46:48

---

- Howard to coordinate intro call with Mark Gordon next week
	- Carrie to block multiple time slots on calendar
	- Email signature booking link needs fixing
- Carrie to send formal proposal/agreement via email
- Project timeline: 30-60 days for initial deliverables