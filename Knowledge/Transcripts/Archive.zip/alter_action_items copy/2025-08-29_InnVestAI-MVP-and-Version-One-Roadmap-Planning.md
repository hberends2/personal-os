# Action Items: InnVestAI MVP and Version One Roadmap Planning

**Date:** 2025-08-29
**Extracted:** 2026-02-05 14:46:48

---

- Howard to draft detailed roadmap email with PowerPoint slides
- Potential roadmap review call with Mike after investment phase
- Continue focus on realistic timeline communication with stakeholders