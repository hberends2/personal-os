# Action Items: InnVestAI six-month budget planning with Vinod

**Date:** 2025-09-05
**Extracted:** 2026-02-05 14:46:48

---

- Howard to send updated InnVestAI tools spreadsheet details
- Diane to adjust budget categories: reduce contingency from 25% to 15%, add miscellaneous line items
- Trademark budget increase needed (details in chat)
- Continue investor outreach for 2-3 additional $50-150k commitments
- Prioritize bringing Vinod and Howard to full-time status once funding secured