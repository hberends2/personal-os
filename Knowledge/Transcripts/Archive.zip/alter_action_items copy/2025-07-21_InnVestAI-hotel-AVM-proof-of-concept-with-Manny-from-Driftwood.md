# Action Items: InnVestAI hotel AVM proof of concept with Manny from Driftwood

**Date:** 2025-07-21
**Extracted:** 2026-02-05 14:46:48

---

- Reconvene around Labor Day after more development progress
- Limited initial client testing (2-3 clients) from September to March
- Carlos Junior (from Driftwood) to review recording and provide perspective
- Explore potential collaboration opportunities between InnVestAI and Driftwood
- Future development roadmap includes:
	- SSO authentication
	- SOC 2 compliance
	- Deeper integrations with industry data sources

Chat with meeting transcript: https://notes.granola.ai/d/84e8706b-adf2-4213-a6f1-f6e4c10106f7