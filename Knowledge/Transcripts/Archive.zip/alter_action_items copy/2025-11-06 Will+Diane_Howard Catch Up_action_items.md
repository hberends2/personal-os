# Action Items - 2025-11-06 Will+Diane_Howard Catch Up

- Will to consider potential involvement
	- Expertise in hotel data and API integrations
	- Self-starter with relevant C-level experience
	- No immediate W-2 position available
- Demo schedule: December 2024/January 2025 with lenders
- Follow-up planned after holidays
