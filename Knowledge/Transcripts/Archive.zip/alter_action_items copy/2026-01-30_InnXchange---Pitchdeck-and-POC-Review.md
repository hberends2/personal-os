# Action Items: InnXchange - Pitchdeck and POC Review

**Date:** 2026-01-30
**Extracted:** 2026-02-05 14:54:33

---

- Howard: POC review Monday 11 AM
- Diane: Add marketplace slide, remove Claude references, adjust user counts
- Diane: Finalize deck formatting before Ben Rafter meeting
- Team: Prepare to defend revenue projections and user assumptions