# Action Items: Will+Diane/Howard Catch Up

**Date:** 2025-11-06
**Extracted:** 2026-02-05 14:54:33

---

- Will to consider potential involvement
	- Expertise in hotel data and API integrations
	- Self-starter with relevant C-level experience
	- No immediate W-2 position available
- Demo schedule: December 2024/January 2025 with lenders
- Follow-up planned after holidays