# Action Items - 2026-01-30 InnXchange - Pitchdeck and POC Review

- Howard: POC review Monday 11 AM
- Diane: Add marketplace slide, remove Claude references, adjust user counts
- Diane: Finalize deck formatting before Ben Rafter meeting
- Team: Prepare to defend revenue projections and user assumptions
