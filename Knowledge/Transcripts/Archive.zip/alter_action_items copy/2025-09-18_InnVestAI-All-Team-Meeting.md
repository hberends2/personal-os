# Action Items: InnVestAI All Team Meeting

**Date:** 2025-09-18
**Extracted:** 2026-02-05 14:46:48

---

- Howard: Create focused 12-month roadmap slide by Monday, add legal/renovation workflow discovery boxes
- Drew: Send safe note template with $5M valuation cap to Carlos, transfer developer payments today
- Drew: Forward cap table analysis to team for next call discussion
- Carrie: Convert presentation content into professional deck format (~$100, 3 hours)
- Team: Tuesday call to review dev site layout and organization
- Howard: Research offshore product manager costs and availability