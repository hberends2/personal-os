# Action Items - 2026-01-28 Recruiter call

for Lightbox Opportunity

- Recruiter sending resume consent form and detailed job description
- Platform Services VP role specifically recommended over Data Platform VP
- Lightbox recently acquired 11 companies requiring platform integration
- Role aligns with Howard’s Real Page acquisition integration experience
- Compensation expected to exceed previous RedIQ package
