# Action Items - 2025-11-13 LLC funding and partner compensation review with Diane

- Howard to obtain written Driftwood confirmation of fund allocation within 4 weeks
- Three-person meeting (Howard, team member, Vinod) to discuss Mark situation before 5:30 call
- Legal consultation needed on LLC complications and potential Mark exit scenarios
- Jessica (proptech startup advisor) consultation to be scheduled
- Howard stepping back from today’s 5:30 LLC call due to budget review workload
