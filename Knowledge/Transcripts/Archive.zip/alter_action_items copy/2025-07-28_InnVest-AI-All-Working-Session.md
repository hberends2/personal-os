# Action Items: InnVest AI All Working Session

**Date:** 2025-07-28
**Extracted:** 2026-02-05 14:46:48

---

- Operating agreement execution: all five members obtain notarization and return signature pages
- Howard: send complete operating agreement document for member review
- Howard: finalize contractor agreements for Raj and Shivam
- Vinod: fix website contact form functionality and migrate to AWS
- Mark: create user persona matrix detailing dashboard requirements by stakeholder type
- Drew: lead Ryan exploratory call and report back on next steps
- Team: prepare for Ellen demo with customization messaging (future versions will allow personalized dashboards)
- Vinod: schedule development team demo once AI model refinement complete

Chat with meeting transcript: https://notes.granola.ai/d/acc9fb18-7c20-48ad-8695-d98d951c8d68