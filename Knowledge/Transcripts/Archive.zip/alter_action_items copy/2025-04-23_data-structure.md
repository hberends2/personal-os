# Action Items: data structure

**Date:** 2025-04-23
**Extracted:** 2026-02-05 14:46:48

---

- Drew to send:
	- Sample data for ~20 properties
	- 2024 full year data
	- Account hierarchy details
- Need to execute NDA
- Howard to follow up with Diane regarding:
	- NDA signature
	- Invest email account setup

Chat with meeting transcript: https://notes.granola.ai/d/1424d1d0-1a06-46af-b8e5-8e976a6fe453