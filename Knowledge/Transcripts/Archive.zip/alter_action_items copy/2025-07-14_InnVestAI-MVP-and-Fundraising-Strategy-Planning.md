# Action Items: InnVestAI MVP and Fundraising Strategy Planning

**Date:** 2025-07-14
**Extracted:** 2026-02-05 14:46:48

---

- Create 6-month budget incorporating:
	- Vinod’s development costs
	- Incorporation expenses
	- Travel/conference costs
- Develop Gantt chart showing dependencies (without specific dates)
- Schedule demo with Mark’s Prakashani analyst
- Review tool/subscription requirements:
	- Identify immediate needs vs. future requirements
	- Current annual estimate: $3K for tools/subscriptions