# Action Items - 2025-12-10 Howard Berends and Wendy Moore

- Wendy scheduling 90-minute deep dive with Rajiv (SVP Product) for next week
- Howard has availability, no scheduling conflicts
- Timeline: First two interview stages before holidays, panel/final interviews early January
- Target decision by mid-January
- Howard has another opportunity in process but no immediate pressure
