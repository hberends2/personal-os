# Action Items: InnVestAI MVP and AI Feature Planning Session

**Date:** 2025-07-16
**Extracted:** 2026-02-05 14:46:48

---

- Vinod to research self-hosted LLM costs vs external API pricing
- Howard to investigate pricing models for user onboarding
- Team alignment call scheduled for tomorrow at 1:30 PM
- Begin MVP development Monday after financial setup (bank account/credit card)
- Continue using Lovable for rapid prototyping and user feedback incorporation

Chat with meeting transcript: https://notes.granola.ai/d/d26308b8-ea19-4467-acd7-4e755758787a