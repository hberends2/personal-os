# Action Items: Infrastructure and data strategy for hotel investment model

**Date:** 2025-05-16
**Extracted:** 2026-02-05 14:46:48

---

- Share PowerPoint presentation via Teams
- Review prompt for immigration research
- Schedule pre-meeting sync before Monday’s call
- 15-minute intro call scheduled with David from scottie.ai regarding beta testing
- Need to create diagram outlining POC vs. MVP deliverables
- Discuss data requirements with Diane and Drew in next meeting

Chat with meeting transcript: https://notes.granola.ai/d/99b7a9ee-4999-4f79-99ae-0589b75a1aba