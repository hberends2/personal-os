# Action Items - 2025-12-15 Settlement

- Mike drafting settlement offer email this week
	- Single option: code transfer, no money, confidentiality clauses
	- Expects response by end of week
	- Goal to complete before holidays if accepted
- Howard to contact Vinod Monday
	- Confirm GitHub access and code packaging
	- Clarify his intentions regarding project participation
	- Ensure any post-November 25th work is excluded
- Two-week holiday pause planned
	- Focus on settlement completion first
	- Reassess partnership structure in January (potential 3-person vs 4-person deal)
	- Howard continuing development of improved version during break
