# Action Items: InnVestAI | Carrie Ng

**Date:** 2025-09-02
**Extracted:** 2026-02-05 14:46:48

---

- Howard to send Carrie sample logos and persona document
- Carrie to draft 3 logo concepts and review Elise AI website for design inspiration
- Contract basis engagement: hourly rate, project-based initially
- Meeting cadence: Weekly business development calls or monthly participation