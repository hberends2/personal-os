# Action Items: InnVestAI partner conflict and potential LLC restructuring

**Date:** 2025-11-12
**Extracted:** 2026-02-05 14:54:33

---

- Wait and observe situation before major decisions
- Howard to message Drew privately about Diane’s financial needs
- Possible quick call with Drew to discuss options
- Avoid including Mark or Diane in financial discussion thread