# Action Items: InnVestAI - Follow Up

**Date:** 2025-04-28
**Extracted:** 2026-02-05 14:46:48

---

- Diane to complete GoDaddy/Microsoft 365 setup
- Howard to:
	- Share business plan document (56 pages, AI-generated)
	- Add team members to Jira/Confluence once emails are set up
	- Research potential for industry-specific large language model
- Schedule detailed underwriting process review with Drew
- Begin documenting detailed product workflows by persona