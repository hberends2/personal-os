# Action Items: WCG Proprietary DB Conversation

**Date:** 2025-12-05
**Extracted:** 2026-02-05 14:54:33

---

- Mark to be updated on discussion (was at Christmas tree farm)
- Both parties to consider partnership structure and terms
- Continued exploration of mutual data sharing arrangements
- Follow-up discussions on technical integration possibilities