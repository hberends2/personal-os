# Action Items: Introduction and LLC

**Date:** 2025-09-17
**Extracted:** 2026-02-05 14:46:48

---

- [ ] Internal founder discussion on shared vision and exit strategy - All founders - [Date TBD]
- [ ] Finalize compensation structure and 1099 contractor approach - All founders - [Date TBD]
- [ ] Research legal requirements for 1099 contractor payments - Diane - [Date TBD]
- [ ] Agree on SAFE note valuation cap for first round - All founders - [Date TBD]
- [ ] Revise LLC agreement incorporating today’s feedback - Drew - [Date TBD]
- [ ] Add founder roles and delegation authority schedule - Drew - [Date TBD]
- [ ] Send updated LLC agreement to Mike for review - Drew - After revisions complete