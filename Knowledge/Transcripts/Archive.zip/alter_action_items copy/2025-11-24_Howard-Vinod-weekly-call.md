# Action Items: Howard | Vinod weekly call

**Date:** 2025-11-24
**Extracted:** 2026-02-05 14:54:33

---

- Decision to gather all requirements before implementation
	- Avoid back-and-forth changes
	- Get alignment from Mark and Drew first
- Proposed meeting structure:
	- Howard to meet with Drew and Mark separately
	- Vinod can join evening calls if needed
	- Will record session for Vinod if unavailable
- Current PRD status: 61-62 pages with extensive screenshots
	- Based on Marc’s specifications and Drew’s KPI cards
	- Expected to be 90% complete pending final review