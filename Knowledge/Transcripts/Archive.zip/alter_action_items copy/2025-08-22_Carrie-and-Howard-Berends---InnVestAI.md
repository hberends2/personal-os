# Action Items: Carrie and Howard Berends - InnVestAI

**Date:** 2025-08-22
**Extracted:** 2026-02-05 14:46:48

---

- Howard to coordinate introductory call between Carrie and Diane
- Timeline: Next week or week after Labor Day depending on Carrie’s availability
- Carrie to review InnVestAI.com website and team LinkedIn profiles before call
- Carrie confirmed interest in part-time weekend work with hourly rate or equity arrangement