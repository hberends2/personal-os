# Action Items: InnVest All Team Working Session

**Date:** 2025-08-19
**Extracted:** 2026-02-05 14:46:48

---

- Diane: Complete operating agreement red-line (2 days)
- Drew: Attorney review of operating agreement
- Mark/Drew/Diane: Website content for Phoenix conference
- Vinod: Daily lead reports, closing date field implementation
- Howard: Finalize account/user setup PRD, formula reviews pending
- All: Formula review completion, MGX subscription decision Thursday
- Team meeting: Thursday 5:30