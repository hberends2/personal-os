# Action Items: InnVestAI website and pro forma page development review

**Date:** 2025-06-23
**Extracted:** 2026-02-05 14:46:48

---

- Howard to:
	- Record demo video for team review
	- Focus afternoon meeting on business matters rather than technical demos
	- Investigate percentage calculation fix
- Team member to:
	- Review embedded application issue
	- Record Teams video demonstration of current functionality
	- Share website link with team

Chat with meeting transcript: https://notes.granola.ai/d/b14ab4b8-cc66-457b-9634-3313e54a1b8e