# Action Items - 2025-11-11 InnVestAI All Team Meeting

and Accountability for the Week Ahead

- Drew: Consult attorney about tax implications and introduce potential fractional CFO Mike Sca in December
- Drew: Get LLC agreement finalized to enable bank account opening within days of completion
- Howard: Send email to team proposing interim solution - sign current LLC, open bank account, provide loan to Diane until W2 payroll established
- Howard: Continue product development testing on staging environment for projection calculations
- Team: Reach consensus on compensation structure requiring 4 out of 5 member approval
- Vinod: Push UI changes and other completed components to staging environment this week
- All: Address outstanding LLC agreement items including manager vs member designations and vesting schedules
