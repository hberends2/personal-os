# Action Items - 2025-11-25 LLC separation strategy with Diane and Mark conflict resolution

- Tonight’s call with team announcement
- Schedule meeting with CBRE Benchmarker team (VP Paul + data team)
- Execute new LLC with remaining three partners after Mark separation
- Review updated valuation page UX changes before sharing with others
