# Action Items - 2026-01-15 Book a Meeting with Jean (Howard Berends)

- Jean will connect Howard with co-founder next week
- Howard to validate concept with former colleagues
	- Reach out to John Tomlinson (former CFO at Bell Partners)
	- Test 4-pillar solution: daily cash position, forecasting, liquidity risk, working capital optimization
	- Get 2-3 customer validation conversations
- Timeline: MVP in 1-2 months, seed round by month 4
