# Action Items: InnVestAI AI strategy and workflow optimization with Diane

**Date:** 2025-07-24
**Extracted:** 2026-02-05 14:46:48

---

- Bank account setup under review, expecting completion by end of week
- Drew to provide sample monthly asset management reports
- Howard to look for uploaded OMs on team site
- Mark to reach out to Bridge senior team during NYC visit next week
- Continue Tuesday/Thursday 5:30 PM meeting schedule

Chat with meeting transcript: https://notes.granola.ai/d/1daa863c-cdf5-4976-9af7-3c1c32fed460