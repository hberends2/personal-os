# Action Items: InnVestAI MVP development and investor funding strategy

**Date:** 2025-07-11
**Extracted:** 2026-02-05 14:46:48

---

- Send email outlining POC/MVP distinction and requirements
- Schedule meeting to review Jira board and prioritize features
- Moving Thursday meeting to Friday (team availability better)
- Complete LLC formation (pending personal information)
- Set up corporate payment method for infrastructure costs
- Determine timeline estimates once MVP features are finalized
- Need InnVestAI email addresses including generic accounts (info@, sales@)

Chat with meeting transcript: https://notes.granola.ai/d/d161a737-3591-48c2-abcf-12c2dbd80c7c