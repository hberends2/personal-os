# Action Items: Clint & Howard Connect

**Date:** 2025-08-20
**Extracted:** 2026-02-05 14:46:48

---

- Schedule detailed show-and-tell in one month
	- Howard’s MVP expected second or third week September (originally hoped week after Labor Day)
	- Clint interested in seeing hotel underwriting tool prototype
	- Potential vendor opportunity since PBA does hotel appraisals
- Explore collaboration opportunities:
	- OM extraction tools (Howard has contact with screenshot-based financial extraction)
	- Complementary rather than competitive projects
	- Howard’s goal: Push-button full investment package generation
- Maintain regular contact for ongoing project updates