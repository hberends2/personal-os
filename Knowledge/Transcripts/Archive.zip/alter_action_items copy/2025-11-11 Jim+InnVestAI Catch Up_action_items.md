# Action Items - 2025-11-11 Jim+InnVestAI Catch Up

- Scheduled follow-up meeting for Thursday at 9am to continue discussion
- Jim offered to connect with Kevin Gallagher at Tremont
	- Former Prism president, now running hotel platform at Tremont
	- Has development background and strong business understanding
- Suggested potential connections with:
	- Buckhead America and Dipping Patel for speculative investments
	- Noble Investment Group
- Warned against Highgate Ventures due to predatory investment practices
- Product demo planned for December when MVP is ready
- Jim to provide strategic input on potential customers and industry connections
