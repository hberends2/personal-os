# Action Items: Hotel financial model development and MVP planning

**Date:** 2025-05-21
**Extracted:** 2026-02-05 14:46:48

---

- Complete food & beverage calculations
- Create initial UI mockups in Lovable
- Determine comp data integration approach
- Review Mark’s document requirements and prioritize MVP features
- Schedule follow-up discussions on technical architecture
- Continue developing initial proof of concept for demonstration

Chat with meeting transcript: https://notes.granola.ai/d/e14e835a-cfb1-422e-9ca0-3d4cb7e54717