# Action Items: Labor Day MVP planning for InnVestAI hotel underwriting product

**Date:** 2025-07-18
**Extracted:** 2026-02-05 14:46:48

---

- Vinod: Contact developers, start Monday, find third developer
- Drew: Reach out to Ryan (Lark) on Monday
- Mark: Decide on Dan Lesser outreach coordination
- Howard: Check Office 365 capacity, set up additional licenses
- Vinod: Establish Novo bank account, Remitly setup
- Drew: Set up Azure account with credit card
- Team: Budget finalization and deposit amounts determination
- Schedule: Tuesday/Thursday 5:30 PM meetings starting next week

Chat with meeting transcript: https://notes.granola.ai/d/cec68788-8f2c-43cc-9c8f-17cb7209611c