# Action Items - 2026-01-27 Book a Meeting with Jean (Howard Berends)

- Jean considering offsite with founders and advisors this weekend
- Will update early next week on next steps
- Discussion topics for offsite:
	- Timing decisions
	- Candidate personality/profile fit (including Howard)
