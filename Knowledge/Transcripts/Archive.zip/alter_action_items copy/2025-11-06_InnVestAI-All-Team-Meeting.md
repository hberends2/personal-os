# Action Items: InnVestAI All Team Meeting

**Date:** 2025-11-06
**Extracted:** 2026-02-05 14:54:33

---

- Howard: Complete testing of input sections and EBITDA/NOI calculations in staging environment
- Howard: Continue addressing feedback items provided Tuesday for system improvements
- Mark: Share customer outreach list early next week for December demo scheduling
- Team: Develop demo script and conduct practice runs during week of November 17th
- Team: Decide on demo format (live vs. pre-recorded video) and participant structure for customer presentations
- Diane: Complete LLC document review this weekend or notify team for simultaneous review process
- Consider implementing borrower loan request submission directly through InnVestAI platform to attract new customers and improve lender efficiency