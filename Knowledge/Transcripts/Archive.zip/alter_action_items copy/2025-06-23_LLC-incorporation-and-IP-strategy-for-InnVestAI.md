# Action Items: LLC incorporation and IP strategy for InnVestAI

**Date:** 2025-06-23
**Extracted:** 2026-02-05 14:46:48

---

- Sam to research Delaware LLC formation
- Schedule attorney discussion re: patents/trademarks
- Team to prepare TAM analysis and pricing strategy
- Howard to implement Drew’s market comp changes
- Need to consolidate materials on team site for review
- Team to develop customer acquisition projections and pricing models