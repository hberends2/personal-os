# Action Items: InnVestAI All Team Meeting

**Date:** 2025-09-25
**Extracted:** 2026-02-05 14:46:48

---

- Howard: Forward Carrie’s logo email to Vinod
- Howard: Provide SOC 2 compliance cost/timing research
- Diane: Complete LLC work and website feedback by Saturday
- Diane: Send Bridge Group information to Mark
- Drew: Review budget for 2026 balance
- Carrie: Logo iterations with compressed font, building adjustments by 10pm Pacific tomorrow