# Action Items: InnVest All Team Working Session

**Date:** 2025-07-31
**Extracted:** 2026-02-05 14:46:48

---

- Howard: Complete POC screenshot documentation by weekend (upload to Teams folder)
- Drew & Mark: PowerPoint presentation refinement and dress rehearsal coordination
- Drew: Add Drew’s email to development environment access list
- Vinod: Database structure diagram completion and team review scheduling
- Saturday noon: Development team introduction call
- Saturday post-noon: Dan/Ryan presentation dress rehearsal
- Next week: Jessica Kramer hour-long presentation coordination
- Ongoing: Tuesday/Thursday 5:30 PM regular team meetings
- Operating agreement completion and bank account opening target: next week