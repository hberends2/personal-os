# Action Items: Hotel valuation model development with team review

**Date:** 2025-06-16
**Extracted:** 2026-02-05 14:46:48

---

- Howard to adjust revenue category organization in sidebar
- Howard to modify metrics display format
- Drew to send additional STR report samples
- Team to explore patent/trademark options for unique features
- Need to integrate market and comp set occupancy data