# Action Items: HOLD: rescheduled Admin call

**Date:** 2025-09-08
**Extracted:** 2026-02-05 14:46:48

---

- HB to reach out to Delve regarding SOC2 compliance
- Budget finalization by tomorrow’s call
- Carrie engagement discussion at tomorrow’s team call
- Mark-Carrie coordination meeting Wednesday
- Megan Kochi call Thursday re: Harvey integration
- Phoenix conference preparation with demo materials