# Action Items: Jim+InnVestAI

**Date:** 2025-11-13
**Extracted:** 2026-02-05 14:54:33

---

- Jim’s potential involvement discussed
	- Strategic thinking capability needed on team
	- Could maintain Airbnb role initially, transition later
	- Equity partnership opportunity without upfront investment
- Current team gaps
	- Strong CTO (Indian, offshore engineering team)
	- Product manager (Howard) essential for real estate expertise
	- Data partner (Andrew Wallace) - potential acquisition target for ~$200K
- Funding requirements: $500-750K working capital needed to pull team full-time
- Jim to review Airbnb conflict agreements before deciding