# Action Items: Diane / Cara

**Date:** 2025-07-09
**Extracted:** 2026-02-05 14:46:48

---

- Moving from POC to MVP development
- Cloud deployment planning
- Integration with legal document management
- Development of investment package generation
- Addition of disposition waterfall calculations
- SOC 2 compliance pursuit
- Seeking early adopter feedback and potential pilot users

Chat with meeting transcript: https://notes.granola.ai/d/f3406a75-dcf8-4254-bd08-8833e13d6551