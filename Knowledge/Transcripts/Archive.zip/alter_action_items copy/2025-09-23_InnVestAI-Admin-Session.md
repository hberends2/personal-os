# Action Items: InnVestAI Admin Session

**Date:** 2025-09-23
**Extracted:** 2026-02-05 14:46:48

---

- Research employee vs. founder equity structures and payment options
- Address team time commitment and equity fairness in upcoming discussions
- Finalize LLC documentation with revised equity and decision-making frameworks
- 5:30 PM team call today (Mark unavailable due to holiday, Carrie joining)