# Action Items - 2026-01-21 Meet with Howard

- Howard to share notes from tonight’s call with John Tomlinson (retired Bell Partners CFO)
- Steve to research the three companies Howard mentioned
- Team to validate market needs through additional stakeholder conversations
- Steve meeting tomorrow with Aspen-based commercial RE manager ($1B assets, tokenization focus)
