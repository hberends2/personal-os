# Action Items: Potential Berecadia partnership and industry data strategy

**Date:** 2025-06-27
**Extracted:** 2026-02-05 14:46:48

---

- Tuesday team call scheduled
- Wednesday 11am ET meeting set to review paperwork/tasks
- Need EIN number to proceed with trademark filing
- Incorporation paperwork being finalized
- Team members to be added as LLC members
- Trademark (not copyright) confirmed as correct protection for name

Chat with meeting transcript: https://notes.granola.ai/d/8cb25fb1-8405-4938-8bba-786f209c80e6