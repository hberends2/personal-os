# Action Items: Thursday Team catch-up

**Date:** 2025-09-11
**Extracted:** 2026-02-05 14:46:48

---

- Formula PRD consolidation in progress
	- Howard incorporating all formula references into single document
	- Screenshots being added for developer clarity
	- Completion target: tomorrow with weekend overflow
- Weekly developer coordination calls planned
- LARC PRD development needed
	- Account-level subscription visibility requirements
	- Technical settings for data access control
	- Timeline: Friday or following week (non-urgent)