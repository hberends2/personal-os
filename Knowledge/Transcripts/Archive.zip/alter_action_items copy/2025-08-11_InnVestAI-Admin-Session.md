# Action Items: InnVestAI Admin Session

**Date:** 2025-08-11
**Extracted:** 2026-02-05 14:46:48

---

- Howard coordinating service agreement call with Drew
- Send Teams message to Drew about operating agreement handoff
- Schedule 1:00 PM meeting tomorrow (Howard available until 5:30)
- Keep 5:30 PM AI strategy call
- Complete pitch deck by Friday
- Resolve calendar visibility and Trello access issues