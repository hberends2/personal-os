# Action Items: InnVestAI Admin Session

**Date:** 2025-09-02
**Extracted:** 2026-02-05 14:46:48

---

- Howard: Complete 3-5 year roadmap broken down by persona
- Howard: Send AI roadmap breakdown (4 steps, near-term focus)
- Diane Fox: Finish investor deck by Sunday
- Diane Fox: Review pricing strategy materials
- Diane Fox: Create dilution/share structure scenarios
- Team call at 2:15 PM with Carrie
- LLC document review needed (Drew’s attorney, spousal provisions, competitive clauses)