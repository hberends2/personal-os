# Action Items: InnVestAI marketing strategy with Carrie for Phoenix Hotel conference

**Date:** 2025-09-10
**Extracted:** 2026-02-05 14:46:48

---

- Howard: Send persona document + technical InnVestAI overview
- Mark: Provide conference follow-up email examples if available
- Team: Finalize summary deck by Tuesday for Carrie’s reference
- Carrie: Send recap email with specific requirements list
- Schedule: Weekly Wednesday calls starting after next Tuesday team meeting (Mark traveling Monday-Tuesday)