# Action Items: Jim+InnVestAI Catch Up

**Date:** 2025-11-11
**Extracted:** 2026-02-05 14:54:33

---

- Scheduled follow-up meeting for Thursday at 9am to continue discussion
- Jim offered to connect with Kevin Gallagher at Tremont
	- Former Prism president, now running hotel platform at Tremont
	- Has development background and strong business understanding
- Suggested potential connections with:
	- Buckhead America and Dipping Patel for speculative investments
	- Noble Investment Group
- Warned against Highgate Ventures due to predatory investment practices
- Product demo planned for December when MVP is ready
- Jim to provide strategic input on potential customers and industry connections