# Action Items: InnXchange POC review

**Date:** 2026-02-02
**Extracted:** 2026-02-05 14:54:33

---

- Diane: Finalize pitch deck by tomorrow morning for Sloan meeting
- Diane: Pursue Ben Rafter introduction through Joe Reardon at Hotel Equities
- Howard: Provide 3 POC screenshots for pitch deck inclusion
- Howard: Email terminology changes for hotel industry alignment
- Both: Schedule follow-up with Pranav at Driftoid after Sloan pitch
- Both: Evaluate partnership options over next 4-6 weeks