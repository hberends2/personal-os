# Action Items: InnVestAI All Team Working Call

**Date:** 2025-08-07
**Extracted:** 2026-02-05 14:46:48

---

- Howard: Forward valuation model formulas to correct email (Mark’s Intrinsic Hotel Capital address)
- Mark: Review and confirm valuation model formulas accuracy
- Vinod & Drew: Review account and user setup documentation
- Team: Evaluate Pendo vs Heap analytics platforms together
- Mark: Resolve Azure access permissions for external file sharing