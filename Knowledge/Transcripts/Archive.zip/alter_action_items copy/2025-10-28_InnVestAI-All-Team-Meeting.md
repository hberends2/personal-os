# Action Items: InnVestAI All Team Meeting

**Date:** 2025-10-28
**Extracted:** 2026-02-05 14:54:33

---

- Vinod: Create centralized Excel feedback tracking document
	- Location: Development folder in team site
	- Include video links for specific issues mentioned
	- Add direct page links for precise issue identification
	- Manual sharing with Mark via business email (doesn’t use Teams regularly)
- Howard: Document both fiscal year and pro-rata calculation approaches
	- Include toggle option for user preference between calendar and fiscal year
	- Consider closing date as fiscal year basis option
- Vinod: Implement demo-friendly field requirements
	- Make certain deal detail fields non-required for demo purposes
- Drew: Complete LLC review process with Diane
	- Send notes for her review if weekend meeting doesn’t occur
- Drew: Continue AVM input/output functionality testing
	- Record testing session for development team
- Drew: Send updated budget and pitch deck to all team members
	- Minor updates for fresh team review
- Drew: Complete marketing plan in Excel
	- Transfer to database system once finalized