# Action Items - 2025-12-05 WCG Proprietary DB Conversation

- Mark to be updated on discussion (was at Christmas tree farm)
- Both parties to consider partnership structure and terms
- Continued exploration of mutual data sharing arrangements
- Follow-up discussions on technical integration possibilities
