# Action Items: Hotel capital markets workflow platform poc demo with potential strategic partner

**Date:** 2026-02-03
**Extracted:** 2026-02-05 14:54:33

---

- Request for introduction to Ben Rafter at Hotel Equities
	- Noted time constraints but willing to facilitate introduction
- Potential outreach to Ali Malou at Otelier for strategic partnership
- Consider Michelle Russo despite interpersonal challenges from past working relationship
- Explore Cindy Green at Calibra, though her equity position may be diluted