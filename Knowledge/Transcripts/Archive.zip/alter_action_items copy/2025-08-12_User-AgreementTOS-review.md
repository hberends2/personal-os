# Action Items: User Agreement/TOS review

**Date:** 2025-08-12
**Extracted:** 2026-02-05 14:46:48

---

- Drew: Get AI language template from attorney
- Diane: Review and complete operating agreement choices
- Team call at 5:30 today