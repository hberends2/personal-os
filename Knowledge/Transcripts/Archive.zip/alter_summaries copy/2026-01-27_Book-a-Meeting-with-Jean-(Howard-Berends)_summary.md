# Summary: Book a Meeting with Jean (Howard Berends)

**Date:** 2026-01-27 17:59:05 UTC  
**Meeting ID:** 0aa8a38b-d78a-4f9a-89db-de6f94a7e075  
**Synced:** 2026-01-30 12:57:16

---

JFB considering an offsite with founders and advisors this weekend

Will update early next week on next steps
