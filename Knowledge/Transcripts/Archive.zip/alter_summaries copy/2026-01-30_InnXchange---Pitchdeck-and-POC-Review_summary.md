# Summary: InnXchange - Pitchdeck and POC Review

**Date:** 2026-01-30 13:58:55 UTC  
**Meeting ID:** 37b8a12e-3a1b-4331-a538-f45ad6b245a1  
**Synced:** 2026-01-30 12:57:16

---

*No Granola notes generated for this meeting.*
