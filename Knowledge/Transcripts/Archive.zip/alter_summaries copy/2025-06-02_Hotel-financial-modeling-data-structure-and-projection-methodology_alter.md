# Alter Summary

**Source:** /Users/howardberends/Documents/Alter/granola_sync/input/summaries/2025-06-02_Hotel-financial-modeling-data-structure-and-projection-methodology_summary.md
**Project:** needs_triage

## Summary

The meeting focused on the financial modeling data structure and projection methodology for hotels. Key discussions included the calculation of undistributed expenses and the relationship between operating departments and their respective revenues. The team reviewed the Department Hierarchy and clarified the differences between RevPOR and ADR. An action item was identified to refine the KPI section by removing POR.

## Decisions

- Remove POR from the KPI section.

## Action Items

- Remove POR from KPI section
