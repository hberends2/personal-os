# Alter Summary

**Source:** /Users/howardberends/Documents/Alter/granola_sync/input/summaries/2025-09-10_Drew-and-Howard-Berends-InnVestAI_summary.md
**Project:** innXchange

## Summary

Drew and Howard Berends discussed potential cross-selling opportunities with existing shared clients at InnVestAI. They identified LARC as a key area for collaboration. The meeting focused on strategies to leverage their current client base for increased sales.

## Decisions

- Focus on cross-selling opportunities with LARC clients.

## Action Items

_None captured._
