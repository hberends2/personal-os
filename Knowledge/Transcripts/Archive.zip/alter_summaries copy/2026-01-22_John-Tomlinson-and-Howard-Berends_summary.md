# Summary: John Tomlinson and Howard Berends

**Date:** 2026-01-22 17:59:10 UTC  
**Meeting ID:** 8312be56-e210-4467-8173-4b18e9d19f2a  
**Synced:** 2026-01-30 12:57:16

---

*No Granola notes generated for this meeting.*
