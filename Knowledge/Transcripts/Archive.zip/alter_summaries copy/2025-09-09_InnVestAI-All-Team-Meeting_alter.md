# Alter Summary

**Source:** /Users/howardberends/Documents/Alter/granola_sync/input/summaries/2025-09-09_InnVestAI-All-Team-Meeting_summary.md
**Project:** innXchange

## Summary

The InnVestAI All Team Meeting focused on the USALI framework and its implications for the lodging industry. Team members discussed the importance of understanding the standards set by USALI for better financial reporting and operational efficiency. The meeting emphasized the need for further training and resources to ensure all team members are aligned with these standards.

## Decisions

- Adopt USALI standards for financial reporting.
- Schedule training sessions on USALI for all team members.

## Action Items

- Organize USALI training sessions
- Distribute USALI resources
