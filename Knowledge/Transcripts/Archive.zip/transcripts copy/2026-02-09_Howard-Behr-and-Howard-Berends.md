# Howard Behr and Howard Berends

**Date:** 2026-02-09 00:00:00 UTC
**Meeting ID:** f8a08df1-2144-47be-8da9-30f209d21440
**Synced:** 2026-02-09 15:06:48

---

# Transcript for: Howard Behr and Howard Berends

### You (2026-02-09T19:01:48.020Z)

How are you doing?

### Guest (2026-02-09T19:01:49.458Z)

All right. How are you doing?

### You (2026-02-09T19:01:51.300Z)

Well. Sorry for being late here. A little bit of a startup issue on there.

### Guest (2026-02-09T19:01:58.658Z)

No worries.

### You (2026-02-09T19:02:00.580Z)

Sorry you did.

### Guest (2026-02-09T19:02:02.178Z)

All right? We're still celebrating here from last night.

### You (2026-02-09T19:02:08.740Z)

Wondering if you were still in Seattle. I figured you thought we were.

### Guest (2026-02-09T19:02:12.658Z)

Yeah, just watched. The game with my son, and it was a good game to watch. Took advantage. Yes.

### You (2026-02-09T19:02:29.540Z)

It was a good game. I am no skin. In the game. I have no forever whatsoever.

### Guest (2026-02-09T19:02:32.978Z)

Yeah.

### You (2026-02-09T19:02:36.260Z)

But, yeah, I was really surprised, really, how poorly New England played.

### Guest (2026-02-09T19:02:42.098Z)

I think.

### You (2026-02-09T19:02:43.620Z)

About the super bowl. It always seems to be lopsided.

### Guest (2026-02-09T19:02:49.778Z)

Well, you, I think with enough time to get really strategic. Sorry. Gonna have to deal with that in a minute. Sorry. I just saw. It was. The call was my stepmother, and I think my dad's going down fast.

### You (2026-02-09T19:03:13.780Z)

You already said the website.

### Guest (2026-02-09T19:03:16.018Z)

No. Sorry. It's literally. It's the wonders of AI is now. It's like telling me what she's saying in the voicemail, like, real fai. Th. It must not be that bad, because she's still talking about going away for two weeks. Okay, fine. I don't know. My dad has Alzheimer's, and it's really progressed. He doesn't know anybody anymore. And we had moved him in to a facility like nine months ago. Actually, it's part of my little journey here because it's timed with when I left, the last thing I was doing. That it was. The timing was good. I needed to go deal with it, so. Even though physically, when he moved in, he was relatively fine. You can see that when the mind's gone, it's like it's not taking care of the body anymore.

### You (2026-02-09T19:04:14.420Z)

We went to a similar situation with my wife's mom.

### Guest (2026-02-09T19:04:17.378Z)

Yeah.

### You (2026-02-09T19:04:17.700Z)

It's difficult.

### Guest (2026-02-09T19:04:17.938Z)

Okay?

### You (2026-02-09T19:04:19.300Z)

Yeah, sorry you're going through that right now. It's.

### Guest (2026-02-09T19:04:22.338Z)

Yeah.

### You (2026-02-09T19:04:24.340Z)

For sure.

### Guest (2026-02-09T19:04:29.618Z)

To make it a little more challenging. My brother has kind of checked out on this, so I don't know. What. He's not the most communicative person, but I don't know why. What if there's something I'm missing here? I don't know.

### You (2026-02-09T19:04:34.900Z)

Dog.

### Guest (2026-02-09T19:04:42.258Z)

But he is not. But, yeah, whatever. So. Yes, it is what it is. You earn this much? Well, in my case, it's mostly here, but gray, it means usually. If the Berends made it this long, that's good, then.

### You (2026-02-09T19:05:00.180Z)

That's. That's true. So what you up to?

### Guest (2026-02-09T19:05:01.698Z)

Yeah. So I've kind of been in this strange state where I took some time. My oldest graduated high school in the spring, and so actually, she just started. She had kind of like a gap semester, so she just started at NYU a couple weeks ago. Which is very different. But she had gone there for a program a couple summers ago, and it was a perfect. She just loved the program. She actually is going once to study real estate, real estate development. So it's one of the top programs, and she had wanted to go there from the beginning, and it's a great place to be from a contact perspective. And interestingly enough, we have a lot of friends, my wife and I actually, from grad school who are in real estate in New York. So she is within the number of friends we have. Living within two to three blocks of where she is is amazing.

### You (2026-02-09T19:05:44.420Z)

O. K. Ay.

### Guest (2026-02-09T19:06:00.818Z)

We have friends who basically she's going to run into it. The Trader Joe's or something like that, like the target. She's not going to get away from it all.

### You (2026-02-09T19:06:09.220Z)

So we got some spies. In the neighborhood.

### Guest (2026-02-09T19:06:11.138Z)

We have some spies in there. Yeah. But also, it's, like, great from a contact perspective. Like, that's what she's studying. And she's going to, like, literally. We had one friend who's like, if she can't get any of the big firms, For internship. All higher. It's, like, slight on saying like already. She'll do an internship with me if you can't. She doesn't get any of the big names, so I'm like, okay, great. Got a fallback.

### You (2026-02-09T19:06:35.300Z)

Yes.

### Guest (2026-02-09T19:06:36.978Z)

So I took some time kind of dealing with all that. We did some travel and stuff. So now I'm finally back in the okay, I better go do something with my life again. And I've kind of been in the in between of do I go back to real like, I've been COO the last couple places. And do I go do that? And I don't know. So I've got. One thing. I'm probably starting in another week or two, which is like this odd connection. If a step cousin who lives here who's got. He works, he's been Microsoft, Amazon kind of stuff, he's particularly focused on product marketing management and particularly kind of go to market stuff. And he's cybersecurity. So he's got. With a few other folks, he's got, built a little business that's doing, like, contracts for that for Microsoft and other folks.

### You (2026-02-09T19:07:36.980Z)

Go.

### Guest (2026-02-09T19:07:38.178Z)

And so they need somebody to step in and kind of take over day to day. So I think I'm going to do that, but that'll be like a part time thing for now. Keep. Keep it going. And then I've got an odd thing that I've been talking to for a while. We'll see if it pans out that it's a. We're referring to it as sober Airbnb. It's apartments for people they would refer to as the third phase. Of recovery. Whether drugs, alcohol, something like that.

### You (2026-02-09T19:08:09.460Z)

Ahead.

### Guest (2026-02-09T19:08:10.978Z)

And the idea. But it's. But it's apartments. And so the idea where I would step in is really maybe like a CEO type of role, but like, and help build. They've done it once in la. They've got some other earlier face programs in la. What thinking is, is that this could be really big. If you go think college campuses where you can get some people who have. Kids who've already, you know, well, to do Berends Kids who've made some bad choices. Would, would benefit from having watchful eye and, and folks that are really there helping them stay on the right path. And. And you put that in apartments and you're managing it, and you're getting double rents. For decent, you know, solid, nice apartments. The idea of scaling that and doing, replicating that and doing that in a number of places, and you can very quickly end up with, you know, with some real value. So that's the other thing that I'm kind of. I'm kind of dancing around right now.

### You (2026-02-09T19:09:19.220Z)

That sounds really good. Really cool. That really hits home.

### Guest (2026-02-09T19:09:23.378Z)

Yeah, I mean, like, it's a nice. You can see the positive value. You can see how it could make money. You could see how it could. And. And my thing is what I keep talking to them. Is great. I'm not the guy. I don't know the sober recovery program side of it. Like, as you can imagine, the people who've invested in this, who started this, they're all people who've been successful, who've gone through some sort of phase, some sort of issue. And. But at the apartment side of it, and while I may not have done development, the operational side of how do you operate? How do you take something you've done once and operationalize it and get a, you know, playbook and all that kind of stuff like that classic, you know, classic product management, classic, you know. Ops stuff. So that's. That's the thing I'm probably most excited about right now.

### You (2026-02-09T19:10:10.340Z)

Yeah. Without getting. Too deep into the personal part. Yeah. My daughter. Less than one semester of college. Before.

### Guest (2026-02-09T19:10:18.658Z)

Okay? Yeah.

### You (2026-02-09T19:10:19.940Z)

Being asked to leave. Because.

### Guest (2026-02-09T19:10:22.418Z)

Yeah, okay. Okay?

### You (2026-02-09T19:10:23.700Z)

She said other issues afterwards.

### Guest (2026-02-09T19:10:26.498Z)

Yeah.

### You (2026-02-09T19:10:27.300Z)

But, yeah, she was in that recovery right now. She's doing well. She's been sober for six months.

### Guest (2026-02-09T19:10:35.298Z)

Okay?

### You (2026-02-09T19:10:35.700Z)

Probably about that. But yeah.

### Guest (2026-02-09T19:10:38.418Z)

But it's. But it's. It's a fight that.

### You (2026-02-09T19:10:41.780Z)

Good news.

### Guest (2026-02-09T19:10:43.538Z)

Yeah, so. So I. Yeah, so. So I'm going to see if that pans out, too. I mean, like, those are the things. So I'm kind of playing around with what I realized is, What I realized a while ago. Like I had. I don't know. I can't remember the last time we talked, but it's been a while.

### You (2026-02-09T19:11:01.060Z)

Two.

### Guest (2026-02-09T19:11:01.298Z)

I had. Before the last thing I did. So the last thing I did is I spent a couple years working with a buddy of mine from grad school that he has a company that. It's Executive Admin Assistance. And have operations in the Philippines, Guatemala and Kenya. So I thought, like, did that for a couple years. It went well until it didn't, which I think part of it is my friend, who I knew from. He's. He's a bit manic as an entrepreneur, and after a while, it just triggered me and it just. And it, like, the timing of when we ended was good for both sides. He needed somebody. Local, but I just couldn't. I. I reached the point, he needs somebody in Portland, which is where I was going. Down there frequently, but I wasn't there all the time. And just for his personality, he needed it. In spite of the fact that it was mostly running a business with people around the world, he really needed his as many direct people right there with him. But. But at the time that I joined there, I had an option to go take over the utility business at Vigo. And I realized at some point, going through it, and I had been doing a Consulting gig for them. And I realized at some point I was like, I don't want to do this again. I've done it. Like I don't. And I think it's something about my personality that I've realized is I don't like doing the same thing again. And. And so. And that's not a bad. It's just. It's just like it's recognizing who you are. And so I kind of like the things that are the easiest, most logical. Is great. I could get into the utility market management world. I spent 15, 16 years doing that. And I could go do it again, but, God, I don't want it. Like, it's just. Like. It's just not what I'm like. I already did it once. I don't want to go do it, and I did it for a long time. So I think that's part of maybe probably hurts me, but it's also. It is what it is, so, yeah.

### You (2026-02-09T19:13:02.900Z)

More books. There are quite a few acts. Wp. And real page people that let this in. Prada. We've got a few bite of the swell there as well.

### Guest (2026-02-09T19:13:14.818Z)

And they did. And then some of them have now gone. There's some other thing, the thing that used to be. Called multifamily utility. There's some new name for it. There's. There's some new name for something. They change names for it. It's something in San Diego, Southern California, and a number of folks are there, like Mark Chintilli, who I. We exchange stuff on a regular basis, in fact. Last night he was texting me about when Rams pay. The Seahawks were always nagging each other.

### You (2026-02-09T19:13:36.980Z)

Yes. Yes.

### Guest (2026-02-09T19:13:47.138Z)

And then once one wins the Super Bowl, There's a polite congratulations. To the other.

### You (2026-02-09T19:13:54.100Z)

Y. Eah.

### Guest (2026-02-09T19:13:56.978Z)

But he. I know he went there in. A couple other people are there as well.

### You (2026-02-09T19:13:59.700Z)

Y. Eah.

### Guest (2026-02-09T19:14:01.938Z)

Yeah. So I don't know. Maybe that's my. So. So I've kind of been pondering, like, do I go back? I mean, I spent. I didn't leave. I only really spent a couple years outside of multifamily, but because the years before that, I was doing things that were very. On the outside like it was the. The. The cleaning and other services for apartments. I was very much outside of the. Wasn't going to the NAA or anything like that anymore. Like, I. It feels like it's been many years, even though it hasn't been that much.

### You (2026-02-09T19:14:35.940Z)

Y. Eah.

### Guest (2026-02-09T19:14:39.698Z)

I don't know. So, yeah, I don't know. That's my. That's my quick story. What's up with you?

### You (2026-02-09T19:14:45.940Z)

Really. This one was story here. All. Right. Kind of doing my own thing for the last year. After the real page. I want to consider this. And kind of like the same way, you know, I got there and, you know, it was a step back, but it was 10 pandemic. So, you know, just the fact that a product integrator.

### Guest (2026-02-09T19:15:10.178Z)

Y. Ep.

### You (2026-02-09T19:15:13.940Z)

Pretty serious fucking day. But even at the same time. It was like, what kind of a. Brag.

### Guest (2026-02-09T19:15:21.298Z)

Okay?

### You (2026-02-09T19:15:22.420Z)

And luckily I got post guy. With. They are multifamily underwriting. Automated valuation hours. Took me back really close to my bark, and I position all that stuff. It was a big fit to kind of get back into what I done.

### Guest (2026-02-09T19:15:43.378Z)

I remember. Yeah, I remember. You dealt. Yeah, yeah.

### You (2026-02-09T19:15:51.380Z)

Basically, when I got into the industry, I did really, really well. It was a great company. People I worked towards. But we had some problems in the realm by the largest broken. Layer. And they owned. They knock. Ed, but at the same time, they kept all their external clients. But the problem we had is that. It was a very limited short lifecycle product. It is only for the application phase. When I got in and I realized that the processes and all the data that they had. You could move throughout the entire lifecycle. So immediately we started putting together. Adding. On a bunch of visual features and different things so that the users could continue to use it. All the time after life. Well. But the problem that we had in getting third party data. Bringing some market comps. Everything. And we could not get any boot in because almost every contract that Berkadia had. Extended, while IQB is could be considered a reseller. So Berkeley is dating on the data from brokers. We couldn't get a hand from it. Back in August of 2024. We have been talking to Radix. See if we could work something out with them, because Katie doesn't need anything. Done. They have a lot of. Data. We can use? Not at all whether it would be never. And so we also have a relationship with the almost of Berkadia, right? So they struck a video. They bought that iq. We saw that for Shackles in the Unleashed, and we could do everything we wanted to do. But unfortunately, Radix is also often reliable transaction lawsuit.

### Guest (2026-02-09T19:18:12.818Z)

Okay? Yep. So they were. They had to be very risk averse, probably at that moment.

### You (2026-02-09T19:18:21.380Z)

I think we overreacted. However. They did what they would. So basically, they have to do a complete pivot on their core project. Product. When they brought Red IQ over with their hands, all of us that went from Berkeley.

### Guest (2026-02-09T19:18:42.018Z)

Got it? Yeah.

### You (2026-02-09T19:18:44.500Z)

They took all the engineers from what I knew. And people would to their core product as well as prior team. So eventually. They basically let everyone go from one. IQ except for one vineyard. N word to keep the lights on. Every guy who had.

### Guest (2026-02-09T19:19:07.378Z)

Why did they not? Did they not pay much? Or did they not? Or did they.

### You (2026-02-09T19:19:12.260Z)

Basically a hobby agreement with the Kvokadi would continue to use the product. And we also had a minority share.

### Guest (2026-02-09T19:19:20.098Z)

Oh, okay.

### You (2026-02-09T19:19:23.380Z)

So it didn't outright sell 100%, but there, it's kind of a little bit of collaboration.

### Guest (2026-02-09T19:19:27.058Z)

Got it.

### You (2026-02-09T19:19:29.380Z)

But the founder of Radix from Kosovo. And we have a huge engineering team. They still.

### Guest (2026-02-09T19:19:38.658Z)

Yeah.

### You (2026-02-09T19:19:40.340Z)

Have domestic, so I am domestic engineers. Got pivotal for a short term when they go to machine.

### Guest (2026-02-09T19:19:48.178Z)

Right.

### You (2026-02-09T19:19:48.500Z)

Everything. January. Of last year. Since then, I. 'm. Consulting job. I did meet a meeting when I was at. Q. And a single office that we came into a hotel. Hospital. Ity and this lady. Was heavily invol. Ved in that and she thought about our kids just to bring the silly and that there's nothing in our hospital. Ity.

### Guest (2026-02-09T19:20:31.458Z)

Right.

### You (2026-02-09T19:20:32.340Z)

Of course. Some women gave me a phone. That went out the door because addicts only multifamily. We kept in touch. When I left, we started talking again. Kind of keeping with a great fan of every asset class out there has some type of a tool. That they need economic. So sure enough. On the radar, he's on the company. There was nothing like it out there. So I started working with her. She had three little founders.

### Guest (2026-02-09T19:21:04.898Z)

Right.

### You (2026-02-09T19:21:14.500Z)

I've been doing a lot of coding. No code. Little fog covered everything, and then.

### Guest (2026-02-09T19:21:20.658Z)

Look at you. Yeah. Okay. Yep.

### You (2026-02-09T19:21:24.500Z)

Post. That's why you're drinking it.

### Guest (2026-02-09T19:21:26.338Z)

Yeah.

### You (2026-02-09T19:21:27.300Z)

I built a group of concept in from code functional. I want to do everything. She and one of the other partners had a huge fallout.

### Guest (2026-02-09T19:21:38.578Z)

Okay?

### You (2026-02-09T19:21:40.980Z)

We never got to market. I still got to keep it in dump till making a few tweaks. I don't know if that's going to go anywhere, which is a shame. Because I participated in a lot of client call. A reason I had a ton of people from the industry. Everyone really positive thing say about it.

### Guest (2026-02-09T19:22:06.898Z)

Right. Right.

### You (2026-02-09T19:22:10.260Z)

So hopefully she can work throughout and then kind of right down the top level, small projects. I kind of decide myself that I'm working.

### Guest (2026-02-09T19:22:22.818Z)

Well, that's what so, I mean. That's. Yeah. I don't know. I mean, I don't know where you're at. I mean, this is part of my thing. Has been. I've been telling people, do I have to work? Be nice if I did for a number of years. I still got. I think I still gotta, you know, 13 year old at home, so it would be. It would be good to get a few more years, but do I have to?

### You (2026-02-09T19:22:38.420Z)

Yeah.

### Guest (2026-02-09T19:22:44.498Z)

And so. It would. And also my wife also. She, she, she, she just recently left after 15 years at, at Pokemon. And but she, but they've had, she had 13 plus years of a great boss and then she had, they brought in, they brought in somebody who, I swear, I think it sounds like 1970s Japanese boss. Who. Who's only, like, you know, 45 or something, but he wouldn't even look at her in meetings. Would. Would address things to the guy who reported to her who happened to speak Japanese. More than he would then he would address. It was just like, she just realized, like, this is like, and. And this guy's gotten rid of most people that were rude like, that he inherited. So it seems like he was brought into.

### You (2026-02-09T19:23:39.140Z)

It's unfortun. Ate.

### Guest (2026-02-09T19:23:42.338Z)

Mean, it's fine from the perspective of there was a nice package. And, you know, like, when you get that, it's like, okay, great, got a little Runway. And she'll find. She's spent so many years in the industry, she'll find something, keep us busy, you know, Keep it busy. I like this idea of doing a little bit of some. I'll call it. Fractional stuff.

### You (2026-02-09T19:23:53.620Z)

Yeah. Y. Eah.

### Guest (2026-02-09T19:24:00.738Z)

And I don't know that I want to give full time anywhere.

### You (2026-02-09T19:24:06.580Z)

I'm here from the interludes. And the thing is. Ageism is a rabbit.

### Guest (2026-02-09T19:24:17.938Z)

Oh, of course, yes. Yeah.

### You (2026-02-09T19:24:19.380Z)

And I had some interviews that were the first couple rounds were sold and they want to incorporate. They were like, it's perfect. Got the perfect background with ribbon for Then I had a video conference and the guy at my age.

### Guest (2026-02-09T19:24:30.178Z)

Yeah.

### You (2026-02-09T19:24:40.260Z)

Next day I get an email thinking, We're going to pursue our candidates. I don't seem like.

### Guest (2026-02-09T19:24:47.298Z)

It's interesting. It's interesting because I've. When I think back over career and the interviews I've done, I've hired a bunch of people who were like, I don't feel like I did poorly in this. In hiring people who were sometimes. Older, but not like, okay, great, you get it. If you're going to hire somebody who's older, who's like sea level or vp, you know, whatever. VP level. But you might not do it for middle. And so I've done it sometimes and found good. But I get it. But it's. But. It's definitely real. And you can see it and you can feel it. The number of people I know who are our age.

### You (2026-02-09T19:25:14.020Z)

Yeah. Y. Eah.

### Guest (2026-02-09T19:25:30.258Z)

I have so many friends from grad school who, if they didn't found a company, they're like, yep. I got like, O here or there, and it was definitely, you know, you could see it was just like everybody above a certain age kind of gone. Or I experienced, you know, the middle. And then. And around here, there's a lot of the slicing of just all of the tech is getting. I mean, they're just. Yeah.

### You (2026-02-09T19:25:43.700Z)

Yeah. Y.

### Guest (2026-02-09T19:25:52.738Z)

Slimming down.

### You (2026-02-09T19:25:52.900Z)

Eah. October. November. It's been a while. Since I. 've been collectors. Who wanted to expand into our multivariate valuation. In other words, What I did.

### Guest (2026-02-09T19:26:18.658Z)

Yeah.

### You (2026-02-09T19:26:19.940Z)

And it's like all the prior what I do with market leader. For me. They had just gotten frogged in. AI came in. We weren't able to compete with some of those companies. But, like, okay. Wait a minute. I've been in. The clarify. Side. I've done acquis. Itions. Item. Underwriting. I took one IQ from a still logic bender done that. And then to get that email, like a pursuing, like who? The buddy out there made me look like I'm 21 anymore.

### Guest (2026-02-09T19:26:58.018Z)

Y. Eah. I wonder. There's one thing where my wife. I think that it's quite possible that it was just she was too late in the process, but she found out about something and an opportunity and got interviewed. But it seemed that they already had a candidate already chosen by the time they interviewed her.

### You (2026-02-09T19:27:24.340Z)

That happens.

### Guest (2026-02-09T19:27:26.418Z)

And they still interviewed her. They talked to her. That candidate was somebody like, we'll call it, two levels below her. At Pokemon that she knew. She was like, she's okay, but nothing great and doesn't have this experience or that experience and this experience. But. So it's a matter of there's a certain amount of, are they looking for somebody more junior who they can mold, or do they want somebody who brings in comes in with the experience because they need help on that. And that's the question I think everybody, every company's got to face, and how much the pain and all that kind of stuff.

### You (2026-02-09T19:27:50.020Z)

Yeah. Yeah. Yeah. Y. Eah. They don't hr for a very. Long time. Interview someone before. By center. Theirs in jeopardy if I bring in somebody who's highly qualified. Have I been doing that for hiring managers? Bunch of stuff. Issue what I.

### Guest (2026-02-09T19:28:24.258Z)

Yeah.

### You (2026-02-09T19:28:32.420Z)

You know, and it's the same kind of like I. These. These are like. Being. In the middle of configure. I don't know if I want to be somebody who is just fishing paper.

### Guest (2026-02-09T19:28:45.698Z)

Okay? Right.

### You (2026-02-09T19:28:49.700Z)

And then back to. Back meetings.

### Guest (2026-02-09T19:28:57.778Z)

Yeah.

### You (2026-02-09T19:28:58.100Z)

Probably why, you know, I'm not. Really pushing too hard because now I know I'm totally familiar. Here. That's a certain. Back a bit.

### Guest (2026-02-09T19:29:09.938Z)

Yeah.

### You (2026-02-09T19:29:10.180Z)

Meeting rather. Than just a few looks really good.

### Guest (2026-02-09T19:29:17.138Z)

Yeah. You got to figure out what you like. Yeah, yeah. Well, it's. There's a point in life when you step back, so I was. At. My wife and I, we had met in the same. It was a dual degree program that we went to. And they had. For the one degree, not the business side, we had a. They have a reunion every three years. And so we were in New York in October, and there were some kids in the program, kids like you. Know, current students in the program, so in their, whatever, mid-20s, and they started asking stuff, and I realized. You know, about, you know, like, all this stuff, and they're all excited about. And I'm like, you know, when you reach a certain phase in career, You're kind of like, I've done a lot of cool things. If I get something really cool that I like, I'll do it. But if it's not, I'm not just doing it just to do it. I'm not trying to. I'm no longer trying to on the 10 year path to build something, to get to some great job. If it's not a good job, now I ain't doing it.

### You (2026-02-09T19:30:17.700Z)

Yes. Yes.

### Guest (2026-02-09T19:30:18.178Z)

And it's not going to get me excited, so why would I, you know, like it? So it's kind of funny.

### You (2026-02-09T19:30:22.420Z)

Y. Eah.

### Guest (2026-02-09T19:30:23.298Z)

I don't know.

### You (2026-02-09T19:30:29.540Z)

Yeah. As you know, the model thing is, especially ever since my kids were born, But I officially diagnosed adhd, you know, because both of my biological kids have it. My wife has it on her family. And then I was weigh that answered a lot of.

### Guest (2026-02-09T19:30:46.578Z)

Okay?

### You (2026-02-09T19:30:51.220Z)

Why did I hate. Oh, my God. Especially when I was in office? Because. I have to stimulate it all the time. And tech. Was that right? Buying an apartment community. And we have. And before we have to picture the really cool 18 months in team.

### Guest (2026-02-09T19:31:16.018Z)

It's great. That's a wonderful intellectual. Like you can see intellectually. You can go, this is really cool. I can understand what you're saying, but it's the day to day that probably is just like, it's slow, methodical. Let me. How do I get from. How do I get from? A to B is a lot of slow project management.

### You (2026-02-09T19:31:26.340Z)

Yeah. Y. Eah. Yeah, that's kind of repeatable. If you're not in there everywhere doing other things and you're running, working, and all these things delegated to other people.

### Guest (2026-02-09T19:31:50.258Z)

Right.

### You (2026-02-09T19:31:52.980Z)

I don't know if the money is worth it. Because I remember. Backing away. I was in a very good chimney. Film. Emotional. Ly because I hated my job. Could not get out of bed. In the morning. It's like I don't want to take the chance on me or anything from my father.

### Guest (2026-02-09T19:32:05.778Z)

Right.

### You (2026-02-09T19:32:10.340Z)

I probably will just keep working. It where I'm working. I can't go to without. I can't retire. My wife will still find, but she feels like she's under a lot of precious thing I got to keep something coming in.

### Guest (2026-02-09T19:32:23.378Z)

Yeah. Yep. Yeah. So. Anything? I don't know. You guys, horses. Are you still big with that?

### You (2026-02-09T19:32:38.100Z)

No. Actually after the real day. Exactly. But I don't know. She. She got a. She got.

### Guest (2026-02-09T19:32:46.338Z)

Yeah.

### You (2026-02-09T19:32:49.780Z)

A private college.

### Guest (2026-02-09T19:32:50.658Z)

I remember. Okay. That's right. Yes.

### You (2026-02-09T19:32:55.540Z)

It was in person.

### Guest (2026-02-09T19:32:57.378Z)

Yeah.

### You (2026-02-09T19:32:57.380Z)

She's doing a lot of education. Probably up. But don't move to here. Women in some place.

### Guest (2026-02-09T19:33:02.098Z)

Okay? Okay?

### You (2026-02-09T19:33:06.900Z)

Here, you know, and she's there. Not full. Professor. Ten years, Joshua. Tenure.

### Guest (2026-02-09T19:33:14.178Z)

Nice.

### You (2026-02-09T19:33:14.820Z)

Last year. About the chair. She's in shape.

### Guest (2026-02-09T19:33:22.098Z)

Okay?

### You (2026-02-09T19:33:22.820Z)

To a. World very well. So, you know, that's definitely everything she. Rel. Ocation and everything else. So many companies. Are going back to the author.

### Guest (2026-02-09T19:33:37.698Z)

Yeah. If I found something in Seattle, it would be interesting just because I've never worked. It's been the last time that I worked in a location that I went to the office. 2009. I think, yeah. As the year I lived in Austin. Yeah. So it's been. Like. So I've lived the entire time I've lived in Seattle. I haven't actually worked at a place in Seattle area. So if I got that, it might be worth it, but otherwise. No. But. But to be honest, most of the places around here are not of interest. It's a lot more techie, and I like the business problem side of things.

### You (2026-02-09T19:34:18.420Z)

Yeah. Y. Eah. It's not. Entirely outgoing the office. There are no problems with your jobs and Grand Rapids machine.

### Guest (2026-02-09T19:34:33.778Z)

Right. Well, that's. Yeah, that's. Unless there's that one company that shows up or something. But, yeah, somebody. I tried reaching out to somebody about. There's one company here that I don't know what the hell they're doing. CRM? Something related? PropTech. It's just a lot of more technical companies here. I want to go learn about. I mean, it turns out when I did the EAI post, it turned out literally. Our brand new next door neighbor wrote me this weekend and said, hey, you want to do coffee or something? I work in, you know, agentic AI and like, okay, cool, fine. I'll pick your brain and let's go chat. But, like, if you want to, you know the true tech. Yeah, great. There's lots of that.

### You (2026-02-09T19:35:14.820Z)

Learn.

### Guest (2026-02-09T19:35:17.458Z)

But. So I don't know. I'm trying to think if there's anything else. My other thing is I found a hobby that I. I don't know if you remember. I was always like. Like runner. I was always, like. Probably every type of trip we went on, we were running, so I picked up with. My kids because they both played like oldest play soccer. My youngest. When my oldest was turned 13, she became a ref and I decided to go do it with her.

### You (2026-02-09T19:35:40.980Z)

Go.

### Guest (2026-02-09T19:35:41.218Z)

And so now I've gotten serious. About it. And I'm now working Howard what's called a regional certification. Which basically means I can do lower level pro games.

### You (2026-02-09T19:35:53.780Z)

Ahead.

### Guest (2026-02-09T19:35:56.178Z)

Up to that level and the highest. And I'm already doing some of the highest level youth games, but it'll make it easier to get those. So it's kind of. That's kind of my little. Like, that's the other thing that. And at least it's a hobby that pays something. It's not that it makes that much, but, I mean, it's enough.

### You (2026-02-09T19:36:05.860Z)

Cool.

### Guest (2026-02-09T19:36:15.378Z)

If I were more serious and I was willing to show up and just like, I. I'm more like, hey, I'll do two. Two games that, you know, on Saturday at a tournament. If I was willing to do eight games on a day, then you'd be making real money over a weekend, but.

### You (2026-02-09T19:36:31.940Z)

Or father.

### Guest (2026-02-09T19:36:35.698Z)

It's for right now, it's here. I think with when I get this regional ref, I'll be able to do more broader. I'll get invited to stuff.

### You (2026-02-09T19:36:41.060Z)

Go.

### Guest (2026-02-09T19:36:44.738Z)

And if I get. And I think with that I'd be eligible once I get some a little bit games and I know those pay real money. Like. Like 500 to 1000 bucks for a game. Which isn't bad for, you know, an hour and a half of getting to run around. And they pay for travel or stuff like that, so it might like. It might. We'll see. I. I gotta. I gotta maintain myself in good enough shape. But that's. That's actually the easier part than just learning, doing all that.

### You (2026-02-09T19:37:17.540Z)

D.

### Guest (2026-02-09T19:37:22.978Z)

Yeah, well, that's. And that's the part I don't really struggle with. But it's kind of funny because I get to deal with. I joke I have to do. So part of doing this is I have to do 40 adult games in the year in which I'm trying to qualify, and. I'm Will. I'm on my way to do to getting there on that. But it's funny, I keep joking that.

### You (2026-02-09T19:37:35.860Z)

Y. Es.

### Guest (2026-02-09T19:37:45.938Z)

I need to get. I've done some that are, like, right near me, that are lower level, but I need to get a good solid mix of higher level games. So there's some that are a little farther south of where I am that it's. I always joke it's the Russians and the Ukrainians. And I say that because I know a couple of the teams that either are Russian or Ukrainian, and they're always yelling at each other, and then they. And then they yell at me. And then I laugh at that. And then I. But my thing is, I found is, what works really well is I laugh at them.

### You (2026-02-09T19:38:14.980Z)

Y. Eah.

### Guest (2026-02-09T19:38:16.338Z)

And I just. No, we're not doing, you know, like, on a regular basis. Like, the last match I did. And I know, like, I'm getting to know these guys, so they're not like. Like, they're literally like, hey, how you doing? What's going on? How's life? They're really friendly about it. But then when the game happens, they're like, the one guy, he's like, you took my goal away. You know, it's like, offside. I got an offside. When he got a goal, and he's like, no, where's most? And of course, they're always telling me. No, it wasn't. It doesn't matter what it is.

### You (2026-02-09T19:38:40.820Z)

Y. Es.

### Guest (2026-02-09T19:38:41.538Z)

But it's. But it's funny. So it's my. This is my little, like, I don't know. I'll call it. It'll be like trying to find a good retirement activity. That'll keep me busy for a while.

### You (2026-02-09T19:38:50.900Z)

Yeah. Yeah. Cool.

### Guest (2026-02-09T19:38:59.618Z)

Not in a while. I mean, he went back to investment banking. Which has been his kind of back and forth over career. And I did talk to Monique.

### You (2026-02-09T19:39:08.100Z)

Down. Down.

### Guest (2026-02-09T19:39:14.258Z)

Only a couple weeks ago, so we talked about him a little bit. He's back with his cadre there and. And whatever Michigan area.

### You (2026-02-09T19:39:27.380Z)

Yeah.

### Guest (2026-02-09T19:39:27.538Z)

And. Or southeastern Michigan, I should say, I guess.

### You (2026-02-09T19:39:31.940Z)

J. Ackson.

### Guest (2026-02-09T19:39:33.938Z)

And so he. Yeah. So I know he's busy with that. Yeah. So she's got into particularly HR for dealing with acquisitions. Mergers and acquisitions. So it's a specialty. Yeah, it's private. It's a lot of. It's private equity, so it's a lot of it's coming in. And like, I talked to her about some stuff related there. I think if something pops up, she'll like. It's kind of like that could be an opportunity because she. Knows what I've done and worked with me, but she's got. It's an interesting. She's definitely got a niche that she's developed. On the hr side. Yeah, so it's kind of cool. But I think she's still trying to figure out, does she bring. Because she's a little bit stuck inside this org and so trying to figure out, does she need to branch out or not.

### You (2026-02-09T19:40:30.660Z)

Okay? Cool.

### Guest (2026-02-09T19:40:33.378Z)

Yeah. I don't know. Yeah.

### You (2026-02-09T19:40:36.740Z)

I'm feeling guilty thinking around here and get to text your work start to tell her.

### Guest (2026-02-09T19:40:43.298Z)

That's. Yeah. No, I probably know I need to go call my stepmother and go find out the deals, but. Yeah, but. Yeah, but, hey, I don't know if there's anything I can do to help. I don't know if there's much. We're kind of in. That sounds like the same phase, which is know.

### You (2026-02-09T19:40:45.540Z)

Yeah. Yeah. Something might pop up. They'll keep you in mobile touch? More than you have one, that's for sure.

### Guest (2026-02-09T19:41:00.418Z)

Yep. Sounds good. Yeah. Yeah. No, that's a good. Great seeing you. You look the same. And enjoy.

### You (2026-02-09T19:41:16.740Z)

Yeah, me too.

### Guest (2026-02-09T19:41:17.058Z)

Cool. Okay. Talk to you.

### You (2026-02-09T19:41:18.340Z)

All right. Take care.