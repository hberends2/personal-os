# Howard | Vinod weekly call

**Date:** 2025-11-04 00:00:00 UTC
**Meeting ID:** 5c5f04d9-9ca2-4961-8839-54d77b632e18
**Synced:** 2026-02-05 14:54:33

---

# Transcript for: Howard | Vinod weekly call

### Guest (2025-11-04T17:32:31.016Z)

Therefore.

### You (2025-11-04T17:32:31.502Z)

Hey, how's it going? Good. How are you? Good. Yeah. It's definitely. What's that?

### Guest (2025-11-04T17:32:53.736Z)

I hope all is well between Mark and I is not bothering too much.

### You (2025-11-04T17:33:00.782Z)

Yeah, I'm not sure about that.

### Guest (2025-11-04T17:33:05.256Z)

Okay?

### You (2025-11-04T17:33:06.062Z)

Yeah. So apparently lark and drew. Basically set down some rules. About who can join customer calls and who can schedule them and who's going to do what. And they basically have totally excluded Diane. So it's like the two of them. Are the only ones who can join these calls. And if Diane tries to schedule a call or do anything like that, They get upset. And, you know, I was like, you know, like, are you kidding me? You've been working on this for years, and now they're starting to set the rules and who can do what. It's like, that's just not cool. And so, yeah, we had another long discussion about Mark and his role.

### Guest (2025-11-04T17:33:55.336Z)

Yeah, that's true.

### You (2025-11-04T17:34:12.782Z)

And basically we. We both agreed, you know, it's nothing new, but, you know, I kind of reminded her that back in February when she and I first started talking, and she was talking about who's going to be involved, what their roles are.

### Guest (2025-11-04T17:34:29.256Z)

Yeah.

### You (2025-11-04T17:34:29.662Z)

I told her. You know, I've been under the impression since then that Mark is. The. The person who's going to make introductions in open doors and bring in these people. For us to work with, and now he's literally. Expecting to run the sales team. And if we hire, like, a VP of sales, that he would report to Mark. And I told Diane, absolutely not. I'm not. I'm not going to do. I'm not going to do that. If Mark is ready to take a leave of absence from his current job for 24 months,

### Guest (2025-11-04T17:34:59.416Z)

Okay? Yeah.

### You (2025-11-04T17:35:09.982Z)

And be a full time InnVestAI. I might be okay with that. But. Yeah, I'm not. I'm not good with two part time. Employees trying to control the sales, the partnerships and everything like that. So we're going to have to have another. Another, you know, deep, difficult discussion.

### Guest (2025-11-04T17:35:37.176Z)

And probably that's why they are sitting on that LLC for so long.

### You (2025-11-04T17:35:41.262Z)

Well, actually, Diane is the one that's got it. And she, you know, she even made a comment at the beginning of the call that she's so busy this week, she can't get to it until the weekend. And I'm like, diane, man, we got to get that done. Now. You know, we're just languishing here. So we were talking about equity and the fact that we probably will need to. Create a second employee equity pool. For first hires and department lease. So, for example, a VP of sales V, you know, customer service, you know, whoever we hire. Where they would get a larger percentage. So I, in the research that I've, I've found so far is typically your early employees would get. Like 0.5 or 0.75% of or even I've seen as low as, you know, 0.3 to 0.5. And that would be something like we could offer to Raj and Shiva and whoever else, you know, they would be at that level, but then the senior level would be anywhere. So, like 3 to 5% or maybe a little bit more. And so I, I, you know, I told her, I think from an administrative standpoint, I think it would be easier for us if we had two separate employee pools to, to do that. So we're going to, we're going to talk about that because, you know, when she mentioned that Mark wants to be. In charge of sales, so I'm like, hell, no. We need a full time salesperson. Tomorrow, right?

### Guest (2025-11-04T17:37:39.016Z)

Right.

### You (2025-11-04T17:37:39.182Z)

And the only way we can do that now is if, you know, we have to have a pretty substantial percentage of equity that we can give. In lieu of a salary. So this position would have to be 100% commission plus equity. At least to start, you know, and then when we bring in revenue, then, you know, we could create a base salary and whatever, but, you know. Even to the point where I. You know, one of the things I mentioned is that. You know, if Mark and Drew don't want her reaching out to. Clients or anybody without one of them being on the call. You know, I told her that right now we've got a model. That you can ingest financial statements, extract the data. And come up with evaluation. But our model won't work for lenders. It won't work for investors. It's like in between, it's got bits and pieces of each. And so if we're going to go for the lenders first, and this is mostly like those KPI cards at the top of the page and things like that, we need to know exactly what a lender needs. For the output. And I need to have those conversations right away, so she's going to go ahead and start setting them up.

### Guest (2025-11-04T17:39:08.056Z)

Yep.

### You (2025-11-04T17:39:09.182Z)

And if Martha drew pushback, you know, I'm going to tell her. I'm going to tell them it's for me. It's not to raise funds. It's not to invest. I need to get feedback now, because no matter what you guys do, we're not ready to sell to a lender. It won't work for them.

### Guest (2025-11-04T17:39:21.736Z)

Y. Ep. Yep. Yep, yep.

### You (2025-11-04T17:39:29.022Z)

So. Yeah. So that's kind of what we were talking about the whole time, and it just kept dragging on and on.

### Guest (2025-11-04T17:39:31.016Z)

That makes sense. Yeah. So the other thing is that I feel like Mark and Drew feel that since they've been putting in whatever money, I don't think it's big. It's probably less. Less than 2000 per month. Less than. Probably less than 2500 per month. They just feel like, you know, they are. Investing. And I didn't want them to get that feeling. And if you remember, in the beginning, I said we should create a pool of money wherein, you know, we could all put in, say, 2,000 each or thousand each. And then they don't. They don't get that feeling of investor. Right. They feel like oh, they are invest. It's just nothing.

### You (2025-11-04T17:39:52.222Z)

Yeah. Y. Eah. Y. Eah. Y. Eah.

### Guest (2025-11-04T17:40:19.496Z)

We could probably, you know, if they feel that way, we could give their money back or, you know, give our portion to them or whatever they have spent so far.

### You (2025-11-04T17:40:30.622Z)

Y. Eah.

### Guest (2025-11-04T17:40:31.096Z)

So that, you know, they shouldn't feel like, oh, they are investing.

### You (2025-11-04T17:40:34.062Z)

Y. Eah.

### Guest (2025-11-04T17:40:35.256Z)

It's no investment at all.

### You (2025-11-04T17:40:36.462Z)

Y. Eah. Yeah. Another thing we talked about is just the demos themselves. Drew has been spending a lot of time in the model. And I think I'd be okay with him. Doing a demo. But I told Diane absolutely we cannot let Mark do a demo by himself.

### Guest (2025-11-04T17:41:00.376Z)

You, Mark, and you do that for sure.

### You (2025-11-04T17:41:01.502Z)

No, he might know. Say, you know. You know, drag and drop a document here and push this button, but he knows nothing about software. Or SaaS. And I explained to Diane, it's like if he says something in a demo, That implies we're committed to doing something for a client, and we can't do it. Or whatever. I mean, it's gonna be. Really negative repercussions. And so, I mean, we need to push back on that. It's like if they insist on being in Diane's calls,

### Guest (2025-11-04T17:41:31.736Z)

That's all.

### You (2025-11-04T17:41:40.862Z)

We need to insist that we're in theirs. I mean, they're basically kind of almost like separating themselves out.

### Guest (2025-11-04T17:41:50.776Z)

Right.

### You (2025-11-04T17:41:51.502Z)

So. I don't know. I don't know.

### Guest (2025-11-04T17:41:54.856Z)

I don't know what they are after. And how to deal with them. Now, I think that's a big mistake from our part. It started from Diane's that we included them initially, right?

### You (2025-11-04T17:42:05.822Z)

Yeah. Yeah.

### Guest (2025-11-04T17:42:07.736Z)

Shouldn't have done that.

### You (2025-11-04T17:42:08.702Z)

Well, Diane made a good point, and I agree. Drew brings a lot of value with his connections and the partnerships that we get with like larc and I forgot the name of the other one, but. And drew, I really think. Is almost like the rope in a tug of war. Right. He's kind of drawn, you know, between Mark and the rest of us. I don't think he's really. Trying to be difficult. But I do think that. Lark is going through. Drew, I think Mark is probably the one who. 's starting the conversations, coming up with these rules.

### Guest (2025-11-04T17:42:48.456Z)

Yeah.

### You (2025-11-04T17:42:53.262Z)

And the other thing that I've noticed from Drew is he seems to think that his experience. Is typical. Because Diane made a comment about. How. They thought that she was soft and that when she gets upset at certain comments. Drew's conversation, that's how my investors talk to me. That's just how it's done. Maybe you ended up with a couple of assholes for investors, and that's not typical. And so they've been kind of hard on her for that as well. And it's like, yeah, it's ridiculous.

### Guest (2025-11-04T17:43:37.576Z)

Yeah.

### You (2025-11-04T17:43:39.422Z)

I told her, it's like, look, you've been working in this for five years. And if it's going to be an issue, then we need to stop right now. And figure out what we're going to do.

### Guest (2025-11-04T17:43:52.296Z)

That's true.

### You (2025-11-04T17:43:53.502Z)

And for the first time, she actually was the one who said, you know, there's plenty of people that could replace Mark. I'm like, yeah. Finally sunk in that, you know, he's not the only person in this industry.

### Guest (2025-11-04T17:44:03.896Z)

Yeah, yeah.

### You (2025-11-04T17:44:08.942Z)

That knows people.

### Guest (2025-11-04T17:44:11.976Z)

Yeah. If you remember, I think I was saying same thing in our previous call.

### You (2025-11-04T17:44:14.782Z)

Yes. Yeah, she even. She even mentioned that. Yeah, she had been odds said the same thing. Mark is not, you know, he's. He's replaceable.

### Guest (2025-11-04T17:44:16.936Z)

Or other call because. All right. Yeah, so far he has not added any value for sure.

### You (2025-11-04T17:44:30.382Z)

Y. Eah. Yeah. Well, that's what I. What I kind of told her is, like, you know, I don't want to be the asshole that I might be the one that's drawing a line in the sand here and that we need Mark to. Basically agree that his role is more of a consultant than anything else. He can make the introductions, he can open the doors. He can certainly participate in in demos. But I told her if, you know, if we hire a VP of sales, he is not to report to Mark. Mark is not to have any direct reports that. That he can simply fulfill his role. Of being the. The middleman who's got the connections. And, you know, we'll have a salesperson. We'll look for somebody who comes from, number one, assess background, and number two, hopefully SAS plus proptech. You know, doesn't have to be hotels or anything else, but as long as they're. Familiar with real estate. That would be a great combination. And that person can directly report to Diane and work with Mark, be a partner with Mark of direct report of Marx. And, you know, it's like, I kind of feel like that has to be addressed before anybody signs the llc. But.

### Guest (2025-11-04T17:46:01.976Z)

Yeah, I think this will just go in that working document.

### You (2025-11-04T17:46:06.062Z)

Yeah. Yeah.

### Guest (2025-11-04T17:46:10.536Z)

The sound is fine to me. That's how it should be. I don't know what Mark is up to.

### You (2025-11-04T17:46:11.262Z)

Y. Eah. Yeah.

### Guest (2025-11-04T17:46:15.016Z)

Yeah, that's. I hope that get sorted out. Well, let's see how that goes.

### You (2025-11-04T17:46:19.182Z)

Y. Eah. Y. Eah.

### Guest (2025-11-04T17:46:23.096Z)

Couple of things I had. One is we got to streamline our offshore team, okay? Because we cannot just. Say, you know they are working for us. There's no company. They don't have any letter. They don't get paid from an official account, they don't have any benefits, no holidays, nothing. So I did speak to in last call. I was telling you there's someone who could help us out. So I did talk to him. So he's basically saying, you can register private limited. There's no LLC in India. Instead of llc. We could register a private limited company, same as llc. And I think this simpler way would be. I register it right now as a consultancy. Consultancy company, just like any other consultancy. And then, you know, we give them offer letter through that company. We run their benefits or pay them from that company's account. And then InnVestAI kind of hire these contracts through this company. So that would be the easiest way. That's what he suggested.

### You (2025-11-04T17:47:34.782Z)

Okay? That sounds good.

### Guest (2025-11-04T17:47:42.776Z)

Yeah, so probably that's the way to go because one is the current guys, right? So it's difficult to hold them here. Just, you know, just say that, yeah, you are working with this company, but they don't have any documents. They cannot show it in their experience and all that. Right. So that's kind of difficult for them. And then. Other thing is, it's difficult to hire any good talent because these guys I knew from my personal connection maybe have to hire anyone from outside. We need to have a proper structure.

### You (2025-11-04T17:48:14.622Z)

Yeah. Yeah, yeah. No, that's true. Okay. I mean, we can certainly put that on the agenda for today's call. I think we need to let them know that this, again, is something that's hanging over our heads, that we have to get taken care of.

### Guest (2025-11-04T17:48:29.176Z)

Yeah. And then the other thing. How is the call with that? He was bit confused about that year zero and I didn't have time to go over that.

### You (2025-11-04T17:48:45.342Z)

Yeah. No. Yeah.

### Guest (2025-11-04T17:48:46.296Z)

Second project by Chim.

### You (2025-11-04T17:48:47.582Z)

Yeah, no, it went well. I just had to explain to him the relationship of the three columns. You know, explain to them why, as the buyer, it's easier to use the existing process for forecasting a full year. Instead of trying to forecast the remaining months of the year, partial year forecast. So he got it. The only thing that we need to do, and I'm going to finish up today, is we need to add to the prd. If you've got a financial statement like the one he was using that shows the four months of actual and then the remaining months of forecast. We need to work on a monthly extraction, so we would have to take those four months that have the word actual in the column.

### Guest (2025-11-04T17:49:39.416Z)

P.

### You (2025-11-04T17:49:47.822Z)

And then sum them up for the year to date.

### Guest (2025-11-04T17:49:51.656Z)

Yeah.

### You (2025-11-04T17:49:52.142Z)

Because I explained to them that as a buyer, I don't want to use the seller's forecast because we may have totally different business plans. And so I think he understands the concept behind it as well as the mechanics, so I think we're good.

### Guest (2025-11-04T17:50:10.856Z)

And then the other thing is, I think most of the UI UX work that you are sent already completed there should be up on a stage.

### You (2025-11-04T17:50:18.862Z)

Yeah, yeah.

### Guest (2025-11-04T17:50:19.736Z)

So at least the dashboard is done.

### You (2025-11-04T17:50:21.982Z)

He showed me what was done so far. And this is another thing that came into mind. I was kind of looking over some of my original ideas. And I don't know how I overlooked it, but we need a map. And so I'm also going to revise the PRD because I think we actually need two maps. I think we need a map. On.

### Guest (2025-11-04T17:50:49.496Z)

Google map.

### You (2025-11-04T17:50:50.222Z)

The. Yeah, yeah. So just embed a Google map on the pipeline so that it would show the location of all the deals in their pipeline.

### Guest (2025-11-04T17:50:52.536Z)

Yeah, we can put that as.

### You (2025-11-04T17:51:01.102Z)

And then also to have a map on the deal itself to show the location of the deal, which would be phase one. And then phase two is, you know, when they fill in the marketing tabs. And they put in comps, then those comps can also be shown on the map. So you show the subject property and then the properties the property page.

### Guest (2025-11-04T17:51:23.576Z)

Ide. Yeah. Yeah, that should be quickly to ever.

### You (2025-11-04T17:51:29.262Z)

So I started working on a couple mockups before my call with Diane, So I'll finish those up as well as the year to date. Clarification for individual columns, and I'll get that out to everybody. Yeah, no, that's about it. I just wanted to let everybody know. Probably starting tomorrow or Thursday. I'm going to start on the AI augmented mockups for user setup and what we need to do on that just to kind of. And I'll start working on a POC for that and just see if we can take a look at that. That's another thing, Diane and I were talking about pricing. And what we need to consider is our core product every client would pay for and then the add ons and, you know, that kept. I kept thinking about, you know, feature flags and how we're going to, how we're going to handle all that. So just something to keep in mind as well.

### Guest (2025-11-04T17:52:40.856Z)

Yeah. We'll definitely need more people once we start, you know, kind of onboarding the users.

### You (2025-11-04T17:52:46.142Z)

Yeah. Yeah. Y. Eah.

### Guest (2025-11-04T17:52:52.376Z)

But, yeah, probably. That. Far from now, right now.

### You (2025-11-04T17:52:55.662Z)

Y. Eah.

### Guest (2025-11-04T17:52:56.456Z)

Not very far project. It depends when you, you know, want to onboard the users.

### You (2025-11-04T17:53:01.342Z)

Right. Right. Which again, you know, we, we I, I created the account and user as part of the CRM, which I guess we could probably just use that as our account user table, but we may have to add more fields in there to designate, you know, what, what products do they have? Make sure we've got all the appropriate roles.

### Guest (2025-11-04T17:53:18.056Z)

On.

### You (2025-11-04T17:53:29.422Z)

Covered. And, you know, we have to get prepared for that as well.

### Guest (2025-11-04T17:53:34.376Z)

Yeah, yeah, yeah. There's a lot of work coming up, for sure.

### You (2025-11-04T17:53:36.782Z)

Yeah, there's. Yeah.

### Guest (2025-11-04T17:53:39.976Z)

Any update on the driftwood thing?

### You (2025-11-04T17:53:44.462Z)

No. No, other than. I mean, Diana's already working.

### Guest (2025-11-04T17:53:45.576Z)

No. Okay.

### You (2025-11-04T17:53:49.902Z)

And she's. She's working on their budgets. And so, I mean, it's still, I think, We can't do. We can't deposit a check until we have the llc. And so that's another thing. Why? You know, it kind of encourages, like. No, we gotta. We gotta get that done. And go from there. So I'm not concerned about the money. I'm just concerned that we can't do anything with the money right now. All.

### Guest (2025-11-04T17:54:21.176Z)

Okay. We can harmonize. You know, the work is piling. We. We got to kind of put in more hours, right?

### You (2025-11-04T17:54:21.342Z)

Right.

### Guest (2025-11-04T17:54:29.176Z)

And kind of stay focused, but. Yeah. I don't know.

### You (2025-11-04T17:54:36.222Z)

Okay? Cool. Anything else?

### Guest (2025-11-04T17:54:41.096Z)

Not really. Yeah. I'll see you in the evening.

### You (2025-11-04T17:54:41.902Z)

All right.

### Guest (2025-11-04T17:54:45.576Z)

Earlier.

### You (2025-11-04T17:54:45.582Z)

Yeah. Yeah. I'm just kind of looking through my notes right now, just see if there's anything else, but I think we pretty much covered everything. So.

### Guest (2025-11-04T17:54:53.336Z)

Okay? Sounds good. Sounds good.

### You (2025-11-04T17:54:54.302Z)

Okay? All right. Yeah, we'll see you later this afternoon.

### Guest (2025-11-04T17:54:57.096Z)

R. Thank. Yeah. See.