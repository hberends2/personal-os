# Hotel model feature refinement with product details and revenue projection strategies

**Date:** 2025-06-20 00:00:00 UTC
**Meeting ID:** 75c64e34-66b4-40a3-a452-de33004f78fa
**Synced:** 2026-02-05 14:46:48

---

# Transcript for: Hotel model feature refinement with product details and revenue projection strategies

### Guest (2025-06-20T16:59:50.404Z)

Hey, Howard.

### You (2025-06-20T16:59:50.651Z)

Hey. Good morning. How are doing? Extra casual. Extra, extra casual.

### Guest (2025-06-20T16:59:52.634Z)

I'm extra casual extra extra casual today. So please

### You (2025-06-20T16:59:55.201Z)

Today. That's a good it's a Friday. Who cares? Alright. I'm gonna try to touch with you, like,

### Guest (2025-06-20T17:00:02.164Z)

Alright. I meant to try to connect with you, like,

### You (2025-06-20T17:00:03.611Z)

like, Wednesday. I've just been

### Guest (2025-06-20T17:00:04.604Z)

like, Wednesday. I've just been

### You (2025-06-20T17:00:05.161Z)

I've just been catching up totally totally behind on many many things. So

### Guest (2025-06-20T17:00:06.504Z)

I've just been catching up totally totally behind on many, many things. So

### You (2025-06-20T17:00:09.651Z)

Yeah. That's always the problem, taking day off. I've I've always hesitated to because take one day off, it takes two days to recover. So Yeah. Interesting. I mean, that was in

### Guest (2025-06-20T17:00:19.864Z)

Yeah. And it's not like I mean, I wasn't even really taking days off. I mean, I was

### You (2025-06-20T17:00:21.381Z)

really taking things off. I mean, I was working on it as a Hawaii and just

### Guest (2025-06-20T17:00:24.544Z)

working while I was in Hawaii. I just

### You (2025-06-20T17:00:25.251Z)

you know, couldn't get as much done. Yeah.

### Guest (2025-06-20T17:00:26.514Z)

you know, couldn't get as much done.

### You (2025-06-20T17:00:27.931Z)

And then it seems like in our, you know, our business, like,

### Guest (2025-06-20T17:00:28.554Z)

And then seems like with our, you know, our main business, like,

### You (2025-06-20T17:00:31.691Z)

things go even, like, talking to right? I feel like I'm not doing anything.

### Guest (2025-06-20T17:00:32.944Z)

things go in and out. Like, there'll be periods where I I feel like I'm not doing anything.

### You (2025-06-20T17:00:35.851Z)

Yeah. And then, you know, it's not that it's, suddenly, there's just, like, too much to do and I'm way behind it. Yeah. Yeah.

### Guest (2025-06-20T17:00:37.454Z)

And then, you know, it's not then it's, like, suddenly, there's just, like, too much to do, and I'm way behind.

### You (2025-06-20T17:00:42.801Z)

Anyway, are we we should report just because I wanted to put together, like,

### Guest (2025-06-20T17:00:44.454Z)

Anyway, are we we should record just because I wanted to put together, like, a

### You (2025-06-20T17:00:47.721Z)

a document. To go along with this conversation, but I just didn't have a chance. Okay.

### Guest (2025-06-20T17:00:49.004Z)

like, a document to go along with this conversation, and I just didn't have a chance.

### You (2025-06-20T17:00:51.881Z)

If we record it,

### Guest (2025-06-20T17:00:52.744Z)

So if we record it

### You (2025-06-20T17:00:53.061Z)

you know, the scale to do that.

### Guest (2025-06-20T17:00:54.674Z)

maybe the notes can help do that.

### You (2025-06-20T17:00:54.731Z)

Let me go ahead and start it. Alright. Cool.

### Guest (2025-06-20T17:01:01.054Z)

K. And I will

### You (2025-06-20T17:01:01.761Z)

Am I I also

### Guest (2025-06-20T17:01:05.014Z)

also

### You (2025-06-20T17:01:05.301Z)

put together some

### Guest (2025-06-20T17:01:06.994Z)

put together some bullet points on this anyway.

### You (2025-06-20T17:01:07.131Z)

bullet points on this anyway. Alright. So

### Guest (2025-06-20T17:01:10.584Z)

So

### You (2025-06-20T17:01:10.971Z)

wanted to go

### Guest (2025-06-20T17:01:11.364Z)

what I

### You (2025-06-20T17:01:11.931Z)

from was well, basically,

### Guest (2025-06-20T17:01:12.784Z)

wanted to go over was basically when when when we were talking about it the other day,

### You (2025-06-20T17:01:18.271Z)

think, like, Diane you know, recognize for

### Guest (2025-06-20T17:01:19.954Z)

I think, like, Diane Mark, and I sort of had it seemed to me like we had some differing opinions on on how some of these things should work. So

### You (2025-06-20T17:01:28.611Z)

Yeah. I feel with it. Like, on Monday or Tuesday,

### Guest (2025-06-20T17:01:30.734Z)

I spoke with them

### You (2025-06-20T17:01:31.841Z)

like, hey. Let's really make sure we all have the cookie.

### Guest (2025-06-20T17:01:32.074Z)

like, on Monday or Tuesday to be like, hey. Let's really make sure we all agree

### You (2025-06-20T17:01:34.841Z)

And

### Guest (2025-06-20T17:01:35.964Z)

on stuff.

### You (2025-06-20T17:01:36.501Z)

I it sounds like we did it actually during

### Guest (2025-06-20T17:01:36.924Z)

And I it sounds like we did actually agree more than I

### You (2025-06-20T17:01:39.331Z)

thought we did, which is good.

### Guest (2025-06-20T17:01:41.294Z)

thought we did, which is good. And then I wanna make sure that all of that got

### You (2025-06-20T17:01:44.281Z)

All of that got clearly communicated to you so that you ordered to

### Guest (2025-06-20T17:01:47.384Z)

clearly communicated to you so that you weren't

### You (2025-06-20T17:01:48.361Z)

doing things that end up having to be, like,

### Guest (2025-06-20T17:01:50.284Z)

doing things that ended up having to be, like, redone.

### You (2025-06-20T17:01:50.321Z)

redone. Right. Right.

### Guest (2025-06-20T17:01:53.384Z)

Because because I know the more that you do, it all builds on The more you do, you know, the harder it is to go back and redo something that that, you know, early on. So

### You (2025-06-20T17:01:59.591Z)

So

### Guest (2025-06-20T17:02:01.334Z)

so

### You (2025-06-20T17:02:02.011Z)

the kind of

### Guest (2025-06-20T17:02:03.364Z)

the the

### You (2025-06-20T17:02:03.531Z)

takeaway from

### Guest (2025-06-20T17:02:04.774Z)

kind of takeaway from it all was

### You (2025-06-20T17:02:05.801Z)

was. It's it's like, I mean, everything

### Guest (2025-06-20T17:02:08.494Z)

it's and it's thankfully, it's like I mean, everything you've done has been really, really, you know, in line with what we I think, all agree. So it's it's, you know, it's pretty minor.

### You (2025-06-20T17:02:15.061Z)

pretty minor. K. So the short part is to say the property

### Guest (2025-06-20T17:02:18.944Z)

So

### You (2025-06-20T17:02:20.181Z)

detail.

### Guest (2025-06-20T17:02:20.254Z)

the first part is to say that the property details like this, I think,

### You (2025-06-20T17:02:20.781Z)

Is, I think, know, is is is good.

### Guest (2025-06-20T17:02:23.614Z)

you know, is is is good.

### You (2025-06-20T17:02:24.721Z)

I'm sure that we're already

### Guest (2025-06-20T17:02:26.264Z)

And I'm sure there's more to be added here, you know, over time. But, like, having the first page be the place where the user puts in the subject property and and associated details is is

### You (2025-06-20T17:02:35.151Z)

an effect. Is good.

### Guest (2025-06-20T17:02:37.134Z)

I think, that is good.

### You (2025-06-20T17:02:38.191Z)

Is part here I think right now,

### Guest (2025-06-20T17:02:39.794Z)

Then this tab here I think right now,

### You (2025-06-20T17:02:42.761Z)

know. Well, this is the here.

### Guest (2025-06-20T17:02:45.114Z)

what this is being used for is not so much market analysis, but

### You (2025-06-20T17:02:45.481Z)

For but

### Guest (2025-06-20T17:02:49.774Z)

more of something that Mark, Diane, and I thought should be called, like, either

### You (2025-06-20T17:02:53.861Z)

market comps?

### Guest (2025-06-20T17:02:54.564Z)

comps or, like, market comps.

### You (2025-06-20T17:02:55.131Z)

Basically, what you guys are doing is they are

### Guest (2025-06-20T17:02:57.174Z)

Basically, what users are doing is they're

### You (2025-06-20T17:02:57.611Z)

and this need to at the end. We still do it right. And maybe you it

### Guest (2025-06-20T17:02:59.694Z)

and this is something we we like, the analysts will do. Right? And maybe they do it multifamily too, but basically, like, they're you know, they know they're gonna they're looking at this property. They wanna you know, somebody up is gonna okay. Well, I wanna know the top 10 or 20 properties that are most competitive with this property in the same location and maybe a handful of other ones in other locations.

### You (2025-06-20T17:03:16.141Z)

So

### Guest (2025-06-20T17:03:18.144Z)

They're gonna go you know, somebody's gonna go compile all the information about those competitive properties, you know, key count, square feet, location,

### You (2025-06-20T17:03:22.071Z)

feet. Those you know,

### Guest (2025-06-20T17:03:26.004Z)

you know, square feet of meeting space, etcetera. Right? And put that all. Right? So

### You (2025-06-20T17:03:29.311Z)

that's really what this

### Guest (2025-06-20T17:03:31.634Z)

that's really what this section, I think, is

### You (2025-06-20T17:03:32.261Z)

set up to be used for. Right. So

### Guest (2025-06-20T17:03:34.274Z)

set up to be used for.

### You (2025-06-20T17:03:35.221Z)

basically, instead of calling

### Guest (2025-06-20T17:03:36.444Z)

So

### You (2025-06-20T17:03:36.791Z)

market analysis, just call it, like,

### Guest (2025-06-20T17:03:37.354Z)

basically, instead of calling it market analysis, just call it, like,

### You (2025-06-20T17:03:38.691Z)

you know, I'll put this in my email, change market analysis.

### Guest (2025-06-20T17:03:40.704Z)

you know and I'll put this in my email. Change market analysis.

### You (2025-06-20T17:03:43.131Z)

To like,

### Guest (2025-06-20T17:03:45.104Z)

To

### You (2025-06-20T17:03:45.611Z)

school problems, I think.

### Guest (2025-06-20T17:03:46.494Z)

like,

### You (2025-06-20T17:03:47.321Z)

Okay.

### Guest (2025-06-20T17:03:47.674Z)

call it market comps, I think.

### You (2025-06-20T17:03:49.341Z)

Yeah. And you know, actually,

### Guest (2025-06-20T17:03:51.534Z)

Yeah. And I think you know, eventually,

### You (2025-06-20T17:03:53.891Z)

be able to select from our database, you know, like,

### Guest (2025-06-20T17:03:55.064Z)

users would be able to select from our database. You know? Like, they'd be able to, like, you know, type in the property name, and it would populate, and then they would be able to populate the basic information.

### You (2025-06-20T17:04:03.181Z)

the

### Guest (2025-06-20T17:04:04.324Z)

And then

### You (2025-06-20T17:04:04.511Z)

thing to really

### Guest (2025-06-20T17:04:05.444Z)

the only thing to really be

### You (2025-06-20T17:04:06.531Z)

here

### Guest (2025-06-20T17:04:07.614Z)

input here is and we've talked about this too.

### You (2025-06-20T17:04:09.641Z)

a little bit. Is that a lot of times,

### Guest (2025-06-20T17:04:11.734Z)

A little bit, is that a lot of times,

### You (2025-06-20T17:04:13.521Z)

companies

### Guest (2025-06-20T17:04:14.444Z)

companies will like, people that are doing underwriting, they'll call around

### You (2025-06-20T17:04:16.261Z)

the companies like, other brands,

### Guest (2025-06-20T17:04:19.044Z)

to, like, other operators, other brands,

### You (2025-06-20T17:04:20.431Z)

Basically, get. Arguments.

### Guest (2025-06-20T17:04:22.504Z)

basically, to get occupancy and ADR, specifically, maybe some other basically, like, if I'm looking at the Marriott Boca Raton, I'll call I'll call Hilton, and I'll be like, hey, Hilton. Tell me the occupancy in the ADR for the last five years of these four Hiltons in the surrounding area.

### You (2025-06-20T17:04:39.081Z)

The same.

### Guest (2025-06-20T17:04:39.474Z)

And I'll call IHG, and I'll do the same. And then I'll call Hyatt, and I'll do the same. And then I'll call maybe a couple of independent operators and do the same. And, usually, you can get a good amount of information.

### You (2025-06-20T17:04:47.751Z)

So Good. I think there should be a

### Guest (2025-06-20T17:04:50.104Z)

So

### You (2025-06-20T17:04:50.421Z)

a full work to do that.

### Guest (2025-06-20T17:04:51.154Z)

I think there should be a

### You (2025-06-20T17:04:52.171Z)

Here.

### Guest (2025-06-20T17:04:52.574Z)

a form to do that here.

### You (2025-06-20T17:04:52.631Z)

Okay. And I you know, it's it's just a new one.

### Guest (2025-06-20T17:04:55.864Z)

And I can you know, you it's it's just annualized information. So it's like you

### You (2025-06-20T17:04:56.511Z)

Information. So it's like, you you

### Guest (2025-06-20T17:04:59.934Z)

you you're literally just getting, like, the way it looks in a lot of the Excel files that we pull up, it's like you have, like,

### You (2025-06-20T17:05:03.121Z)

know, like, literally just, you know, 2020 or 2019, 2020, 2022, '23, '24, and then

### Guest (2025-06-20T17:05:05.774Z)

literally just, you know, twenty twenty you know, 2019, 2020, 21, 22, 23, 24, and then just occupancy ADR, and then RevPAR is calculated. So it's just it's very it's very simple.

### You (2025-06-20T17:05:15.171Z)

But that way, because

### Guest (2025-06-20T17:05:16.584Z)

But that way, somebody can because, you know, on a blended average, you know, might be 150, but the range yeah, which is what you're getting in the concept. But the range of that might be 50 plus, 50 minus. You know? So it's like, knowing what the range is on your on your blended comp set is very helpful to see, you know, how high or how, you know, how high you can go or how low you should go.

### You (2025-06-20T17:05:35.701Z)

Okay.

### Guest (2025-06-20T17:05:38.204Z)

And this, I think, right now,

### You (2025-06-20T17:05:40.231Z)

Doesn't

### Guest (2025-06-20T17:05:42.694Z)

doesn't need to tie to anything else. Like, those occupancy and ADR numbers they should just be I mean, they should be

### You (2025-06-20T17:05:49.801Z)

obviously.

### Guest (2025-06-20T17:05:50.884Z)

stored, obviously, in in the data models unique to each

### You (2025-06-20T17:05:52.721Z)

Customer.

### Guest (2025-06-20T17:05:54.824Z)

customer, but they're not gonna they're not gonna feed into the rest of this stuff.

### You (2025-06-20T17:05:55.921Z)

Feed into the rest of the stuff. Right. Okay. That makes sense.

### Guest (2025-06-20T17:05:59.334Z)

Yeah. It's it's

### You (2025-06-20T17:05:59.851Z)

Just a page. Yeah.

### Guest (2025-06-20T17:06:02.324Z)

yeah.

### You (2025-06-20T17:06:02.531Z)

Reference. Yeah. K.

### Guest (2025-06-20T17:06:03.194Z)

It's just a reference point. Yeah.

### You (2025-06-20T17:06:03.711Z)

Okay.

### Guest (2025-06-20T17:06:05.364Z)

Okay. I think something that you that we could add, and we don't maybe this goes in the parking lot for now, would be a tab that is an actual market analysis

### You (2025-06-20T17:06:16.931Z)

Think we

### Guest (2025-06-20T17:06:18.094Z)

that we could you know, you could pull in We've talked about Lark and Hotel Horizon's data as, like, two of the main

### You (2025-06-20T17:06:24.431Z)

Yeah.

### Guest (2025-06-20T17:06:24.594Z)

you know, data I guess, sources of data for, like, market data. Like, how is the US, you know, national RevPAR trending?

### You (2025-06-20T17:06:31.521Z)

Right? Post

### Guest (2025-06-20T17:06:33.884Z)

Right? CoStar has stuff like that too. So that's probably something that you can put in the parking lot for now as, like, an actual market. And that that way, a user can

### You (2025-06-20T17:06:37.991Z)

that's what's

### Guest (2025-06-20T17:06:41.714Z)

say, like, okay. Well, I'm looking at a hotel and you know, Boca Raton. Like, how is Boca Raton doing? Just generally speaking.

### You (2025-06-20T17:06:45.131Z)

speaking. Yeah. And

### Guest (2025-06-20T17:06:47.944Z)

And and they can get that information before they go into start making their

### You (2025-06-20T17:06:49.721Z)

projections. Alright. Now see, that's kinda what I thought this page was because

### Guest (2025-06-20T17:06:51.794Z)

projections.

### You (2025-06-20T17:06:53.971Z)

honestly, think I mentioned before, this is just basically a copy paste from Mark's model.

### Guest (2025-06-20T17:06:58.804Z)

I think no. I think I think what you were envisioning was correct. I think and I I think these models are there's so many things in them which gets a little confusing, and then they get, like,

### You (2025-06-20T17:07:15.471Z)

What.

### Guest (2025-06-20T17:07:16.314Z)

the nomenclature of what a thing is or how it's used gets maybe a little bit lost because of there's so much stuff going on.

### You (2025-06-20T17:07:22.391Z)

So I will call you think you originally had

### Guest (2025-06-20T17:07:24.524Z)

So I think what you maybe originally had

### You (2025-06-20T17:07:25.571Z)

And

### Guest (2025-06-20T17:07:27.714Z)

and I think Vinod has some that on the dashboards he's put together. I've seen, like, market, you know, trends and whatnot. Like, people in our models, like, they don't do that. They don't put that stuff in the model because it's not

### You (2025-06-20T17:07:37.021Z)

I guess it's just like

### Guest (2025-06-20T17:07:39.124Z)

I guess it's just like so if somebody wants to read the market trend,

### You (2025-06-20T17:07:39.451Z)

something market They go over market now. They go

### Guest (2025-06-20T17:07:43.874Z)

they go or mark it out, they go read the Hotel Horizons or CBRE report, or they go read the Lark report. To get that. So it doesn't go in the model anywhere, so it's a little bit of, like, a misleading in the sense of, like, it would be there normally if we were, you know, looking at it big picture.

### You (2025-06-20T17:07:57.481Z)

get Okay. Yeah. Because what I'm what I want to avoid are those phone calls. That you mentioned. If possible, Right? So so you know, probably in the short term, we'll have to have that more that you talked about where you they can go and input this information based on those conversations. But maybe it's not possible. Maybe the data that we get

### Guest (2025-06-20T17:08:28.964Z)

Well,

### You (2025-06-20T17:08:29.231Z)

third parties is too old.

### Guest (2025-06-20T17:08:30.434Z)

yeah, I mean,

### You (2025-06-20T17:08:31.601Z)

And stales.

### Guest (2025-06-20T17:08:31.674Z)

well, no. No. It's it's it's a little bit, like,

### You (2025-06-20T17:08:34.181Z)

So

### Guest (2025-06-20T17:08:36.344Z)

this what we're doing right here, this piece, this, like, getting information on comps,

### You (2025-06-20T17:08:37.301Z)

this, like, get picture comps, Yeah. I think it will ever be

### Guest (2025-06-20T17:08:41.254Z)

I don't think it will ever be something you can automate because it's not you're not

### You (2025-06-20T17:08:41.831Z)

something you can always because it's not you're not supposed to do it. Okay.

### Guest (2025-06-20T17:08:46.224Z)

supposed to do it.

### You (2025-06-20T17:08:46.601Z)

Like, it is

### Guest (2025-06-20T17:08:47.274Z)

It's against the rules. Like, it is very much like

### You (2025-06-20T17:08:47.771Z)

very much like

### Guest (2025-06-20T17:08:51.214Z)

like, we don't even email each other about it.

### You (2025-06-20T17:08:52.111Z)

Like, we don't even voice mails. We don't text

### Guest (2025-06-20T17:08:54.434Z)

Like,

### You (2025-06-20T17:08:55.091Z)

It's like you just

### Guest (2025-06-20T17:08:55.324Z)

don't even leave voice mails. We don't text. It's like you just

### You (2025-06-20T17:08:55.891Z)

you cold call

### Guest (2025-06-20T17:08:58.084Z)

you cold call

### You (2025-06-20T17:08:58.961Z)

you get to the

### Guest (2025-06-20T17:08:59.584Z)

and you you get the and then you make connections. Like, when I was at my last operator,

### You (2025-06-20T17:08:59.951Z)

connections like mine was in my last offer we gift baskets to

### Guest (2025-06-20T17:09:04.554Z)

we would literally, like,

### You (2025-06-20T17:09:05.481Z)

analysts on the feasibility team.

### Guest (2025-06-20T17:09:05.954Z)

send gift baskets to the analysts on the feasibility team at Hilton and Hyatt Marriott IHG. And say just, like they get, like, you know, couple $100 gift cards, whatever, just like, thank you, whatever. But then we would

### You (2025-06-20T17:09:16.571Z)

Give

### Guest (2025-06-20T17:09:16.664Z)

just call them. Every week, we'd call them, like,

### You (2025-06-20T17:09:18.391Z)

these numbers because they have

### Guest (2025-06-20T17:09:18.874Z)

just barrage of, like, we need these numbers because they have they have all the

### You (2025-06-20T17:09:19.731Z)

all of this thing that, you know, we have no we have no

### Guest (2025-06-20T17:09:22.254Z)

data. You know? We have no we have no data. We had 50 hotels in our portfolio, but we are underwriting all the time. So but we would never email, never leave messages,

### You (2025-06-20T17:09:28.751Z)

we're doing.

### Guest (2025-06-20T17:09:29.744Z)

leave any record of what we were doing because it is technically against the rules.

### You (2025-06-20T17:09:32.451Z)

I guess whose rules

### Guest (2025-06-20T17:09:33.004Z)

And you could get fired for it. So

### You (2025-06-20T17:09:34.971Z)

The brand.

### Guest (2025-06-20T17:09:36.144Z)

the brands. Like, the brands

### You (2025-06-20T17:09:36.631Z)

Oh, Okay. Thank

### Guest (2025-06-20T17:09:39.404Z)

technically like, Marriott, Hilton, Hyatt, like,

### You (2025-06-20T17:09:41.021Z)

technically, like, I think

### Guest (2025-06-20T17:09:43.254Z)

technically, like, if they knew that their analysts were sharing

### You (2025-06-20T17:09:44.391Z)

confidential statistics

### Guest (2025-06-20T17:09:46.724Z)

confidential know, data, that's they would be like, oh, we can't because it's not

### You (2025-06-20T17:09:49.791Z)

you Right?

### Guest (2025-06-20T17:09:52.014Z)

right? It's like

### You (2025-06-20T17:09:52.731Z)

That invest in itself.

### Guest (2025-06-20T17:09:53.584Z)

the investors that invested in the hotel and the

### You (2025-06-20T17:09:54.111Z)

The operators

### Guest (2025-06-20T17:09:56.604Z)

hotel, they have confidentiality agreements that no one's supposed to share that beyond the immediate pool, much less a a potential competitor.

### You (2025-06-20T17:10:01.821Z)

Right. Right? So it's like, very much, but potentially

### Guest (2025-06-20T17:10:04.054Z)

Right? So it's, like, very much but but everybody does it.

### You (2025-06-20T17:10:04.911Z)

does it. It's just, like, you can't get, like,

### Guest (2025-06-20T17:10:07.564Z)

It's just, like,

### You (2025-06-20T17:10:07.921Z)

could you could walk towards it

### Guest (2025-06-20T17:10:08.664Z)

you can't get like, you couldn't you couldn't it's one of those things you really

### You (2025-06-20T17:10:09.681Z)

you really at least in this current day.

### Guest (2025-06-20T17:10:12.694Z)

at at least in this current day and age, you know, you cannot formalize because it is

### You (2025-06-20T17:10:12.881Z)

Know, you cannot formalize because it is technically that's what's the production. Yeah. Got it.

### Guest (2025-06-20T17:10:17.454Z)

technically not supposed to be done.

### You (2025-06-20T17:10:19.111Z)

Yep.

### Guest (2025-06-20T17:10:20.314Z)

Yeah. But but the the that's why I say this is more of, a comp analysis of just selected comps. But, like, a true market analysis

### You (2025-06-20T17:10:30.161Z)

Using that large data right, that we talked about

### Guest (2025-06-20T17:10:31.884Z)

of, like, using that Lark data, right, that we've talked about

### You (2025-06-20T17:10:33.341Z)

Like, that that, I think, we could I don't think that's what types it out.

### Guest (2025-06-20T17:10:35.564Z)

like, that that, I think, we we could automate. I don't think that needs

### You (2025-06-20T17:10:37.321Z)

That way again. Right?

### Guest (2025-06-20T17:10:38.584Z)

to be typed in. That that we would get from

### You (2025-06-20T17:10:38.771Z)

Third party sources. They're You know, they're actually

### Guest (2025-06-20T17:10:40.964Z)

third party sources that are you know, that that's what they do. They sell this marketing.

### You (2025-06-20T17:10:43.741Z)

k. Okay.

### Guest (2025-06-20T17:10:45.964Z)

Okay.

### You (2025-06-20T17:10:51.391Z)

Yeah.

### Guest (2025-06-20T17:10:53.784Z)

Then

### You (2025-06-20T17:10:54.641Z)

So you're this part here. The evaluations, I think,

### Guest (2025-06-20T17:10:56.844Z)

so that gets to this this part here, the evaluation piece. I think

### You (2025-06-20T17:10:57.961Z)

more That's sort great that they

### Guest (2025-06-20T17:11:00.224Z)

Mark, Diane, and I were sort of agreed that the name of this rather than valuation, it might be clearer if it were just

### You (2025-06-20T17:11:07.631Z)

projections or proof

### Guest (2025-06-20T17:11:10.024Z)

projections or pro or maybe pro form a

### You (2025-06-20T17:11:10.801Z)

Okay. And he he said approach.

### Guest (2025-06-20T17:11:13.294Z)

I think I think they said pro form a.

### You (2025-06-20T17:11:13.911Z)

A. Put together. I kinda prefer that over. Okay.

### Guest (2025-06-20T17:11:16.134Z)

Would be would be better.

### You (2025-06-20T17:11:17.341Z)

Yeah.

### Guest (2025-06-20T17:11:17.514Z)

Yeah. And then later on, there might

### You (2025-06-20T17:11:18.571Z)

And there might be something else zero capital expense, investment, social things are going on. They

### Guest (2025-06-20T17:11:22.484Z)

something else. Like, here, we have, you know, capital expense, investment assumptions. These are sort of

### You (2025-06-20T17:11:26.671Z)

to know, develop a change. So maybe I'm not sure.

### Guest (2025-06-20T17:11:27.524Z)

they lead to, you know, the valuation. So maybe I don't know if they will be a tab called evaluation or not. But, ultimately, this section here is really what you're doing is

### You (2025-06-20T17:11:34.411Z)

Alright.

### Guest (2025-06-20T17:11:35.684Z)

the pro form a projections. You can just call it pro form a. And then here, So

### You (2025-06-20T17:11:53.411Z)

Be the way you have.

### Guest (2025-06-20T17:11:54.304Z)

here, you the way you have occupancy, ADR, RevPAR laid out, like, the way it is over here is is great. I think, you know, one thing we talked about is still adding in

### You (2025-06-20T17:12:04.171Z)

To the occupancy

### Guest (2025-06-20T17:12:04.644Z)

market comp set to the occupancy, right, so that it looks and functions like ADR.

### You (2025-06-20T17:12:10.361Z)

you know, is good.

### Guest (2025-06-20T17:12:10.754Z)

But, otherwise, this this section over here is, you know, is good.

### You (2025-06-20T17:12:11.341Z)

I think the way that is we can change

### Guest (2025-06-20T17:12:13.624Z)

I think the way that it's laid out here

### You (2025-06-20T17:12:14.991Z)

such that there is a

### Guest (2025-06-20T17:12:15.844Z)

if we can change it such that

### You (2025-06-20T17:12:17.911Z)

rather than occupancy.

### Guest (2025-06-20T17:12:18.624Z)

there is a

### You (2025-06-20T17:12:19.371Z)

If this does

### Guest (2025-06-20T17:12:20.124Z)

rather than occupancy, if this says because what what this really is, this is the penetration analysis that we've talked about.

### You (2025-06-20T17:12:25.161Z)

k. Thank you. Yeah. But

### Guest (2025-06-20T17:12:27.604Z)

And I know you have this down here.

### You (2025-06-20T17:12:28.571Z)

this is something that's what this is. Right? Because you're looking at, you know, how does the properties occupancy in your

### Guest (2025-06-20T17:12:29.524Z)

But this is so that's what this is. Right? Because you're looking at, you know, how does my properties occupy

### You (2025-06-20T17:12:33.481Z)

kind of penetrate to the market in the concept.

### Guest (2025-06-20T17:12:34.824Z)

ADR, and RevPAR penetrate to the market in the comp set? So

### You (2025-06-20T17:12:35.881Z)

So if you change if you have

### Guest (2025-06-20T17:12:39.484Z)

if you chain you know, if you have a

### You (2025-06-20T17:12:40.121Z)

instead of occupancy, just it's called this penetration analysis.

### Guest (2025-06-20T17:12:41.504Z)

instead of occupancy, you could just call call this penetration analysis.

### You (2025-06-20T17:12:43.371Z)

And that, like,

### Guest (2025-06-20T17:12:45.604Z)

And then underneath that like, you know, indented, right, like subcategories and penetration analysis, have

### You (2025-06-20T17:12:50.521Z)

Okay. Alright.

### Guest (2025-06-20T17:12:51.934Z)

ARC, ADR, RevPar. So I'll put that on.

### You (2025-06-20T17:13:04.351Z)

Alright. That'll help because I was actually gonna try to get the penetration this weekend, and I didn't connect the dots there. So Yeah.

### Guest (2025-06-20T17:13:14.204Z)

Yeah. Good. Well, I'm glad I able to get to you before you today with more work on that. So

### You (2025-06-20T17:13:24.941Z)

So that this revenue

### Guest (2025-06-20T17:13:25.024Z)

and then

### You (2025-06-20T17:13:26.221Z)

section

### Guest (2025-06-20T17:13:26.244Z)

on so then this revenue section, right, that you can remove

### You (2025-06-20T17:13:26.801Z)

there. You can tell you

### Guest (2025-06-20T17:13:30.334Z)

ADR RevPAR, And you can put I mean, rooms revenue

### You (2025-06-20T17:13:37.041Z)

Yeah. It's fine. It's really just a calculation of everything.

### Guest (2025-06-20T17:13:39.424Z)

yeah. I mean, this is fine. The rooms revenue is really just a calculation of everything above.

### You (2025-06-20T17:13:42.811Z)

Because they like that,

### Guest (2025-06-20T17:13:43.314Z)

So that's it's great. That's

### You (2025-06-20T17:13:44.441Z)

that for this

### Guest (2025-06-20T17:13:45.044Z)

can stay like that.

### You (2025-06-20T17:13:46.071Z)

case. I

### Guest (2025-06-20T17:13:47.324Z)

For this piece,

### You (2025-06-20T17:13:48.201Z)

we did have this on just a little bit.

### Guest (2025-06-20T17:13:48.914Z)

I think we did talk about this a little bit

### You (2025-06-20T17:13:50.441Z)

And you know, say, like, really

### Guest (2025-06-20T17:13:52.814Z)

and, you know, saying that, like, really, rooms revenue

### You (2025-06-20T17:13:52.901Z)

great revenue.

### Guest (2025-06-20T17:13:55.894Z)

food and beverage, other, whatever, you know, is that they could should or could just be this at the same level as room revenue.

### You (2025-06-20T17:14:03.121Z)

Because there's this whole flow with your main departments. Right?

### Guest (2025-06-20T17:14:04.284Z)

Right? You have because those correspond with your main departments. Right?

### You (2025-06-20T17:14:05.961Z)

Yeah. So if possible,

### Guest (2025-06-20T17:14:08.114Z)

Revenues generated. So

### You (2025-06-20T17:14:09.331Z)

if

### Guest (2025-06-20T17:14:10.224Z)

if possible to make it rooms revenue,

### You (2025-06-20T17:14:11.241Z)

other miscellaneous

### Guest (2025-06-20T17:14:12.364Z)

food and beverage, other,

### You (2025-06-20T17:14:12.901Z)

That's great.

### Guest (2025-06-20T17:14:14.114Z)

miscellaneous, that's great.

### You (2025-06-20T17:14:15.221Z)

If it's if if if you I mean, if it's too if it's gonna be a lot of

### Guest (2025-06-20T17:14:17.534Z)

If it's if if if you I mean, if it's too if that's gonna be a lot of work and

### You (2025-06-20T17:14:19.681Z)

work and it's easier to read them in this instance here.

### Guest (2025-06-20T17:14:22.464Z)

easier to leave them in this

### You (2025-06-20T17:14:23.081Z)

Then that's fine. Just make this

### Guest (2025-06-20T17:14:24.304Z)

indent here,

### You (2025-06-20T17:14:25.141Z)

not call this one way.

### Guest (2025-06-20T17:14:25.334Z)

then that's fine. Just make this

### You (2025-06-20T17:14:26.591Z)

Not really try to do.

### Guest (2025-06-20T17:14:27.344Z)

not call this one, like, non rooms revenue.

### You (2025-06-20T17:14:27.861Z)

And that will be able to differentiate from because otherwise, it's confusing kind of other revenue.

### Guest (2025-06-20T17:14:30.044Z)

And that way, it'll differentiate from because otherwise, it's confusing to have other revenue and other that's gonna confuse people.

### You (2025-06-20T17:14:35.311Z)

So here here was my vision for that.

### Guest (2025-06-20T17:14:36.014Z)

But if you call it non rooms revenue, then that's clear.

### You (2025-06-20T17:14:40.281Z)

Is that the other revenue items in that section would be dependent upon what the user checked in the property details. So if this is a hotel that doesn't have food or beverage or anything, the goal was to not even have it showed on, shown on the sidebar. So I think what you're describing might actually make it easier so that we're not having to deal with a category and subcategory So if we just remove other revenue, and just have rooms revenue, food and beverage other operated, The other option is to always have them on the sidebar but only have them active based on what the user has selected in the property details. Yeah. So if they don't have a food and beverage, you'll still see it. But it'll be, you know, like a lighter shade of gray And when they click on it, nothing happens because there is no food and beverage. So, that's something that, you know, we may do some AB testing with clients or have a both ways. Let them weigh in into, whether they wanted Yeah. To be that way.

### Guest (2025-06-20T17:16:04.224Z)

Yeah.

### You (2025-06-20T17:16:05.281Z)

But, yeah, I kinda like the idea of just getting rid of the whole other revenue primary category and just having the other ones underneath. That would make that easier.

### Guest (2025-06-20T17:16:16.284Z)

Okay.

### You (2025-06-20T17:16:17.161Z)

Okay. Cool. K. Great. And how can

### Guest (2025-06-20T17:16:18.994Z)

Okay. Cool. Good. And allocated,

### You (2025-06-20T17:16:21.611Z)

in our system, it is system.

### Guest (2025-06-20T17:16:23.184Z)

it is a

### You (2025-06-20T17:16:24.291Z)

Charged

### Guest (2025-06-20T17:16:24.344Z)

our system, it is its own and in a lot of

### You (2025-06-20T17:16:25.081Z)

account it. It's going like, section. Okay. But it

### Guest (2025-06-20T17:16:26.714Z)

charts of accounts, it is its own, like, section

### You (2025-06-20T17:16:28.751Z)

technically should always be zero.

### Guest (2025-06-20T17:16:29.814Z)

But it technically should always be zero.

### You (2025-06-20T17:16:31.231Z)

It doesn't doesn't need to really included because it's, again, should always zero.

### Guest (2025-06-20T17:16:33.054Z)

So it doesn't need to really be included because it, again, should really always be zero.

### You (2025-06-20T17:16:34.931Z)

Explain that to me. It'll always be zero.

### Guest (2025-06-20T17:16:37.184Z)

So

### You (2025-06-20T17:16:38.701Z)

So the way like the the charts we have supposed to work is, like,

### Guest (2025-06-20T17:16:43.334Z)

the way, like, the the charts of accounts supposed to work is, like,

### You (2025-06-20T17:16:44.481Z)

in your operating departments, you know, rooms how they're operating this, like, if

### Guest (2025-06-20T17:16:46.774Z)

in your operating departments,

### You (2025-06-20T17:16:48.281Z)

you get your app, your cherry

### Guest (2025-06-20T17:16:48.364Z)

you know, rooms out there operating miscellaneous f and b, you have you generated all your revenue.

### You (2025-06-20T17:16:49.581Z)

all your revenue. Yeah. And then each departments

### Guest (2025-06-20T17:16:53.114Z)

And then each of those departments

### You (2025-06-20T17:16:53.131Z)

will accept the miscellaneous. But we're we never talk about it.

### Guest (2025-06-20T17:16:55.374Z)

except for miscellaneous, but

### You (2025-06-20T17:16:56.611Z)

They have corresponding

### Guest (2025-06-20T17:16:57.174Z)

rooms, food and beverage, other operating, they have corresponding departmental expenses.

### You (2025-06-20T17:16:57.731Z)

department expenses right here. House comparison, rooms part

### Guest (2025-06-20T17:17:00.884Z)

Right? You have housekeepers in the rooms department. You have servers and cooks and f and b, and you have spa technicians and pool lifeguards in other operator. Right?

### You (2025-06-20T17:17:09.261Z)

But do you only have and then and then

### Guest (2025-06-20T17:17:11.094Z)

But

### You (2025-06-20T17:17:11.831Z)

a distributed energy

### Guest (2025-06-20T17:17:11.994Z)

you only have and then and then it'd be undistributed. In general

### You (2025-06-20T17:17:16.251Z)

like, Perry's made in since marketing sider dumpster undistributed

### Guest (2025-06-20T17:17:19.344Z)

like repairs and maintenance, sales and marketing, etcetera, those are undistributed

### You (2025-06-20T17:17:19.391Z)

departments that don't get allocated They're undistributed.

### Guest (2025-06-20T17:17:22.574Z)

departments that don't get allocated. They're undistributed because they're

### You (2025-06-20T17:17:23.421Z)

Because they are big departments that basically, like, came out to a whole hotel. They turn everything

### Guest (2025-06-20T17:17:27.404Z)

big departments that basically, like, cater to the whole hotel. They serve

### You (2025-06-20T17:17:29.971Z)

And then the last section is, like,

### Guest (2025-06-20T17:17:32.314Z)

everything.

### You (2025-06-20T17:17:32.641Z)

bunch of different entities.

### Guest (2025-06-20T17:17:33.144Z)

And then the last section, these, like,

### You (2025-06-20T17:17:34.371Z)

Allocated targets are things that are very

### Guest (2025-06-20T17:17:35.854Z)

undistribute or these allocated departments are things that

### You (2025-06-20T17:17:37.671Z)

like, really

### Guest (2025-06-20T17:17:39.594Z)

are very, like,

### You (2025-06-20T17:17:39.681Z)

a couple of things. It's employee

### Guest (2025-06-20T17:17:41.404Z)

it's really just a couple of things. It's employee dining,

### You (2025-06-20T17:17:42.301Z)

It it it's like, an in house walker. Right. Sometimes

### Guest (2025-06-20T17:17:45.944Z)

It's, like, an in house laundry are the two main ones.

### You (2025-06-20T17:17:47.461Z)

sometimes operate a lot. Their own department for, like,

### Guest (2025-06-20T17:17:49.744Z)

Sometimes you'll sometimes operators will have their own department for, like, employee benefits.

### You (2025-06-20T17:17:55.101Z)

long list.

### Guest (2025-06-20T17:17:55.294Z)

Where they, like, put all the employee benefit costs, basically, because you have a long list of employee types

### You (2025-06-20T17:17:56.351Z)

You're calling.

### Guest (2025-06-20T17:17:59.864Z)

different types of benefits. You have health insurance, life insurance, dental insurance, you know, workers' comp,

### You (2025-06-20T17:18:01.511Z)

Payroll taxes. Right? All of this stuff is, like, 25,000,000 stuff they would go into.

### Guest (2025-06-20T17:18:05.164Z)

Right? Like, all this stuff is, like, 25 lines of stuff that would go into right?

### You (2025-06-20T17:18:05.751Z)

Right? Not only operator. Like, if you really do it the right way, you would

### Guest (2025-06-20T17:18:09.714Z)

And now all the operators like, if you were really gonna do it the right way, you would

### You (2025-06-20T17:18:10.381Z)

have to you break out each of those costs for every single position.

### Guest (2025-06-20T17:18:14.054Z)

have you would break out each of those costs for every single position.

### You (2025-06-20T17:18:16.091Z)

Yeah. And in every single department. That's like hundreds and hundreds of lives. Not that I've been out there for

### Guest (2025-06-20T17:18:19.734Z)

In every single department. But that's, like, hundreds and hundreds of lines. Not all the operators are gonna do

### You (2025-06-20T17:18:23.901Z)

So

### Guest (2025-06-20T17:18:26.084Z)

that because it's just a lot of work.

### You (2025-06-20T17:18:27.381Z)

departure.

### Guest (2025-06-20T17:18:27.554Z)

So sometimes what they do is they just dump it

### You (2025-06-20T17:18:28.281Z)

Call.

### Guest (2025-06-20T17:18:29.654Z)

in a in its own department, called employee benefits, and then they just allocate it out to each department. That way, it's it's basically, like, goes from, like, a 150, 200 lines to, like, 20.

### You (2025-06-20T17:18:36.551Z)

So it sounds to me like allocated there is no such thing as allocated revenue. Correct. No. Allocated revenue. Yeah. Yeah.

### Guest (2025-06-20T17:18:45.394Z)

Correct. There should be no allocated revenue.

### You (2025-06-20T17:18:46.761Z)

So if you go go up and click on the property details and open up that model

### Guest (2025-06-20T17:18:49.914Z)

Yeah. Yeah.

### You (2025-06-20T17:18:52.491Z)

Click on the next. So on that allocated there, yeah, when you expand that out, so we've got the three categories in each of those three categories have the subcategories. And and now that I'm looking at it, that is only expense. Yeah.

### Guest (2025-06-20T17:19:09.034Z)

Yeah. Well so

### You (2025-06-20T17:19:10.251Z)

So that's is actually

### Guest (2025-06-20T17:19:13.434Z)

yeah. And so this is actually,

### You (2025-06-20T17:19:13.811Z)

these are

### Guest (2025-06-20T17:19:15.694Z)

these are these are the undistributed departments.

### You (2025-06-20T17:19:16.361Z)

Okay. So l it is distributed are the same?

### Guest (2025-06-20T17:19:20.074Z)

Yeah. Yeah. So no. No. No. They're not. So undistributed would be

### You (2025-06-20T17:19:30.211Z)

Right.

### Guest (2025-06-20T17:19:30.984Z)

admin in general,

### You (2025-06-20T17:19:31.211Z)

Marketing. Utilities,

### Guest (2025-06-20T17:19:32.134Z)

property operations and maintenance,

### You (2025-06-20T17:19:33.041Z)

and

### Guest (2025-06-20T17:19:34.444Z)

sales and marketing,

### You (2025-06-20T17:19:35.431Z)

Right. So

### Guest (2025-06-20T17:19:35.654Z)

utilities,

### You (2025-06-20T17:19:36.761Z)

Okay. Yeah.

### Guest (2025-06-20T17:19:36.924Z)

and information and technology.

### You (2025-06-20T17:19:38.301Z)

It's

### Guest (2025-06-20T17:19:39.764Z)

Allocated yeah, allocated is is really it's always gonna be, like, two big ones again are gonna be employee bet it's three big ones. Employee benefits, in house laundry,

### You (2025-06-20T17:19:47.791Z)

generate. Revenue.

### Guest (2025-06-20T17:19:49.574Z)

and employee dining because those don't generate revenue. They they never do. They never will. They're not supposed to. They are simply there to service

### You (2025-06-20T17:19:57.841Z)

Treated

### Guest (2025-06-20T17:19:58.474Z)

they basically basically,

### You (2025-06-20T17:19:59.681Z)

I don't know why they're not

### Guest (2025-06-20T17:19:59.774Z)

the way the app they get they get treated is I don't know why they're not under departments. I don't know why they do it this way, but

### You (2025-06-20T17:20:08.801Z)

like, it has to get

### Guest (2025-06-20T17:20:09.484Z)

they get allocated out. So, basically, you have

### You (2025-06-20T17:20:11.231Z)

You have it.

### Guest (2025-06-20T17:20:12.814Z)

like, in house dining. You have it you think about a hotel, there's usually, like, a cafeteria in the hotel where they have, like, cooks and they cook food, whatever, for the employees.

### You (2025-06-20T17:20:21.001Z)

Over the for every month, they

### Guest (2025-06-20T17:20:22.954Z)

So the cost of that whole thing

### You (2025-06-20T17:20:23.351Z)

they will allocate out to each department.

### Guest (2025-06-20T17:20:24.944Z)

over the for every month

### You (2025-06-20T17:20:25.391Z)

Based on the number of employees in the department.

### Guest (2025-06-20T17:20:26.784Z)

they they will allocate out to each department based on the number of employees in the department.

### You (2025-06-20T17:20:27.891Z)

Got it. So that answers the question, then two, because I when you were in Hawaii, I started working on expense breakdown into the categories and subcategories to put into that expense section of the model. And those items that you just mentioned, the employee benefits and how dining, I couldn't really they they didn't seem to tie to any of them. So that makes sense that there would be an allocated expense. What was the third one? You said employee benefits, in house dining, and was the other one? Employee meals? In house laundry. So laundry dining benefits. Oh, in house dining. Okay.

### Guest (2025-06-20T17:21:05.404Z)

House laundry.

### You (2025-06-20T17:21:05.931Z)

So and then in house laundry.

### Guest (2025-06-20T17:21:06.554Z)

So laundry, dining benefits.

### You (2025-06-20T17:21:08.001Z)

Yeah.

### Guest (2025-06-20T17:21:08.624Z)

Yeah.

### You (2025-06-20T17:21:09.541Z)

Okay. So did I so is it in house dining or employee dining? Guess just put employee dining I can I can look it up and see how it was in your spreadsheet? But yeah. Okay.

### Guest (2025-06-20T17:21:23.154Z)

I guess just put employee dining.

### You (2025-06-20T17:21:24.601Z)

Alright. So that makes sense. So so I think I need to get rid of the allocated out of this motor.

### Guest (2025-06-20T17:21:32.684Z)

Or you can just you could rename this

### You (2025-06-20T17:21:34.271Z)

Oh, yeah. I'm just a minute. But anyway, realistically,

### Guest (2025-06-20T17:21:37.904Z)

undistributed. But

### You (2025-06-20T17:21:38.761Z)

every hotel will I mean, a hotel select service, you have limited service hotel might not actually have ever

### Guest (2025-06-20T17:21:41.354Z)

mean, realistically, every hotel mean, a hotel a select service, you know, limited service hotel might not have

### You (2025-06-20T17:21:46.131Z)

It might not even have his twentieth, but

### Guest (2025-06-20T17:21:47.344Z)

food and beverage. It might not have other operated

### You (2025-06-20T17:21:48.481Z)

it is going to have

### Guest (2025-06-20T17:21:49.804Z)

It might not even have miscellaneous, but

### You (2025-06-20T17:21:50.371Z)

ops and maintenance, administrative, sales, marketing, information technology, and utility.

### Guest (2025-06-20T17:21:52.414Z)

it is going to have ops and maintenance, administrative, sales and marketing, information and technology, and utilities.

### You (2025-06-20T17:21:55.341Z)

We can't run a hotel without those departments regardless. So Right. So They don't

### Guest (2025-06-20T17:21:59.274Z)

You can't run a hotel without those departments regardless. So

### You (2025-06-20T17:22:00.551Z)

need you guys can't get rid of this entirely because they they don't they don't need

### Guest (2025-06-20T17:22:02.734Z)

they almost don't need you could almost, yeah, get get rid of

### You (2025-06-20T17:22:04.501Z)

That's what I was thinking. I think we can get rid of the allocated.

### Guest (2025-06-20T17:22:06.114Z)

this entirely because they they don't they almost don't need to be checked. Like, they are so

### You (2025-06-20T17:22:09.421Z)

Yeah. Just go ahead and cancel out of that and go back to the valuation tab.

### Guest (2025-06-20T17:22:10.354Z)

yeah.

### You (2025-06-20T17:22:18.231Z)

Then go ahead and click on the expense. There. Click on the undistributed expense. And go ahead and just click on that to navigate down. So here is where we have the property operations and maintenance admin info sales and marketing. And if you scroll down, you got utilities there. Yep. Yep. Okay.

### Guest (2025-06-20T17:22:43.774Z)

Yeah.

### You (2025-06-20T17:22:44.181Z)

And so then you've got your non allocated

### Guest (2025-06-20T17:22:45.644Z)

Yep.

### You (2025-06-20T17:22:48.401Z)

expenses below that. Your management fees, real estate taxes. So where would those

### Guest (2025-06-20T17:22:54.404Z)

Yeah.

### You (2025-06-20T17:22:56.051Z)

allocated expenses go for the employee benefits, employee dining, and and out laundry? I I honestly don't think you need me to include them. Okay.

### Guest (2025-06-20T17:23:05.034Z)

I don't I honestly don't think you even need to include them.

### You (2025-06-20T17:23:05.121Z)

Yeah. Because they are again, like, if you if you were to get it in our system, like, if you go and look at the data,

### Guest (2025-06-20T17:23:07.824Z)

Yeah. Because they are, again, like,

### You (2025-06-20T17:23:11.311Z)

they

### Guest (2025-06-20T17:23:11.484Z)

if you if you were to even in our system, like, if you go look at the data,

### You (2025-06-20T17:23:11.921Z)

they department is it should always be zero. Right? Because the total expenses you incur for

### Guest (2025-06-20T17:23:15.394Z)

they the the department is almost always it should always be zero.

### You (2025-06-20T17:23:18.111Z)

employee dining

### Guest (2025-06-20T17:23:19.164Z)

Right? Because the total expenses you incur for

### You (2025-06-20T17:23:19.351Z)

because it it employee dining department, you're allocating it out, you know,

### Guest (2025-06-20T17:23:22.134Z)

employee dining because in the in the employee dining department,

### You (2025-06-20T17:23:23.541Z)

75% of room, 10% or 20% to

### Guest (2025-06-20T17:23:25.874Z)

you're allocating it out, you know,

### You (2025-06-20T17:23:27.571Z)

to the network.

### Guest (2025-06-20T17:23:27.674Z)

75% to rooms, 10% or 20% to food and beverage, and the rest

### You (2025-06-20T17:23:28.111Z)

And the rest to, like, other operator or whatever. Right? So departmental expenses are are

### Guest (2025-06-20T17:23:32.614Z)

to, like, other operated or whatever. Right? So the departmental expenses are are

### You (2025-06-20T17:23:32.941Z)

in department are zero. Okay. And the actual cost is ends up being

### Guest (2025-06-20T17:23:36.744Z)

in the department are zero, and the actual cost is ends up being

### You (2025-06-20T17:23:39.231Z)

one of the other parts. Gotcha. So just

### Guest (2025-06-20T17:23:41.484Z)

being born in one of the other departments.

### You (2025-06-20T17:23:41.901Z)

need that'd really good included. Right. So so back on that mobile, I can just take allocated off.

### Guest (2025-06-20T17:23:44.534Z)

So it doesn't need doesn't even really need to be included.

### You (2025-06-20T17:23:47.191Z)

Sounds good. So just adding

### Guest (2025-06-20T17:23:47.674Z)

Yes.

### You (2025-06-20T17:23:49.981Z)

noise Okay.

### Guest (2025-06-20T17:23:51.924Z)

Think you could take allocated off.

### You (2025-06-20T17:23:52.021Z)

Okay.

### Guest (2025-06-20T17:23:53.444Z)

Yeah.

### You (2025-06-20T17:23:55.701Z)

Okay.

### Guest (2025-06-20T17:23:56.064Z)

Okay. Cool.

### You (2025-06-20T17:23:56.131Z)

Cool. I'll put the notes here. So

### Guest (2025-06-20T17:24:00.504Z)

I will put a note here. So

### You (2025-06-20T17:24:16.131Z)

Okay.

### Guest (2025-06-20T17:24:20.184Z)

k.

### You (2025-06-20T17:24:20.671Z)

Otherwise, yeah,

### Guest (2025-06-20T17:24:22.934Z)

Then otherwise, yeah, I mean, these all

### You (2025-06-20T17:24:24.931Z)

moving.

### Guest (2025-06-20T17:24:27.904Z)

we talked about moving moving this Yeah. K.

### You (2025-06-20T17:24:50.431Z)

And then r d like, on

### Guest (2025-06-20T17:24:54.444Z)

And then

### You (2025-06-20T17:24:55.131Z)

and I did you said your your the thing that you Yeah. Yeah. S r a. Thank you.

### Guest (2025-06-20T17:24:55.934Z)

on these like, on the predictions and I did it. I answered your

### You (2025-06-20T17:25:00.041Z)

Yeah.

### Guest (2025-06-20T17:25:00.664Z)

your the thing that you

### You (2025-06-20T17:25:00.861Z)

So I did and, basically, what I was gonna say there was that

### Guest (2025-06-20T17:25:02.654Z)

the survey. Yeah. So I did.

### You (2025-06-20T17:25:05.911Z)

I think

### Guest (2025-06-20T17:25:06.274Z)

Basically, what I was gonna say, though, is that

### You (2025-06-20T17:25:07.421Z)

all of them should have, like,

### Guest (2025-06-20T17:25:10.074Z)

I think

### You (2025-06-20T17:25:11.511Z)

I guess, like, working with this, like,

### Guest (2025-06-20T17:25:11.874Z)

all of them should have, like,

### You (2025-06-20T17:25:13.911Z)

there's this basically the amount

### Guest (2025-06-20T17:25:15.684Z)

I guess, like, looking at this, like, you have this this is basically the amount

### You (2025-06-20T17:25:15.761Z)

here. So could probably go I guess, maybe go on.

### Guest (2025-06-20T17:25:19.784Z)

here. So

### You (2025-06-20T17:25:20.491Z)

And then p this is

### Guest (2025-06-20T17:25:21.534Z)

which could probably go on, I guess, maybe go on top.

### You (2025-06-20T17:25:22.861Z)

Barack. Room. Probably

### Guest (2025-06-20T17:25:24.604Z)

And then p this is

### You (2025-06-20T17:25:26.801Z)

and percent of revenues. So we

### Guest (2025-06-20T17:25:27.084Z)

her occupied room. Probably wanna do it on per available room.

### You (2025-06-20T17:25:29.931Z)

each the

### Guest (2025-06-20T17:25:31.424Z)

And percent of revenue. So each of them can have the same

### You (2025-06-20T17:25:35.821Z)

options for projecting.

### Guest (2025-06-20T17:25:35.904Z)

categories, like the same options for projecting.

### You (2025-06-20T17:25:41.471Z)

I think I did say my feedback if no

### Guest (2025-06-20T17:25:45.214Z)

I think

### You (2025-06-20T17:25:45.701Z)

like percent of revenue

### Guest (2025-06-20T17:25:46.294Z)

I did say in my feedback that

### You (2025-06-20T17:25:48.371Z)

for revenues.

### Guest (2025-06-20T17:25:48.764Z)

I felt like

### You (2025-06-20T17:25:49.761Z)

Right? I'm gonna say food and beverage revenue is 20% of

### Guest (2025-06-20T17:25:50.364Z)

percent of revenue for revenues

### You (2025-06-20T17:25:53.201Z)

yeah. I guess to me, when we talk about it,

### Guest (2025-06-20T17:25:53.974Z)

If I'm gonna say food and beverage revenue is 20% of

### You (2025-06-20T17:25:56.291Z)

usually of total revenue.

### Guest (2025-06-20T17:25:57.334Z)

I guess to me, when we talk about it,

### You (2025-06-20T17:25:57.831Z)

You're like, 60%

### Guest (2025-06-20T17:26:00.354Z)

it's usually of total revenue. You're like, oh, rooms is 60% of revenue, food and beverage

### You (2025-06-20T17:26:01.431Z)

other. That's

### Guest (2025-06-20T17:26:05.084Z)

thirty. Other miscellaneous are ten.

### You (2025-06-20T17:26:06.551Z)

Mhmm. I you know, it's not

### Guest (2025-06-20T17:26:08.784Z)

That's how I usually think of it.

### You (2025-06-20T17:26:08.821Z)

I don't know how that works because

### Guest (2025-06-20T17:26:10.754Z)

Mathematically, I don't know how that works because

### You (2025-06-20T17:26:11.111Z)

if you're putting percent here, and it's calculated as percent of total

### Guest (2025-06-20T17:26:15.294Z)

if you're putting a percentage here, and it's calculating a per as a percentage of total, but you haven't actually finished your total revenue yet. That seems a little bit backwards, but

### You (2025-06-20T17:26:25.461Z)

Yeah. Yeah. That that's why I was

### Guest (2025-06-20T17:26:25.614Z)

I don't know. If that matters or not.

### You (2025-06-20T17:26:27.841Z)

wondering. I I thought for the revenue, for step. First.

### Guest (2025-06-20T17:26:36.674Z)

Expenses, it's easier because you will have done the preceding step

### You (2025-06-20T17:26:36.961Z)

So you put it on. Of it before you do a. Right. So expense as a percent of revenue.

### Guest (2025-06-20T17:26:40.134Z)

first. So you will have put in rooms revenue before you do rooms expenses.

### You (2025-06-20T17:26:43.481Z)

Right. If you do,

### Guest (2025-06-20T17:26:44.414Z)

So rooms expense as a percent of rooms revenue is

### You (2025-06-20T17:26:44.501Z)

screw that revenue

### Guest (2025-06-20T17:26:47.174Z)

very easy. If you do food and beverage revenue as a percent of total revenue, but you haven't calculated

### You (2025-06-20T17:26:49.931Z)

Did I have that in the forms? I thought I took that off of the

### Guest (2025-06-20T17:26:52.334Z)

total revenue yet, then it gets a little bit weird.

### You (2025-06-20T17:26:52.701Z)

I thought I took that

### Guest (2025-06-20T17:26:58.374Z)

I think you had expense

### You (2025-06-20T17:26:58.621Z)

Alright. Yeah. I I knew that yeah. I knew revenue was only

### Guest (2025-06-20T17:27:00.554Z)

I think you had expenses in there too, but yeah.

### You (2025-06-20T17:27:03.331Z)

per per per available room.

### Guest (2025-06-20T17:27:05.204Z)

But, I mean, I

### You (2025-06-20T17:27:06.801Z)

Or per occupied room. I don't I don't remember. It seems like Diane always says it should be on per occupied room. And that's you know, you and I already had a conversation once about preoccupied room and ADR and interchangeable terms and what's what. Yeah.

### Guest (2025-06-20T17:27:26.974Z)

Yeah.

### You (2025-06-20T17:27:28.891Z)

Is good. Yeah.

### Guest (2025-06-20T17:27:30.984Z)

No. But I think you have the way you have it here is good.

### You (2025-06-20T17:27:33.231Z)

I think

### Guest (2025-06-20T17:27:33.714Z)

Per occupied room per year.

### You (2025-06-20T17:27:34.271Z)

yeah. So, like, you know, the the

### Guest (2025-06-20T17:27:36.784Z)

I think yeah. So, like,

### You (2025-06-20T17:27:37.441Z)

sale

### Guest (2025-06-20T17:27:39.454Z)

you know,

### You (2025-06-20T17:27:39.721Z)

put

### Guest (2025-06-20T17:27:40.534Z)

the the whole thing of you know, and beverage revenue, if you wanted to calculate it as a percentage of

### You (2025-06-20T17:27:46.151Z)

revenue are you using? Yeah.

### Guest (2025-06-20T17:27:47.524Z)

of

### You (2025-06-20T17:27:48.091Z)

I

### Guest (2025-06-20T17:27:48.954Z)

revenue. Right? Like, what

### You (2025-06-20T17:27:49.561Z)

I was able to see what

### Guest (2025-06-20T17:27:50.494Z)

revenue are you using?

### You (2025-06-20T17:27:51.631Z)

action item.

### Guest (2025-06-20T17:27:51.914Z)

I was

### You (2025-06-20T17:27:52.241Z)

I five.

### Guest (2025-06-20T17:27:54.104Z)

I guess we'll just see what Mark and Diane say. Right? Because, like, I was I would think it would be you would say total revenue, but then mathematically,

### You (2025-06-20T17:27:57.671Z)

That becomes complicated because have it.

### Guest (2025-06-20T17:28:01.604Z)

think that becomes complicated because you

### You (2025-06-20T17:28:01.871Z)

I I need to go back and change that. I I see that that's correct.

### Guest (2025-06-20T17:28:03.734Z)

haven't actually calculated total revenue yet. So

### You (2025-06-20T17:28:06.411Z)

I didn't even okay. Yeah. I didn't I didn't even really ask I don't know why I did that. I guess I had brain fart. I knew revenue was just I think I think

### Guest (2025-06-20T17:28:18.794Z)

Well, I think we have said that. I think I think we have said that. Like, I think I probably even

### You (2025-06-20T17:28:22.851Z)

But, yeah, you're right. You can't you can't do a percentage of revenue if you don't have the total revenue

### Guest (2025-06-20T17:28:24.834Z)

told you that that was how we look at it and think of it.

### You (2025-06-20T17:28:27.821Z)

and it's a circular. Yeah. So Yes. You can go through your efforts. Yeah. Or

### Guest (2025-06-20T17:28:31.184Z)

Yeah.

### You (2025-06-20T17:28:32.581Z)

Yeah. Be complete if you put

### Guest (2025-06-20T17:28:33.534Z)

Yes. You get a kinda circular reference or or at least

### You (2025-06-20T17:28:36.361Z)

percent.

### Guest (2025-06-20T17:28:36.694Z)

it would be incomplete if you put in, you know, I want food and beverage revenue to be 20% the number that comes out would be totally different

### You (2025-06-20T17:28:36.801Z)

Then Yeah. Yeah.

### Guest (2025-06-20T17:28:44.044Z)

when you put it in.

### You (2025-06-20T17:28:44.341Z)

Okay. Alright. Awesome. I'll just send an email to the other two and tell them to

### Guest (2025-06-20T17:28:45.444Z)

Than after you started putting in these other things.

### You (2025-06-20T17:28:48.471Z)

disregard the revenue portion just when we do the expense and below.

### Guest (2025-06-20T17:28:49.024Z)

So

### You (2025-06-20T17:28:52.171Z)

On the Yeah. Form. Okay.

### Guest (2025-06-20T17:28:54.854Z)

Yeah. And as far as and then so allocated here, you can also get rid of. Right?

### You (2025-06-20T17:29:05.731Z)

Yeah. Yeah.

### Guest (2025-06-20T17:29:06.904Z)

I'll need that.

### You (2025-06-20T17:29:07.131Z)

And

### Guest (2025-06-20T17:29:08.334Z)

Yeah.

### You (2025-06-20T17:29:08.761Z)

yeah. And here are

### Guest (2025-06-20T17:29:10.344Z)

And then yeah. And then what I was gonna suggest on all of these so here on

### You (2025-06-20T17:29:13.351Z)

you you set up

### Guest (2025-06-20T17:29:14.974Z)

all of these, you have one you you set it up to select one for all. But I think it would be this is probably gonna be more work, so I apologize in advance. But

### You (2025-06-20T17:29:25.581Z)

Exactly why I sent the form.

### Guest (2025-06-20T17:29:26.884Z)

do one for each section one for each department. Right? So

### You (2025-06-20T17:29:27.851Z)

Is to out you know, is is there just one rule of thumb where all expenses

### Guest (2025-06-20T17:29:30.994Z)

oh,

### You (2025-06-20T17:29:34.151Z)

gonna be based on the POR or on you have to

### Guest (2025-06-20T17:29:41.684Z)

I I think it's more or less one yeah. It's like one yeah. It's in the it it would be more or less one rule of, like, you're gonna do POR PAR, percent of revenue, whatever. Like, you're gonna there's the same rough grouping

### You (2025-06-20T17:29:51.551Z)

that

### Guest (2025-06-20T17:29:54.614Z)

categories or options that you might use to forecast, but they're gonna be different.

### You (2025-06-20T17:29:57.521Z)

system.

### Guest (2025-06-20T17:29:58.864Z)

I might choose to do rooms expense on a POR basis and then food and beverage expense on a percent of revenue basis. And then other operated depending on what's in the other operating department, Right? Like,

### You (2025-06-20T17:30:09.381Z)

Right? Whatever.

### Guest (2025-06-20T17:30:10.404Z)

I might choose to do it on a POR, PAR, percent of revenue, amount,

### You (2025-06-20T17:30:13.221Z)

People look at it, but it's gonna

### Guest (2025-06-20T17:30:14.034Z)

right, whatever. Like,

### You (2025-06-20T17:30:14.431Z)

unique to each.

### Guest (2025-06-20T17:30:15.164Z)

there are a lot of different

### You (2025-06-20T17:30:16.861Z)

Okay.

### Guest (2025-06-20T17:30:17.304Z)

ways one might look at it, but it's gonna be unique to each

### You (2025-06-20T17:30:17.941Z)

So what what I can do it's gonna take a little bit of work

### Guest (2025-06-20T17:30:19.964Z)

row essentially.

### You (2025-06-20T17:30:22.521Z)

but right there, in the section headers, you know, so for your room's expense, I would just add a drop down there you know, right above the the input row. So Yeah. So that I send that same thing other expense or food and beverage

### Guest (2025-06-20T17:30:40.854Z)

Yeah.

### You (2025-06-20T17:30:44.231Z)

drop down, other operated drop down. That's just a blank row that's shaded gray. It just Yeah. So okay. Yeah. That's not that's not too difficult.

### Guest (2025-06-20T17:30:54.134Z)

Yeah. Yeah. I'll put a note here for that.

### You (2025-06-20T17:31:11.111Z)

It. You can just

### Guest (2025-06-20T17:31:11.484Z)

And then order wise, I was gonna say

### You (2025-06-20T17:31:14.371Z)

That's

### Guest (2025-06-20T17:31:15.934Z)

you should just always make it rooms, f and b, other operated, missed Saleh. So And then in the undistributed, it would always be admin and general. Info and tech. Sales and marketing, repairs,

### You (2025-06-20T17:31:51.911Z)

Yeah.

### Guest (2025-06-20T17:31:54.464Z)

maintenance,

### You (2025-06-20T17:31:56.291Z)

Not

### Guest (2025-06-20T17:31:56.524Z)

and Not everybody does it this way, but that's the way that the USally guidebook says to do it. So Marriott is the worst offender. They do it in some really

### You (2025-06-20T17:32:04.661Z)

the worst Yeah. But this is not

### Guest (2025-06-20T17:32:09.774Z)

some different order.

### You (2025-06-20T17:32:10.371Z)

Like,

### Guest (2025-06-20T17:32:10.944Z)

But this is the way Sally says to do it, so I feel like we should just stick to that. Most like, I would say probably, like,

### You (2025-06-20T17:32:14.491Z)

Okay. Yeah.

### Guest (2025-06-20T17:32:15.914Z)

two thirds of the operators do it in this order. So it's it's the majority. Yep. And then

### You (2025-06-20T17:32:19.841Z)

Good.

### Guest (2025-06-20T17:32:22.454Z)

yeah. I think you have this. This is good.

### You (2025-06-20T17:32:24.501Z)

Yeah.

### Guest (2025-06-20T17:32:27.554Z)

Yeah. I think okay. So this is all good. So and then, yeah, as far as expenses,

### You (2025-06-20T17:32:32.281Z)

Yeah. Right.

### Guest (2025-06-20T17:32:32.544Z)

you can do the same here. Right? Room's expense, you can bring this up a level. Right? Allocate, it can go away, and then undistributed

### You (2025-06-20T17:32:39.741Z)

Mean,

### Guest (2025-06-20T17:32:42.804Z)

I mean, it can be indented like this, or you could bring it up a level either way. Whatever's whatever's easier.

### You (2025-06-20T17:32:50.541Z)

And

### Guest (2025-06-20T17:32:52.444Z)

And then nonoperating, yeah, think this is good.

### You (2025-06-20T17:32:53.201Z)

k. Alright. Nothing earth shattering.

### Guest (2025-06-20T17:32:57.404Z)

Yeah. Cool. Okay. Yeah. I didn't think it would be, but I I wanted to get

### You (2025-06-20T17:33:06.221Z)

Yep. It

### Guest (2025-06-20T17:33:07.674Z)

you know, bring it up to you, you know, sooner rather than later so that it, you know, was

### You (2025-06-20T17:33:07.931Z)

can play maybe. Yeah. So let's go back to

### Guest (2025-06-20T17:33:11.484Z)

didn't

### You (2025-06-20T17:33:12.241Z)

the whole POR, PAR, ADR conversation.

### Guest (2025-06-20T17:33:12.664Z)

conflict with anything you were already doing.

### You (2025-06-20T17:33:17.431Z)

Are we

### Guest (2025-06-20T17:33:19.884Z)

Mhmm.

### You (2025-06-20T17:33:20.271Z)

using the right ones with POR? Because I remember you mentioning the only difference between them is one of them shows all occupied rooms and then the other is the occupied less the free rooms. Right. And I have not seen anything in any of these Excel spreadsheets

### Guest (2025-06-20T17:33:45.024Z)

Correct.

### You (2025-06-20T17:33:46.871Z)

where it breaks out the free rooms. So it seems Yeah. That's a date that's data we

### Guest (2025-06-20T17:33:51.714Z)

Yeah.

### You (2025-06-20T17:33:52.391Z)

have. Yeah.

### Guest (2025-06-20T17:33:55.614Z)

And that's yeah. In in a lot of the

### You (2025-06-20T17:33:57.841Z)

Your

### Guest (2025-06-20T17:34:00.924Z)

like, the models that you're probably gonna see from Diane and Mark, like,

### You (2025-06-20T17:34:01.781Z)

you're such a Yeah.

### Guest (2025-06-20T17:34:04.734Z)

because comp rooms are just such a small like, like, they're not really consequential. Right? So people just either they either ignore them or they just include them in the rooms that are sold and calculate ADR that way.

### You (2025-06-20T17:34:19.361Z)

Right.

### Guest (2025-06-20T17:34:21.074Z)

Again, it's like because if you have

### You (2025-06-20T17:34:22.601Z)

No. Here.

### Guest (2025-06-20T17:34:24.014Z)

right, like, here you have numb the number of rooms that you sold might be you know, 100,000 rooms or whatever. Right? And you have couple 100, know, comp rooms, it's just, like, not gonna move the needle.

### You (2025-06-20T17:34:33.191Z)

Okay.

### Guest (2025-06-20T17:34:36.684Z)

So people don't track it. When you get to when you get to, like, asset management, and, like, operating the hotel, like, more, you know, day to day, it is a 100% separated. Like,

### You (2025-06-20T17:34:42.791Z)

Like SDR I just it's deaf.

### Guest (2025-06-20T17:34:47.874Z)

STR separates it very clearly. Like, it is it is definitely, like,

### You (2025-06-20T17:34:48.971Z)

Thing. That is They they have a different thing for acquisition purposes. It's

### Guest (2025-06-20T17:34:52.564Z)

a different thing that is you. That they calculate differently. But, again, for acquisitions purposes, it's like

### You (2025-06-20T17:34:57.411Z)

the

### Guest (2025-06-20T17:34:58.484Z)

the people doing acquisitions and underwriting are like it's just not that

### You (2025-06-20T17:34:58.851Z)

Yeah. Included here.

### Guest (2025-06-20T17:35:01.554Z)

doesn't doesn't really make a difference. So

### You (2025-06-20T17:35:02.321Z)

I think Okay.

### Guest (2025-06-20T17:35:03.464Z)

I I don't know that we need to include it here. I think

### You (2025-06-20T17:35:06.261Z)

Yeah.

### Guest (2025-06-20T17:35:08.594Z)

we can use one in the same

### You (2025-06-20T17:35:09.271Z)

Can

### Guest (2025-06-20T17:35:11.144Z)

like, the number of rooms sold,

### You (2025-06-20T17:35:12.391Z)

Good. For right now,

### Guest (2025-06-20T17:35:13.874Z)

can just be the same as the number of room rooms occupied. For right now, and that is can be used to calculate ADR

### You (2025-06-20T17:35:18.901Z)

it's like

### Guest (2025-06-20T17:35:20.814Z)

and everything on a POR basis.

### You (2025-06-20T17:35:21.791Z)

If you want to take a read

### Guest (2025-06-20T17:35:23.334Z)

As as far as, like, thinking ahead,

### You (2025-06-20T17:35:26.401Z)

I provided

### Guest (2025-06-20T17:35:26.624Z)

if you wanted to create

### You (2025-06-20T17:35:27.381Z)

are separated out so you can see if I've sold

### Guest (2025-06-20T17:35:28.774Z)

like, I think in the data that I provided to you, they are separated out.

### You (2025-06-20T17:35:30.601Z)

just the copper. Separately.

### Guest (2025-06-20T17:35:33.104Z)

So you'll see rooms sold, and then you'll see comp rooms.

### You (2025-06-20T17:35:34.151Z)

So if you wanna create separate lines for them,

### Guest (2025-06-20T17:35:36.324Z)

Separately.

### You (2025-06-20T17:35:37.461Z)

like, in the packet with data model,

### Guest (2025-06-20T17:35:39.004Z)

So if you wanna create separate lines for them, like,

### You (2025-06-20T17:35:39.421Z)

Yeah. It could be the same number. Right? Now. Their complex should always be zero for now. Like, that's fine. It just

### Guest (2025-06-20T17:35:42.264Z)

in the back end, like, data model, and they can just be the same number right now. They're conference can just always be zero for now. Like, that's fine. They can just be the same.

### You (2025-06-20T17:35:48.211Z)

you know, it's not it's not a big Right.

### Guest (2025-06-20T17:35:51.774Z)

It's just not you know what I mean? It's just not it's not a big

### You (2025-06-20T17:35:52.711Z)

Alright. So is everybody in agreement then that for now, the proof of concept,

### Guest (2025-06-20T17:35:56.034Z)

thing right now.

### You (2025-06-20T17:35:58.631Z)

you are budgeting the expenses, is POR the correct term and the correct Yes.

### Guest (2025-06-20T17:36:10.124Z)

Yes. PLR is is yeah. The way you have, like, this use of PLR here is a 100% correct. Everybody will recognize that. That's a

### You (2025-06-20T17:36:12.731Z)

That's that's what I had to change because I originally had ADR there. And I just wanna make sure. Okay. Okay.

### Guest (2025-06-20T17:36:18.654Z)

yeah.

### You (2025-06-20T17:36:19.161Z)

Yeah.

### Guest (2025-06-20T17:36:23.164Z)

Yeah. ADR is only gonna be used for this piece up here calculating, you know,

### You (2025-06-20T17:36:27.091Z)

Alright. And else, you know, we're talking about with

### Guest (2025-06-20T17:36:29.054Z)

revenue over room sold.

### You (2025-06-20T17:36:30.461Z)

we talk about

### Guest (2025-06-20T17:36:31.804Z)

And then anything else, we we, you know, we talk about when it's we talk about

### You (2025-06-20T17:36:32.591Z)

using you know, it's, yeah, per occupied rates. Yeah. So here's another question.

### Guest (2025-06-20T17:36:35.904Z)

using you know, it's, yeah, it's preoccupied rooms.

### You (2025-06-20T17:36:39.491Z)

Key metrics, I just added that yesterday.

### Guest (2025-06-20T17:36:40.604Z)

POR.

### You (2025-06-20T17:36:41.631Z)

And Mark had mentioned that people like to look at them both on a financial and a percent on a on a on a money and on a percent. Basis. So I'm looking at that. Yeah. If you go back up to the valuation there. So up at the very top, he mentioned that most of those are based on a percentage of total revenue. So, obviously, if we were to we talked about having a toggle. Where they can view it one way or the other. Right? So if I talk when I say I wanna see it on percentage, seems like total revenue would then always be 100%, then total expenses, gross operating profit, it'd be

### Guest (2025-06-20T17:37:25.304Z)

Yeah.

### You (2025-06-20T17:37:32.721Z)

would be based on a percentage of the total revenue. Is that your understanding? That's yeah. That's correct. Okay.

### Guest (2025-06-20T17:37:41.204Z)

That's yeah. That's correct.

### You (2025-06-20T17:37:42.881Z)

He also did not ask for total expenses. I added that in based on my previous experience. If in the hotel industry, total expenses is not something that should be up there in the key metrics I can take that out. What do you think I think I think you say that.

### Guest (2025-06-20T17:38:04.604Z)

I think you can

### You (2025-06-20T17:38:05.671Z)

Because I think the landscape on audio will be working with us on our laptop.

### Guest (2025-06-20T17:38:07.704Z)

I think you can take it out because I think the landscape a lot of people are gonna be looking at this on a on a laptop?

### You (2025-06-20T17:38:13.821Z)

Very important.

### Guest (2025-06-20T17:38:14.924Z)

Where it's small.

### You (2025-06-20T17:38:15.691Z)

Yeah.

### Guest (2025-06-20T17:38:16.194Z)

I think landscape is is gonna be

### You (2025-06-20T17:38:16.321Z)

And also, they are doing many many different, like,

### Guest (2025-06-20T17:38:18.524Z)

very important.

### You (2025-06-20T17:38:20.231Z)

break that

### Guest (2025-06-20T17:38:20.324Z)

And, also,

### You (2025-06-20T17:38:21.171Z)

and categorizations of expenses.

### Guest (2025-06-20T17:38:21.894Z)

there are many, many different, like,

### You (2025-06-20T17:38:23.531Z)

Right. So

### Guest (2025-06-20T17:38:24.944Z)

breakdowns and and categorizations of expenses.

### You (2025-06-20T17:38:27.781Z)

EBITDA, right, like, so I think

### Guest (2025-06-20T17:38:28.134Z)

So, right, between, you know, revenue GOP, EBITDA. Right? Like so I think users will know they'll know the difference you know, they'll know

### You (2025-06-20T17:38:37.291Z)

look at those expenses. Okay. Alright. So then the question is,

### Guest (2025-06-20T17:38:38.864Z)

what goes into GOP and what goes into EBITDA. Like, they'll they'll be able to look at those expenses.

### You (2025-06-20T17:38:42.621Z)

if we take expenses out, what I could do is rather than have a toggle that goes back and forth, because then essentially all we're looking at on a percentage basis would be the GOP and the it'd be, we wouldn't be looking at anything else. Yeah. So it's so I could just simply add a a row

### Guest (2025-06-20T17:39:05.134Z)

Yeah.

### You (2025-06-20T17:39:05.551Z)

between, underneath each of those. So you'll have gross operating profit dollar, gross operating profit percent, and then same thing for EBITDA that you'd have the dollar and percent. So, essentially, we would Yeah.

### Guest (2025-06-20T17:39:17.824Z)

Yeah.

### You (2025-06-20T17:39:18.511Z)

Adding one. That would be useful. Yeah. It sounds good. Useful.

### Guest (2025-06-20T17:39:21.544Z)

Yeah. I think

### You (2025-06-20T17:39:21.781Z)

Okay. Alright.

### Guest (2025-06-20T17:39:23.204Z)

that would be useful.

### You (2025-06-20T17:39:24.431Z)

Get to the

### Guest (2025-06-20T17:39:24.644Z)

Yeah. I think that would be useful. I mean, if you really wanted to

### You (2025-06-20T17:39:27.381Z)

umbrella. To

### Guest (2025-06-20T17:39:29.054Z)

get fancy

### You (2025-06-20T17:39:30.401Z)

That

### Guest (2025-06-20T17:39:30.824Z)

if you added us a row below GOP and a row below EBITDA,

### You (2025-06-20T17:39:31.141Z)

would be they'd be toggle between the GOP percent

### Guest (2025-06-20T17:39:35.094Z)

that

### You (2025-06-20T17:39:35.381Z)

of

### Guest (2025-06-20T17:39:35.834Z)

would be they could be toggled between

### You (2025-06-20T17:39:36.191Z)

revenue GOP

### Guest (2025-06-20T17:39:38.244Z)

GOP percent

### You (2025-06-20T17:39:38.981Z)

or GOP

### Guest (2025-06-20T17:39:40.014Z)

of revenue, GOP

### You (2025-06-20T17:39:41.271Z)

That would be you know, like,

### Guest (2025-06-20T17:39:42.434Z)

POR, or g o p

### You (2025-06-20T17:39:43.811Z)

that would be useful. But

### Guest (2025-06-20T17:39:44.884Z)

p a r.

### You (2025-06-20T17:39:45.111Z)

it but have to.

### Guest (2025-06-20T17:39:46.074Z)

That would be you know, like a that would be useful. But it but it doesn't have to be again, I don't know how much having just the margin, having GOP percent of revenue and EBITDA percent of revenue is

### You (2025-06-20T17:39:53.581Z)

Yeah. Let's let's do that for a start.

### Guest (2025-06-20T17:39:56.894Z)

would just be that would be, again, yeah, very, very helpful.

### You (2025-06-20T17:39:58.751Z)

Yeah. Because if you take a look at the revenue and expense tabs, it is possible to use a

### Guest (2025-06-20T17:40:00.774Z)

Okay.

### You (2025-06-20T17:40:03.271Z)

caret.

### Guest (2025-06-20T17:40:03.564Z)

Yeah.

### You (2025-06-20T17:40:03.811Z)

To expand. Know? So if you go up there and click on, like, the, revenue no. At the top of that summit, summary table. Right? The where it says yeah. So you can see that we got the total other operated,

### Guest (2025-06-20T17:40:16.524Z)

Oh, okay.

### You (2025-06-20T17:40:18.801Z)

But, you know, if you wanna see all of the detail, if you

### Guest (2025-06-20T17:40:19.474Z)

I see.

### You (2025-06-20T17:40:21.721Z)

click on that total other operated revenue caret, it'll drop down and show more rows. But what I was talking.

### Guest (2025-06-20T17:40:29.824Z)

Got it.

### You (2025-06-20T17:40:29.931Z)

That's what I was talking about earlier. Yeah. If you do that, it just it just pushes everything else below it down.

### Guest (2025-06-20T17:40:34.654Z)

Yeah. I see. Oh, I see.

### You (2025-06-20T17:40:37.891Z)

So having those I see. Fine, So we could Okay. Yeah. For the key metrics if if we end up

### Guest (2025-06-20T17:40:42.764Z)

Okay. I see.

### You (2025-06-20T17:40:44.571Z)

having to add more to it.

### Guest (2025-06-20T17:40:44.664Z)

Okay. Yeah. Yeah. Yeah.

### You (2025-06-20T17:40:47.811Z)

Got

### Guest (2025-06-20T17:40:53.154Z)

Got it. No. No. No. That makes that's okay. Now I understand more how this is how this can be used. Okay.

### You (2025-06-20T17:40:53.241Z)

Yeah.

### Guest (2025-06-20T17:40:57.794Z)

Yeah. No. I think just just having a GOP percent of revenue and EBITDA percent of revenue

### You (2025-06-20T17:41:01.531Z)

And if we take out the total expense row, then we're only adding in

### Guest (2025-06-20T17:41:02.444Z)

would be, yeah, would be sufficient for

### You (2025-06-20T17:41:05.191Z)

a net one row, which is not a big deal.

### Guest (2025-06-20T17:41:05.384Z)

key metrics. Yeah.

### You (2025-06-20T17:41:09.781Z)

Yeah. Okay. Cool. Okay.

### Guest (2025-06-20T17:41:14.534Z)

Yeah.

### You (2025-06-20T17:41:18.961Z)

Go. Very helpful. I appreciate it.

### Guest (2025-06-20T17:41:20.204Z)

Alright. No. This is great. This is awesome.

### You (2025-06-20T17:41:22.271Z)

Okay. Cool. I will I just

### Guest (2025-06-20T17:41:23.734Z)

I think

### You (2025-06-20T17:41:24.161Z)

just simply simple notes here.

### Guest (2025-06-20T17:41:25.424Z)

yeah.

### You (2025-06-20T17:41:26.241Z)

Okay.

### Guest (2025-06-20T17:41:26.324Z)

Okay.

### You (2025-06-20T17:41:27.451Z)

And I'll send it to you now.

### Guest (2025-06-20T17:41:27.694Z)

Cool. I will I took just some quick simple notes here. And I'll send them to you now.

### You (2025-06-20T17:41:33.951Z)

Yeah. Me know if you have any questions.

### Guest (2025-06-20T17:41:35.724Z)

And then

### You (2025-06-20T17:41:37.111Z)

Alright. Yeah. Will do. Cool.

### Guest (2025-06-20T17:41:38.844Z)

yeah, let me know if you have any other questions as you work through stuff.

### You (2025-06-20T17:41:39.761Z)

Alright. Thanks, Yep. Bye.

### Guest (2025-06-20T17:41:41.864Z)

Cool. Alrighty. Thanks, Howard. Yep. Bye.