# Invest AI dashboard development and feature prioritization

**Date:** 2025-06-09 00:00:00 UTC
**Meeting ID:** d8f64d2a-5482-4d4d-840c-8491f88c404b
**Synced:** 2026-02-05 14:46:48

---

# Transcript for: Invest AI dashboard development and feature prioritization

### You (2025-06-09T19:10:56.961Z)

Hey there. How was annoying you last week, Mark? Good.

### Guest (2025-06-09T19:11:00.125Z)

Well, how was NYU last week, Mark? Good? It was good. Interesting. Know, people were, doing a lot of talk. A of people talking about, you know, doing more analysis than deals.

### You (2025-06-09T19:11:11.641Z)

Doing more analysis than deals. That was kind of the

### Guest (2025-06-09T19:11:13.785Z)

That was kind of the,

### You (2025-06-09T19:11:14.401Z)

the theme.

### Guest (2025-06-09T19:11:15.015Z)

the theme. I'll talk about biohacking. What's biohacking? That seems to be the, the flavor of the day. What what is that? Like, just diving in super deep or something else? Yeah. Just like people, you know, this like, the new version of wellness

### You (2025-06-09T19:11:28.181Z)

Just like the new. Version of wellness where people are going

### Guest (2025-06-09T19:11:30.315Z)

people are going for, like, resorts for body treatments and

### You (2025-06-09T19:11:32.131Z)

by

### Guest (2025-06-09T19:11:34.295Z)

okay. Things and, you know,

### You (2025-06-09T19:11:35.161Z)

Korea

### Guest (2025-06-09T19:11:35.655Z)

pre, giving blood samples before arriving at the resort so that they can have treatments.

### You (2025-06-09T19:11:38.831Z)

so they can have treatments. Got it.

### Guest (2025-06-09T19:11:40.625Z)

Got it.

### You (2025-06-09T19:11:41.821Z)

I saw it.

### Guest (2025-06-09T19:11:42.415Z)

I I reminded them that, you know, when I go on vacation, I like to do the opposite of healthy.

### You (2025-06-09T19:11:42.591Z)

Wanted them that, you know, I like to do the opposite. Opposite of healthy.

### Guest (2025-06-09T19:11:46.485Z)

No one no one seemed to understand that. Embiid write and write. Enjoy

### You (2025-06-09T19:11:52.581Z)

Spirit.

### Guest (2025-06-09T19:11:53.105Z)

spirits. And yes. Exactly. So Yes. But yeah. No. Definitely.

### You (2025-06-09T19:11:53.261Z)

Yes. Exactly. So Yes. But yeah. Definitely have to Yeah. People stuff.

### Guest (2025-06-09T19:11:58.075Z)

You know? Usual stuff. It was good, though.

### You (2025-06-09T19:11:59.581Z)

Sounds good.

### Guest (2025-06-09T19:12:00.225Z)

It was good. Yep. The news came out that it was just kind of muted. Right? Like,

### You (2025-06-09T19:12:03.601Z)

Right? Like,

### Guest (2025-06-09T19:12:05.785Z)

kind of bland and, you know, very divided. Some people thinking this

### You (2025-06-09T19:12:06.241Z)

know, the more divided it, some people think this, like, kind of half a degree would be much better. Others saying it

### Guest (2025-06-09T19:12:10.755Z)

second half of the year would be much better. Others saying no, that we'll be in the same place.

### You (2025-06-09T19:12:13.011Z)

we'll be in the same place in the second half of the year.

### Guest (2025-06-09T19:12:15.725Z)

The second half of the year.

### You (2025-06-09T19:12:16.451Z)

Yeah.

### Guest (2025-06-09T19:12:17.205Z)

Yeah. Well, there's just so much unknown now in the economy with all the tariffs and all the economic volatility that I guess people are somewhat,

### You (2025-06-09T19:12:20.641Z)

Yeah.

### Guest (2025-06-09T19:12:25.315Z)

confused about what they should be doing. But that's a perfect time for

### You (2025-06-09T19:12:26.341Z)

By this work time for him new analytical

### Guest (2025-06-09T19:12:28.645Z)

new analytical

### You (2025-06-09T19:12:29.361Z)

technology to help

### Guest (2025-06-09T19:12:30.095Z)

technology to help make decisions.

### You (2025-06-09T19:12:30.621Z)

me. Decisions. Yeah.

### Guest (2025-06-09T19:12:32.535Z)

Right. Right. How's that for a segue?

### You (2025-06-09T19:12:32.861Z)

Yeah. Right. I never said There you go. That's good segue. So

### Guest (2025-06-09T19:12:35.295Z)

That's just a good segue. So,

### You (2025-06-09T19:12:37.691Z)

I get I'm from Trish

### Guest (2025-06-09T19:12:38.315Z)

I get I'm not sure if Drew's joining because, like, he may still be in Hawaii, Okay. But let's just jump in because Howard's done a lot of work over the past week.

### You (2025-06-09T19:12:42.171Z)

let's just jump in because Howard's done all our work over the past week. And

### Guest (2025-06-09T19:12:46.575Z)

And we're getting closer. We're probably over the 50% hump at this point.

### You (2025-06-09T19:12:46.941Z)

getting closer to probably percent of them at this point. So

### Guest (2025-06-09T19:12:51.545Z)

So so I'll turn it over to you, Howard. Is that good?

### You (2025-06-09T19:12:51.991Z)

so turn it over to Howard. Is it going? It it is. But like I said, I I well, actually, let me take a quick look here, see if I can actually make the older version if it's a functioning here. Yeah. Okay. Let me let me go ahead and share my screen. And I know this a little bit of repeat, but Mark wasn't able to so let me go ahead and just kinda quickly cover those items. Let me get this done now. Okay. So do you see the Invest AI dashboard? Not yet. Not yet. Yes.

### Guest (2025-06-09T19:13:32.845Z)

Not yet.

### You (2025-06-09T19:13:33.291Z)

Yep. Okay. Okay. Alright. So starting off

### Guest (2025-06-09T19:13:37.055Z)

Yes. Yep.

### You (2025-06-09T19:13:38.701Z)

where we were last week, you know, there is no summary page yet. So property details, Mark, this is one thing that we showed last week. But we did make some changes here. Basically just, you know, very simple changes by making the state a drop down selector, adding the zip code, etc. But the most important item is the food and beverage categories and subcategories. So the idea is when a user is setting up a brand new deal. That they wanna work on, During that setup process, they identify other than the rooms revenue, what other type of revenue is coming in. And so Drew provided a a an Excel spreadsheet that gave the hierarchy that's that's typically used. So if it's if it doesn't have any other ancillary I can just click on none and then save it. You can see then nothing else can be selected. Or if they have different types of food and beverage, you know, you can select down here and it has the four sub categories banquets and catering, kitchen, minor and outlets. And maybe I just have minor food and beverage. Maybe the only thing I have is a coffee shop. If I click on that, then it clicks all these others, which mean when I go into the valuation, and I start working on food and beverage, I will have those different categories avail if I want to go ahead and actually budget at the coffee shop level, for food and beverage. If I don't, I can just go ahead and click food and beverage and then I only have one general food and beverage line item. To budget. Okay? So it's up to the user. To to budget and evaluate whatever they way they're used to. So those are the big We can. I think what Drew was trying to do is to

### Guest (2025-06-09T19:15:54.305Z)

Can we add a few more categories, or is that a lot of

### You (2025-06-09T19:15:56.261Z)

keep it apples to apples with what he's got in the system. So if we have

### Guest (2025-06-09T19:15:57.305Z)

additional work?

### You (2025-06-09T19:16:00.961Z)

HPIS clients that we can just import that information here or others. But, yeah, adding adding other categories. If there's something that we all agree that should be added in here, we can certainly do that. That's not a problem. Yep. You know,

### Guest (2025-06-09T19:16:20.485Z)

Yeah. So for example, I mean, I think that you know, we should add resort fee because that's a big thing.

### You (2025-06-09T19:16:23.651Z)

you know, maybe help folks.

### Guest (2025-06-09T19:16:25.815Z)

We should probably add

### You (2025-06-09T19:16:27.841Z)

That's also

### Guest (2025-06-09T19:16:29.305Z)

you know, maybe health club spa

### You (2025-06-09T19:16:30.911Z)

Yeah. There there's a

### Guest (2025-06-09T19:16:32.635Z)

because that's also

### You (2025-06-09T19:16:33.711Z)

there's a spa in fitness.

### Guest (2025-06-09T19:16:35.535Z)

something that

### You (2025-06-09T19:16:36.091Z)

But I don't see the first one that you mentioned. Yeah. Before

### Guest (2025-06-09T19:16:39.245Z)

you know, some of these

### You (2025-06-09T19:16:42.271Z)

Okay. So With that fall under

### Guest (2025-06-09T19:16:46.625Z)

The resort fee is a kind of a big thing.

### You (2025-06-09T19:16:46.651Z)

the other operated category?

### Guest (2025-06-09T19:16:48.985Z)

So in some cases,

### You (2025-06-09T19:16:49.881Z)

Are big. Okay. So I I would

### Guest (2025-06-09T19:16:51.925Z)

I No. I mean, some of these are big

### You (2025-06-09T19:16:53.691Z)

think you know, you could probably as well, but I think

### Guest (2025-06-09T19:16:56.955Z)

components of revenue. So I I would and, you know, Diane, I'm

### You (2025-06-09T19:17:01.121Z)

Okay.

### Guest (2025-06-09T19:17:01.965Z)

I wanna get your opinion obviously as well, but I think resort fee is kind of, like, one of those things

### You (2025-06-09T19:17:02.131Z)

So you would recommend that we put that here

### Guest (2025-06-09T19:17:05.945Z)

that typically is its own line item.

### You (2025-06-09T19:17:06.931Z)

as one of the main categories? Yeah. Put it right there.

### Guest (2025-06-09T19:17:07.845Z)

Mhmm.

### You (2025-06-09T19:17:09.961Z)

And beverage. Okay. No. No. It's not a problem at all.

### Guest (2025-06-09T19:17:14.795Z)

Yeah. I'd put it right under food and beverage. If it's not too much trouble.

### You (2025-06-09T19:17:17.541Z)

I mean And then you know, that was some of these things are typically their own line items.

### Guest (2025-06-09T19:17:25.065Z)

Then I guess the you know, Diane, is there anything else that comes to mind? Because I I think that some of these things are typically they're

### You (2025-06-09T19:17:26.481Z)

Catch all. But tip it's. Spout.

### Guest (2025-06-09T19:17:30.235Z)

own line items. Other is just more of a catch all. But, typically, you see resort fee, maybe see spa, gym,

### You (2025-06-09T19:17:36.961Z)

I think

### Guest (2025-06-09T19:17:38.215Z)

You know, if we're gonna try to go after four star hotels, but I assume we are.

### You (2025-06-09T19:17:38.681Z)

should be itself. Okay. Okay. So you you think the the spa fitness

### Guest (2025-06-09T19:17:41.785Z)

That should probably also I see it as an other, but it's probably should be its own

### You (2025-06-09T19:17:44.681Z)

could be its own category? Bye. Yeah. No. We can we can move that up. That's not a problem.

### Guest (2025-06-09T19:17:53.855Z)

Mhmm. The resort fee is more important, but I I I would think spa and fitness too.

### You (2025-06-09T19:18:02.691Z)

Right.

### Guest (2025-06-09T19:18:04.815Z)

Know, it's like for select service, it doesn't apply. But for full service and resort, it definitely is a

### You (2025-06-09T19:18:05.471Z)

Yeah. Okay. Alright.

### Guest (2025-06-09T19:18:09.235Z)

significant component.

### You (2025-06-09T19:18:11.291Z)

That's good.

### Guest (2025-06-09T19:18:12.335Z)

Diane, is there anything else you could think of?

### You (2025-06-09T19:18:14.641Z)

Okay.

### Guest (2025-06-09T19:18:16.455Z)

No. I think that's good. And then the

### You (2025-06-09T19:18:22.871Z)

Yeah. The this this hasn't changed.

### Guest (2025-06-09T19:18:24.295Z)

market analysis page is what looks so good.

### You (2025-06-09T19:18:25.891Z)

And this is just a replication, like I mentioned before, what was in Mark's spreadsheet.

### Guest (2025-06-09T19:18:27.585Z)

Like, I think we're really getting there.

### You (2025-06-09T19:18:30.551Z)

And I know that we don't want to have actual names in here. So before we get down in front of somebody outside of the the five of us, you know, we'll go ahead and make some changes here. So the big change is on the valuation page now. So notice when I click on valuation, you know, it brings everything up.

### Guest (2025-06-09T19:18:49.025Z)

Thank you.

### You (2025-06-09T19:18:51.271Z)

What I started to notice is that a lot of these summary metrics at the top that we want to have visible was starting to get pretty excessive, and it was pushing the rest of the page down. So what I'm going to do is go with different tabs. So I've got an occupancy metric when I'm working on revenue, I can just click on revenue. I have these so that as I scroll, those will always remain visible. But most importantly is is navigation. Right? So it stops or it starts at occupancy. And you can go ahead and input your your data here. So if I wanted this to be 76.2. I can go ahead and change that. And as I make these changes, I mean, every time I hit a digit, you can see up above in that summary something changes. So if I go with 81.3, every time it comes up here until you finally get to the 81.3, and that'll change your occupied rooms, etcetera. And then if I want to work on the ADR, even though it's visible here on smaller screens, it may not be. So I can click but the bottom line is we now have the ability to click through. You can go in any area, whatever you want to work on. And so in the other operated, this is what I was just talking about where we don't have the ability to get to drill down into those individual line items. But we could budget on the basis of the dollar per occupied room per year, which I think is the way I saw it in both spreadsheets. You know, might have been differently, but know? And these numbers here are totally made up.

### Guest (2025-06-09T19:20:32.445Z)

Mhmm.

### You (2025-06-09T19:20:34.881Z)

Randomly generated, but you know, you can see how it works. And so if I wanted to keep going with the trend, you know, I might go $60 So you can see then the total f and b revenue at $60 a room comes out to be a million $8.00 2, you know, and then maybe $62 the next year, etcetera. And I can go down and do the same thing for every single one of these. Right? So this might be 35, not 350. Tab over make it 37. Everything you can see. So now if I go to the financial revenue page, now you can see when we get down into the food and beverage line, you can see the two inputs that I had there for 25 and 26, the two inputs for the other operated. That's that's that's how it works. Right? So ideally, not for the proof of concept, but when we get to the clients who do want to get into that other detail, we could have other subcategories here in the other operated where you then you could get the food and beverage and then you could have the multiple rows for all the different categories in food and beverage. And it's all eventually going to roll up. Into whatever the page is. So so yeah. Yeah. So Diane and I x-ray to one of objects. Up and see an APL and then run

### Guest (2025-06-09T19:22:01.895Z)

It looks looks great. And, Howard, there's index

### You (2025-06-09T19:22:03.551Z)

Thursday, six

### Guest (2025-06-09T19:22:06.265Z)

right, too on the occupancy and ADR. I remember on Thursday, say

### You (2025-06-09T19:22:09.301Z)

Yes. You're talking about here on

### Guest (2025-06-09T19:22:11.235Z)

like, seeing that there was an index line.

### You (2025-06-09T19:22:13.391Z)

the ADR and the RevPar. Yeah. We've got the index to market. Property to comp set, property to market,

### Guest (2025-06-09T19:22:19.975Z)

Yeah.

### You (2025-06-09T19:22:23.141Z)

Same thing on the RevPar. And then basically, then we have the sum of all of that to come up with the total rooms revenue. Which again is reflected up on top here for your historical and then your forecast going along the top.

### Guest (2025-06-09T19:22:39.355Z)

Mhmm.

### You (2025-06-09T19:22:40.121Z)

And this is all dynamic as well. You may only have, you know, two years of historical and ten years of forecast This will all basically represent whatever data we have for this particular deal. Will be reflected there. And then get to a the test assumptions. It it I don't have the financing on here yet.

### Guest (2025-06-09T19:23:01.185Z)

Where do we enter, the debt assumptions?

### You (2025-06-09T19:23:02.671Z)

So right now, yeah. Right now, I feel that we are pretty close, if not close enough.

### Guest (2025-06-09T19:23:10.195Z)

Oh, okay.

### You (2025-06-09T19:23:11.761Z)

For the revenue So the next step would be just to continue on down this page and then get into our expense calculations. And then we can start looking at financing penetration, a couple other things there. So so Right. Right.

### Guest (2025-06-09T19:23:32.415Z)

Okay. Yeah. Because you can't

### You (2025-06-09T19:23:32.891Z)

Right. So And also, once the box is on top,

### Guest (2025-06-09T19:23:36.095Z)

you can't get to the IRR without

### You (2025-06-09T19:23:37.831Z)

we may wanna add more

### Guest (2025-06-09T19:23:37.875Z)

debt assumptions. That's what and then also, one of the boxes on top

### You (2025-06-09T19:23:39.661Z)

that says there. Yield. Yeah.

### Guest (2025-06-09T19:23:44.405Z)

we may wanna add one that says debt yield.

### You (2025-06-09T19:23:47.371Z)

Work.

### Guest (2025-06-09T19:23:48.075Z)

Because that's a big that's a big part of of

### You (2025-06-09T19:23:48.711Z)

But that's kind of their Yeah. So so

### Guest (2025-06-09T19:23:51.485Z)

the finance consideration. And if we're gonna try to market this to lenders,

### You (2025-06-09T19:23:53.401Z)

everything that you see up here is just made up.

### Guest (2025-06-09T19:23:55.415Z)

right, that's kind of their

### You (2025-06-09T19:23:56.881Z)

I just

### Guest (2025-06-09T19:23:57.005Z)

number one

### You (2025-06-09T19:23:57.591Z)

I just randomly put five cards up

### Guest (2025-06-09T19:24:01.095Z)

Right.

### You (2025-06-09T19:24:01.921Z)

No. No. Could be. There. Deal. Yeah.

### Guest (2025-06-09T19:24:04.345Z)

Yeah. No. No. It's it's all the right things, but you may wanna just a six could be debt yield just as a in sort of an order of importance.

### You (2025-06-09T19:24:04.571Z)

And so Yeah. You can you can see that these are very wide with just a little bit. I mean, you could literally probably put half you know, maybe no. I wouldn't say a dozen, but I think we could easily get eight cards.

### Guest (2025-06-09T19:24:22.285Z)

No. I I like we I think

### You (2025-06-09T19:24:22.691Z)

Yeah. But, you know, kind of

### Guest (2025-06-09T19:24:26.175Z)

is more because if you put too much up there, it gets

### You (2025-06-09T19:24:27.281Z)

Yeah. Plus, remember, you know, we will eventually have a summary page.

### Guest (2025-06-09T19:24:28.395Z)

confusing. But debt yield is kind of of these, you have all the right ones, but for debt yield.

### You (2025-06-09T19:24:32.051Z)

Which will be that that will be laid out just like the Excel spreadsheets where you've got different sections for each different item. So so that's where you'll have a lot of the information too. A lot of these metrics on the valuation page are there for me as an underwriter or a broker. Trying to come to what they feel is a valuation. And every time I make a change in the input, you know, want to see how is that going to change the ROI. Or how is that going to change the occupancy. Right? Everything here will eventually be live. So every time I change even a single digit on this page, I would expect pretty much everything up here to change. Then when I get it to the point where it says, okay, this looks good. This is my number. You know, you'll have the summary page. Then. And it'll be in a printable format. So if you want to get a PDF and print out the summary page, you'll be able to do so. With just a couple pushes of a button. Yep. And then, of course, the occupancy report again.

### Guest (2025-06-09T19:25:40.205Z)

Yeah.

### You (2025-06-09T19:25:40.541Z)

This is just using the made up numbers that I have, but that's all coming from this valuation page. So anytime I make a change there, it's immediately reflected in real time here. And and I would expect to have know, similar reports for revenue expenses. You know, with the revenue, we could have multiple graphs on the page showing all of the different departments. And again, same thing. If if if we want to put together a package, we can have a little button here that says print. I could print it and get a PDF of it. Yeah. That's true. And the one thing think about is maybe for future version

### Guest (2025-06-09T19:26:21.015Z)

Yeah. That's really good.

### You (2025-06-09T19:26:21.161Z)

But you know, time, see

### Guest (2025-06-09T19:26:25.115Z)

Mean, one thing to think about, and this may be for a future version,

### You (2025-06-09T19:26:27.611Z)

assumptions. Mhmm.

### Guest (2025-06-09T19:26:28.295Z)

but

### You (2025-06-09T19:26:28.731Z)

Right? So

### Guest (2025-06-09T19:26:28.835Z)

you know, oftentimes,

### You (2025-06-09T19:26:29.661Z)

like, that

### Guest (2025-06-09T19:26:30.515Z)

we like to see

### You (2025-06-09T19:26:30.631Z)

cost top, you really wanna see

### Guest (2025-06-09T19:26:32.155Z)

comparative returns with different assumptions.

### You (2025-06-09T19:26:32.701Z)

those. Return.

### Guest (2025-06-09T19:26:34.825Z)

Right? So

### You (2025-06-09T19:26:36.171Z)

Percent

### Guest (2025-06-09T19:26:36.315Z)

like, that row across the top, you may wanna see those returns, but then you may also wanna see it at

### You (2025-06-09T19:26:38.831Z)

Yeah. So you know, again, maybe that's just you know, feel like some kind of a sense

### Guest (2025-06-09T19:26:41.915Z)

60% versus 70% debt levels.

### You (2025-06-09T19:26:43.121Z)

sort of thing. Yeah. Yeah. The risk matrix is something I think is is

### Guest (2025-06-09T19:26:44.905Z)

Right? So, you know, again, maybe that's just you know, like, some kind of, like, sensitivity matrix sort of thing.

### You (2025-06-09T19:26:47.891Z)

mandatory. You have to have you know so what if we do you know, cap rates by every one eighth of a percentage or quarter of a percentage? Higher, lower, different terms of financing, you know, that that definitely is something that we need to have. The question is how how do we present it? Could we do something like a a mini line graph or something at the top up here? Or do we want to have a larger page or both? Right? You could have one. Would be able

### Guest (2025-06-09T19:27:24.925Z)

Yeah. And and also in a in a perfect world, the user

### You (2025-06-09T19:27:25.111Z)

Right? Yes. See.

### Guest (2025-06-09T19:27:27.885Z)

would be able to change the

### You (2025-06-09T19:27:28.381Z)

A kilo versus 20,000 a kilo. Yeah. We may wanna

### Guest (2025-06-09T19:27:30.535Z)

matrix parameters. Right? So you may wanna see what the impact is of a

### You (2025-06-09T19:27:31.461Z)

see what's 50,000,000. 60,000,000.

### Guest (2025-06-09T19:27:34.395Z)

thousand a key renovation versus 20,000 a key.

### You (2025-06-09T19:27:34.661Z)

Mhmm. Percent debt. So

### Guest (2025-06-09T19:27:37.385Z)

May wanna see what the difference is between paying 50,000,000 and 52,000,000 or

### You (2025-06-09T19:27:37.831Z)

if the answer could actually have menu of different options, in the sense

### Guest (2025-06-09T19:27:42.065Z)

60% debt or 70% debt. So

### You (2025-06-09T19:27:42.261Z)

Yeah. That be kinda like the ultimate

### Guest (2025-06-09T19:27:44.575Z)

the user could actually have a menu of different options in the sensitivity,

### You (2025-06-09T19:27:44.941Z)

Oh, it's you know, I I don't wanna downplay this, but but

### Guest (2025-06-09T19:27:49.075Z)

That would really be kinda like the ultimate

### You (2025-06-09T19:27:50.191Z)

honestly, doing something like that using a database and a website is much, much easier than Excel. You know, so so yeah, I mean that would be that would be something that we could do quickly and easily. Okay. I think that would be really helpful. Yeah. I thought I'd keep add some that as well. Right? This is once we get to the end of the line, every

### Guest (2025-06-09T19:28:11.325Z)

Okay. I think that would be really helpful for the users. And Red IQ had some functionality like that as well.

### You (2025-06-09T19:28:15.321Z)

different. Right. From one copy type to the other

### Guest (2025-06-09T19:28:17.035Z)

Right? Like, this isn't once we get to the NOI line, every there's really not that much

### You (2025-06-09T19:28:17.881Z)

property type. Yeah. Yeah. So the question is, you know,

### Guest (2025-06-09T19:28:21.435Z)

that's different

### You (2025-06-09T19:28:22.451Z)

we we do wanna prioritize this in terms of

### Guest (2025-06-09T19:28:22.535Z)

from one property type to the other property type.

### You (2025-06-09T19:28:26.261Z)

what's the minimum functionality we need to get some of the analysts sitting down and just you know, even if it's just section by section, it's like, Let's let's do the valuation page. Let's do your occupancy, revenue, and expense forecasting. And see how does that compare to the Excel models. Then, you know, we could add in maybe financing and you know, I I I don't want to try to get too much done before we get this in front of people. Then otherwise the feedback we're gonna get is gonna be difficult to keep up with. Right? So I'd like to take it one bite at a time instead of trying to eat the elephant. So component Yes. Yeah.

### Guest (2025-06-09T19:29:13.045Z)

Yeah. But but I do think that having the the

### You (2025-06-09T19:29:13.881Z)

I don't yeah. I I I think in before we give it to any analyst, we're gonna need

### Guest (2025-06-09T19:29:17.685Z)

the debt component is gonna be

### You (2025-06-09T19:29:18.811Z)

the page that I'm working on now,

### Guest (2025-06-09T19:29:19.705Z)

critical. And then

### You (2025-06-09T19:29:21.391Z)

the financing assumptions, and probably the penetration analysis that you've in the spreadsheets. But I don't I don't know. I'm gonna leave that up to you whether do we need a penetration before we get this in front of the very first set of eyes. Or could we just leave it with the occupancy revenue expenses?

### Guest (2025-06-09T19:29:45.945Z)

Well, yeah, the penetration is used

### You (2025-06-09T19:29:48.021Z)

Yeah. So if you have to

### Guest (2025-06-09T19:29:50.525Z)

to do the projections. Right? Because you're you're benchmarking against the competitive set.

### You (2025-06-09T19:29:50.771Z)

we could do the projection. Yeah. Okay. Yeah. That makes sense.

### Guest (2025-06-09T19:29:55.015Z)

If you don't have the penetration, I don't know how we could

### You (2025-06-09T19:29:55.681Z)

Pieces what what I was the capital expensive to work?

### Guest (2025-06-09T19:29:57.985Z)

do the projections.

### You (2025-06-09T19:29:59.241Z)

Because that's what's sort of

### Guest (2025-06-09T19:29:59.465Z)

And then

### You (2025-06-09T19:30:00.151Z)

a critical piece of it. So I see you have

### Guest (2025-06-09T19:30:01.645Z)

then the other piece is

### You (2025-06-09T19:30:02.511Z)

a parking lot.

### Guest (2025-06-09T19:30:03.065Z)

what how is the capital expense input work? Because that's also a

### You (2025-06-09T19:30:03.251Z)

Yeah. But See. Is that what that is? Yeah.

### Guest (2025-06-09T19:30:06.765Z)

critical piece of it. So I see you have it in the parking lot, but

### You (2025-06-09T19:30:07.161Z)

So so how do you your capital improvement?

### Guest (2025-06-09T19:30:10.665Z)

or I see is that what that is? Like, it's I can only sleep read it.

### You (2025-06-09T19:30:11.541Z)

Haven't gotten to that point yet. Okay. Yeah. So that's enough

### Guest (2025-06-09T19:30:13.715Z)

So so how do you enter in sort of different your capital improvement

### You (2025-06-09T19:30:14.791Z)

I think. People are gonna need to have a big because Yeah. When you

### Guest (2025-06-09T19:30:17.205Z)

budget?

### You (2025-06-09T19:30:17.591Z)

buy something, part of it.

### Guest (2025-06-09T19:30:18.635Z)

Okay. Because that's another thing that I think people are gonna need to have because

### You (2025-06-09T19:30:18.811Z)

Typically want some capital to effectively change.

### Guest (2025-06-09T19:30:23.605Z)

when you buy something, you acquire something, you typically wanna

### You (2025-06-09T19:30:23.861Z)

Yeah. Yeah. So the so the way I've been approaching this is

### Guest (2025-06-09T19:30:26.665Z)

have some capital plan to effectuate change.

### You (2025-06-09T19:30:28.031Z)

like I said, I'm I'm starting at the top and working my way down the the p and l statement. And the forecasting. So I'll take a look at the way the spreadsheet that you provided calculates it. I'll take a look at the the way that the spreadsheet that Diane put together. Confirmed that they're basically the same. You know, they the the formulas might be a little bit different, but the output should be the same. Then I will translate that into this web page. And then Drew's been very helpful by providing some of the the calculations that he's doing in HBIS, because there, again, I want to make sure that the numbers tie. So that that you know, users of their system if they see a different number here, they're gonna question who's right. Right? So we don't want to create that potential conflict. But I think I've got the majority of the data that I need now to where the expenses, the CapEx, and the investment assumptions should move much faster than I've done so far. Because those are the ones that there's really not a whole lot of you know, variance or variations in how they calculate them. They're more straight forward than the others. So that's why we were talking before hand, and I think you know, I think probably within next week, maybe two weeks, we'll be ready to have a model that's got all that data in it. That we can get in front of some pay some people. That's great. Yeah. Yeah.

### Guest (2025-06-09T19:32:07.295Z)

That's great.

### You (2025-06-09T19:32:10.481Z)

Our

### Guest (2025-06-09T19:32:11.405Z)

Yeah. No. Diane and I spoke, and I I think we

### You (2025-06-09T19:32:11.781Z)

Mhmm. Yeah. So Yeah. That's it. We got some, you know, some brands

### Guest (2025-06-09T19:32:15.595Z)

starting to put together a list of

### You (2025-06-09T19:32:16.031Z)

I think, some quick public

### Guest (2025-06-09T19:32:17.095Z)

our testers.

### You (2025-06-09T19:32:18.071Z)

feedback.

### Guest (2025-06-09T19:32:18.415Z)

Mhmm. So, we've got some we've got some, you know, some friends that'll really give us

### You (2025-06-09T19:32:18.881Z)

Yeah. Yeah. For the companies as well. So their testimonials, like, I think

### Guest (2025-06-09T19:32:22.515Z)

I think, some quick but really meaningful feedback.

### You (2025-06-09T19:32:24.741Z)

say it has potential,

### Guest (2025-06-09T19:32:25.825Z)

They work for good companies as well, so their testimonials, like, if if

### You (2025-06-09T19:32:27.661Z)

some positive feedback that we can start to roll

### Guest (2025-06-09T19:32:30.435Z)

even if they could say it has potential or I really like that, you know, some some positive

### You (2025-06-09T19:32:31.441Z)

into this as we take it through the summer. And Yeah. And our strategy

### Guest (2025-06-09T19:32:35.405Z)

feedback. That we can start to roll into this as we

### You (2025-06-09T19:32:36.641Z)

know, our marketing strategy and our fund raise. Strategy and things like that.

### Guest (2025-06-09T19:32:39.415Z)

take it through the summer and and our strategy, you know, our marketing strategy

### You (2025-06-09T19:32:42.261Z)

I'm hoping for

### Guest (2025-06-09T19:32:44.655Z)

our fundraising strategy and things like that.

### You (2025-06-09T19:32:45.061Z)

makes sense computer. For a better

### Guest (2025-06-09T19:32:48.865Z)

I'm hoping for the comment being it's the greatest thing since

### You (2025-06-09T19:32:49.231Z)

If it's anything less than that, I'm gonna be very disappointed.

### Guest (2025-06-09T19:32:52.335Z)

computers were invented, but you know? That's my goal. It's the lightning speed of how the data gets loaded. Right? That they'll they'll be

### You (2025-06-09T19:33:02.821Z)

Each. Feel like that will

### Guest (2025-06-09T19:33:05.105Z)

like, oh my god. I don't have to spend thirty or and not thirty minutes to an hour loading this. He

### You (2025-06-09T19:33:05.651Z)

be a big. Like, Yeah.

### Guest (2025-06-09T19:33:09.715Z)

each time. I I I feel like that will be a big, like,

### You (2025-06-09T19:33:11.051Z)

And then

### Guest (2025-06-09T19:33:13.555Z)

relief

### You (2025-06-09T19:33:14.361Z)

because

### Guest (2025-06-09T19:33:14.695Z)

Mark and I talked a little bit about this too, and

### You (2025-06-09T19:33:15.051Z)

they're find lots of

### Guest (2025-06-09T19:33:19.255Z)

I wanna be sensitive to the analyst because there is a lot of what Howard, you and I, we follow all the same people on LinkedIn. And so you probably saw some of the post recently, like, do analysts become obsolete? Does this actually you know, can it be done does this can AI and this this

### You (2025-06-09T19:33:38.741Z)

on those quotes saying,

### Guest (2025-06-09T19:33:39.325Z)

platform do it better than an analyst? And I thought,

### You (2025-06-09T19:33:39.881Z)

that the job of the analyst

### Guest (2025-06-09T19:33:43.005Z)

someone, Jen Tindle, had a really great comment to some of those posts saying that

### You (2025-06-09T19:33:43.451Z)

and improve and Yep. Instead of

### Guest (2025-06-09T19:33:47.285Z)

the job of the analyst changes and improves. And instead of just being a data pusher, they become more like a prompt engineer and trying to dig deeper and to find

### You (2025-06-09T19:33:52.441Z)

So I coffee. That we're

### Guest (2025-06-09T19:33:58.975Z)

So I just wanna be sensitive when we're talking to the analysts that we're giving them Like, this doesn't replace your job at all. It improves your job. Right? And it makes gives them

### You (2025-06-09T19:34:05.281Z)

Yeah.

### Guest (2025-06-09T19:34:08.615Z)

actually gives them more time to think about their job as opposed to just typing all day. Mhmm. Maybe that should be our tagline. Right? Like, a tool to helping analysts have time to think.

### You (2025-06-09T19:34:16.361Z)

Process

### Guest (2025-06-09T19:34:17.595Z)

Yeah. Yes. Right? Because, I mean, we're we're basically removing the the

### You (2025-06-09T19:34:17.631Z)

time down. Definitely. The you. You know?

### Guest (2025-06-09T19:34:21.515Z)

you know, the the process and giving them more time to actually I mean, I'm always telling

### You (2025-06-09T19:34:24.711Z)

Just

### Guest (2025-06-09T19:34:26.605Z)

know, I call them the kids. You know, before you give us the model, actually spend an

### You (2025-06-09T19:34:27.981Z)

Well, it you know, it's actually a double edged sword.

### Guest (2025-06-09T19:34:30.285Z)

thinking about what you've just completed. And they never have time to do that because they're always late.

### You (2025-06-09T19:34:32.381Z)

In in a good way. In that. And and we've got the proof

### Guest (2025-06-09T19:34:35.385Z)

Yep.

### You (2025-06-09T19:34:36.381Z)

at at Red IQ, you know, because our salespeople had to address this issue every single call. You know, because I thought, well, yeah, you're you're putting our analysts out of business. Well, no. You're now giving them the tools to instead of analyzing one deal every two days because they're spending in there, all of a sudden, you can analyze three deals in one day or five deals in one day. And that was actually a huge selling point to some of the smaller clients because they were missing out on deals that were perfect for their criteria, but they didn't have the bandwidth to go through the full analysis. So instead of focusing on you know, this is just gonna make your job faster or can do it automatically. We did they flipped it around to saying, no. Instead of, you know, instead of three or five a week, you can now do 20 a week. And and get through there. So Yeah. For the person, I'm pitch. Senior management. Four. Yeah. Yeah. Depends on the audio.

### Guest (2025-06-09T19:35:43.805Z)

Of course, our our sales pitch to senior management will be that they can have two analysts now instead of four.

### You (2025-06-09T19:35:47.291Z)

Yeah. Yeah.

### Guest (2025-06-09T19:35:49.115Z)

But so well,

### You (2025-06-09T19:35:50.491Z)

Yeah. They'll be able to

### Guest (2025-06-09T19:35:52.255Z)

gonna have to have multiple versions of the truth here. Mhmm.

### You (2025-06-09T19:35:53.661Z)

tap AI opportunity as

### Guest (2025-06-09T19:35:55.145Z)

Or that the or that they'll have very centralized data at a senior level, and they'll be able

### You (2025-06-09T19:35:55.611Z)

much better. Than having it. Scattered. Throughout a shared drive. Right?

### Guest (2025-06-09T19:35:59.845Z)

to tackle AI opportunities much better than having it

### You (2025-06-09T19:36:02.751Z)

Of data analytics Right?

### Guest (2025-06-09T19:36:04.015Z)

scattered throughout a a shared drive. Right?

### You (2025-06-09T19:36:06.931Z)

Information? Yeah. Right?

### Guest (2025-06-09T19:36:07.515Z)

Yeah. I mean, listen. The the when the basis of

### You (2025-06-09T19:36:09.031Z)

We just have that

### Guest (2025-06-09T19:36:10.245Z)

analytics, right, is having accurate

### You (2025-06-09T19:36:11.121Z)

compose deal. You know, it goes

### Guest (2025-06-09T19:36:12.425Z)

reliable, long term information.

### You (2025-06-09T19:36:12.881Z)

some file account that no one knows where it is.

### Guest (2025-06-09T19:36:14.405Z)

Right.

### You (2025-06-09T19:36:15.031Z)

And three years later,

### Guest (2025-06-09T19:36:15.215Z)

Right now, the industry doesn't have that. Right? Every time that they

### You (2025-06-09T19:36:16.311Z)

you know, they can't find it.

### Guest (2025-06-09T19:36:18.075Z)

close a deal, you know, it goes into some file cabinet. No one knows where it is, and

### You (2025-06-09T19:36:19.571Z)

To compare you know,

### Guest (2025-06-09T19:36:22.205Z)

three years later, you know, they can't find it again. Right? So so we're actually gonna allow them to compare

### You (2025-06-09T19:36:24.581Z)

My covenant set that be a

### Guest (2025-06-09T19:36:27.435Z)

you know, results and analyze things in a very efficient way.

### You (2025-06-09T19:36:27.701Z)

four of few users start to to use

### Guest (2025-06-09T19:36:30.755Z)

Mark Kevin said he thought there would be a,

### You (2025-06-09T19:36:30.841Z)

that and they could turn bits around. Much faster.

### Guest (2025-06-09T19:36:34.585Z)

once a few users start to to use this,

### You (2025-06-09T19:36:35.251Z)

That there be a competitive like, a sense of competitiveness

### Guest (2025-06-09T19:36:38.645Z)

and they could turn bids around much faster, that there would be a

### You (2025-06-09T19:36:39.871Z)

that would bring other people to the table because they would be potentially losing at more than

### Guest (2025-06-09T19:36:43.745Z)

competitive like, a sense of competitiveness

### You (2025-06-09T19:36:44.321Z)

first one with the best bid to the table often wins.

### Guest (2025-06-09T19:36:46.765Z)

that would bring other people to the table because they would be

### You (2025-06-09T19:36:47.891Z)

And say, thought,

### Guest (2025-06-09T19:36:49.785Z)

losing out. I mean, the first one with the best bid to the table off

### You (2025-06-09T19:36:49.791Z)

that if you get successfully,

### Guest (2025-06-09T19:36:54.095Z)

wins. And so he, you know, and so he thought,

### You (2025-06-09T19:36:54.171Z)

and getting bids out. Quickly. Moving the process forward quickly.

### Guest (2025-06-09T19:36:56.975Z)

that if you get a few groups using it and they're using it successfully,

### You (2025-06-09T19:36:58.501Z)

That it will take industry.

### Guest (2025-06-09T19:37:00.895Z)

and getting bids out very quickly and moving the process forward quickly,

### You (2025-06-09T19:37:00.941Z)

Others would say, oh, I have to be able to compete. With this in order to win deals. So

### Guest (2025-06-09T19:37:05.235Z)

that

### You (2025-06-09T19:37:05.501Z)

Totally.

### Guest (2025-06-09T19:37:05.965Z)

it would take note in the industry and others would say, oh, I have to be able to compete with this in order to win deals. So Yeah. I

### You (2025-06-09T19:37:09.921Z)

An acquisitions person, right, to say

### Guest (2025-06-09T19:37:12.455Z)

totally agree. And I I think that, you know, one of the other benefits is that

### You (2025-06-09T19:37:12.561Z)

the lender. Appraiser. To the private industry before person. You know, this is a

### Guest (2025-06-09T19:37:16.555Z)

if you're an acquisitions person, right, you still have to send your information to the lender and to the appraiser and

### You (2025-06-09T19:37:20.761Z)

consistent

### Guest (2025-06-09T19:37:21.525Z)

the property conditions report person. You know, this is a convenient way to disseminate information

### You (2025-06-09T19:37:22.431Z)

So

### Guest (2025-06-09T19:37:25.955Z)

and make sure everyone's working off the same consistent data. So that will also expedite the whole process.

### You (2025-06-09T19:37:29.931Z)

to know, all the way. I mean, I just feel like I've actually done, you know, just

### Guest (2025-06-09T19:37:31.775Z)

That's all I've done in the last three weeks is push data to lenders to appraisers, to you know? Like, I I mean, I just feel like that's pushed you could just

### You (2025-06-09T19:37:36.851Z)

Yes. Yep. Yeah. So

### Guest (2025-06-09T19:37:40.845Z)

push a button. Right? It just goes. Right? Because everything's already organized. Yes. Yep. Yeah. So There's lots of lots of up it's really exciting. I mean, it really

### You (2025-06-09T19:37:46.871Z)

Yeah. So, Mark, how I think

### Guest (2025-06-09T19:37:50.215Z)

think it has the ability to change the way

### You (2025-06-09T19:37:50.261Z)

think it'll take us to get it to the point where we at?

### Guest (2025-06-09T19:37:52.245Z)

people do business.

### You (2025-06-09T19:37:53.281Z)

Handful of analysts ready

### Guest (2025-06-09T19:37:53.395Z)

So, Mark, how long do you think it'll take us

### You (2025-06-09T19:37:55.331Z)

to look at this. Well,

### Guest (2025-06-09T19:37:58.125Z)

to get to the point where we have

### You (2025-06-09T19:37:58.991Z)

mean, I think that I'm

### Guest (2025-06-09T19:38:00.285Z)

a handful of analysts ready to look at this?

### You (2025-06-09T19:38:01.041Z)

thinking two weeks

### Guest (2025-06-09T19:38:03.415Z)

Well, I mean, I think that

### You (2025-06-09T19:38:03.461Z)

Yeah. We can expect them to hopefully use this for a couple of

### Guest (2025-06-09T19:38:06.915Z)

I would think maybe within

### You (2025-06-09T19:38:07.861Z)

So back.

### Guest (2025-06-09T19:38:09.055Z)

you know, two weeks,

### You (2025-06-09T19:38:09.151Z)

Yeah. So

### Guest (2025-06-09T19:38:10.575Z)

Yep. We can expect them to hopefully use this for a couple of deals and then give us

### You (2025-06-09T19:38:11.111Z)

talking you know, people just busy. Doing things. But I think if we you know,

### Guest (2025-06-09T19:38:15.025Z)

some feedback.

### You (2025-06-09T19:38:15.341Z)

what we approach

### Guest (2025-06-09T19:38:16.285Z)

Yeah. You know, it is summertime. Right? So we want you know, people are just busy and

### You (2025-06-09T19:38:16.401Z)

that we just say you know you get back to us with it? You know? Fourteen days? With

### Guest (2025-06-09T19:38:20.535Z)

doing things. But I I think if we, you know,

### You (2025-06-09T19:38:21.891Z)

back. I guess that's

### Guest (2025-06-09T19:38:22.645Z)

we approach them, we just say, you know, can you get back to us within

### You (2025-06-09T19:38:22.871Z)

probably reasonable. Yeah. Yeah.

### Guest (2025-06-09T19:38:25.925Z)

you know, fourteen days? With your feedback? I I think that's that's probably reasonable.

### You (2025-06-09T19:38:29.031Z)

Through.

### Guest (2025-06-09T19:38:30.925Z)

Mhmm.

### You (2025-06-09T19:38:31.751Z)

This is the

### Guest (2025-06-09T19:38:31.775Z)

And we'll wanna do, like, a kickoff

### You (2025-06-09T19:38:33.881Z)

high level.

### Guest (2025-06-09T19:38:35.005Z)

call, right, where we walk them through the product and say things like, this is the proof of

### You (2025-06-09T19:38:35.381Z)

Will write Because we don't wanna that we're not delivering an

### Guest (2025-06-09T19:38:39.495Z)

concept. It's at a very high level.

### You (2025-06-09T19:38:41.561Z)

commercial one here with a

### Guest (2025-06-09T19:38:42.025Z)

Right? Because we don't want obviously, they need to understand that

### You (2025-06-09T19:38:45.141Z)

digitally improve

### Guest (2025-06-09T19:38:46.185Z)

not delivering an m an MPV or a version one here that this

### You (2025-06-09T19:38:46.711Z)

the accuracy. Of what they do. So

### Guest (2025-06-09T19:38:49.805Z)

is just to show that we can digitally improve the the speed and

### You (2025-06-09T19:38:52.111Z)

for them. You know, if they have an opportunity And then we do almost like a

### Guest (2025-06-09T19:38:55.455Z)

at which they do this. Oh, absolutely. And it may even make it more fun for them.

### You (2025-06-09T19:38:57.581Z)

demo. Know, how to work. Do how to work? Through.

### Guest (2025-06-09T19:38:59.675Z)

Know, if they have an opportunity to meet our whole team.

### You (2025-06-09T19:39:00.901Z)

Tricks that to figure out.

### Guest (2025-06-09T19:39:01.905Z)

And, you know, maybe we do almost, a half an hour demo and, know, Howard can kinda walk them through how it works. Right? Because if they have to figure out how to use this, it's gonna take them two weeks You know? But if we could just walk them through it in almost like a quick tutorial,

### You (2025-06-09T19:39:03.031Z)

Weeks. You know, that feels special right now. Team. And it'll make them clear. Much more efficient. So

### Guest (2025-06-09T19:39:14.065Z)

make them feel special, right, because they're meeting the whole executive team, and it'll make review of the technology so much more efficient because they'll understand how to use it.

### You (2025-06-09T19:39:18.801Z)

just sort of VIP treatment. Right.

### Guest (2025-06-09T19:39:22.305Z)

Mhmm.

### You (2025-06-09T19:39:22.691Z)

Yeah. So

### Guest (2025-06-09T19:39:23.285Z)

Maybe we just set up, like, a thirty or forty five minute call, and we just sort of, give them the VIP treatment Right.

### You (2025-06-09T19:39:30.311Z)

the next thing is

### Guest (2025-06-09T19:39:31.355Z)

So then the I feel like, like, we

### You (2025-06-09T19:39:31.931Z)

get to is just being to tap.

### Guest (2025-06-09T19:39:33.795Z)

Howard has made so much progress. And so

### You (2025-06-09T19:39:35.011Z)

Gonna or call out.

### Guest (2025-06-09T19:39:37.295Z)

the next thing big hurdle we need to get to is just being able to test

### You (2025-06-09T19:39:37.561Z)

Acquisitions or their to make sure that

### Guest (2025-06-09T19:39:41.455Z)

a handful of underwriting or call it acquisitions or whatever you wanna call it

### You (2025-06-09T19:39:42.161Z)

is producing the same return as Right? We get confidence

### Guest (2025-06-09T19:39:46.305Z)

to make sure that the model the an Excel model is

### You (2025-06-09T19:39:46.851Z)

that the two things are spitting out.

### Guest (2025-06-09T19:39:49.325Z)

producing the same returns as Invest AI. Right? And once we get confidence that

### You (2025-06-09T19:39:49.811Z)

Results. Then we feel good to them.

### Guest (2025-06-09T19:39:54.635Z)

those two things are spitting out the same results,

### You (2025-06-09T19:39:55.441Z)

To this this analyst advisory group. Yep.

### Guest (2025-06-09T19:39:57.715Z)

then we feel good we can go with a proof of concept to the to this this analyst advisory group.

### You (2025-06-09T19:40:03.821Z)

Excellent.

### Guest (2025-06-09T19:40:04.665Z)

Yep. No. I think that makes sense.

### You (2025-06-09T19:40:04.881Z)

Appreciate the feedback. Yeah. I know it's longer than we have hoped. But the policy

### Guest (2025-06-09T19:40:11.055Z)

So it's good, and

### You (2025-06-09T19:40:11.401Z)

would and

### Guest (2025-06-09T19:40:13.075Z)

Yeah. And I know it's taking longer than we had hoped,

### You (2025-06-09T19:40:13.201Z)

I'm I'm I I think this every time. But

### Guest (2025-06-09T19:40:16.785Z)

but the product is looking really good. And I I say this every time we meet, but I don't think we could have done this without partnering with technology leaders like Vinod and Howard that have done this in the multifamily

### You (2025-06-09T19:40:29.631Z)

Yep.

### Guest (2025-06-09T19:40:31.625Z)

space. So it's it's been really a great partnership.

### You (2025-06-09T19:40:33.011Z)

Okay. Perfect.

### Guest (2025-06-09T19:40:34.885Z)

From our perspective. I completely agree.

### You (2025-06-09T19:40:35.111Z)

Okay. So next to Monday, before then. I don't know how it affects

### Guest (2025-06-09T19:40:37.825Z)

Okay.

### You (2025-06-09T19:40:39.471Z)

kind of contingent on

### Guest (2025-06-09T19:40:41.795Z)

Thumbs up. So next Monday, or do we wanna meet before then? I don't Howard, I've kind of contingent on you and what you feel like you can get through and

### You (2025-06-09T19:40:48.491Z)

Yeah. Yeah. I was I was just gonna say,

### Guest (2025-06-09T19:40:50.085Z)

time frame, and we're happy to meet you again soon. If you want, like, quick feedback,

### You (2025-06-09T19:40:51.271Z)

since we since we kept our meeting today,

### Guest (2025-06-09T19:40:53.315Z)

you could always reach out and call me or email me. I'm always happy to jump on the phone.

### You (2025-06-09T19:40:55.211Z)

I didn't bother to record the video, like I said, but but as I go along, I think that's probably the quickest and easiest way is I'll do a quick tutorial video You watch it when you get a five when you have five minutes available. Provide feedback we can just keep going you know, on a daily basis if I have something new every day to show something. That'll probably be the best way. Otherwise, waiting until the next week's call, you know, that's just going to drag it out. So Okay. Yeah.

### Guest (2025-06-09T19:41:31.075Z)

Mhmm. Vinod is I know you have

### You (2025-06-09T19:41:34.901Z)

This week? Anything you're working on? Or

### Guest (2025-06-09T19:41:37.325Z)

a a lot of work to do for your contract job, but is there anything

### You (2025-06-09T19:41:37.661Z)

do you need to get down?

### Guest (2025-06-09T19:41:40.375Z)

we can do to help you this week on anything you're working on? Or do you need to be heads down on your the

### You (2025-06-09T19:41:48.031Z)

Stick with

### Guest (2025-06-09T19:41:48.395Z)

the moneymaker that's paying your bills right now?

### You (2025-06-09T19:41:48.901Z)

Howard on. Basically. Yeah.

### Guest (2025-06-09T19:41:51.905Z)

So, I mean, I think with

### You (2025-06-09T19:41:52.001Z)

Sync with So

### Guest (2025-06-09T19:41:56.195Z)

Howard on regular basis. We have daily sync meeting.

### You (2025-06-09T19:42:00.341Z)

Alright. So the last

### Guest (2025-06-09T19:42:00.725Z)

So, I mean,

### You (2025-06-09T19:42:02.451Z)

put that month ahead free call.

### Guest (2025-06-09T19:42:03.385Z)

I think we're on that front.

### You (2025-06-09T19:42:04.121Z)

On calendar. And

### Guest (2025-06-09T19:42:05.635Z)

Good on that? Okay.

### You (2025-06-09T19:42:06.021Z)

we'll for them.

### Guest (2025-06-09T19:42:07.525Z)

Alright. So then I'll just put next Monday at 03:00 on the calendar.

### You (2025-06-09T19:42:08.081Z)

And these video. With feedback. Yeah. And that

### Guest (2025-06-09T19:42:12.615Z)

And we'll communicate before then in

### You (2025-06-09T19:42:13.811Z)

should be we should be getting much closer

### Guest (2025-06-09T19:42:15.805Z)

these videos and recorded videos with feedback. And then

### You (2025-06-09T19:42:16.351Z)

by next Monday at three. Alright. Alright. Alright, everyone.

### Guest (2025-06-09T19:42:20.395Z)

we should be

### You (2025-06-09T19:42:21.441Z)

Thank you.

### Guest (2025-06-09T19:42:21.815Z)

we should be getting much closer

### You (2025-06-09T19:42:22.581Z)

Alright. Bye.

### Guest (2025-06-09T19:42:23.485Z)

by next Monday at three. Alright. Alright, everyone. Thank you. Thank you. Thanks, guys. Bye. Thanks for it. Bye bye. Thank you.