# Coordination Call

**Date:** 2025-04-22 00:00:00 UTC
**Meeting ID:** 45b8c137-dfcf-4ca0-bca2-a59d02ab10d4
**Synced:** 2026-02-05 14:46:48

---

# Transcript for: Coordination Call

### You (2025-04-22T17:34:25.027Z)

Hey, Diane. Hey, Diane.

### Guest (2025-04-22T17:34:27.638Z)

Hey, Darwin.

### You (2025-04-22T17:34:28.387Z)

Hey. Hey.

### Guest (2025-04-22T17:34:29.108Z)

Hey.

### You (2025-04-22T17:34:29.587Z)

Sorry. I'm late. No problem.

### Guest (2025-04-22T17:34:34.708Z)

No problem. Drew's running late, and I

### You (2025-04-22T17:34:39.197Z)

And don't know if Mark has joined.

### Guest (2025-04-22T17:34:40.938Z)

don't know if Mark is joining.

### You (2025-04-22T17:34:42.157Z)

K.

### Guest (2025-04-22T17:34:42.828Z)

Do I have an echo on your side?

### You (2025-04-22T17:34:43.857Z)

I'm to echo on your side No. Okay. You said he's open.

### Guest (2025-04-22T17:34:46.598Z)

Okay.

### You (2025-04-22T17:34:49.487Z)

And that is Vinod joint? Yeah. We met yesterday. He's got it on his calendar. Okay. We we talked about it. So He's been busy. It's nice that it's, oh, wow.

### Guest (2025-04-22T17:34:49.948Z)

And then is Vinod joining? Okay. He's been busy. It's nice. It's like, oh, wow. With emails and things like that. You know, like, let we need to do this and this and this. Exciting.

### You (2025-04-22T17:35:10.847Z)

Yeah. You know, I don't have an echo, but you do sound like maybe on your end. It sounds like it's kinda reverberating a bit or something.

### Guest (2025-04-22T17:35:18.818Z)

Yes. Let's see.

### You (2025-04-22T17:35:21.027Z)

Let's see.

### Guest (2025-04-22T17:35:32.958Z)

I'm gonna leave and join again.

### You (2025-04-22T17:35:34.377Z)

Okay. Did you note?

### Guest (2025-04-22T17:36:31.398Z)

Did you finish the note taking?

### You (2025-04-22T17:36:31.447Z)

Or the the arrangement? Yeah. Yeah. I sent that out to to everybody on Sunday.

### Guest (2025-04-22T17:36:35.438Z)

Or the data range thing?

### You (2025-04-22T17:36:38.067Z)

So you should have gotten a copy of the email then. So Vinod is now starting to put together the database. There we go. I all I was were tiling strangely. Not sure why that's working that way. Alright. There. Yeah. So I mean, I got as much done as I can. For now. Definitely have enough done so that we can do the summary, the operating cash flow, cash flow summary, five year cash flow pages, and and probably a good portion of the penetration for version one. I mean, it sounds like a lot, but they actually share a lot of data.

### Guest (2025-04-22T17:37:34.718Z)

Okay.

### You (2025-04-22T17:37:36.727Z)

So for example, I I think the cash flow summary

### Guest (2025-04-22T17:37:39.338Z)

Right.

### You (2025-04-22T17:37:40.107Z)

just takes the data off the operating cash flow and divides it by a thousand. Right? To to to put it, it's just the same data. It's just formatted differently.

### Guest (2025-04-22T17:37:47.898Z)

Mhmm.

### You (2025-04-22T17:37:48.987Z)

So, yeah, I think we're I think we're in good play. Good place there. So I know Vinod was working on database, and I kind of pinged me this morning, said he was making making some progress there. Okay. Let me oh, crap. I left my phone downstairs. Let me see if I can ping the note on Okay. Just just message him on iPhone.

### Guest (2025-04-22T17:38:26.668Z)

Okay.

### You (2025-04-22T17:38:45.307Z)

I'm wondering if he thinks that maybe it was moved to Friday. I was all over. Sorry about that. Hello?

### Guest (2025-04-22T17:38:55.868Z)

I moved all over. Sorry about that.

### You (2025-04-22T17:38:59.177Z)

Oh, hey, Mark. How are you?

### Guest (2025-04-22T17:39:00.578Z)

Hello?

### You (2025-04-22T17:39:00.917Z)

Hey, Mark. Good. How are you? Good. We're waiting for Vinod and Drew.

### Guest (2025-04-22T17:39:07.698Z)

Hey, Mark. Good. How are you?

### You (2025-04-22T17:39:08.167Z)

Was this call originally a two?

### Guest (2025-04-22T17:39:09.118Z)

We're waiting for Vinod and Drew.

### You (2025-04-22T17:39:10.117Z)

One. Oh. Okay. It looks like I got confused. Sorry. I'm a little late. Oh, no. Maybe it was

### Guest (2025-04-22T17:39:14.558Z)

Was this call originally a two? One.

### You (2025-04-22T17:39:17.987Z)

two. I I thought it I thought it started two.

### Guest (2025-04-22T17:39:20.318Z)

Okay. I guess I got confused. Sorry. I'm a little late. Oh, no. Maybe maybe it was

### You (2025-04-22T17:39:20.437Z)

I'm just driving back from meeting. Can you hear me okay?

### Guest (2025-04-22T17:39:24.538Z)

two. I I thought it I thought it started two.

### You (2025-04-22T17:39:26.907Z)

Yeah.

### Guest (2025-04-22T17:39:27.028Z)

I'm just driving back from a meeting.

### You (2025-04-22T17:39:27.627Z)

Yep. All good. How's everyone doing?

### Guest (2025-04-22T17:39:29.948Z)

Can you hear me okay?

### You (2025-04-22T17:39:32.117Z)

Good. Yeah.

### Guest (2025-04-22T17:39:33.768Z)

Yep.

### You (2025-04-22T17:39:34.617Z)

We're making progress.

### Guest (2025-04-22T17:39:34.958Z)

Oh, good. How's everyone doing?

### You (2025-04-22T17:39:36.367Z)

It's really exciting to see what Howard and are doing.

### Guest (2025-04-22T17:39:38.168Z)

Good.

### You (2025-04-22T17:39:40.007Z)

That's great.

### Guest (2025-04-22T17:39:40.838Z)

We're making progress. It's really

### You (2025-04-22T17:39:42.827Z)

Yeah. Making some good progress.

### Guest (2025-04-22T17:39:44.068Z)

exciting to see what Howard and Vinod are doing. That's great.

### You (2025-04-22T17:39:48.717Z)

So how was your weekend, Mark? My weekend was was good. I've been drinking out of town, so it was fun. Cool. Had some golf. How about you?

### Guest (2025-04-22T17:40:02.658Z)

My weekend was was good.

### You (2025-04-22T17:40:03.177Z)

Weather wasn't too great around here, so I think we spend most of the time inside.

### Guest (2025-04-22T17:40:05.408Z)

From out of town, so it was fun.

### You (2025-04-22T17:40:08.447Z)

But still are you, guys? Still a good weekend. Michigan.

### Guest (2025-04-22T17:40:08.518Z)

Played some golf. How about you?

### You (2025-04-22T17:40:12.997Z)

So Okay. Yeah. It's been a little cooler than usual.

### Guest (2025-04-22T17:40:14.938Z)

Where are you based?

### You (2025-04-22T17:40:18.617Z)

And we had some Break it up, being done?

### Guest (2025-04-22T17:40:19.908Z)

Okay.

### You (2025-04-22T17:40:20.637Z)

Not really. Not getting a whole lot done outdoors. So but I think it's it's actually supposed to warm up today. It's in the probably low

### Guest (2025-04-22T17:40:26.138Z)

Spring has not begun?

### You (2025-04-22T17:40:30.007Z)

sixties, and tomorrow and Thursday, we're supposed to be up in the seventies. So I think we're finally getting some decent weather. Right. How's Atlanta, Diane?

### Guest (2025-04-22T17:40:40.858Z)

That's good news.

### You (2025-04-22T17:40:40.927Z)

Atlanta's good. I'm an Baltimore today.

### Guest (2025-04-22T17:40:44.938Z)

Right.

### You (2025-04-22T17:40:45.457Z)

Oh, okay.

### Guest (2025-04-22T17:40:47.518Z)

How's Atlanta, Diane? Atlanta's good. I'm in Baltimore today. Oh, okay.

### You (2025-04-22T17:41:07.957Z)

Well, Diane, was there anything else you wanted to start on before Drew and Vinod joined? Vinod has not replied back to my text. He may be on a call. He what? He may he might be on a call. I don't know. Okay. He hasn't replied back to my text

### Guest (2025-04-22T17:41:23.728Z)

Let's

### You (2025-04-22T17:41:24.717Z)

yet. On this side, let's see.

### Guest (2025-04-22T17:41:28.088Z)

He what? Okay. Okay. Well, on my side let's see. Share. Mark won't be able to see this, but

### You (2025-04-22T17:41:42.617Z)

I'll be back in my office in about ten minutes. Yeah I can see it yep Okay. So

### Guest (2025-04-22T17:41:52.518Z)

I'll be back in my office in about ten minutes.

### You (2025-04-22T17:41:53.317Z)

I'm sure I have this is what Drew had started.

### Guest (2025-04-22T17:41:57.368Z)

You, can you see this Excel sheet?

### You (2025-04-22T17:41:59.067Z)

Yeah.

### Guest (2025-04-22T17:41:59.798Z)

Okay. So up here are this is what Drew had started.

### You (2025-04-22T17:42:03.657Z)

K. Diane, are you using an external speaker or

### Guest (2025-04-22T17:42:06.648Z)

Which was, like, the product road map.

### You (2025-04-22T17:42:07.707Z)

microphone or something? I

### Guest (2025-04-22T17:42:10.088Z)

But down here is where I started the budget.

### You (2025-04-22T17:42:11.627Z)

Okay. Yeah if you've got two devices you might have to mute one of them

### Guest (2025-04-22T17:42:19.598Z)

I'm hold on. Let me try one other thing. Give me one second.

### You (2025-04-22T17:42:57.347Z)

Much, much better. Okay. Yeah. Yeah. I think you're getting a little loop going there with

### Guest (2025-04-22T17:43:04.728Z)

Howard, can you hear me now?

### You (2025-04-22T17:43:05.707Z)

whatever speaker and microphone combination you had originally.

### Guest (2025-04-22T17:43:08.618Z)

Okay.

### You (2025-04-22T17:43:09.177Z)

Okay. Yeah. So is this a checklist? It It's

### Guest (2025-04-22T17:43:18.558Z)

Okay.

### You (2025-04-22T17:43:18.747Z)

K. To get, you know,

### Guest (2025-04-22T17:43:20.958Z)

So it's more I'm gonna put numbers.

### You (2025-04-22T17:43:28.057Z)

months.

### Guest (2025-04-22T17:43:29.808Z)

To get to the 1 and a half 2,000,000.

### You (2025-04-22T17:43:31.977Z)

I'm sorry. What?

### Guest (2025-04-22T17:43:34.988Z)

We talked about last week, $4.20 more.

### You (2025-04-22T17:43:36.047Z)

I just started on

### Guest (2025-04-22T17:43:38.588Z)

Months.

### You (2025-04-22T17:43:39.297Z)

Yeah. I can I can hear you just fine?

### Guest (2025-04-22T17:43:40.768Z)

Are you sure we still don't have a

### You (2025-04-22T17:43:41.337Z)

Okay. Yeah. Hear I I I can hear you you. Of

### Guest (2025-04-22T17:43:46.518Z)

Are you sure I okay.

### You (2025-04-22T17:43:52.927Z)

No worries.

### Guest (2025-04-22T17:43:53.628Z)

I can hear you as well.

### You (2025-04-22T17:43:54.337Z)

Can you see the spreadsheet, though?

### Guest (2025-04-22T17:43:55.768Z)

Can you hear me? Yes.

### You (2025-04-22T17:43:58.267Z)

I do. Yes. Okay. So so you're on it. Okay.

### Guest (2025-04-22T17:43:59.238Z)

Sorry. My camera is not working for some reason, so I'll just be on audio. Right in. Yes.

### You (2025-04-22T17:44:08.217Z)

Technology. Development. Yes.

### Guest (2025-04-22T17:44:13.288Z)

So what I need is

### You (2025-04-22T17:44:13.707Z)

Yeah. Yeah.

### Guest (2025-04-22T17:44:17.058Z)

the

### You (2025-04-22T17:44:17.247Z)

I look at that part.

### Guest (2025-04-22T17:44:18.798Z)

technology

### You (2025-04-22T17:44:19.457Z)

Credit documents. But

### Guest (2025-04-22T17:44:20.208Z)

development Yes. Yep.

### You (2025-04-22T17:44:23.937Z)

think

### Guest (2025-04-22T17:44:26.358Z)

Yeah. I was actually looking to that part. I the documents, but it's not finalized yet.

### You (2025-04-22T17:44:30.917Z)

Okay. Then

### Guest (2025-04-22T17:44:33.938Z)

I think we I'll I'll should have by, say, before the end of this week. Okay.

### You (2025-04-22T17:44:43.807Z)

much.

### Guest (2025-04-22T17:44:44.888Z)

And then I've gone through and put

### You (2025-04-22T17:44:45.427Z)

Same with insurance.

### Guest (2025-04-22T17:44:48.598Z)

marketing office equipment

### You (2025-04-22T17:44:50.957Z)

Said. And

### Guest (2025-04-22T17:44:51.658Z)

which I don't really need very much.

### You (2025-04-22T17:44:52.617Z)

talked about that last

### Guest (2025-04-22T17:44:54.028Z)

I'm gonna put placeholder

### You (2025-04-22T17:44:54.527Z)

week. The $1.25 to $1.50 for.

### Guest (2025-04-22T17:44:56.328Z)

licensing and registration. Same with insurance.

### You (2025-04-22T17:45:00.577Z)

And

### Guest (2025-04-22T17:45:03.148Z)

With all the reason. And we talked about that last week, geek, the $1.25. To $1.50. For each of us. And then

### You (2025-04-22T17:45:17.867Z)

Okay. Yeah. If you're on your headphones,

### Guest (2025-04-22T17:45:19.018Z)

for travel and conferences, These are the whole conferences. Sorry. I have an echo and so it's weird for me to have my own voice.

### You (2025-04-22T17:45:28.957Z)

security. And it has customer

### Guest (2025-04-22T17:45:31.588Z)

I don't hear an echo.

### You (2025-04-22T17:45:31.817Z)

support. And I

### Guest (2025-04-22T17:45:34.978Z)

Okay. Yeah. I hear an echo.

### You (2025-04-22T17:45:35.777Z)

research. I've had.

### Guest (2025-04-22T17:45:38.008Z)

It's equally

### You (2025-04-22T17:45:38.617Z)

Sky

### Guest (2025-04-22T17:45:40.458Z)

It's okay for you. I know.

### You (2025-04-22T17:45:43.667Z)

total

### Guest (2025-04-22T17:45:44.168Z)

Yep.

### You (2025-04-22T17:45:44.807Z)

budget.

### Guest (2025-04-22T17:45:44.988Z)

And data security and customer support. And I had done this research, where I found guides on how to fill out the twenty four month budget.

### You (2025-04-22T17:46:05.807Z)

Alright. Diane, I just pasted the link

### Guest (2025-04-22T17:46:09.658Z)

I'm also working on

### You (2025-04-22T17:46:10.567Z)

to the Google Sheets that I've been working on with all the

### Guest (2025-04-22T17:46:12.158Z)

Trello

### You (2025-04-22T17:46:14.837Z)

technical numbers.

### Guest (2025-04-22T17:46:16.288Z)

and, again, Charcart.

### You (2025-04-22T17:46:17.687Z)

Okay. So

### Guest (2025-04-22T17:46:19.858Z)

So that we have our

### You (2025-04-22T17:46:20.727Z)

Vinod and I were still working on a couple things here. You'll see that there's a you know, like, the database

### Guest (2025-04-22T17:46:22.388Z)

road map and to do list

### You (2025-04-22T17:46:25.217Z)

servers, you know, some of the back end stuff that we'll have to get pricing on. But I've got pricing for most of the other items up there.

### Guest (2025-04-22T17:46:34.478Z)

Okay.

### You (2025-04-22T17:46:36.317Z)

And keep in mind, not all of this needs to be done in day one. Some of these can wait until we either grow the team or have a need for it. So like, there's two of them on there that do the same thing, guide and scribe. Those are basically screen recording tools that will use AI to create user

### Guest (2025-04-22T17:47:01.218Z)

Right.

### You (2025-04-22T17:47:01.387Z)

onboarding and tools like that. So, obviously, something like that, we're not gonna need until we're actually bringing in clients. So So you know, instead of calling back on getting the enterprise, we'll probably feature of the chat so that we've got to the next evaluation. So, you know, the the Slack would be

### Guest (2025-04-22T17:47:37.218Z)

Yeah. I think a few items we should

### You (2025-04-22T17:47:39.427Z)

probably great. I don't know.

### Guest (2025-04-22T17:47:40.828Z)

just close ASAP. One is that chat application. Right?

### You (2025-04-22T17:47:42.047Z)

One that Howard has created the result is there.

### Guest (2025-04-22T17:47:45.328Z)

So, you know, instead of holding back on getting the email replies,

### You (2025-04-22T17:47:47.057Z)

I just keep just mess it up one I don't know that.

### Guest (2025-04-22T17:47:49.908Z)

we would probably have as each other on the chat so that we could see double little. So either Teams or Slack would be

### You (2025-04-22T17:47:56.817Z)

Beauty of the app is easier, like, you have the app. You get the notification and all. Right?

### Guest (2025-04-22T17:47:59.558Z)

probably great. I don't know the one app that Howard had created.

### You (2025-04-22T17:48:01.387Z)

Yeah. Vinod, I I really kinda created that as a

### Guest (2025-04-22T17:48:04.228Z)

Whether we all are in there.

### You (2025-04-22T17:48:04.647Z)

stop gap between now and when we do have something.

### Guest (2025-04-22T17:48:06.258Z)

I just keep mess I, like, just message everyone

### You (2025-04-22T17:48:07.607Z)

But I agree. You know, you and I were talking about the email yesterday. We do need to get

### Guest (2025-04-22T17:48:10.568Z)

on that channel, but I don't hear about it. So probably we all are not there.

### You (2025-04-22T17:48:13.067Z)

that set up. And I did

### Guest (2025-04-22T17:48:15.458Z)

Also, think the using the app is easier. Like,

### You (2025-04-22T17:48:15.707Z)

mention before that Microsoft or GoDaddy had a

### Guest (2025-04-22T17:48:18.568Z)

you have the app. You get the notification and all. Right?

### You (2025-04-22T17:48:20.387Z)

really good deal with Microsoft. If we wanna host it in Microsoft And if we do, we could bump up one level, I think it is, and the

### Guest (2025-04-22T17:48:26.918Z)

Yeah.

### You (2025-04-22T17:48:30.227Z)

I don't remember exactly what the cost was, but that would include Office three sixty five with Teams so that we could all just then use a Teams chat. As well. So but until we all have the same domain, email domain, and we're part of the same organization, we won't be able to use things like that until we can until we do. Yeah. Two professional. Right? Right. Right. That's what I'm talking about. I yeah. Yeah. Yeah.

### Guest (2025-04-22T17:49:16.698Z)

You guys but you guys don't have

### You (2025-04-22T17:49:19.747Z)

Know, Microsoft

### Guest (2025-04-22T17:49:20.478Z)

like, Teams professional. Right?

### You (2025-04-22T17:49:22.277Z)

products. Yeah. Yeah.

### Guest (2025-04-22T17:49:24.798Z)

Yeah. Do you

### You (2025-04-22T17:49:25.877Z)

Like,

### Guest (2025-04-22T17:49:26.338Z)

Using personal? Yeah. Okay.

### You (2025-04-22T17:49:28.907Z)

like. Includes everything.

### Guest (2025-04-22T17:49:31.058Z)

Hold on. Let me see because you there are, you know, there are different license

### You (2025-04-22T17:49:33.317Z)

But like, 15 Right? That's that's what I was looking at.

### Guest (2025-04-22T17:49:37.718Z)

levels. For, Microsoft, all the different products.

### You (2025-04-22T17:49:40.637Z)

If we just did email only with the GoDaddy,

### Guest (2025-04-22T17:49:43.218Z)

Yeah. You know, I don't know

### You (2025-04-22T17:49:44.527Z)

they have a special for, like, the first year where it's, like, $4.95 a month.

### Guest (2025-04-22T17:49:46.358Z)

Like, getting an e five license, which is the one that's, like,

### You (2025-04-22T17:49:49.507Z)

But if we wanna get the

### Guest (2025-04-22T17:49:49.538Z)

everything, which is what I have is, like, you know, over a hundred dollars a month. It's very expensive.

### You (2025-04-22T17:49:52.047Z)

basic Office three sixty five team

### Guest (2025-04-22T17:49:53.788Z)

But a basic license, like, the very, very basic is, like,

### You (2025-04-22T17:49:55.067Z)

It seems to me, like, it was 15 or $17 a month. It was pretty it was fairly

### Guest (2025-04-22T17:49:57.008Z)

$15 a month. Right? So

### You (2025-04-22T17:49:59.917Z)

inexpensive. So yep. Yeah. Yeah. It would be yeah. It would be for the invest domain. And so we would just have the invest domain.

### Guest (2025-04-22T17:50:19.198Z)

Yeah. So the ones within yeah. I'm okay.

### You (2025-04-22T17:50:23.387Z)

Microsoft, we would use that. So we'd get the DNS and everything from

### Guest (2025-04-22T17:50:23.488Z)

Where is it? Products, payments, marketplace. Here we go. Yeah. The one that includes

### You (2025-04-22T17:50:27.277Z)

GoDaddy, set it up in Microsoft so that we would have email service.

### Guest (2025-04-22T17:50:27.408Z)

I mean, you're really just looking for email and and does that one that that with GoDaddy, does that include, Teams as well?

### You (2025-04-22T17:50:32.387Z)

Yeah.

### Guest (2025-04-22T17:50:34.608Z)

Okay. That would be that would be sufficient.

### You (2025-04-22T17:50:44.477Z)

Yeah. Yeah. Very expensive. And we can always we can always expand later if we need it.

### Guest (2025-04-22T17:50:50.578Z)

Yeah.

### You (2025-04-22T17:50:51.147Z)

Yeah. Yeah.

### Guest (2025-04-22T17:50:58.788Z)

Microsoft Teams. Okay. Yeah. There's Microsoft Teams Essentials and Teams Yeah. So we should able to get something for not that expensive. Okay. Yeah. Yeah.

### You (2025-04-22T17:51:12.677Z)

Yeah. Yeah.

### Guest (2025-04-22T17:51:15.158Z)

Okay. So we take a call on that one? Just to close one item? Team.

### You (2025-04-22T17:51:23.367Z)

Yeah. But I'm gonna have to work with Diane because, you know, she did give me access

### Guest (2025-04-22T17:51:25.218Z)

Yeah. Team. Yeah. Teams and email.

### You (2025-04-22T17:51:27.917Z)

to

### Guest (2025-04-22T17:51:28.288Z)

Through GoDaddy. Right?

### You (2025-04-22T17:51:28.707Z)

GoDaddy, but the Microsoft would be a separate

### Guest (2025-04-22T17:51:30.508Z)

That's what Howard was saying. Yeah. Yep.

### You (2025-04-22T17:51:33.617Z)

you know, it it was it was marketed through GoDaddy, but we would have to set up in the

### Guest (2025-04-22T17:51:37.748Z)

Cool. So, Howard, you you'll take care of that

### You (2025-04-22T17:51:39.977Z)

account and everything like that. So we need to figure out

### Guest (2025-04-22T17:51:42.538Z)

or I should

### You (2025-04-22T17:51:42.567Z)

you know, who's gonna whose plastic we're gonna use for the first few months and who's gonna be the administrator and at least on the email portion, I know that we can set up multiple administrators. So, you know, one of the skips hits by the proverbial train, But with with the domain, you I there's limited things that I could do

### Guest (2025-04-22T17:52:06.648Z)

Mhmm.

### You (2025-04-22T17:52:07.047Z)

Diane, with with your with your login. So Okay. Yep. Yeah. Just let me know when you have and shoot me an invite. We'll set some time up to do it. It's

### Guest (2025-04-22T17:52:30.678Z)

Okay. Maybe you and I could have a separate call and just go through all of them. I can put the total together

### You (2025-04-22T17:52:37.487Z)

So

### Guest (2025-04-22T17:52:38.138Z)

then we can figure it out

### You (2025-04-22T17:52:39.977Z)

Yeah.

### Guest (2025-04-22T17:52:40.618Z)

Okay.

### You (2025-04-22T17:52:40.977Z)

Yeah.

### Guest (2025-04-22T17:52:41.628Z)

Okay.

### You (2025-04-22T17:52:42.497Z)

In fact, if you take a look on that spreadsheet, Trello is owned by Atlassian. So

### Guest (2025-04-22T17:52:47.588Z)

It's the same with Trello.

### You (2025-04-22T17:52:49.337Z)

for the Jira

### Guest (2025-04-22T17:52:49.658Z)

I had a like, I I've been paying, like, $10 a month.

### You (2025-04-22T17:52:51.627Z)

that Vinod and I would be using, that's $17.20 a month.

### Guest (2025-04-22T17:52:53.948Z)

But to upgrade for all of you is gonna increase the price.

### You (2025-04-22T17:52:56.557Z)

And if we add confluence on top of it, that's 32.

### Guest (2025-04-22T17:52:58.738Z)

So it's just another thing that added.

### You (2025-04-22T17:53:01.497Z)

With confluence, that also includes Trello and actually quite a few other ones. Loom, which is very good. So altogether, we're talking about just shy of $40 a month. To get everything. There. So Perfect. I Yeah. Yeah. Yeah. Because I have this speaker challenge, Howard and Vinod you wanna leave through? Been done. So

### Guest (2025-04-22T17:53:37.658Z)

Per person. Right?

### You (2025-04-22T17:53:39.247Z)

sorry. Our

### Guest (2025-04-22T17:53:39.268Z)

Yes.

### You (2025-04-22T17:53:40.687Z)

Yeah. Speak with you. And

### Guest (2025-04-22T17:53:43.388Z)

Because I have this speaker challenge, Howard and Vinod do you wanna lead through what's been done

### You (2025-04-22T17:53:48.027Z)

thing Yeah. Yeah.

### Guest (2025-04-22T17:53:51.668Z)

since last week and where we need to go on the proof of comp? Concept. Yeah. Cool. So, Howard,

### You (2025-04-22T17:53:58.217Z)

So

### Guest (2025-04-22T17:54:00.588Z)

so, Howard, I'll with you, and then you can kind of take it forward from there. So Howard and

### You (2025-04-22T17:54:03.387Z)

I don't care. So

### Guest (2025-04-22T17:54:07.438Z)

I met the day before. Was it yesterday, Howard? Or

### You (2025-04-22T17:54:08.197Z)

basically, okay. At

### Guest (2025-04-22T17:54:11.148Z)

day

### You (2025-04-22T17:54:11.327Z)

legacy. Flow.

### Guest (2025-04-22T17:54:13.758Z)

So, basically, we are

### You (2025-04-22T17:54:14.137Z)

And a form insert some of it.

### Guest (2025-04-22T17:54:18.068Z)

discussing what is the MVP that we want to create. Right?

### You (2025-04-22T17:54:18.227Z)

Things that user is supposed to. So patching

### Guest (2025-04-22T17:54:21.568Z)

So

### You (2025-04-22T17:54:21.837Z)

That part of the integration

### Guest (2025-04-22T17:54:23.088Z)

I think the first item is do your model that create files.

### You (2025-04-22T17:54:28.267Z)

depth.

### Guest (2025-04-22T17:54:30.488Z)

So

### You (2025-04-22T17:54:31.217Z)

Could take a part. Right?

### Guest (2025-04-22T17:54:32.138Z)

basically, a way to create a deal, like, a deal flow

### You (2025-04-22T17:54:32.437Z)

So for data, your topic know. To

### Guest (2025-04-22T17:54:38.358Z)

and a form to insert

### You (2025-04-22T17:54:38.477Z)

probably simplify.

### Guest (2025-04-22T17:54:41.588Z)

some of the details that user is supposed to punch in as part of the deal creation. And

### You (2025-04-22T17:54:51.367Z)

Bit.

### Guest (2025-04-22T17:54:52.748Z)

then probably

### You (2025-04-22T17:54:53.777Z)

Probably how to suggest

### Guest (2025-04-22T17:54:55.898Z)

the data part. Right? So for data, I think we were

### You (2025-04-22T17:54:56.967Z)

So we could just, like, give the data in

### Guest (2025-04-22T17:55:01.038Z)

talking where if, you know, Drew would probably simplify that data's

### You (2025-04-22T17:55:01.297Z)

and say, call it for my.

### Guest (2025-04-22T17:55:05.858Z)

piece, their work grade, like, at

### You (2025-04-22T17:55:06.347Z)

Call it. And

### Guest (2025-04-22T17:55:10.158Z)

the one, Drew, you sent earlier, that was, like,

### You (2025-04-22T17:55:13.787Z)

a different

### Guest (2025-04-22T17:55:14.958Z)

I felt that was a bit

### You (2025-04-22T17:55:15.007Z)

task that we find. So

### Guest (2025-04-22T17:55:18.868Z)

probably hard to ingest.

### You (2025-04-22T17:55:21.637Z)

Okay.

### Guest (2025-04-22T17:55:22.598Z)

If we could just, like,

### You (2025-04-22T17:55:22.697Z)

Yeah.

### Guest (2025-04-22T17:55:24.808Z)

give the data in say column format. So we have column names

### You (2025-04-22T17:55:32.327Z)

You know?

### Guest (2025-04-22T17:55:32.738Z)

header on the top, and then, you know, data filled in

### You (2025-04-22T17:55:33.477Z)

Hyper security. You know? Dimension.

### Guest (2025-04-22T17:55:36.038Z)

probably in a row or in different tabs, that will be fine too.

### You (2025-04-22T17:55:40.217Z)

Account and

### Guest (2025-04-22T17:55:42.188Z)

Then I would kind of write a script to grab the data and put it in our database.

### You (2025-04-22T17:55:42.357Z)

department. Like, hire structure.

### Guest (2025-04-22T17:55:46.878Z)

Okay. Yeah. I think we should we didn't really get to this when we last

### You (2025-04-22T17:55:47.097Z)

So which is you know, they use out of data.

### Guest (2025-04-22T17:55:51.128Z)

couple weeks ago when we, like, went through and talked about

### You (2025-04-22T17:55:51.567Z)

Get spit out And I

### Guest (2025-04-22T17:55:54.268Z)

the location table, the, you know,

### You (2025-04-22T17:55:56.267Z)

so

### Guest (2025-04-22T17:55:58.228Z)

financial type version period, you know, that sort of dimension.

### You (2025-04-22T17:56:01.407Z)

Howard said it.

### Guest (2025-04-22T17:56:02.258Z)

The we did not get to talk about the account and department.

### You (2025-04-22T17:56:07.247Z)

You want to have color,

### Guest (2025-04-22T17:56:08.228Z)

Like hierarchy and structure,

### You (2025-04-22T17:56:10.147Z)

super to do.

### Guest (2025-04-22T17:56:11.848Z)

So

### You (2025-04-22T17:56:12.917Z)

To put in

### Guest (2025-04-22T17:56:13.308Z)

which is which is obviously the, you know, the big piece of how the data

### You (2025-04-22T17:56:13.497Z)

Super wanted to include with that, like,

### Guest (2025-04-22T17:56:17.018Z)

gets spit out and how it gets organized. So we could do

### You (2025-04-22T17:56:21.977Z)

Yeah.

### Guest (2025-04-22T17:56:23.928Z)

Like, I I think and I think you said an email, Howard, that that you and I should set up the time to talk specifically about that. Because I we can I can manipulate the data to

### You (2025-04-22T17:56:28.197Z)

Like,

### Guest (2025-04-22T17:56:32.368Z)

if you want it all in columns, totally fine?

### You (2025-04-22T17:56:35.327Z)

record.

### Guest (2025-04-22T17:56:35.728Z)

Super easy to do.

### You (2025-04-22T17:56:35.907Z)

Has a lot

### Guest (2025-04-22T17:56:37.018Z)

I think we also wanted one thing we

### You (2025-04-22T17:56:38.647Z)

a year

### Guest (2025-04-22T17:56:39.038Z)

wanted to include was, like, an ID number, like,

### You (2025-04-22T17:56:39.547Z)

of financial type

### Guest (2025-04-22T17:56:43.438Z)

account ID or some kind of

### You (2025-04-22T17:56:44.757Z)

an account ID,

### Guest (2025-04-22T17:56:45.538Z)

numerical ID versus the names.

### You (2025-04-22T17:56:46.357Z)

a department ID, and maybe things and other things

### Guest (2025-04-22T17:56:48.788Z)

Totally makes sense. But I think the other I mean, the other

### You (2025-04-22T17:56:50.487Z)

too.

### Guest (2025-04-22T17:56:51.928Z)

thing that

### You (2025-04-22T17:56:52.417Z)

The last US

### Guest (2025-04-22T17:56:53.918Z)

like, the way our system is built is

### You (2025-04-22T17:56:54.847Z)

and the department ID.

### Guest (2025-04-22T17:56:56.468Z)

to to preserve uniqueness

### You (2025-04-22T17:56:56.767Z)

Are what's

### Guest (2025-04-22T17:57:00.088Z)

a record has

### You (2025-04-22T17:57:01.817Z)

there's

### Guest (2025-04-22T17:57:02.158Z)

a month, a year, a financial type,

### You (2025-04-22T17:57:02.827Z)

like, account ID, I correspond to, like,

### Guest (2025-04-22T17:57:05.988Z)

aversion period,

### You (2025-04-22T17:57:08.127Z)

right?

### Guest (2025-04-22T17:57:08.348Z)

an operating unit ID,

### You (2025-04-22T17:57:08.737Z)

And then it's carbon might be too

### Guest (2025-04-22T17:57:10.388Z)

an account ID,

### You (2025-04-22T17:57:10.757Z)

so this department might be

### Guest (2025-04-22T17:57:11.938Z)

a department ID,

### You (2025-04-22T17:57:12.167Z)

to your house keeping

### Guest (2025-04-22T17:57:13.528Z)

Mhmm. And maybe maybe some other things too.

### You (2025-04-22T17:57:14.767Z)

whatever. And if there's

### Guest (2025-04-22T17:57:16.648Z)

But the so the

### You (2025-04-22T17:57:16.857Z)

like, there's a double table, like, there's a driver, he goes, oh,

### Guest (2025-04-22T17:57:17.958Z)

the last two I said, the account ID

### You (2025-04-22T17:57:20.057Z)

Right? So there's

### Guest (2025-04-22T17:57:20.408Z)

and the department ID

### You (2025-04-22T17:57:21.187Z)

like, four, five levels of hierarchy. So

### Guest (2025-04-22T17:57:22.338Z)

are what feed into the chart of accounts.

### You (2025-04-22T17:57:23.407Z)

the link accounts all get matched to a linked account from our side. All the listed

### Guest (2025-04-22T17:57:25.708Z)

And there's by the an account

### You (2025-04-22T17:57:28.947Z)

accounts get mapped to operating expense

### Guest (2025-04-22T17:57:29.758Z)

ID might correspond to, like, win in cost.

### You (2025-04-22T17:57:30.927Z)

group group.

### Guest (2025-04-22T17:57:33.648Z)

Right?

### You (2025-04-22T17:57:33.767Z)

Group

### Guest (2025-04-22T17:57:34.348Z)

Then the department might be Zooms or the department might be food and beverage or housekeeping or whatever. And then there's, like, there's another table. Like, there's a hierarchy built on that. Right? So there's, like, four or five levels of hierarchy. So the Linen accounts all get mapped to a Linen account on our side, and then all the Linen accounts get mapped

### You (2025-04-22T17:57:51.477Z)

That they are hour have completed.

### Guest (2025-04-22T17:57:55.018Z)

to an operating expense grouping. And all the operating expense grouping is getting mixed to, like, a

### You (2025-04-22T17:57:58.487Z)

So

### Guest (2025-04-22T17:58:00.088Z)

you know, whatever. Another and it goes all the way up. Right? So I don't know if that's the same kind of thing that we would build in this or if there's another way to do it.

### You (2025-04-22T17:58:05.167Z)

just on that. I think that's

### Guest (2025-04-22T17:58:07.588Z)

Maybe that's not hierarchical. I don't I don't know. I'm just I wanna make sure that get that set up the right way.

### You (2025-04-22T17:58:08.437Z)

no work. We need. For at least for that. Well,

### Guest (2025-04-22T17:58:12.208Z)

So, Drew, I would build it completely on the model. Model that Diane and Howard completed. So apart from whatever calculation is

### You (2025-04-22T17:58:19.717Z)

scripts.

### Guest (2025-04-22T17:58:24.078Z)

done in the model, like, whatever unique data fields that has,

### You (2025-04-22T17:58:26.197Z)

So

### Guest (2025-04-22T17:58:29.788Z)

I'll build it just on that. I think that's what we need for, at least, for the MVP when we'll when we'll feed our database. And then whenever we generate the model, those unique

### You (2025-04-22T17:58:41.847Z)

So I go to to invest

### Guest (2025-04-22T17:58:44.958Z)

get generated in the model, and then, you know, we already have the calculation in place.

### You (2025-04-22T17:58:45.777Z)

AI, I create to you.

### Guest (2025-04-22T17:58:50.698Z)

So you wouldn't

### You (2025-04-22T17:58:52.097Z)

And then

### Guest (2025-04-22T17:58:52.238Z)

so you don't so so you wouldn't put any of that in the data model?

### You (2025-04-22T17:58:52.737Z)

I clicked on the point, I'll basically

### Guest (2025-04-22T17:58:56.518Z)

What you're saying, or at least not right now? So what so say I am

### You (2025-04-22T17:59:00.577Z)

And I have the calculations in terms of everything. Code base.

### Guest (2025-04-22T17:59:04.688Z)

analyst. I go to

### You (2025-04-22T17:59:05.137Z)

And, you know, I'll basically insert the data

### Guest (2025-04-22T17:59:06.528Z)

so I go to our

### You (2025-04-22T17:59:08.387Z)

that. Model.

### Guest (2025-04-22T17:59:10.648Z)

invest AI. I create create the

### You (2025-04-22T17:59:14.837Z)

Yeah. Vinod, something just popped into my

### Guest (2025-04-22T17:59:15.668Z)

app. I create the deal, and then I

### You (2025-04-22T17:59:17.857Z)

I think I think you and I maybe should work on a workflow

### Guest (2025-04-22T17:59:18.988Z)

click on, say, download model. Right?

### You (2025-04-22T17:59:20.677Z)

chart.

### Guest (2025-04-22T17:59:21.268Z)

At that point, I'll basically

### You (2025-04-22T17:59:21.777Z)

Make it a little bit easier for everybody to understand as what

### Guest (2025-04-22T17:59:23.628Z)

grab the data.

### You (2025-04-22T17:59:25.127Z)

what steps we're taking here to

### Guest (2025-04-22T17:59:26.618Z)

I'll have the calculations done in the code base.

### You (2025-04-22T17:59:27.087Z)

between the time I input the name of the deal in the model

### Guest (2025-04-22T17:59:30.978Z)

And, you know, I'll basically insert the data in that

### You (2025-04-22T17:59:31.587Z)

to the time I get the output. That might help. I can get started on that.

### Guest (2025-04-22T17:59:34.648Z)

model at that point of time.

### You (2025-04-22T17:59:35.917Z)

Yeah.

### Guest (2025-04-22T17:59:36.378Z)

Once the user downloads the model.

### You (2025-04-22T17:59:37.227Z)

Yep. Yep. I can. Yep. Other

### Guest (2025-04-22T17:59:46.948Z)

Mhmm. Yep.

### You (2025-04-22T17:59:48.137Z)

know, AG,

### Guest (2025-04-22T17:59:48.528Z)

Yep.

### You (2025-04-22T17:59:49.697Z)

for the MVP or proof of concept. And then if if they have right our program funding, we can start to work through it

### Guest (2025-04-22T17:59:55.008Z)

Yeah.

### You (2025-04-22T17:59:57.047Z)

how much people Yep. So for MVP, right,

### Guest (2025-04-22T18:00:02.308Z)

Yeah. Yep. Yep. We can we can Hello.

### You (2025-04-22T18:00:03.337Z)

we just focus on Right?

### Guest (2025-04-22T18:00:05.118Z)

What you're saying is for now, we've skewed it at a very high level, right, the data? Because I have it in the model a high level, just rooms, food and beverage, other, you know, a and g,

### You (2025-04-22T18:00:11.747Z)

You want that

### Guest (2025-04-22T18:00:16.228Z)

for the MVP or the proof of concept. And then as we advance, right, and we get

### You (2025-04-22T18:00:20.037Z)

Okay.

### Guest (2025-04-22T18:00:20.958Z)

our first round of funding, we can start to work through

### You (2025-04-22T18:00:21.877Z)

Yeah. Yeah. But

### Guest (2025-04-22T18:00:23.978Z)

how much deeper we wanna go into the data

### You (2025-04-22T18:00:26.227Z)

too. Make sure I get the data organized.

### Guest (2025-04-22T18:00:26.728Z)

Yeah. Yeah. So for MVP, right, we'll just focus on a few tabs few initial tabs, right, summary and a few more tabs there. That's what what I and Howard was discussing.

### You (2025-04-22T18:00:42.477Z)

Around to people. And then ability to track merchant.

### Guest (2025-04-22T18:00:47.728Z)

Okay. Yeah. That makes sense. Yeah.

### You (2025-04-22T18:00:49.987Z)

Yes. But not version one.

### Guest (2025-04-22T18:00:50.458Z)

Let's see. Like, Vinod, let's meet separately to

### You (2025-04-22T18:00:52.127Z)

That would be

### Guest (2025-04-22T18:00:53.348Z)

make sure I get the data organized in the way that you

### You (2025-04-22T18:00:54.937Z)

I mean, it it it would delay.

### Guest (2025-04-22T18:00:56.178Z)

that that works for you.

### You (2025-04-22T18:00:57.467Z)

The release on it.

### Guest (2025-04-22T18:00:58.578Z)

Sounds good. Sounds good. Yeah. On the VP, can we also include

### You (2025-04-22T18:01:00.807Z)

Just real quick. This not every technology problems. Something

### Guest (2025-04-22T18:01:05.578Z)

the ability to, like,

### You (2025-04-22T18:01:06.817Z)

the process.

### Guest (2025-04-22T18:01:07.008Z)

email or route

### You (2025-04-22T18:01:07.557Z)

Yep. Problem. Right?

### Guest (2025-04-22T18:01:08.318Z)

a model around to people, and then

### You (2025-04-22T18:01:08.877Z)

Right. So in this process, rather than

### Guest (2025-04-22T18:01:11.878Z)

the ability to track versions.

### You (2025-04-22T18:01:12.887Z)

you just offset. That the user I in my

### Guest (2025-04-22T18:01:21.798Z)

Right.

### You (2025-04-22T18:01:22.187Z)

session. Rather than know, have to put it back

### Guest (2025-04-22T18:01:25.648Z)

You can also

### You (2025-04-22T18:01:26.177Z)

in the platform in order serve it as version.

### Guest (2025-04-22T18:01:27.708Z)

real quick, Howard, interrupt.

### You (2025-04-22T18:01:28.347Z)

Yeah. And then

### Guest (2025-04-22T18:01:29.078Z)

This there's also you can look

### You (2025-04-22T18:01:29.277Z)

user two,

### Guest (2025-04-22T18:01:30.848Z)

not everything is a technology problem. Some things are just a process.

### You (2025-04-22T18:01:32.867Z)

is gonna download the model from

### Guest (2025-04-22T18:01:34.378Z)

Problem. Right? Right. So business process,

### You (2025-04-22T18:01:35.697Z)

the portal, as you know,

### Guest (2025-04-22T18:01:37.238Z)

rather than emailing a model around

### You (2025-04-22T18:01:37.477Z)

but it's gonna pull the data that put in there and have the version two.

### Guest (2025-04-22T18:01:39.798Z)

you just

### You (2025-04-22T18:01:40.487Z)

And they re up for

### Guest (2025-04-22T18:01:40.998Z)

I think you would say that the process that the users need to use is

### You (2025-04-22T18:01:41.497Z)

You you prefer you

### Guest (2025-04-22T18:01:45.588Z)

I, analyst one, download the model, do my projections,

### You (2025-04-22T18:01:47.287Z)

Yeah. So I mean,

### Guest (2025-04-22T18:01:49.738Z)

rather than email it to somebody

### You (2025-04-22T18:01:50.337Z)

the first model that we have in the application, right, that's coming from the data.

### Guest (2025-04-22T18:01:51.338Z)

I have to put it back in the platform in order to preserve it as version one.

### You (2025-04-22T18:01:54.837Z)

Unless we update the data,

### Guest (2025-04-22T18:01:55.388Z)

And then user two, maybe my boss, maybe another analyst, whoever, whoever,

### You (2025-04-22T18:01:57.377Z)

it's not gonna update the order because you're gonna get

### Guest (2025-04-22T18:01:59.518Z)

is gonna download the model from

### You (2025-04-22T18:02:01.337Z)

So as

### Guest (2025-04-22T18:02:02.658Z)

the portal as, you know,

### You (2025-04-22T18:02:04.227Z)

goal.

### Guest (2025-04-22T18:02:04.478Z)

it's gonna pull the data that I put in there, and that'll be version two. And they reupload

### You (2025-04-22T18:02:05.777Z)

File, right, So you have

### Guest (2025-04-22T18:02:08.548Z)

So you you to preserve the versions, you have to reupload to the portal. That's

### You (2025-04-22T18:02:09.557Z)

system whether you are that's

### Guest (2025-04-22T18:02:12.928Z)

how does that work?

### You (2025-04-22T18:02:13.917Z)

not

### Guest (2025-04-22T18:02:15.138Z)

So, I mean,

### You (2025-04-22T18:02:15.257Z)

part of the

### Guest (2025-04-22T18:02:16.498Z)

the first model that we'll have in the

### You (2025-04-22T18:02:18.627Z)

model.

### Guest (2025-04-22T18:02:19.728Z)

right, that's coming from the database. Unless we update the data,

### You (2025-04-22T18:02:20.047Z)

Based on based on Yeah. And But it

### Guest (2025-04-22T18:02:24.248Z)

it's not update your model because you're gonna get the same data all the times.

### You (2025-04-22T18:02:27.597Z)

core technology, and I thought that was one of the foundation

### Guest (2025-04-22T18:02:28.708Z)

So as far as version worsening goes, that will be part of some file management system. Right?

### You (2025-04-22T18:02:31.127Z)

Yeah. I I I think just just to kinda clarify and and

### Guest (2025-04-22T18:02:34.278Z)

So

### You (2025-04-22T18:02:34.927Z)

what what Drew was mentioning here. The ultimate goal is to

### Guest (2025-04-22T18:02:35.028Z)

you have this file management system wherein you upload your file versions but that's

### You (2025-04-22T18:02:39.567Z)

not have the analysts have to

### Guest (2025-04-22T18:02:40.378Z)

not the part of

### You (2025-04-22T18:02:43.077Z)

download a spreadsheet.

### Guest (2025-04-22T18:02:43.128Z)

the model that you download

### You (2025-04-22T18:02:44.827Z)

And make changes. The goal is for them to do all of their work in the tool.

### Guest (2025-04-22T18:02:47.448Z)

based on the based on what is in the database.

### You (2025-04-22T18:02:50.487Z)

So if they want to tweak a number, if they want to tweak

### Guest (2025-04-22T18:02:50.958Z)

But is it is it is it the model sharing part of our core

### You (2025-04-22T18:02:53.507Z)

the food and beverage, or if they want to tweak any assumption that's in the model,

### Guest (2025-04-22T18:02:55.298Z)

technology? I mean, I thought that was one of the foundations.

### You (2025-04-22T18:02:57.787Z)

they do it in the model. And then the changes are reflected instantly. And so I think when it comes to versioning, that's much easier online so that if if Drew goes in there and he changes a couple of assumptions, you know, we will know that Drew is logged in. Drew clicked on this cell. He changed this number at a particular time stamp. So we have a history and a trail. Right? But if a if if a user has to come into our model and then download an Excel spreadsheet, at that point, it's in a black hole. We have no way of knowing what that user's doing to a spreadsheet, including possibly changing formulas. Right? So that's the idea is to have them work in the model online, make all their changes. If they want to export it to Excel, and do something, that's fine. But that Excel just becomes an outside tool where the single source of truth on that deal still resides in the invest database. Does that clarify? Until redone. Back in. Yeah. I I I call that. Completely. The work yeah. Yeah. By the way. Yeah. Yeah. Ideally, the only thing that gets uploaded

### Guest (2025-04-22T18:04:37.358Z)

Until it's re until somebody reuploads it.

### You (2025-04-22T18:04:38.907Z)

during the process is

### Guest (2025-04-22T18:04:40.138Z)

Back into the system.

### You (2025-04-22T18:04:41.097Z)

more recent data.

### Guest (2025-04-22T18:04:41.418Z)

Yeah. I I I didn't really tell that

### You (2025-04-22T18:04:42.927Z)

So if they get another financial statement,

### Guest (2025-04-22T18:04:44.288Z)

completely. The work a workflow might be useful in this case, Howard.

### You (2025-04-22T18:04:46.117Z)

from last month or updated market data. That would be ingested into the model

### Guest (2025-04-22T18:04:49.298Z)

Vinod, you said you missed that Might make it clear. And and and, you know, indication of

### You (2025-04-22T18:04:53.517Z)

via

### Guest (2025-04-22T18:04:53.988Z)

where you know, in the workflow,

### You (2025-04-22T18:04:54.917Z)

our process. We wouldn't want

### Guest (2025-04-22T18:04:57.548Z)

how and where is somebody interacting

### You (2025-04-22T18:04:58.897Z)

to have

### Guest (2025-04-22T18:04:59.748Z)

with

### You (2025-04-22T18:05:00.157Z)

the users

### Guest (2025-04-22T18:05:00.198Z)

the data or the system? Yeah.

### You (2025-04-22T18:05:01.597Z)

mean, the bottom line is we don't want them to export into Excel make changes, and then re upload that information. The changes

### Guest (2025-04-22T18:05:09.568Z)

Yeah.

### You (2025-04-22T18:05:12.337Z)

example because Yep. So, like, if Diane starts a model and then you know, I want to get to see the work she did. Mhmm. And you know, I've answered many certain changes. You will be able to sort of do a lot Yes. I can Yes.

### Guest (2025-04-22T18:05:35.778Z)

Right. But if I could just if I just to use an example because it will help me understand. Like, if if Diane starts a model,

### You (2025-04-22T18:05:40.437Z)

Absolutely. In fact, that's that's kind of the the basic function and one of the things that that we did with Red IQ is to incorporate

### Guest (2025-04-22T18:05:44.648Z)

and then you know, I wanna log in to see

### You (2025-04-22T18:05:48.247Z)

the concept of the team.

### Guest (2025-04-22T18:05:48.298Z)

the work she did.

### You (2025-04-22T18:05:49.487Z)

Or a group or an account. So you would have an account

### Guest (2025-04-22T18:05:49.498Z)

And, you know, I've asked her to make certain changes. I mean, will I be able to sort of

### You (2025-04-22T18:05:52.937Z)

we'll call it Mark's investment service.

### Guest (2025-04-22T18:05:54.398Z)

log in to a live version of what she did, see all of her changes?

### You (2025-04-22T18:05:55.867Z)

And that account includes Diane and Drew.

### Guest (2025-04-22T18:05:57.808Z)

I could then make additional changes, and then Diane could pull it up a half an hour later.

### You (2025-04-22T18:06:00.237Z)

Vinod and I work for a different company.

### Guest (2025-04-22T18:06:01.718Z)

And see what I did. And we're kinda working off the same sheet of music. I mean, is that the

### You (2025-04-22T18:06:03.247Z)

Right? So we're in a different account. So whatever you do,

### Guest (2025-04-22T18:06:05.738Z)

at a very simplistic

### You (2025-04-22T18:06:06.817Z)

will be visible to Diane and Drew. They can get in there at any time, do what they wanna

### Guest (2025-04-22T18:06:07.198Z)

level, is that kind of

### You (2025-04-22T18:06:11.457Z)

I will never see your deal because I'm not part of the account. But then Vinod and I can do the same thing. Right? So Yeah. So I'm trying to see a lot. So Yeah. Yes. We do wanna not Right. Right. So

### Guest (2025-04-22T18:06:42.558Z)

Okay. So then I so and then could I go in and, like, see a log of all the changes Diane made? So maybe at one point, she was using a

### You (2025-04-22T18:06:49.577Z)

press. That you know,

### Guest (2025-04-22T18:06:51.918Z)

know, 3% growth rate, and then she changed it to a 5% growth rate. And then

### You (2025-04-22T18:06:54.637Z)

to. To potentially go through that. I think we wanna

### Guest (2025-04-22T18:06:55.778Z)

know, just sort of, like, be able to

### You (2025-04-22T18:06:56.717Z)

try to show them

### Guest (2025-04-22T18:06:57.668Z)

see a change log, if you will.

### You (2025-04-22T18:06:57.707Z)

you know, the scope of what we're doing.

### Guest (2025-04-22T18:06:59.468Z)

On an automated basis.

### You (2025-04-22T18:07:00.647Z)

Depth.

### Guest (2025-04-22T18:07:00.968Z)

But in the later version,

### You (2025-04-22T18:07:01.517Z)

Right.

### Guest (2025-04-22T18:07:02.898Z)

not in the MVP work version, though.

### You (2025-04-22T18:07:03.297Z)

So

### Guest (2025-04-22T18:07:05.058Z)

So

### You (2025-04-22T18:07:05.097Z)

see that as kind of functionality

### Guest (2025-04-22T18:07:08.628Z)

how much more work again, I I just

### You (2025-04-22T18:07:08.807Z)

element. So appreciate how important about.

### Guest (2025-04-22T18:07:11.858Z)

asking because I don't know. Like like, how much more work would it be to have that

### You (2025-04-22T18:07:12.987Z)

Thing. How much I don't

### Guest (2025-04-22T18:07:15.868Z)

in the first version? Because I again, one of the things that

### You (2025-04-22T18:07:18.087Z)

how

### Guest (2025-04-22T18:07:19.268Z)

you know, we present this to

### You (2025-04-22T18:07:21.277Z)

of sort of program?

### Guest (2025-04-22T18:07:22.408Z)

potential users. I I think we wanna try to show them you know, the scope of what we're doing and and the depth of what we're doing. Right, to make that first impression. So

### You (2025-04-22T18:07:30.807Z)

Yeah.

### Guest (2025-04-22T18:07:31.518Z)

and I I I've always viewed that as kind of, like, a key

### You (2025-04-22T18:07:31.647Z)

Vinod, let me let me let me

### Guest (2025-04-22T18:07:34.188Z)

functionality element.

### You (2025-04-22T18:07:34.797Z)

tell you what I have in in mind, and you tell me if it's

### Guest (2025-04-22T18:07:36.828Z)

So I I appreciate how much work is involved in doing all this, but I just like how much

### You (2025-04-22T18:07:38.947Z)

correct. But

### Guest (2025-04-22T18:07:41.078Z)

I don't specifically understand. Like, what was that an extra week? Is it a month? Is it, like,

### You (2025-04-22T18:07:41.097Z)

we should, out of the gate, be able to track everything that's done in the app. So

### Guest (2025-04-22T18:07:45.418Z)

how much more is that? In terms of of sort of programming?

### You (2025-04-22T18:07:48.407Z)

when I log in, it's going to show Howard Behrend's logged in on April 22 at 02:08PM eastern time.

### Guest (2025-04-22T18:07:51.218Z)

Yeah.

### You (2025-04-22T18:07:55.437Z)

And then every time I click

### Guest (2025-04-22T18:07:56.408Z)

Yeah. Probably

### You (2025-04-22T18:07:57.907Z)

in the application,

### Guest (2025-04-22T18:07:58.648Z)

like,

### You (2025-04-22T18:07:59.337Z)

it'll track. So it'll know that after I logged in, I went to this particular screen or I went into here and I changed a number. Right? The activity we can track. But to create a version one or version two means we have to add additional functionality so that after I go through and I make changes

### Guest (2025-04-22T18:08:21.858Z)

Right.

### You (2025-04-22T18:08:23.327Z)

I'm going have to click a button to say, okay, this is now happy hollows version one. And then if Diane goes in later and she makes changes, if she wants to change the or if she wants to make that the official version, you know, then she can click this button, and it becomes version two. That's where we get into you know, saving versions, rather than just having the activity log. Right? There's a little bit difference there. And I I think, you know, the node is gonna have to explain the difference in terms of, you know, how much effort is involved on the development side for something like that. Yeah. It's definitely think you. Work. And then you know, whatever. I'm I don't

### Guest (2025-04-22T18:09:30.478Z)

Yeah. I mean, there's definitely

### You (2025-04-22T18:09:31.487Z)

don't have to tell me. Don't ability to upload

### Guest (2025-04-22T18:09:34.118Z)

effort there. But, yeah, I'll I'll

### You (2025-04-22T18:09:34.487Z)

the documents in version one.

### Guest (2025-04-22T18:09:37.148Z)

more through to it, and I'll let you know.

### You (2025-04-22T18:09:39.047Z)

So we'll try it for certain things have data we can from

### Guest (2025-04-22T18:09:43.088Z)

So I mean, what yeah. Sure. So what Howard and I discussed

### You (2025-04-22T18:09:46.527Z)

And you know,

### Guest (2025-04-22T18:09:47.488Z)

is, like, you know, user can log in, create the deal,

### You (2025-04-22T18:09:47.617Z)

kind of

### Guest (2025-04-22T18:09:51.718Z)

and then you know, for now, whatever I don't think we wanna give

### You (2025-04-22T18:09:57.957Z)

the know, that

### Guest (2025-04-22T18:09:59.258Z)

the user the

### You (2025-04-22T18:09:59.977Z)

we have.

### Guest (2025-04-22T18:10:00.688Z)

ability to upload the documents in version one. So

### You (2025-04-22T18:10:01.407Z)

So I think that's that's what we can discuss as final. The first time VP. Yeah. And I and I think it's it's important to clarify

### Guest (2025-04-22T18:10:07.418Z)

most probably for certain deals, we will have the data available from

### You (2025-04-22T18:10:11.047Z)

what version one means.

### Guest (2025-04-22T18:10:12.048Z)

Drew's and, you know, we'll

### You (2025-04-22T18:10:14.387Z)

To to me, and I know Vinod and I spoke about this,

### Guest (2025-04-22T18:10:15.338Z)

kind of the data in application from the database and, you know, let the user

### You (2025-04-22T18:10:18.067Z)

version one is what we go to as a demo. That we can go out to

### Guest (2025-04-22T18:10:22.698Z)

generate the model

### You (2025-04-22T18:10:24.467Z)

friends and colleagues and say, here's what I'm putting together.

### Guest (2025-04-22T18:10:25.908Z)

you know, that we have. So I think that's

### You (2025-04-22T18:10:28.807Z)

So you can click through. You can do things. You can input a number. You see the numbers

### Guest (2025-04-22T18:10:30.488Z)

we discussed as part of the first MVP.

### You (2025-04-22T18:10:33.297Z)

change. Also, the what we would probably go to the initial funding. And say, you know, this is what the model does. We don't need to have, at that point, the ability to drag and drop a financial statement into a box, watch while this thing is being processed, and then everything goes there. We would do is we would say, Okay, after you upload this document, this is what the model does. So we're going to assume, you know, everybody is familiar with the drag and drop. Know, you're gonna have to make certain assumptions or, know, you're gonna have to do it in conjunction with a PowerPoint. Say, you know, we can do mock ups and say, this is what you do. And this is what the model does. So I think the most important thing for version one is to use it for something that we can sit down in front of these people and show them how the model's going to work. And make sure that the calculations are correct so that if we change a holding period from five years to eight years, all of the data is correct based on the changes that we make, right? At the same time, it doesn't mean we'd we'd wait until that's done before we start working on. Document upload. I mean, we're gonna be hopefully, Vinod and I are gonna be a step or two ahead of where actual model is. You know, we're gonna keep working ahead to get that functionality there as soon as possible. Right? Does that make sense? Yeah. All of us hopefully. Created. Yeah. So you know, add on And some more time.

### Guest (2025-04-22T18:12:21.208Z)

Alright.

### You (2025-04-22T18:12:21.287Z)

To the investors of one Yeah.

### Guest (2025-04-22T18:12:26.438Z)

Yeah. And

### You (2025-04-22T18:12:27.047Z)

Something.

### Guest (2025-04-22T18:12:27.198Z)

yeah, and by the end of the, like, MVP, we'll have the entire role

### You (2025-04-22T18:12:27.537Z)

And then is another. Like, everyone does know what

### Guest (2025-04-22T18:12:32.168Z)

map map, like, and the entire arc

### You (2025-04-22T18:12:34.067Z)

That functionality will come in the future. But

### Guest (2025-04-22T18:12:34.988Z)

diagram and the mock ups hopefully created. So

### You (2025-04-22T18:12:37.537Z)

personally think that the live caption with Trips database is a really

### Guest (2025-04-22T18:12:39.158Z)

with the this MVP will also, you know,

### You (2025-04-22T18:12:41.627Z)

great. Feature because it can show a

### Guest (2025-04-22T18:12:42.178Z)

over the let's show the road map and the mock ups.

### You (2025-04-22T18:12:43.597Z)

user that if essentially, how we're direct

### Guest (2025-04-22T18:12:45.768Z)

And where we are headed.

### You (2025-04-22T18:12:46.977Z)

their property manager to

### Guest (2025-04-22T18:12:47.258Z)

So that'll give some more clarity to the investors or owner.

### You (2025-04-22T18:12:48.927Z)

interface with Drew, then

### Guest (2025-04-22T18:12:51.208Z)

We are demoing to.

### You (2025-04-22T18:12:51.217Z)

could be instantaneous. No one has to drag and drop. No one has to do anything. Right? It's just it's a

### Guest (2025-04-22T18:12:52.538Z)

And and chiming in on something, and that is

### You (2025-04-22T18:12:56.127Z)

sync.

### Guest (2025-04-22T18:12:56.248Z)

the like, does know what a drag and drop is. Right? So I don't think that's hard for people to

### You (2025-04-22T18:12:56.657Z)

It seems like connection as we can create at this point, which actually that is something

### Guest (2025-04-22T18:13:01.038Z)

get their heads around

### You (2025-04-22T18:13:01.267Z)

we talked about. Right? It's how we are we gonna create that connection

### Guest (2025-04-22T18:13:02.188Z)

that that functionality will come in the future. But I personally think that

### You (2025-04-22T18:13:04.597Z)

be yeah, some sort of excel

### Guest (2025-04-22T18:13:06.858Z)

the live connection with Drew's database is a really great feature.

### You (2025-04-22T18:13:07.367Z)

outlet. Data or create? A live API, a real API that's true?

### Guest (2025-04-22T18:13:10.208Z)

Because it can show a user that if essentially an owner directs their property manager to interface with Drew, then it can be instantaneous. No one has to drag and drop. No one has to do anything.

### You (2025-04-22T18:13:19.997Z)

Yeah. I guess well, this is probably after the question.

### Guest (2025-04-22T18:13:23.018Z)

Right? It's just it's a seam as seamless a connection as we can create at this point.

### You (2025-04-22T18:13:23.447Z)

You

### Guest (2025-04-22T18:13:27.958Z)

Which actually that is something we talked about. Right? Is how are we gonna create that

### You (2025-04-22T18:13:29.347Z)

to to demonstrate this to investor for

### Guest (2025-04-22T18:13:31.758Z)

connection? Will it be via some sort of an

### You (2025-04-22T18:13:32.017Z)

know, prosperity to build this tool.

### Guest (2025-04-22T18:13:34.838Z)

data drop, or are we gonna create

### You (2025-04-22T18:13:35.427Z)

Know,

### Guest (2025-04-22T18:13:38.128Z)

a live API a real API with Drew? For the on the DP?

### You (2025-04-22T18:13:42.747Z)

in our

### Guest (2025-04-22T18:13:43.108Z)

It'll be oh, for the MVP, was thinking it could just be we'll just use

### You (2025-04-22T18:13:44.687Z)

for, you know, repopulated. With in

### Guest (2025-04-22T18:13:48.098Z)

like, I guess, well, I just I'll ask this as a question. Do we need to show

### You (2025-04-22T18:13:50.887Z)

And you know, show like,

### Guest (2025-04-22T18:13:53.408Z)

like, to to demonstrate this to investors or, you know, customers, do we need to show data for a new deal getting pulled from one system to another, or because I would think it's sufficient to have the data in our data model or or, you know, kind of prepopulated. With multiple properties,

### You (2025-04-22T18:14:15.577Z)

Right. Yeah. No. You're absolutely right. For the initial versions,

### Guest (2025-04-22T18:14:16.598Z)

So maybe, you know, 20 or 30 whatever it is. And you know, we can show

### You (2025-04-22T18:14:20.127Z)

we just need to show the data's there.

### Guest (2025-04-22T18:14:21.518Z)

like, so the data is already in our like, it's in our system, so to speak.

### You (2025-04-22T18:14:22.477Z)

Is where you can even get an an an an

### Guest (2025-04-22T18:14:25.798Z)

And we can show the process of a user going in to create a new deal

### You (2025-04-22T18:14:26.657Z)

a PowerPoint or a or a some type of a

### Guest (2025-04-22T18:14:29.858Z)

populate the data,

### You (2025-04-22T18:14:30.257Z)

tool. I mean, I use PowerPoint generically. There are some really good tools out there

### Guest (2025-04-22T18:14:31.568Z)

so it pops up for them, you know, on their interface, but it was already in the

### You (2025-04-22T18:14:34.717Z)

that use

### Guest (2025-04-22T18:14:35.998Z)

So it's it's not like we're not

### You (2025-04-22T18:14:36.027Z)

automation in video. I mean we could show visually that okay here's

### Guest (2025-04-22T18:14:37.548Z)

pulling data, you know, each time. Like like, in order to demonstrate this, we don't need to pull new data. The data can already

### You (2025-04-22T18:14:40.217Z)

Drew's database and we can show the data goes from here to here this is what we get and then we can demo it. We don't have to have an API

### Guest (2025-04-22T18:14:44.438Z)

be there.

### You (2025-04-22T18:14:50.187Z)

you know, any anywhere near version one. You know? Because that's again, I'm not that that's a fairly standard business operation to create APIs or get data pushed from point a to point b. There's no special sauce there. So as long as we can just say, you know, this is have a data source. That data gets pushed into Invest AI. Then then this is how we use the tool to model it. The actual API I mean, even if we had a a live API, they're not gonna see anything. Right? And so yeah. So so for yeah. Definitely from an MVP and sitting in front of a a potential investor, we would just have the data uploaded and ready to go. So one more time. So say time. So time. So, client or the potential user or the potential angel investor, and they on the that we're showing that if you had say top so we can find Wow. So they would get out of this. Like, wow, it's really

### Guest (2025-04-22T18:15:51.948Z)

That was a show. Yeah.

### You (2025-04-22T18:15:52.597Z)

improves the process Mhmm. Based on the MVP for MVP that may be the road map break that shows how the MVP would be.

### Guest (2025-04-22T18:16:02.218Z)

So, Howard, can we go back through those one more

### You (2025-04-22T18:16:02.257Z)

Won. And we'll we'll three to five Wow's be

### Guest (2025-04-22T18:16:06.408Z)

time? So say I'm the I'm the client

### You (2025-04-22T18:16:06.417Z)

First thing I'm gonna be working on is

### Guest (2025-04-22T18:16:09.578Z)

or the potential user or the potential angel investor.

### You (2025-04-22T18:16:09.857Z)

the form and inputting the data. How much of it has to be manually input?

### Guest (2025-04-22T18:16:13.138Z)

Based on the MVP that we're showing them, if you had to say the top

### You (2025-04-22T18:16:14.647Z)

Can be extracted, but the wow factor is going to be

### Guest (2025-04-22T18:16:16.908Z)

three or five wows that they would get out of this, like, wow. This really improves

### You (2025-04-22T18:16:17.837Z)

after the deal is set up. How

### Guest (2025-04-22T18:16:21.818Z)

the process based on the MVP or

### You (2025-04-22T18:16:22.087Z)

you can change an assumption. Or change an input and immediately see the result

### Guest (2025-04-22T18:16:24.838Z)

the MVP and maybe the road map, right, that shows how the MVP will go to v one, and it'll have what would those three or five wows be?

### You (2025-04-22T18:16:29.357Z)

of that change. Because what we also want to do as part of this MVP is we want to identify, you know, the

### Guest (2025-04-22T18:16:33.718Z)

In your mind?

### You (2025-04-22T18:16:36.387Z)

the three to five key metrics that an investor wants to look at. To make sure that the deal matches there? Is it the NOI? Is it you know, your rate of return? I mean, what are the KPIs do you want to show? So that you can go in there, like I said before, if you change the holding period. How does that change all those metrics? If you change, you know, your food and beverage assumptions, how does that change your overall metrics? You know, the idea is to be able to, within seconds, change an assumption or make an assumption or do something and see immediately does this deal meet my minimum qualifications? Or do I walk away? Right? So so that is something we can quickly and easily do in version one. You can do it online via our software. Right? So everyone models, no changing Excel, and then uploading it. I wanna sit here, and I wanna to push a number on my keyboard and show how is that going to change the overall investment period. We can use color coding, we can use all sorts of different things, green, red, yellow, different types of indicators for these metrics. To make it really stand out. And then, you know, we can say, okay, well, next

### Guest (2025-04-22T18:18:00.368Z)

And that is you can do it online via our software.

### You (2025-04-22T18:18:03.207Z)

month we get these new financial statements or the

### Guest (2025-04-22T18:18:04.318Z)

Right? So everyone can see it, everyone sees real time. Right?

### You (2025-04-22T18:18:06.587Z)

new updated market, which will already be preloaded, but we can say, Okay, we let's say we're showing March of twenty twenty five today. And then on May 1, we'll have our April information, and then, right, we can go into the tool, change the date to May 1, and then see everything flow through and all the numbers change. Right then and there. So you know, the Right. And that that would be a for me. Yeah. Taking in all this time. So to 12 calculation Right? It's just when you are looking on it. Deal. Information. It that work goes away and it's also for you, then we ten, fifteen minutes. See. Right there. Yeah. In in the multifamily industry, there is a kind of a rule of thumb

### Guest (2025-04-22T18:18:58.308Z)

Right. And that that would be a while for me because it does take an analyst time to to

### You (2025-04-22T18:18:59.397Z)

amongst the salespeople and the team, saying,

### Guest (2025-04-22T18:19:02.678Z)

clip all of that in, check the trailing 12 calculations. Right? It

### You (2025-04-22T18:19:02.687Z)

if you can sell the leasing agent, then you're gonna get the deal. Because

### Guest (2025-04-22T18:19:06.808Z)

it's just when you are working on a deal and you get new information,

### You (2025-04-22T18:19:08.327Z)

the leasing agents, lot of times, are the ones

### Guest (2025-04-22T18:19:11.028Z)

if it if that

### You (2025-04-22T18:19:11.437Z)

who are inputting the residents when they move in and they move out, they're doing all of this paperwork

### Guest (2025-04-22T18:19:12.288Z)

work goes away and it's all done for you, that would be a wow. I'd be like, oh, ten to fifteen minutes saved right there.

### You (2025-04-22T18:19:17.207Z)

and if, if you can sell them on the product, it'll work its way up the chain. Instead of the other way around. I think we need to be focusing on who is going to be working in this tool every day. And that would be the analysts. If we can meet their requirements, and make a very painless process to underwrite a deal they will convince their supervisors or their owners that they need the tool. And that's that's why I'm really kind of focusing on the ease of input making everything clear. Don't have to hunt and peck and go from this page to this page and then back to another page. I mean, everything has to flow. Nice and smooth all the way until the end. Then boom, you got your numbers. Right? Okay. I I registered customer is gonna be the acquisition. Catalyst. Right? Well, that yeah. Yeah. We're what let's let's make sure there's a difference between customer and user. Right? The customers who are gonna be signing the contract and cutting the checks yeah, they're going to be the investors. But are those investors large enough so that they have a staff? Of analysts who are running the numbers? Are they a one person shop or are they a multi person shop? Right?

### Guest (2025-04-22T18:20:39.868Z)

But but our our initial customer is gonna be the acquisition analyst. Right?

### You (2025-04-22T18:20:42.387Z)

In either case, it's the user that you want to convince

### Guest (2025-04-22T18:20:44.278Z)

I mean, that's that's what

### You (2025-04-22T18:20:46.637Z)

that you need they need this product. Right? But we also have to make sure that it meets the needs of the investor. I mean, if we're just making a tool that makes it easier on the analysts and the investor says, they're doing their job already with Excel. Why do I need this? Then you know, obviously, we've lost. So we do need to have features that the investor needs as well. They may not want to go in and change assumptions or do anything, but we do want to have reporting and different things, you know, and this is a lot where Drew's data comes in and what other market data can we pull in to say, okay, well, here's your deal, and here's all of the market and here's all the other comparable data and all the things you would ever need so that you can just log in to Invest, pull up your deal, and see exactly what the status is. At this point. Right? So you know, it's kinda you have to differentiate between who's writing the check and then who's actually gonna be using it every day. Well, it happens. Think I think it was unless the analysts support it, Right. I don't think that the the investors gonna buy. Exactly. His or her boss, you know, this is gonna allow me to do twice. Much work. Yes. And you know, I think that's what I think it's gonna be combination of you know, both. Yeah. Yeah. No. They're all really validating No. The purchase. Yeah. So seems like there's a lot bathroom

### Guest (2025-04-22T18:22:15.688Z)

Well yeah. But I I think I think unless

### You (2025-04-22T18:22:16.017Z)

want. To put date. Artificially.

### Guest (2025-04-22T18:22:20.388Z)

unless the analysts support it, I don't think the the the investor is gonna buy it. Right? At the end of the day, the the analyst has to say to, his or her boss, this is gonna allow me to do twice as much work. And, you know, I think that so I think it's gonna be a

### You (2025-04-22T18:22:34.497Z)

Right?

### Guest (2025-04-22T18:22:36.008Z)

combination of know, both that that sort of ultimately validate the the purchase. So so you're saying so the Wow's for version one are inputting data more efficiently. And being able to change inputs. Easier? I mean, is there anything else sort of envisioned for v one?

### You (2025-04-22T18:22:51.617Z)

Track what's going on.

### Guest (2025-04-22T18:22:53.388Z)

Well, I think getting the from the that would be sort of the

### You (2025-04-22T18:22:53.717Z)

With their Yeah. Right?

### Guest (2025-04-22T18:22:58.108Z)

the analyst perspective. Right? Like, that's what's gonna probably get the analyst excited is a more efficient way to do the underwriting to

### You (2025-04-22T18:23:05.567Z)

So you know, the

### Guest (2025-04-22T18:23:07.188Z)

do the work, so to speak. The other side of that that the

### You (2025-04-22T18:23:09.467Z)

for this. School

### Guest (2025-04-22T18:23:10.438Z)

the high the executives or the investor Right? Like,

### You (2025-04-22T18:23:10.607Z)

team. Ability.

### Guest (2025-04-22T18:23:13.878Z)

investment committee people are gonna look at is the ability to more effectively see and

### You (2025-04-22T18:23:20.167Z)

Experience, I mean,

### Guest (2025-04-22T18:23:20.558Z)

track

### You (2025-04-22T18:23:20.987Z)

the the biggest

### Guest (2025-04-22T18:23:21.388Z)

what's going on with their deals.

### You (2025-04-22T18:23:21.787Z)

delay

### Guest (2025-04-22T18:23:23.718Z)

Right? Versus as Mark, as you have said, right, like, it's

### You (2025-04-22T18:23:24.077Z)

process is is a know, you need do an initial model.

### Guest (2025-04-22T18:23:27.138Z)

through different Excel spreadsheets, knowing which version is correct, like,

### You (2025-04-22T18:23:27.767Z)

And invariably, the first model work. And, you know, the team spends hours

### Guest (2025-04-22T18:23:30.388Z)

is a know, error prone and inefficient way of working.

### You (2025-04-22T18:23:32.197Z)

trying to edit the model. To get it

### Guest (2025-04-22T18:23:34.388Z)

So I think we, you know,

### You (2025-04-22T18:23:35.237Z)

deal to work.

### Guest (2025-04-22T18:23:35.928Z)

the the flip side of that is what we're gonna offer for the executive level teams is the ability to to

### You (2025-04-22T18:23:36.187Z)

And you know, a lot of times the analysts you know, is up late at night, He or she

### Guest (2025-04-22T18:23:40.898Z)

manage them all online more efficiently. Maybe that'll be a I'm guessing that's the

### You (2025-04-22T18:23:41.587Z)

just sort of tinkering with it and being sort changes. You know,

### Guest (2025-04-22T18:23:45.088Z)

that that would be a wow for you. Right? More so I mean, know, based on my

### You (2025-04-22T18:23:45.207Z)

everyone sight. Changes are. So that's why I think it is tracking feature

### Guest (2025-04-22T18:23:48.828Z)

experience, I mean, the the biggest

### You (2025-04-22T18:23:50.397Z)

I mean, that that's what

### Guest (2025-04-22T18:23:50.708Z)

delay in the process is is the

### You (2025-04-22T18:23:52.987Z)

personally, I interesting about that. You know, it's something interesting, but

### Guest (2025-04-22T18:23:54.358Z)

you know, you you do an initial model,

### You (2025-04-22T18:23:56.747Z)

just having that

### Guest (2025-04-22T18:23:56.838Z)

and invariably, the first model doesn't work. And then, you know, the team spends hours on the phone trying

### You (2025-04-22T18:23:57.717Z)

tracking tool knowing what changed the way it long had a big change efficiently.

### Guest (2025-04-22T18:24:02.078Z)

edit the model to get it

### You (2025-04-22T18:24:02.087Z)

And, you know, I think five different

### Guest (2025-04-22T18:24:03.968Z)

deal to work.

### You (2025-04-22T18:24:04.077Z)

people be able to make changes. So, continuously, tracking

### Guest (2025-04-22T18:24:04.998Z)

And, you know, a lot of times, the analyst you know, is up late at night, and and he or she is just sort of tinkering with it and making sort of changes. And

### You (2025-04-22T18:24:06.837Z)

the changes that each person. Is making, You know, to me, that that's where I see It's very significant. Value.

### Guest (2025-04-22T18:24:13.178Z)

you know, everyone loses sight of kind of what those changes are. So that's why I think that this

### You (2025-04-22T18:24:14.307Z)

Yeah. No. Right. Because we will have to this morning, I was with my analyst.

### Guest (2025-04-22T18:24:17.678Z)

tracking feature

### You (2025-04-22T18:24:18.297Z)

You know, every time you get a chance, you have to resave the model.

### Guest (2025-04-22T18:24:19.148Z)

I mean, that that's what personally, I've got most

### You (2025-04-22T18:24:21.557Z)

It's computer crashed twice.

### Guest (2025-04-22T18:24:22.928Z)

interesting about it. I mean, all the stuff is interesting, but just having that tracking tool, knowing

### You (2025-04-22T18:24:23.427Z)

Pay. And, you know, then I he kind of

### Guest (2025-04-22T18:24:27.748Z)

what changes are made, knowing how to make changes efficiently

### You (2025-04-22T18:24:30.197Z)

kind of just trying to move from that rate.

### Guest (2025-04-22T18:24:31.438Z)

and, you know, having five different people be able to make changes simultaneously and tracking

### You (2025-04-22T18:24:32.017Z)

So, again, it's just something that happened at least to me, on a regular basis.

### Guest (2025-04-22T18:24:35.748Z)

the changes that each person is making you know, to me, that that's

### You (2025-04-22T18:24:37.877Z)

Use that to kind of think about how

### Guest (2025-04-22T18:24:39.708Z)

where I see it as very significant amount of value here.

### You (2025-04-22T18:24:40.977Z)

take our product once you get So, James,

### Guest (2025-04-22T18:24:43.158Z)

Right? Because what happened, like, to this morning, I was on the phone with my analyst, and know, every time he made a change, he had to resave the model and his computer crashed twice because the model was too big. And, you know, then I asked what changes he made last night, and he kind of didn't remember. So I could tell he was kind of just trying to go from memory and

### You (2025-04-22T18:24:57.667Z)

we can all kind of see what each other And real time.

### Guest (2025-04-22T18:25:01.098Z)

again, it's just something that that happens at least to me, on a regular basis. So I'm I'm just trying to use that lens to kind of think about how to make our product most unique. So change the tracking activity log.

### You (2025-04-22T18:25:14.077Z)

Yeah. Yeah. Just the

### Guest (2025-04-22T18:25:14.468Z)

Sounds like a Well, and then letting multiple people make changes and everyone and and make those

### You (2025-04-22T18:25:16.367Z)

the So so, Mark, a couple points. Number one, you are absolutely right. We do have to market to both.

### Guest (2025-04-22T18:25:20.208Z)

be transparent. So, you know, if all four of us were all

### You (2025-04-22T18:25:23.777Z)

The user and the investor. And to

### Guest (2025-04-22T18:25:23.858Z)

five of us are are working on the same model, could all kind of see what each other is doing

### You (2025-04-22T18:25:27.577Z)

to do that, in version one, we will need to have some basic

### Guest (2025-04-22T18:25:28.688Z)

in real time. Yeah. On our platform, though, the user and

### You (2025-04-22T18:25:31.317Z)

reporting, whether it be a page of graphs and charts,

### Guest (2025-04-22T18:25:33.838Z)

modifying the model. They're modifying the data. Right?

### You (2025-04-22T18:25:34.817Z)

a printed report,

### Guest (2025-04-22T18:25:37.088Z)

Model you are generating.

### You (2025-04-22T18:25:37.457Z)

combination of the two, you know, that, that is something that's very important that we'll need to do.

### Guest (2025-04-22T18:25:38.548Z)

So multiple users not the model. Yeah. Yeah. Yeah. Not the model. Just the data.

### You (2025-04-22T18:25:43.367Z)

The second thing is

### Guest (2025-04-22T18:25:43.758Z)

Yeah. Just the data.

### You (2025-04-22T18:25:46.637Z)

when we are able to incorporate AI one of the best use cases for AI so far has been financial analysis. And what I want to get to very early in the stage, it's not going to happen on day one because we have to have the tool first. But to have that little AI chat in there, that says, hey, take a look at this model. And tell me what can I tweak or what can change in order for it to meet and then fill in the blank with whatever metric you need? It's fun. It it does a it does a fantastic job of that. You know, you do have to have some parameters. Right? You know, don't want us to have it come back and say, oh, triple your food and and and budget. Revenue and which is not realistic. Right? But you you you it would have to the parameters in there, especially if you have other markets data. Right? So it'll take whatever your assumptions are. It can take a look at the

### Guest (2025-04-22T18:26:51.798Z)

It's funny you say that. I was just thinking that as you were

### You (2025-04-22T18:26:54.697Z)

in general and the different deals.

### Guest (2025-04-22T18:26:56.708Z)

speaking.

### You (2025-04-22T18:26:57.727Z)

That's where we really want to get. Because that's that's going to be the point where it's a no brainer. To use the tool. So sort of on on once you get a paper, like, each? Phase of our launch and, like, what each be. It's fascinating. Right? I hope it's sort of the ultimate. But like, do we have, like, a road map that shows, you know, version work? Through six and all we can hope to achieve in each sort of incremental version?

### Guest (2025-04-22T18:27:33.368Z)

Yeah. Yeah. Do we do we have sort of on on

### You (2025-04-22T18:27:36.517Z)

Process of

### Guest (2025-04-22T18:27:38.938Z)

one sheet of paper, like, phase of our launch and, like, what each sort of incremental functionality will be. Right? Because, I mean, that AI thing is fascinating. Right? And that would be sort of the ultimate But, like, do we have, like, a road map that shows

### You (2025-04-22T18:27:52.617Z)

I tried to educate

### Guest (2025-04-22T18:27:54.588Z)

you know, versions one through six and what

### You (2025-04-22T18:27:55.197Z)

them.

### Guest (2025-04-22T18:27:56.698Z)

we hope to achieve in each sort of incremental version?

### You (2025-04-22T18:28:00.307Z)

Well, that's that's

### Guest (2025-04-22T18:28:02.058Z)

I am kind of in

### You (2025-04-22T18:28:05.177Z)

tool.

### Guest (2025-04-22T18:28:05.528Z)

of making that. I was working on that yesterday night, so I think we should have that

### You (2025-04-22T18:28:05.777Z)

Yeah. That's Yeah. That's that's when we start

### Guest (2025-04-22T18:28:10.468Z)

So Let let me and I can I did sort of try to track some of that in the initial product

### You (2025-04-22T18:28:10.777Z)

press releases, you know, and and market

### Guest (2025-04-22T18:28:15.338Z)

that product document that I put together?

### You (2025-04-22T18:28:15.777Z)

articles in in in the reg. But yeah,

### Guest (2025-04-22T18:28:18.838Z)

Oh, I can send that back out, but

### You (2025-04-22T18:28:19.797Z)

We do need to start at that high level, though, Drew. I think we you know, it's a funnel. We need to start

### Guest (2025-04-22T18:28:21.528Z)

I tried to some of the things that would be I mean, that was more that was much bigger picture, though, than

### You (2025-04-22T18:28:24.437Z)

high level and then start breaking it down into bite sized chunks. What

### Guest (2025-04-22T18:28:27.308Z)

than maybe what we're talking about.

### You (2025-04-22T18:28:27.997Z)

can we do with the resources we have and how much time will it take

### Guest (2025-04-22T18:28:28.778Z)

Because, Howard, what you just outlined

### You (2025-04-22T18:28:32.697Z)

So I think that's that's a great place

### Guest (2025-04-22T18:28:32.848Z)

is kind of the ultimate tool. But, you know, how do we get there?

### You (2025-04-22T18:28:35.717Z)

to start with what you with what you put together. And and Diane together. Using Trello and a Gantt chart as well. So Yeah.

### Guest (2025-04-22T18:29:06.558Z)

This is what Drew put together. Yeah. Yeah.

### You (2025-04-22T18:29:12.407Z)

Together.

### Guest (2025-04-22T18:29:16.928Z)

Got it. So where do we go from here?

### You (2025-04-22T18:29:31.877Z)

Yeah.

### Guest (2025-04-22T18:29:32.518Z)

Yeah. I'll could probably share something real quick if I can. Just putting together.

### You (2025-04-22T18:29:43.117Z)

So five, for finalize.

### Guest (2025-04-22T18:29:53.568Z)

Oh, okay. So my laptop is working fine. Yeah. I can yeah. I was kind of creating some map here. I could

### You (2025-04-22T18:30:01.867Z)

Start right. There. It's extract

### Guest (2025-04-22T18:30:04.538Z)

probably share this.

### You (2025-04-22T18:30:05.237Z)

to data flow. CSV. Right? So I

### Guest (2025-04-22T18:30:08.218Z)

I knew that. I'll send it via email. From here, I think the next step is for for Drew, Howard, me to finalize the

### You (2025-04-22T18:30:19.397Z)

which think there. Front end. Of the

### Guest (2025-04-22T18:30:24.348Z)

how we gonna grab the data from Drew's system. Right? And then probably I'll start writing that script to

### You (2025-04-22T18:30:33.367Z)

Obviously, an email. I'll create

### Guest (2025-04-22T18:30:34.108Z)

extract the data from

### You (2025-04-22T18:30:35.037Z)

the

### Guest (2025-04-22T18:30:35.918Z)

the CSV or Excel file that we get.

### You (2025-04-22T18:30:36.307Z)

know, it's

### Guest (2025-04-22T18:30:40.298Z)

And then create the database. I was

### You (2025-04-22T18:30:41.877Z)

how it's

### Guest (2025-04-22T18:30:43.748Z)

had already started working

### You (2025-04-22T18:30:45.307Z)

Yeah.

### Guest (2025-04-22T18:30:45.408Z)

on putting together the application, which would be React front end, node, back end, and then

### You (2025-04-22T18:30:51.767Z)

And I think our help. Already started working on creating the

### Guest (2025-04-22T18:30:55.198Z)

yeah. Basically, they are for the net front end and node. Js. I have some code written. I

### You (2025-04-22T18:30:56.367Z)

form for point. So

### Guest (2025-04-22T18:30:59.608Z)

wanna put that on GitHub.

### You (2025-04-22T18:31:00.837Z)

Yeah. I haven't started that because I do need input from

### Guest (2025-04-22T18:31:01.358Z)

So, I mean, once we have that official email, I'll create the

### You (2025-04-22T18:31:04.487Z)

pretty much everybody on the call.

### Guest (2025-04-22T18:31:05.298Z)

you know, our

### You (2025-04-22T18:31:06.347Z)

With the exception of you who who have used the model

### Guest (2025-04-22T18:31:09.018Z)

invest

### You (2025-04-22T18:31:10.297Z)

and knows if I'm going to sit down and underwrite

### Guest (2025-04-22T18:31:11.598Z)

office account on GitHub and

### You (2025-04-22T18:31:13.527Z)

a model or underwrite a deal using this model,

### Guest (2025-04-22T18:31:15.098Z)

just make it accessible to this group.

### You (2025-04-22T18:31:16.187Z)

where do I start? Right? Obviously, name, address, etcetera,

### Guest (2025-04-22T18:31:19.618Z)

And then I think Howard had

### You (2025-04-22T18:31:20.797Z)

be the first place. But then what? What where do you go with the assumptions? So so Diane and Drew, I'm gonna

### Guest (2025-04-22T18:31:24.298Z)

already started working on creating the form for user input. So

### You (2025-04-22T18:31:27.347Z)

deal look to to you, Mark as well.

### Guest (2025-04-22T18:31:28.838Z)

put that all together.

### You (2025-04-22T18:31:30.917Z)

You know, maybe we just need to get a call share the screening, and then just go you know, where I can just observe what order you're getting in because that that's gonna determine the the the forms on the screen. Right? So if we create a new deal in Invest, after I put in the name and address, where do I go next? What form is supposed to come up on the screen with the blanks? I'm going to type in this information. Is it revenue assumptions? Is it penetration, comp data? That's that's what we need to find out. Yeah. Well, the model that I sent yeah. Yeah. I mean, that is the that's the layout that we've got. So I need two things. Number one, underwrite a deal with it or or put in the same inputs that you do in another deal. Make sure the numbers match. Make sure that the calculations and the formulas are correct. I didn't change anything. Could I have possibly fat fingered something? Sure. That's all I want to find out is is did I change anything? And then the second thing is yes.

### Guest (2025-04-22T18:32:36.278Z)

Yeah. And that's in that model, the model that you sent. Right? You're saying, like, we can go through and

### You (2025-04-22T18:32:40.387Z)

When you go through this model and you're starting from scratch on a new deal, what cells, what are you inputting first? And what is the logical order? That's those are the two things I need. Well, we can do we can do it two ways. You can either just do it individually, write down the order, and send it to me, or we can just set up a call anytime. I'm I'm pretty much quite open whenever if we wanna go through it together as a team, with a screen share, You just let me know what's easiest. Yeah. Yeah. Alone together. Yeah. Just talk Yeah. Yeah.

### Guest (2025-04-22T18:33:21.728Z)

When would you like to do that?

### You (2025-04-22T18:33:24.967Z)

Yeah. So we can either break it up into bite sized chunks because I I'm I'm assuming it's gonna take a while to go through each item. You know, as opposed to, you know, if you want to set block off two hours, you know, whatever you guys want to I'm I'm wide open. I'm I'm

### Guest (2025-04-22T18:33:42.238Z)

Yeah. I think they're they're probably most efficient to just do it online together.

### You (2025-04-22T18:33:44.637Z)

free tomorrow

### Guest (2025-04-22T18:33:46.518Z)

Just talk it through. Because we'll we'll have different, you know, perspectives, and we could just talk them through.

### You (2025-04-22T18:33:47.047Z)

I'm I'm

### Guest (2025-04-22T18:33:50.778Z)

This way, you don't you wanted to deal with, you know, three or four different versions of our our comments.

### You (2025-04-22T18:33:55.907Z)

you know. Okay. Friday is afternoon one time. It it's it's the annual dinner for my wife's university for all the professors and everything. So Friday afternoon,

### Guest (2025-04-22T18:34:13.768Z)

I'm I'm free. Tomorrow's

### You (2025-04-22T18:34:14.557Z)

is the only time that probably won't work.

### Guest (2025-04-22T18:34:15.588Z)

tough wait. What is today? Tuesday?

### You (2025-04-22T18:34:17.097Z)

We can look at early next week as well. Whatever.

### Guest (2025-04-22T18:34:18.848Z)

Thursday is tough for me, but Wednesday and Friday, I'm pretty open. So Friday late afternoon would work for me. I'm traveling this week. My part time job.

### You (2025-04-22T18:34:29.107Z)

Yeah. Any I I can't be anytime before 03:00. Eastern time works.

### Guest (2025-04-22T18:34:34.108Z)

Time.

### You (2025-04-22T18:34:34.487Z)

But a gentleman that is working with a platform called

### Guest (2025-04-22T18:34:49.458Z)

Well, what is Monday.

### You (2025-04-22T18:34:49.857Z)

and it's specializes in CapEx on the multifamily side.

### Guest (2025-04-22T18:34:52.028Z)

What is fry I mean, is there what time are you

### You (2025-04-22T18:34:55.237Z)

Pro form?

### Guest (2025-04-22T18:34:55.548Z)

unavailable, Howard? Friday? Is it, like,

### You (2025-04-22T18:34:56.897Z)

But I

### Guest (2025-04-22T18:34:57.998Z)

o'clock, 02:00, 03:00?

### You (2025-04-22T18:34:58.007Z)

him in in, like, the the area. One would be hard

### Guest (2025-04-22T18:35:03.088Z)

Does that work for you?

### You (2025-04-22T18:35:04.347Z)

for me. 02:00 would only give us

### Guest (2025-04-22T18:35:06.128Z)

Anne, or is that

### You (2025-04-22T18:35:06.997Z)

us an hour.

### Guest (2025-04-22T18:35:07.078Z)

I'll have a lunch too on Friday with someone that

### You (2025-04-22T18:35:07.767Z)

But that's okay, can just start with an hour. Know, are we at it?

### Guest (2025-04-22T18:35:12.378Z)

I'm hopeful may actually be interesting to this group. It's a gentleman

### You (2025-04-22T18:35:15.447Z)

Yeah. I I could do

### Guest (2025-04-22T18:35:16.568Z)

that is working with a platform called Tailorbird, and it specializes in

### You (2025-04-22T18:35:16.957Z)

like, Friday, I It's not a great day. Thursday morning. Oh, well,

### Guest (2025-04-22T18:35:21.538Z)

CapEx on the multifamily side, kind of like a Rabbit or a Procore. But I have lunch with him in in, like, the up in the Midtown area. So

### You (2025-04-22T18:35:30.707Z)

So Drew is West Coast time.

### Guest (2025-04-22T18:35:32.398Z)

01:00 might be hard for maybe 02:00 would work, but that only gives

### You (2025-04-22T18:35:32.897Z)

So say like, I'm Yeah.

### Guest (2025-04-22T18:35:36.948Z)

us an hour. But, if that's okay, we could just start with an hour and see how far we get.

### You (2025-04-22T18:35:38.797Z)

I'm up in unfortunately, I have to. So maybe maybe

### Guest (2025-04-22T18:35:44.298Z)

Yeah. I mean, I I could do fraud for your

### You (2025-04-22T18:35:47.187Z)

But

### Guest (2025-04-22T18:35:47.468Z)

Friday afternoon is not great. For me, I could do Thursday morning if that

### You (2025-04-22T18:35:48.537Z)

I just, of course, have traveled all day. And

### Guest (2025-04-22T18:35:50.798Z)

Oh, well, if that's no. No. Let's do let's do Monday or Tuesday or something

### You (2025-04-22T18:35:51.267Z)

Tuesday.

### Guest (2025-04-22T18:35:55.078Z)

that. Sounds like that. Next week will be better for everybody.

### You (2025-04-22T18:35:55.317Z)

You? Friday. Like,

### Guest (2025-04-22T18:35:59.358Z)

What is so Drew is West Coast time.

### You (2025-04-22T18:36:01.317Z)

again, I

### Guest (2025-04-22T18:36:02.918Z)

So do you wanna say, like, noon on Monday eastern?

### You (2025-04-22T18:36:03.297Z)

by individual perspective without me. Right? How do you

### Guest (2025-04-22T18:36:07.148Z)

Yeah. That's I'm on a plane on Monday. Unfortunately, I have to go to New York.

### You (2025-04-22T18:36:09.637Z)

model versus how do I model?

### Guest (2025-04-22T18:36:12.118Z)

Okay. So maybe maybe doing it all three of us at the same time is not gonna be realistic.

### You (2025-04-22T18:36:13.267Z)

Yep. We Yep. We

### Guest (2025-04-22T18:36:17.068Z)

But,

### You (2025-04-22T18:36:17.327Z)

We

### Guest (2025-04-22T18:36:17.908Z)

I just unfortunately, I'm traveling Monday, and and

### You (2025-04-22T18:36:18.457Z)

Okay.

### Guest (2025-04-22T18:36:21.208Z)

Tuesday next week. I'm gonna have to be in New York.

### You (2025-04-22T18:36:22.107Z)

Ceiling? Page?

### Guest (2025-04-22T18:36:23.668Z)

Well, then why don't you and Drew and Howard take a first step on Friday, like, at one or something like that? And

### You (2025-04-22T18:36:24.757Z)

No. I want I wanna I wanna go through an entire basic underwriting.

### Guest (2025-04-22T18:36:30.698Z)

again, I won't be able to join, but

### You (2025-04-22T18:36:30.727Z)

From a to z. And find out Alright.

### Guest (2025-04-22T18:36:33.718Z)

it might be actually a good thing to get your perspective

### You (2025-04-22T18:36:33.757Z)

I'm I'm actually working So this week on

### Guest (2025-04-22T18:36:36.218Z)

like, your individual perspectives without me. Right? How do you

### You (2025-04-22T18:36:36.387Z)

the default. Deal. And we just this model is just

### Guest (2025-04-22T18:36:39.718Z)

model versus how do I model?

### You (2025-04-22T18:36:40.287Z)

you know, fresh. It was do it.

### Guest (2025-04-22T18:36:41.908Z)

Yeah. We and then I I can join the second call with you too, Diane.

### You (2025-04-22T18:36:42.267Z)

Good to see it now. So k. I'm happy to play. Get a copy. Share with you guys.

### Guest (2025-04-22T18:36:46.818Z)

So there's some continuity as well.

### You (2025-04-22T18:36:46.917Z)

And just so you can see, like, exactly how we can prove it and show you

### Guest (2025-04-22T18:36:48.468Z)

Okay. And, Howard, is your goal to just see, like, a a

### You (2025-04-22T18:36:50.457Z)

how we went about doing this, how we will you know,

### Guest (2025-04-22T18:36:52.808Z)

summary page, or you wanna see the whole

### You (2025-04-22T18:36:53.767Z)

every time we go about it. It, we we whatever reason, try to make a better So Yeah. In theory. It's keeps getting better.

### Guest (2025-04-22T18:37:00.038Z)

Alright. Because I knew we I'm I'm actually working

### You (2025-04-22T18:37:01.367Z)

Yeah. Thank you, Tyler. Like, you're in a long time. Right? Yeah.

### Guest (2025-04-22T18:37:05.008Z)

just this week on a development deal in Florida. We just this model is just, you know,

### You (2025-04-22T18:37:10.567Z)

So I'm happy.

### Guest (2025-04-22T18:37:10.778Z)

fresh. I just we're just finishing it now. So

### You (2025-04-22T18:37:13.017Z)

Alright.

### Guest (2025-04-22T18:37:13.698Z)

mean, I'm happy to, like, you know, confidentially just share with you guys and just so you could see, like, exactly. I will walk you through it and show you how we went about doing it. It's kind of a you know, every time we do a model, we we whatever reason, try to make it better than the prior one. So in theory, it's keep it's getting better.

### You (2025-04-22T18:37:31.227Z)

Yeah.

### Guest (2025-04-22T18:37:32.278Z)

Keep telling the analytical team, at some point, we should stop improving.

### You (2025-04-22T18:37:32.957Z)

Yeah. I think it would be best if it's the version that we've been working on.

### Guest (2025-04-22T18:37:35.348Z)

Yeah. They keep changing it every time. They're just trying to make it interesting for me. But

### You (2025-04-22T18:37:36.627Z)

Okay. Fine. No problem. But what I would really be interested in is as we go through there, if you

### Guest (2025-04-22T18:37:39.868Z)

anyway so I'm happy to use that as an example if if that's helpful.

### You (2025-04-22T18:37:43.087Z)

see something that's that you have in your model that we don't have,

### Guest (2025-04-22T18:37:46.548Z)

We can have that, yeah, as well. And I think we'll then

### You (2025-04-22T18:37:46.947Z)

that you think would be useful to add, that's that's gonna be

### Guest (2025-04-22T18:37:49.658Z)

and you but you wanna see it specifically in in this in in the model that you worked on as well.

### You (2025-04-22T18:37:50.497Z)

very important as well. So Yeah. Okay. Yeah. Let's

### Guest (2025-04-22T18:37:54.088Z)

Howard? Well, again, I I'm just doing it to be helpful if you'd rather Howard, you wanna use your version, I'm fine too. I'm just offering

### You (2025-04-22T18:37:54.487Z)

I'll go ahead and send out the time. So what time on Friday? By the way, I could do

### Guest (2025-04-22T18:37:58.998Z)

as an option. But whatever is whatever is easiest for you, I'll I'm happy to do.

### You (2025-04-22T18:38:01.697Z)

know, or some stuff. Do I'm I'm There's a Is that better for you?

### Guest (2025-04-22T18:38:06.598Z)

Okay. Fine. Let's do that.

### You (2025-04-22T18:38:07.857Z)

I

### Guest (2025-04-22T18:38:08.398Z)

No problem at all.

### You (2025-04-22T18:38:09.477Z)

I do Like well, I can do I So Thursday, what time?

### Guest (2025-04-22T18:38:18.068Z)

Yep. Okay.

### You (2025-04-22T18:38:24.077Z)

Okay. Let's let's do after because Drew is West Coast. So

### Guest (2025-04-22T18:38:28.288Z)

By the way, could do Thursday too if that's better for you. I know you said you have

### You (2025-04-22T18:38:28.387Z)

That's right. It's like three. Yeah. Thursday at three is good. I'll go ahead and send out the invite here.

### Guest (2025-04-22T18:38:31.818Z)

some personal stuff on the afternoon. Thursday works for me as well. Is that better for you?

### You (2025-04-22T18:38:37.087Z)

Yeah.

### Guest (2025-04-22T18:38:37.988Z)

I well, actually, I can do Thursday if it's between, like,

### You (2025-04-22T18:38:40.347Z)

Okay.

### Guest (2025-04-22T18:38:41.548Z)

well, I can do I can do Thursday. I can do Thursday. I've got a I have a lunch meeting for, like,

### You (2025-04-22T18:38:49.777Z)

No. We haven't really yet. Yeah. So what if I

### Guest (2025-04-22T18:38:51.068Z)

twelve to two, but I could either do before or after.

### You (2025-04-22T18:38:53.657Z)

just hear

### Guest (2025-04-22T18:38:56.688Z)

So I do Thursday at, like, three? Yeah. Howard, please include me too. That might be some learning for me. And I quickly wanna touch base on the website. I don't know whether

### You (2025-04-22T18:39:10.707Z)

yeah. So now so we can

### Guest (2025-04-22T18:39:14.798Z)

guys already talked about that.

### You (2025-04-22T18:39:14.977Z)

do it.

### Guest (2025-04-22T18:39:18.398Z)

We haven't really. Yeah. So one is at

### You (2025-04-22T18:39:22.297Z)

So I yesterday.

### Guest (2025-04-22T18:39:23.828Z)

shared a logo. I don't know whether you guys like data. I did get the email from Howard that he liked it. I was looking at yeah. I thought that it looks good. Yeah. I I only looked at it briefly. This yeah. You said it now. Yeah. I see it now. So oh, yeah. And I see there were some logo options Howard, that you sent out previously.

### You (2025-04-22T18:39:48.207Z)

A five or

### Guest (2025-04-22T18:39:50.128Z)

And I'll I sent one yesterday night.

### You (2025-04-22T18:39:50.377Z)

He said there was one. Kind of liked, and what we need to do is

### Guest (2025-04-22T18:39:54.958Z)

Yeah. Yeah. I see it. So, yeah, that is there. And then what where are we

### You (2025-04-22T18:40:00.177Z)

minimal.

### Guest (2025-04-22T18:40:02.238Z)

with the website? Well,

### You (2025-04-22T18:40:03.757Z)

Underwriting.

### Guest (2025-04-22T18:40:04.468Z)

Like, are we creating content, or what are we waiting for?

### You (2025-04-22T18:40:08.437Z)

You're talking about

### Guest (2025-04-22T18:40:08.478Z)

So I think, Mark, you and

### You (2025-04-22T18:40:09.277Z)

information about our company Right? Partnership, the background, all that type of stuff that's on the website.

### Guest (2025-04-22T18:40:13.298Z)

Vinod were gonna take the website. Right? And we last left it that Howard sent you about five or six examples. You said there was one you kind of liked, and what we need to do is down and just determine what's gonna be on the website. Probably minimal Well, other than the actual underwriting model, right, which has to be on the website for us to do the demo.

### You (2025-04-22T18:40:33.927Z)

Call. Speak to It says

### Guest (2025-04-22T18:40:37.968Z)

But you're talking about information about our company, right, the partnership, the background, like, that type of stuff that's on a website.

### You (2025-04-22T18:40:42.337Z)

for It I mean, I just wanna

### Guest (2025-04-22T18:40:52.268Z)

Vinod, you there? Oh, that was for me. That's that's what we're talking about. Right? It's like, who's our like, one there is a a a platform

### You (2025-04-22T18:40:59.757Z)

Yeah. They take one for one?

### Guest (2025-04-22T18:41:03.908Z)

called

### You (2025-04-22T18:41:04.867Z)

I think

### Guest (2025-04-22T18:41:04.928Z)

think it's Revere, and I really like it because when you open it up, it says for owners, for lenders,

### You (2025-04-22T18:41:09.427Z)

Yeah.

### Guest (2025-04-22T18:41:13.228Z)

for and so it's very, clear who it's for. Yeah. I mean, I just wanted to follow-up follow-up on that because last week, we said

### You (2025-04-22T18:41:20.837Z)

So I tried to do that that

### Guest (2025-04-22T18:41:23.148Z)

we are creating a website, and I just wanna understand where we are on that.

### You (2025-04-22T18:41:24.037Z)

example. And I tried to start

### Guest (2025-04-22T18:41:27.288Z)

Hey, Diane. Howard, I sent around a list of of

### You (2025-04-22T18:41:27.947Z)

simpler.

### Guest (2025-04-22T18:41:30.068Z)

you know, eight or seven or eight different websites. Did you

### You (2025-04-22T18:41:30.817Z)

Thing.

### Guest (2025-04-22T18:41:33.468Z)

are you referring to one from his list? I think you liked one, you? Yeah. I like the I like the REL one.

### You (2025-04-22T18:41:35.907Z)

45 demo. The outside. The one they went through.

### Guest (2025-04-22T18:41:39.678Z)

I just thought it was it was I actually compared it to I was trying to use the Apple website as a point of reference. This is everything they do. So

### You (2025-04-22T18:41:44.447Z)

Yeah.

### Guest (2025-04-22T18:41:46.758Z)

consumer friendly, and they probably spent billions of dollars researching what consumers like.

### You (2025-04-22T18:41:47.437Z)

So something. Called an idea.

### Guest (2025-04-22T18:41:51.138Z)

So I tried to use that as a as a example.

### You (2025-04-22T18:41:55.077Z)

But

### Guest (2025-04-22T18:41:55.558Z)

And the REL one I thought, sort of was most similar. And then the other macro comment I had was just that it seemed like most of the sites that you said us a forty five minute demo, and and the REL site was the one that actually

### You (2025-04-22T18:42:09.547Z)

know, we don't wanna

### Guest (2025-04-22T18:42:09.998Z)

went through and kind of explained what they were doing without a demo, which I think also made it more user friendly.

### You (2025-04-22T18:42:11.287Z)

like keeping it simple just

### Guest (2025-04-22T18:42:16.218Z)

Okay. Good one.

### You (2025-04-22T18:42:17.247Z)

Yeah. No. We we don't wanna plagiarize or copy Ariel there.

### Guest (2025-04-22T18:42:18.058Z)

So probably we can base something off on Ariel's side and

### You (2025-04-22T18:42:21.087Z)

They're quite a ways behind the rest. Market size and users. Yeah.

### Guest (2025-04-22T18:42:22.128Z)

know, we can change the content or whatever we need to do. But at least we could put together something and then move. I got it. Their tagline

### You (2025-04-22T18:42:26.027Z)

Yeah. Right. No. I understand.

### Guest (2025-04-22T18:42:30.038Z)

the only multi

### You (2025-04-22T18:42:30.517Z)

Yeah. Yeah. You know, once that

### Guest (2025-04-22T18:42:31.118Z)

software you'll ever need. Like, that's a pretty powerful

### You (2025-04-22T18:42:32.247Z)

cent. There's no confusion. As to what their objective was. Yeah.

### Guest (2025-04-22T18:42:34.208Z)

opening statement. Right? And that's kind of what we've all been saying. Right? Like, we we wanna that we'll just it's you know, we don't wanna plagiarize. But I just think keeping it simple and really just know, explaining it clearly has a big impact.

### You (2025-04-22T18:42:48.377Z)

I

### Guest (2025-04-22T18:42:51.738Z)

Right.

### You (2025-04-22T18:42:52.977Z)

capacity.

### Guest (2025-04-22T18:42:53.168Z)

No. No. I'm just saying as an example, they just they they managed to con

### You (2025-04-22T18:42:55.337Z)

Another side of, like,

### Guest (2025-04-22T18:42:56.198Z)

yeah. No. My point is that just they managed to explain their

### You (2025-04-22T18:42:57.227Z)

content. But I

### Guest (2025-04-22T18:43:00.118Z)

vision very concisely, you know, in one sentence and

### You (2025-04-22T18:43:02.007Z)

and things like that. For you.

### Guest (2025-04-22T18:43:03.538Z)

was no confusion as to kind of what their

### You (2025-04-22T18:43:03.757Z)

To post. Sounds good. Sounds good. I was saying how you're

### Guest (2025-04-22T18:43:05.868Z)

objective was. Cool. So probably I'll I'll put together something and then, you know, we can move forward and change the content and

### You (2025-04-22T18:43:12.337Z)

No. That's what we were just talking about. We weren't really working on

### Guest (2025-04-22T18:43:14.338Z)

something like that. And, Vinod, if you need

### You (2025-04-22T18:43:16.107Z)

content yet. We were just trying to decide what

### Guest (2025-04-22T18:43:19.128Z)

I'm this week, I'm completely tied up. But Monday and Tuesday, I have a

### You (2025-04-22T18:43:19.737Z)

type of landing page we we liked, and that was the REL.

### Guest (2025-04-22T18:43:23.718Z)

capacity. So if you need just another set, like,

### You (2025-04-22T18:43:25.807Z)

Cool. Sorry.

### Guest (2025-04-22T18:43:27.098Z)

for me to write content or I've never created a website, but I can definitely write content and things like that.

### You (2025-04-22T18:43:32.067Z)

Like, it's

### Guest (2025-04-22T18:43:33.568Z)

For you to post.

### You (2025-04-22T18:43:33.947Z)

Alright.

### Guest (2025-04-22T18:43:35.398Z)

Sounds good. Sounds good. I think Howard was saying

### You (2025-04-22T18:43:36.627Z)

Cool. Cool.

### Guest (2025-04-22T18:43:39.108Z)

you're working with Mark on some content or something. That's what I remember.

### You (2025-04-22T18:43:39.457Z)

So let's go How calls to talk about the database Right. And to schedule that.

### Guest (2025-04-22T18:43:53.818Z)

Cool. Cool. So I'll I'll create

### You (2025-04-22T18:43:54.227Z)

Yeah.

### Guest (2025-04-22T18:43:57.918Z)

something on, like, sim not exactly Ariel, but something similar to that, then we can go from there.

### You (2025-04-22T18:44:03.877Z)

Through. The office shuttle under right process for hotel step by step beginning better. In our

### Guest (2025-04-22T18:44:09.348Z)

Okay. So

### You (2025-04-22T18:44:10.777Z)

Yeah. Just I already did send the invite.

### Guest (2025-04-22T18:44:10.958Z)

let's go through the the again, the next steps. Howard, Vinod, and Drew, you guys are gonna have a separate call to

### You (2025-04-22T18:44:15.357Z)

I I put down location TBD because I do not have

### Guest (2025-04-22T18:44:17.358Z)

talk about the database and the data transfer. Right? And I'll just we'll just leave it to you guys to schedule that

### You (2025-04-22T18:44:20.327Z)

an account with Teams or anything. Usually, when Vinod and I meet we just use Google Meet.

### Guest (2025-04-22T18:44:24.888Z)

Yeah.

### You (2025-04-22T18:44:26.567Z)

It's got a one hour limit. So, you know, we could if if we go beyond one hour,

### Guest (2025-04-22T18:44:28.218Z)

The four of you are gonna have a call. I think it was at 03:00 on Thursday, to walk through the acquisition underwriting process

### You (2025-04-22T18:44:31.647Z)

it'll just quit. I yeah. If if you if you've got if you've got a different

### Guest (2025-04-22T18:44:37.108Z)

for hotel step by step beginning to end.

### You (2025-04-22T18:44:38.937Z)

tool that we can use, then then if you wanna just let me know the URL and

### Guest (2025-04-22T18:44:39.818Z)

And, Howard, you're gonna send that invite. Okay.

### You (2025-04-22T18:44:43.627Z)

I'll add it to the send out the revised invite. So the around. User. Underwrite so

### Guest (2025-04-22T18:45:05.578Z)

I can send it out.

### You (2025-04-22T18:45:05.887Z)

use them all. I'll just try to figure out if

### Guest (2025-04-22T18:45:06.798Z)

I could

### You (2025-04-22T18:45:08.147Z)

it's better. Like, said, there's any help. You know,

### Guest (2025-04-22T18:45:11.948Z)

Yeah.

### You (2025-04-22T18:45:12.407Z)

like, just like with the the clinic.

### Guest (2025-04-22T18:45:14.308Z)

Correct.

### You (2025-04-22T18:45:14.387Z)

So

### Guest (2025-04-22T18:45:18.668Z)

The next thing is someone actually has to test

### You (2025-04-22T18:45:22.347Z)

website,

### Guest (2025-04-22T18:45:22.498Z)

the model that Howard sent around

### You (2025-04-22T18:45:22.857Z)

I think I would

### Guest (2025-04-22T18:45:25.578Z)

So why don't I take that on if that's alright? Like, because I'm I was the original user. I'm gonna

### You (2025-04-22T18:45:25.797Z)

have that example. And if you need help with content creation

### Guest (2025-04-22T18:45:30.068Z)

gonna underwrite another deal that I have that I actually have to underwrite in real life

### You (2025-04-22T18:45:31.627Z)

out to me. On Monday. I can help you with that.

### Guest (2025-04-22T18:45:34.918Z)

And so I'll use the I'll I'll just try to figure out if there's any

### You (2025-04-22T18:45:35.537Z)

Okay. So

### Guest (2025-04-22T18:45:39.648Z)

like you said, if there's any you know, user errors, like, just from, like, the the inputting

### You (2025-04-22T18:45:44.057Z)

is gonna take.

### Guest (2025-04-22T18:45:44.988Z)

So the I'll but I won't be doing that until Monday or Tuesday of next week, but I'll take that on.

### You (2025-04-22T18:45:48.027Z)

For us to

### Guest (2025-04-22T18:45:49.958Z)

And then on the website,

### You (2025-04-22T18:45:51.147Z)

what the first couple preview it. With. Is up.

### Guest (2025-04-22T18:45:53.688Z)

Vinod, you're gonna take a stab looking at the example website we talked about then if you need any help with content creation, you'll reach out to me on Monday and Tuesday, and I can help you with that. Amazing. Okay. And then can I ask a big picture question? So for Howard and Vinod who understand, like, how long this is gonna take

### You (2025-04-22T18:45:55.317Z)

That works with just because they're family. After two weeks? Firstly I have been to say and two year.

### Guest (2025-04-22T18:46:15.528Z)

when do you think the MVP will actually be ready

### You (2025-04-22T18:46:17.857Z)

So

### Guest (2025-04-22T18:46:18.728Z)

for us to I don't know. Maybe we won the first people we wanna preview it with is the Pakistani analyst that Mark works with just because they're almost, like,

### You (2025-04-22T18:46:28.247Z)

Is that

### Guest (2025-04-22T18:46:28.798Z)

friends and family. What would you say? Are we two weeks, three weeks, a month?

### You (2025-04-22T18:46:31.657Z)

plan. On itself. Important.

### Guest (2025-04-22T18:46:34.518Z)

Away from

### You (2025-04-22T18:46:34.527Z)

That's all. Think.

### Guest (2025-04-22T18:46:35.718Z)

I mean, firstly, before we say when will we ready, what are we gonna are we like, have we closed on what we are actually delivering as part of the MVP So I know, you know, the deal creation flow, the model, creation, the data ingestion. For the model. And the website. Is that all we're gonna deliver? And, of course, the road map and some mock ups and

### You (2025-04-22T18:47:05.277Z)

So

### Guest (2025-04-22T18:47:05.298Z)

sort of things.

### You (2025-04-22T18:47:06.537Z)

it's basically

### Guest (2025-04-22T18:47:06.558Z)

I guess this could be in the mock ups

### You (2025-04-22T18:47:08.377Z)

yeah. A

### Guest (2025-04-22T18:47:10.358Z)

but I would love to have, like, the sales comps. In that just because it's such a core part of underwriting.

### You (2025-04-22T18:47:15.727Z)

Right.

### Guest (2025-04-22T18:47:17.598Z)

That something that could be done in the MVP? You know, those sales comps I sent you from Lester and Weiss? Or should that just be a mock up in the road map? I mean, we can create sales sales come by bleep.

### You (2025-04-22T18:47:35.307Z)

Okay.

### Guest (2025-04-22T18:47:35.598Z)

So it's basically

### You (2025-04-22T18:47:37.707Z)

And they're working trade it. For

### Guest (2025-04-22T18:47:39.948Z)

a page wherein we are showing two two different

### You (2025-04-22T18:47:40.847Z)

Right? So you're kinda getting a bunch benchmark if you're overpaying.

### Guest (2025-04-22T18:47:44.408Z)

deals. Right? Parallelly. Data from two different deals parallel. That's what sales companies

### You (2025-04-22T18:47:49.647Z)

Right.

### Guest (2025-04-22T18:47:52.088Z)

Basically, yes. It's like if I'm underwriting a deal and I'm thinking it's worth

### You (2025-04-22T18:47:52.137Z)

Yeah. I can I can get together, Vinod, and I'll I'll I'll take a look at what's in the version one dot one that I sent around? I

### Guest (2025-04-22T18:47:56.788Z)

50,000,000, what and then I'd calculate it per key or per

### You (2025-04-22T18:48:00.317Z)

did not do anything on the sales comps yet. So

### Guest (2025-04-22T18:48:01.658Z)

per door, I think you guys might say, in multifamily.

### You (2025-04-22T18:48:03.167Z)

but it looks like it's fairly

### Guest (2025-04-22T18:48:04.738Z)

Gets to be able to see, okay, three or four other hotels in the

### You (2025-04-22T18:48:06.247Z)

straightforward. Information.

### Guest (2025-04-22T18:48:08.508Z)

in the market traded or more or less

### You (2025-04-22T18:48:09.567Z)

So yeah. Yeah.

### Guest (2025-04-22T18:48:11.738Z)

Right? So you're kinda getting a benchmark if you're overpaying or underpaying.

### You (2025-04-22T18:48:12.777Z)

Yeah. Yeah. So I what I wanna do before I do get too far down that road is

### Guest (2025-04-22T18:48:15.648Z)

On a per key basis. Right. And we can do If get into the top rates in that, that would be

### You (2025-04-22T18:48:19.067Z)

take a look at that sales comps tab in that Excel

### Guest (2025-04-22T18:48:20.578Z)

you know, even better. But know that's hard to come by.

### You (2025-04-22T18:48:22.327Z)

And if we agree on it doesn't necessarily have to be the format. But if we agree that the data that's in there is what we need, then then I'll go ahead and start working on that. Yeah. Is really power of red cock. Yeah.

### Guest (2025-04-22T18:48:41.248Z)

Yeah. We can we can aim for that.

### You (2025-04-22T18:48:42.017Z)

Does that mean

### Guest (2025-04-22T18:48:44.058Z)

Okay.

### You (2025-04-22T18:48:45.767Z)

What they're probably they're probably selling web scraping as AI. Right. As well. Mhmm. Yeah. It is. It's really

### Guest (2025-04-22T18:49:03.468Z)

Yeah. Howard, this this Ariel this Ariel site, which

### You (2025-04-22T18:49:03.847Z)

friendly. Yeah.

### Guest (2025-04-22T18:49:07.898Z)

is really, really well done, they offer AI powered rent comps. Does that mean they're making up the rent comps? Like, I don't know what the AI part is.

### You (2025-04-22T18:49:15.617Z)

That I think Howard like, five or six sales comps for

### Guest (2025-04-22T18:49:18.988Z)

Right.

### You (2025-04-22T18:49:21.147Z)

campaign suite. In DC at the convention

### Guest (2025-04-22T18:49:23.238Z)

Well, we should really look at I mean, their their site is as well organized as I've seen.

### You (2025-04-22T18:49:23.837Z)

center. Was being converted

### Guest (2025-04-22T18:49:27.858Z)

It really It's just it's in a font that's easy to read, and it's

### You (2025-04-22T18:49:28.957Z)

federal bills, comps, and But but

### Guest (2025-04-22T18:49:32.048Z)

a white background, and it's just it's really user friendly. Cool. That's

### You (2025-04-22T18:49:41.767Z)

at.

### Guest (2025-04-22T18:49:41.848Z)

feedback.

### You (2025-04-22T18:49:42.127Z)

Yeah. Included in your sales topics. Yeah.

### Guest (2025-04-22T18:49:42.928Z)

And just to clarify on the sales comps, you know, the model

### You (2025-04-22T18:49:46.437Z)

If you have if you have a copy of that that you can send as well then,

### Guest (2025-04-22T18:49:46.698Z)

that I sent you, Howard, had, like, five or six sales comps for the, Cambria Suites in DC at the convention center, which was being converted to a Hyatt House.

### You (2025-04-22T18:49:52.427Z)

The the wiser and would you call it? The wiser and something?

### Guest (2025-04-22T18:49:57.588Z)

So it was actually, like, someone went out and found those

### You (2025-04-22T18:49:58.237Z)

I I think don't know who it's easier. Okay. Yeah.

### Guest (2025-04-22T18:50:00.908Z)

comps and included it. But but

### You (2025-04-22T18:50:01.127Z)

And I I it, but I'll resend it. It won't actually, I won't resend it. I'm just gonna upload it.

### Guest (2025-04-22T18:50:03.198Z)

what I'm hoping to do is create, like, a library, right, using the Lester and Weiss where you could go in and, like, select, select, select, select,

### You (2025-04-22T18:50:05.657Z)

Alright. I'll I'll go take Yeah. Okay. Yeah. So near all the time line.

### Guest (2025-04-22T18:50:11.038Z)

and four or five of them get

### You (2025-04-22T18:50:12.417Z)

Kind of get this around. I will let you know how

### Guest (2025-04-22T18:50:13.238Z)

included as your sales comps. And on

### You (2025-04-22T18:50:23.397Z)

wow factor, but not go overboard in an FPP. Right? Because this is the scooter. Right? And so we just we didn't wanna

### Guest (2025-04-22T18:50:27.558Z)

Yeah. They just turn white. They go by l w. It's easier to Oh, yeah. Yeah.

### You (2025-04-22T18:50:31.667Z)

the scooter going, and then

### Guest (2025-04-22T18:50:31.738Z)

Yeah. And I I did send it, but I'll resend it. And I'll well, actually,

### You (2025-04-22T18:50:33.607Z)

start to

### Guest (2025-04-22T18:50:34.758Z)

I won't resend it. I'm just gonna upload it to our

### You (2025-04-22T18:50:34.867Z)

go out and talk to people and talk to investors and to get that ball rolling on things. Yeah. Functional markups

### Guest (2025-04-22T18:50:38.778Z)

okay. So, Dion, on the timeline, we'll kind of get together and I will let you know

### You (2025-04-22T18:50:41.657Z)

work just as well for initial demos and

### Guest (2025-04-22T18:50:45.748Z)

Howard and And, again, what we're trying

### You (2025-04-22T18:50:47.067Z)

sitting in front of an investor. You know?

### Guest (2025-04-22T18:50:50.078Z)

to do here though is, right, we all agree, we want to create enough

### You (2025-04-22T18:50:50.507Z)

Not not a static PowerPoint page that just shows numbers. I mean, we can put together

### Guest (2025-04-22T18:50:54.478Z)

wow factor, but not go overboard in an MVP.

### You (2025-04-22T18:50:55.357Z)

something that actually works. Yeah. And go from there. So yeah.

### Guest (2025-04-22T18:50:58.338Z)

Right? Because this is the scooter. Right? And so

### You (2025-04-22T18:51:00.417Z)

Okay.

### Guest (2025-04-22T18:51:01.418Z)

we just we just wanna get the scooter going and then start to

### You (2025-04-22T18:51:01.967Z)

Thank you, everyone, and I appreciate your patience. When when should we have this call next week? Because I know there's a lot of moving schedules.

### Guest (2025-04-22T18:51:05.978Z)

go out and talk to people and talk to investors and

### You (2025-04-22T18:51:09.117Z)

Does this time next week work for

### Guest (2025-04-22T18:51:09.248Z)

to get that ball rolling on things.

### You (2025-04-22T18:51:11.977Z)

01:30 or two because I have to make for two today. Well, let's just go to two next week on Tuesday with everyone.

### Guest (2025-04-22T18:51:20.938Z)

Okay.

### You (2025-04-22T18:51:22.317Z)

Yeah. And next Tuesday, I've got a I have a flight at 04:00. I can try to get to the airport by two. I may be in transit, but I'll try.

### Guest (2025-04-22T18:51:31.598Z)

Okay. Thank you everyone, and I appreciate your

### You (2025-04-22T18:51:31.837Z)

Okay. Then I will get that put on everyone's calendar.

### Guest (2025-04-22T18:51:35.248Z)

patience. When should we have this call next week? Because I know there's a lot of moving schedules.

### You (2025-04-22T18:51:36.247Z)

Well, Vinod Vinod, would 01:30 still work for you?

### Guest (2025-04-22T18:51:40.188Z)

Does this time next week work for everyone?

### You (2025-04-22T18:51:40.987Z)

Yeah. 01:30 would work. Yeah. Okay.

### Guest (2025-04-22T18:51:43.108Z)

01:30 or two because I had the meeting for two today.

### You (2025-04-22T18:51:44.737Z)

Yeah. I would say let's just keep it at the same time next next Tuesday then.

### Guest (2025-04-22T18:51:47.098Z)

Well, let's just go just

### You (2025-04-22T18:51:48.177Z)

Okay. 01:30. Yeah.

### Guest (2025-04-22T18:51:50.868Z)

two next week on Tuesday work for everyone? Yeah. Next Tuesday, I've got a I have a flight at four, so I can try to be at the airport by two. I may be in transit, but I'll try.

### You (2025-04-22T18:51:59.017Z)

Yeah. Actually paid for is

### Guest (2025-04-22T18:52:02.828Z)

Okay. Then I will get that

### You (2025-04-22T18:52:04.637Z)

the

### Guest (2025-04-22T18:52:05.898Z)

put on everyone's calendar.

### You (2025-04-22T18:52:06.697Z)

Right? Of five or six emails as

### Guest (2025-04-22T18:52:07.398Z)

Sounds good.

### You (2025-04-22T18:52:08.867Z)

plus the Microsoft integration?

### Guest (2025-04-22T18:52:11.548Z)

Yeah. 01:30 would work. Yeah.

### You (2025-04-22T18:52:12.697Z)

Yeah. GoDaddy doesn't actually have email servers. You usually have to get that. So I used to get mine through Zoho.

### Guest (2025-04-22T18:52:19.288Z)

Go ahead. 01:30.

### You (2025-04-22T18:52:20.857Z)

I wasn't too happy with them.

### Guest (2025-04-22T18:52:21.828Z)

Yeah. One item on your and Howard's place

### You (2025-04-22T18:52:24.197Z)

But Microsoft does as well. So

### Guest (2025-04-22T18:52:24.848Z)

plate to Diane. That's email and

### You (2025-04-22T18:52:26.827Z)

apparently, there's a marketing

### Guest (2025-04-22T18:52:28.238Z)

the tracking. Yep. And remind me, so what we're what

### You (2025-04-22T18:52:30.297Z)

partnership with them because with GoDaddy, if you

### Guest (2025-04-22T18:52:33.288Z)

we need to actually pay for is the

### You (2025-04-22T18:52:34.107Z)

set it up through Microsoft, then there was a much

### Guest (2025-04-22T18:52:36.818Z)

through GoDaddy. Right? The five or six emails

### You (2025-04-22T18:52:38.107Z)

cheaper first year.

### Guest (2025-04-22T18:52:39.868Z)

plus the Microsoft integration?

### You (2025-04-22T18:52:40.927Z)

So, yeah, you and I can we can get together. Basically, we just have to log in GoDaddy and and

### Guest (2025-04-22T18:52:44.748Z)

Okay.

### You (2025-04-22T18:52:46.047Z)

push the right buttons. But, actually, so what you'll do is you'll have the domain through GoDaddy but the emails will be controlled through servers on Microsoft. Right? So Okay. Yeah. Okay. I know can get that done by next week. That would be awesome if we had invested. Yeah. It's actually very yeah. It's actually pretty quick. I mean, once once we get in there and input the information that Microsoft needs to connect to the domain, It's really we could probably do it in a half hour, hour. And get everything set up. Okay. Alright, everyone. Thank you. For your today. Bye.

### Guest (2025-04-22T18:53:29.248Z)

Okay.

### You (2025-04-22T18:53:29.447Z)

Alright. Yes.

### Guest (2025-04-22T18:53:30.808Z)

Okay. I know. Maybe we can get that done by next week.

### You (2025-04-22T18:53:31.347Z)

You are. I said you did the 03:30 though. Right? With with the three. It's at three? Okay. Then, yes, we are having it.

### Guest (2025-04-22T18:53:35.598Z)

That would be awesome if we all had Invest AI emails. Yes?

### You (2025-04-22T18:53:38.417Z)

Better give you a few minutes. Okay. Thanks, everyone. Yep. See you.

### Guest (2025-04-22T18:53:39.248Z)

Okay.

### You (2025-04-22T18:53:43.387Z)

Thank you.

### Guest (2025-04-22T18:53:49.368Z)

Okay. Okay. Alright, everyone. Thank you for your time today. Hey, Diana. We do this call for free. Alright. Yes. We are. Except is it at 03:30, though, right, with with It's at three. It's at three? Okay. Then, yes, we are having it. Okay. Okay. Thanks, Bye. Thank you.