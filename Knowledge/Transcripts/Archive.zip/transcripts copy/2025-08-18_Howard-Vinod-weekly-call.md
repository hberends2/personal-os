# Howard | Vinod weekly call

**Date:** 2025-08-18 00:00:00 UTC
**Meeting ID:** 9154c9db-07ff-449f-a585-e006d6fc39af
**Synced:** 2026-02-05 14:46:48

---

# Transcript for: Howard | Vinod weekly call

### You (2025-08-18T21:29:51.820Z)

Good. How's your weekend?

### Guest (2025-08-18T21:29:56.877Z)

Weekend was okay. Nothing much. Yeah, but I think we got a lot of things done, which is good, but didn't go out. Yourself.

### You (2025-08-18T21:30:15.260Z)

I stuck around our house. Pretty much the entire weekend.

### Guest (2025-08-18T21:30:19.197Z)

Okay?

### You (2025-08-18T21:30:20.220Z)

And came up. To the lake yesterday. And getting a period of cooling off. So yesterday it just started to clear up. It was cloudy today it didn't rain. But the rest of this week is supposed to be like mid-70s, maybe 80, a couple days nice and cool at night. So I think my wife and I were probably going to be tag teaming. Who's going to come up to the cottage and who's going to stay back and take care of the dogs? Yeah. Came up yesterday. And I knocked out so much yesterday afternoon, I didn't really have a whole lot to do today. I just kind of trying to go through old notes and trying to see what else needs to be done. I did make a lot of those updates to the POC.

### Guest (2025-08-18T21:31:16.157Z)

Yeah.

### You (2025-08-18T21:31:16.620Z)

I just now need to. Revise the prds. That include that?

### Guest (2025-08-18T21:31:32.477Z)

We are kind of actively working, so some of them might get missed, but we'll just make the modification whenever we'll.

### You (2025-08-18T21:31:45.180Z)

Hopefully you're not working on these yet. I don't know what order you're doing anything. Yeah.

### Guest (2025-08-18T21:31:55.197Z)

Performa is in full swing. Have a look at some of the performer work. So.

### You (2025-08-18T21:32:04.300Z)

No. Maybe you can show me where it's located. I can pull it up one these days.

### Guest (2025-08-18T21:32:10.877Z)

Yes, it's a. Right, now I'm just showing you from the dev. So if you go here, Right. So either you click on this deal or you click on this start icon here.

### You (2025-08-18T21:32:14.380Z)

Yeah. Okay? Yeah.

### Guest (2025-08-18T21:32:23.117Z)

I don't know whether it has been is it visible? Or I can jump on from the laptop.

### You (2025-08-18T21:32:28.140Z)

Okay?

### Guest (2025-08-18T21:32:28.157Z)

So if you go here, it'll kind of open a new tab for you. And of course, we'll make whatever change is required in UX or wherever working through it. And we were getting some success extracting some of the data. Proceed. And when I was testing yesterday night, I had some good success with Excel as well as with the PDFs.

### You (2025-08-18T21:32:38.940Z)

Yeah. Oh, good. Okay.

### Guest (2025-08-18T21:33:02.797Z)

But then when we deploy it, I think there is still some hiccups. Kind of fixing that. By adding that a lot of improvements. That needs to be done and a lot of testing and all that.

### You (2025-08-18T21:33:17.100Z)

Yeah. Good.

### Guest (2025-08-18T21:33:20.637Z)

But, yeah, I think we are making some good progress.

### You (2025-08-18T21:33:23.500Z)

All right. Were you able to get Raj and Siobhan set up with invest emails?

### Guest (2025-08-18T21:33:31.277Z)

I haven't got to that.

### You (2025-08-18T21:33:32.140Z)

Okay. All right.

### Guest (2025-08-18T21:33:34.237Z)

That's why we just want to focus on the MVP and completed as soon as possible and then we can do all of the work.

### You (2025-08-18T21:33:39.980Z)

Well, yeah, that's why I was wondering, because I did give them access to the folders that have the PRDs. I just wanted to make sure that they could access them. They weren't having trouble with their Gmail accounts.

### Guest (2025-08-18T21:33:56.157Z)

Yeah, I think RA road back to you, right? That he was not getting access to PRD documents. Something like that. That's what he was telling me. No.

### You (2025-08-18T21:34:04.220Z)

No, I don't recall seeing anything.

### Guest (2025-08-18T21:34:06.797Z)

Okay, but anyways, I sent them.

### You (2025-08-18T21:34:08.060Z)

Was this recently?

### Guest (2025-08-18T21:34:09.757Z)

Yeah, they sent a few days back. You were saying? Yeah, I have the URL, but I can't access it. But I did send them the latest prd documents. If there are more updates, let me know.

### You (2025-08-18T21:34:23.900Z)

Okay, yeah, I'll double check. And see if I maybe misspelled his email or something. Okay? Yeah, that way. I just want to be sure that we don't have to go through a bunch of steps to get him the PRDs and that I can just make a revision, send out an email to let him know what change, then we'll make an access it right away. Cool.

### Guest (2025-08-18T21:34:51.677Z)

Yeah. And then we are having some hiccups. With the staging environment. I just want to check real quick whether it is up now.

### You (2025-08-18T21:35:00.700Z)

Yeah.

### Guest (2025-08-18T21:35:01.197Z)

And it'll let you know that probably that thing I was just showing you should be available there as well.

### You (2025-08-18T21:35:09.660Z)

And that was indeed dev environment, right?

### Guest (2025-08-18T21:35:13.517Z)

Earlier I showed you from there. But this should be available on a staging tool, let's say.

### You (2025-08-18T21:35:14.940Z)

Yeah. Okay?

### Guest (2025-08-18T21:35:20.717Z)

I don't have a deal, but I'll quickly. Yeah, I mean you can do. You can really have a look anywhere on Dev or stage. That probably. Quite interesting.

### You (2025-08-18T21:35:31.260Z)

Yeah. Do anything but look and scroll. But, yeah, that'd be pretty cool if I can get in there and start seeing what's been built so far.

### Guest (2025-08-18T21:35:41.437Z)

Yeah.

### You (2025-08-18T21:35:41.980Z)

And take it from there. One of the things that I was working on over the weekend as well is. I found a template for CRM. Salesforce HubSpot. Their free versions are okay.

### Guest (2025-08-18T21:36:04.637Z)

Okay?

### You (2025-08-18T21:36:06.300Z)

But this one kind of included things that were in some of their paid tiers. So I'm just wondering, try to show it to the team tomorrow what I've got done so far.

### Guest (2025-08-18T21:36:20.557Z)

Yeah. Right.

### You (2025-08-18T21:36:23.580Z)

And then we can decide if we want to do something like that. You can deploy it. Into InnVestAI rather than using just a wide open URL on the web. But I still want to look into some of the other ones as well.

### Guest (2025-08-18T21:36:43.037Z)

Sure. And I think you are also looking at post harvest as well.

### You (2025-08-18T21:36:46.780Z)

Yeah. That one looked really good. Have you had a chance to go through the website?

### Guest (2025-08-18T21:36:55.117Z)

Yeah, I quickly went through it, but did you look at the pricing and all that?

### You (2025-08-18T21:36:59.180Z)

Yeah.

### Guest (2025-08-18T21:37:00.157Z)

Was it good?

### You (2025-08-18T21:37:00.220Z)

Basically free.

### Guest (2025-08-18T21:37:02.477Z)

Oh, awesome.

### You (2025-08-18T21:37:03.180Z)

Yeah, it's open source. They have a ton of big companies that use it. And there is a page on there that says 90% of their clients don't pay anything because their free tier. And it's not you basically get all the products on the free tier, it's just how much you use it. And I think you get like 1 million tokens a month. They say somewhere on there that only 10% of their clients exceed that. Those are the big names that are probably on there. And even then, it's really cheap.

### Guest (2025-08-18T21:37:44.637Z)

Yep. Yeah, yeah, I see it really cheap. It says.00005 cent per event or something. Which is.

### You (2025-08-18T21:37:54.380Z)

And I think that kicks in after you hit your million or something. So, yeah, I think that one looks really promising. If you take a look at all the different features, they have them broken up by role. They haven't broken up by department. And it's like, I can't imagine.

### Guest (2025-08-18T21:38:06.157Z)

Even.

### You (2025-08-18T21:38:09.900Z)

That we would ever need to go to Pendo or Heap. Because it seems like this one has everything we need.

### Guest (2025-08-18T21:38:19.837Z)

Both coffee. We can definitely use this one.

### You (2025-08-18T21:38:21.820Z)

Yeah. So, yeah, I think had a good call with Diane today. I told her I'm getting a little frustrated. At how long it's taking to get the LLC up and running. And so she promised that sometime this week. She's going to set up a call with everybody where we can go through it together. Line by line, make sure we're all in agreement. I hope so. She even admitted she was very apologetic. But she said she went to the library this weekend. To kind of see Quester herself to get stuff done. And she said she started reading through it, just about fell asleep because it's so boring and getting up, going and working on something else and just kind of dropped it. And it's like, yeah, it is boring. It's legal stuff, but, man, we got. To get this thing done.

### Guest (2025-08-18T21:39:06.957Z)

Thanks indeed.

### You (2025-08-18T21:39:15.580Z)

Now.

### Guest (2025-08-18T21:39:15.917Z)

Yeah. And I think that working agreement remaining as well so account couldn't open so I reached out to true that if we could just one more me $800 for both the engineers.

### You (2025-08-18T21:39:24.380Z)

Yeah.

### Guest (2025-08-18T21:39:29.997Z)

Then I'll just pay them from my account for now, and then he gets sometime after that. So they kind of complained that one month, I think, today, or they're going to complete it tomorrow.

### You (2025-08-18T21:39:41.100Z)

Okay?

### Guest (2025-08-18T21:39:42.077Z)

I just wanted to pay them so that they don't get demotivated, right?

### You (2025-08-18T21:39:45.180Z)

Yeah. I mean, as long as we keep track of it, keep records of it, that's no big deal.

### Guest (2025-08-18T21:39:51.517Z)

Yeah, so he did. When Mommy 800, which is great.

### You (2025-08-18T21:39:54.300Z)

Yeah.

### Guest (2025-08-18T21:39:55.357Z)

And then I'll probably. I need to add their account and all that, but I'll do that.

### You (2025-08-18T21:40:01.500Z)

There's another one I sent. I think I may have only sent it to Diane and Drew. I don't remember now, but there's another. Online bank specifically for startups and tech companies called Brex B R E X. Yeah.

### Guest (2025-08-18T21:40:20.397Z)

Okay?

### You (2025-08-18T21:40:21.660Z)

So I suggested that they look into that. Because it's got all sorts of benefits. For startups and small teams. We could all get a virtual credit card and with certain limits, so we wouldn't have to reach out if we needed $800. To pay somebody. We could all have some money available to us. And it looked pretty good.

### Guest (2025-08-18T21:40:53.917Z)

Cool. Cool. Yeah. As far as this won't.

### You (2025-08-18T21:40:55.660Z)

Yeah. Ultimately, I think it's really kind of going to be up to those guys. I could care less. It's not like I'm going to need to access to the money. But.

### Guest (2025-08-18T21:41:09.517Z)

Right. Yeah. One thing. I definitely want to talk to you today. What is your personal. Do you think it's going to work?

### You (2025-08-18T21:41:17.660Z)

What's that?

### Guest (2025-08-18T21:41:20.077Z)

Do you think InnVestAI. Is going to work, these guys might then draw all that kind of align.

### You (2025-08-18T21:41:23.660Z)

Yeah. Yeah. Yeah. Yeah. The calls that we had with Jessica. And others. I liked the call last week because as opposed to our first call, I didn't have to speak. I was able to sit there, and I spent pretty much the entire call. Watching Jessica's reaction to what was being said. And I got the impression, the very first call that she was really thinking that this was something worthwhile. And she made some comments last time that made it sound like she she wants to get involved. Not. Not as a partner, as a founder, but, you know, as a consultant, advisory. You know, she might get like a 3% cut or something like that, right? She loves it. I could tell she just really wants to get in there. And we've had good conversations with other people as well. The response that we're getting has been so encouraging. But also today in my call with Diane, she mentioned there was a deal Path seminar. Last week. And I sat in on it, but it was sable stuff. I just kind of tuned out. But Diane and Mark also attended it, and she said Mark. And her talk afterward. And she said, mark. During with what's what he saw on that seminar, he finally gets what we're doing with AI.

### Guest (2025-08-18T21:43:09.357Z)

Okay?

### You (2025-08-18T21:43:10.780Z)

He told him that he's totally. And now he understands now what it is that we're trying to do. Agrees with what we put down as the roadmap and what we need to focus on. I sent that email today with the pricing article that I read. That was interesting to me as well. I never saw an article yet that included the math. And showing how outcome based pricing can be anywhere from two to five times the revenue is just regular subscription. So, yeah, I think at this point, Drew's on board. He's officially. He told Diane a couple weeks ago. Diane said tonight. Is committed, so, yeah. I really do. Think it's going to fly.

### Guest (2025-08-18T21:44:15.757Z)

Fourth. Yeah. I'm hoping that. We get budgets sooner. And we are kind of able to sit full time on this if the idea is really good.

### You (2025-08-18T21:44:25.180Z)

Yeah.

### Guest (2025-08-18T21:44:31.437Z)

Because right now, There's so much work. I'm sitting at the throat night over the weekend and all.

### You (2025-08-18T21:44:41.020Z)

Oh, I know, I know.

### Guest (2025-08-18T21:44:46.237Z)

But because I like the idea as well. And whatever we are doing.

### You (2025-08-18T21:44:51.420Z)

Yeah.

### Guest (2025-08-18T21:44:52.877Z)

Those are good. But I mean, yes, sooner we are able to kind of dedicate our full energy in this. That will be great, but I don't know. How far out we are on that path. Probably.

### You (2025-08-18T21:45:07.820Z)

I don't think we're too far. We've had conversations with people. I think that once we have the MVP ready to show. I think we're going to have people who are going to start. Or who will be ready to write a check. It's not going to be huge, but it's going to be enough to get us through maybe 150 grand, maybe more.

### Guest (2025-08-18T21:45:31.837Z)

Yeah.

### You (2025-08-18T21:45:33.900Z)

But when I talk to Diane, and this is just between you and I, she said that's still one area that Mark is pushing back. He doesn't want to go out and start getting investors until we've got paid clients and we're underway. And Diane disagrees with, I mean, everybody disagrees with him and she keeps ringing up that apparently he invested as a precede. Angel investor and lost money. And so he insists now that nobody's going to invest in this until we've got paid clients. And it's like I told Diane. I said, look, just because he had a bad experience, wants. Doesn't mean everybody feels the same way. We can get investors tomorrow. If we just go out and ask. I mean, I've talked to a couple people and basically I kind of told her. I said, look, if he's not ready, if he's not willing to go out and look for a precede or angel investing,

### Guest (2025-08-18T21:46:27.517Z)

Yeah.

### You (2025-08-18T21:46:37.820Z)

I'll do it. She can do it. She's got contacts. So that's the last thing we need to get Mark to come around on is that we need money now. We're not going to get to that point.

### Guest (2025-08-18T21:46:42.557Z)

Right? Yeah. Yeah.

### You (2025-08-18T21:46:51.020Z)

She has no revenue. I don't have any revenue. Marquez. Yeah, well, she made a covenant. It was kind of snarky, but it's like she goes, yeah.

### Guest (2025-08-18T21:46:57.677Z)

I don't know much. Earlier.

### You (2025-08-18T21:47:03.420Z)

Mark has two houses. He's got one in New York City and one in the Hamptons. And I don't think he understands what it means to not have money and that pay bills. He goes, I don't think he can just relate to what you and I are going through and just like, yeah, it's probably true.

### Guest (2025-08-18T21:47:15.197Z)

That's true. All right.

### You (2025-08-18T21:47:22.700Z)

Out of touch with the working man, so, yeah. I think that's probably our biggest focus now.

### Guest (2025-08-18T21:47:26.957Z)

Yeah. Yeah, I mean, negative thing of not having the investor now is the kind of pushes us further to helping this product.

### You (2025-08-18T21:47:37.980Z)

Yeah.

### Guest (2025-08-18T21:47:38.557Z)

Fast enough, and I kind of got, you know, very, what do you call, entry level engineers. Just because, you know, we don't have enough budget and, you know, I don't want to blow up someone's personal accounts, right? If we had some budget, you could probably hire, you know, senior engineer or something. These guys are really good. These guys are so focused. Working 24 7. I mean, they are awesome, but. Yeah, we could probably have a senior engineer in some higher budget. There have been great. And more than that, if we had budget, I would love to you meet full time and dedicate all our energy here, right?

### You (2025-08-18T21:48:34.380Z)

Well, I am. I mean, this is my full time job, so I'm treating it like that. Even though I'm not getting any revenue on just figuring. Yeah, it'll come right.

### Guest (2025-08-18T21:48:45.597Z)

Yeah.

### You (2025-08-18T21:48:46.620Z)

I'll get reward even if it's closer to the back end. Maybe a couple of years from now we get a big check, but who knows?

### Guest (2025-08-18T21:48:57.357Z)

And that reminds me. Showmu had forwarded your resume to the vp.

### You (2025-08-18T21:48:57.660Z)

Yeah. I think we all right.

### Guest (2025-08-18T21:49:05.357Z)

He'll provide some feedback. Let's see.

### You (2025-08-18T21:49:06.700Z)

Yeah. I still don't know what this job I'm applying for. I'm like, okay, you want to resume? I'll give you a resume, whatever.

### Guest (2025-08-18T21:49:18.637Z)

It's basically they wanted. Some sort of data and product guy. Leader, data and product leader.

### You (2025-08-18T21:49:30.220Z)

Okay?

### Guest (2025-08-18T21:49:31.757Z)

Not really coding. But kind of providing some guidance on how to tell develop more data driven products.

### You (2025-08-18T21:49:41.500Z)

All right. I can do that. Like I said, I wasn't exactly sure what angle I would supposed to take in the resume. And when you said try to get more data and there's like. Well, I didn't actually do the data cleaning. I directed the data cleaning and did that. But it does sound like it's more definitely more in line with what I did before.

### Guest (2025-08-18T21:50:06.637Z)

All right? I'm even the kind of research you do. And they kind of expose that you have on Excel. It's very kind of, very much connected. And the other thing I think is if they allow more work than this is not going to be very pressing job. So I'm sure you'll be able to manage InnVestAI and Morgan very well.

### You (2025-08-18T21:50:26.780Z)

Yeah. I'd make it work. Evenings and weekends. No big deal. We're empty nesters now. My daughter moved out last week end. So it's just my wife and I, and it's not a big deal. Plenty of time.

### Guest (2025-08-18T21:50:46.237Z)

Yeah. Yes. Yeah. Let's see this. This goes through.

### You (2025-08-18T21:50:51.180Z)

Yep. Yeah.

### Guest (2025-08-18T21:50:52.157Z)

I'm sure, Amanita. He speaks to you once, he 'll like you for sure. But let's see.

### You (2025-08-18T21:50:58.300Z)

Yeah. Do you know the guy's name?

### Guest (2025-08-18T21:51:01.757Z)

I'm at something.

### You (2025-08-18T21:51:03.500Z)

Okay?

### Guest (2025-08-18T21:51:04.637Z)

I'm on something.

### You (2025-08-18T21:51:07.420Z)

Because Morgan was a client of Real Page, and I think they were a kind of conservative, and I actually worked with some people from Morgan. But they were probably more on the utility management side. Of the business.

### Guest (2025-08-18T21:51:19.917Z)

Okay?

### You (2025-08-18T21:51:23.100Z)

Probably not so much on the BI or the reporting or data, so I probably haven't met them anyway. Or whoever.

### Guest (2025-08-18T21:51:23.917Z)

Good, good. Right. Yeah, even there are Barcadius clients.

### You (2025-08-18T21:51:37.500Z)

Yeah. Yeah, I think they did do some work in Red IQ as well.

### Guest (2025-08-18T21:51:43.437Z)

Right. All right.

### You (2025-08-18T21:51:44.380Z)

Okay? All right, well, I think I will get probably all of the PRDs updated tomorrow. And. Yeah, it's just, you know, I added the closing date. To the pipeline. And then that feeds the valuation tab for the financing. And also the pro forma tab. So now there is. Based on whatever year the closing date is. So right now, if I put a closing date of, like, October 1st, there's a 2025 year to date column and then a 2025 forecast column. It calculates the number of days for each. So you can go ahead and continue with the forecasting. That's really about it. You just have to insert another column. And you have to calculate the number of days from January 1st to closing for the year to date, and then the rest for the regular year. So it's not that difficult.

### Guest (2025-08-18T21:52:49.117Z)

Yeah, it's not definitely. I don't feel good.

### You (2025-08-18T21:52:50.940Z)

Yeah.

### Guest (2025-08-18T21:52:53.917Z)

We have worked on that part yet, but we'll do it. When we get to it.

### You (2025-08-18T21:52:56.460Z)

Yeah, yeah. All right. Very cool. Anything else.

### Guest (2025-08-18T21:53:03.517Z)

Anything. This guy. Are saying from technical perspective, whether it's going slow or anything. I don't think we are going slow.

### You (2025-08-18T21:53:13.260Z)

Not. No, I don't think we are either. In fact, I think Diane actually has expressed how happy she is and how fast it's going. None of them come from. A technological product. Development field, so they don't know what fast or slow is. Kind of puts us in a good position.

### Guest (2025-08-18T21:53:35.117Z)

That's what I'm saying. That's true.

### You (2025-08-18T21:53:43.500Z)

I don't know if we're going to meet the Labor Day. I mean, that's what, 10 days, two weeks from now? I don't expect to have a fully working MVP by then, and I've been kind of setting the stage for that.

### Guest (2025-08-18T21:53:57.757Z)

Yeah, I don't think we can really do it by Labor Day because it's just been a month.

### You (2025-08-18T21:54:02.780Z)

Yeah, it just wasn't enough time.

### Guest (2025-08-18T21:54:06.477Z)

Yeah. We are still trying.

### You (2025-08-18T21:54:11.340Z)

Yeah. Okay? Anything else I can do for you?

### Guest (2025-08-18T21:54:20.957Z)

Not really. Everything is all good for now, but. Yeah.

### You (2025-08-18T21:54:24.300Z)

All right. Yes, I have. Any other questions, I'll let you know. But otherwise, I'll let everybody know when those PRDs are updated.

### Guest (2025-08-18T21:54:36.477Z)

And sorry. I couldn't get to a few things that you had sent, but hopefully sometime.

### You (2025-08-18T21:54:40.540Z)

Oh, no, no, I don't. Yeah, I don't. Those. Most of those are not urgent. A lot of them are. Just FYI, if I find something cool, the other ones, like the post hog and everything.

### Guest (2025-08-18T21:54:48.477Z)

Yeah.

### You (2025-08-18T21:54:54.540Z)

Be nice to have something up and running by the time we get to version one, but, I mean, we don't need something like that for the mvp. We're just going to be working with a handful of selected people. And not concerned about things like that yet.

### Guest (2025-08-18T21:55:10.477Z)

Yeah. And then in between, few of these things also came up, right? Email and then website going down and all that.

### You (2025-08-18T21:55:15.820Z)

Yeah. Always going to be fires to put out somewhere.

### Guest (2025-08-18T21:55:22.397Z)

Yep.

### You (2025-08-18T21:55:23.020Z)

Unfortunately. All right, cool.

### Guest (2025-08-18T21:55:28.077Z)

Thank you.

### You (2025-08-18T21:55:28.700Z)

All right, I will talk to you in tomorrow's meeting.

### Guest (2025-08-18T21:55:30.317Z)

Tomorrow. Yeah, okay.

### You (2025-08-18T21:55:33.500Z)

Take care.

### Guest (2025-08-18T21:55:34.237Z)

Thank you.

### You (2025-08-18T21:55:34.940Z)

See? Ya.