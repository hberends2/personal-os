# Howard Berends and Emanuel Pavlopoulos

**Date:** 2025-09-22 00:00:00 UTC
**Meeting ID:** 31601a0e-947f-4f97-b0e9-04906f034ba0
**Synced:** 2026-02-05 14:46:48

---

# Transcript for: Howard Berends and Emanuel Pavlopoulos

### Guest (2025-09-22T15:00:25.711Z)

Hey, Howard.

### You (2025-09-22T15:00:27.954Z)

Good morning. How are you?

### Guest (2025-09-22T15:00:31.071Z)

Good. Where are you calling him from?

### You (2025-09-22T15:00:35.154Z)

I am actually calling in from my cottage. In michigan.

### Guest (2025-09-22T15:00:42.671Z)

Very cool.

### You (2025-09-22T15:00:48.994Z)

Midwestern. Guys. Osborne, wisconsin. Are you in Wisconsin? Right now.

### Guest (2025-09-22T15:00:55.871Z)

Let me know. No, I'm actually in florida.

### You (2025-09-22T15:00:59.554Z)

Okay? I hear you. I lived in texas. For many, many years. But I grew up here. I tell you? I mean, I used to ski. I used ice skate, play hockey. I used to do everything in the winter. And now it's like if it's 50 degrees.

### Guest (2025-09-22T15:01:18.191Z)

Yeah.

### You (2025-09-22T15:01:19.234Z)

I'm, like, freaking out. It's like. I can't handle the cold.

### Guest (2025-09-22T15:01:24.911Z)

Yeah, I was. I was up in illinois.

### You (2025-09-22T15:01:25.154Z)

Yeah. I was up in the Omaker.

### Guest (2025-09-22T15:01:28.351Z)

Over the past six months. I just came back in July.

### You (2025-09-22T15:01:28.354Z)

Over the past. Six months. Back. In july.

### Guest (2025-09-22T15:01:36.111Z)

And I was sick every month.

### You (2025-09-22T15:01:36.674Z)

I was sick. Every time.

### Guest (2025-09-22T15:01:38.271Z)

That I was out there. It was brutal. Normally I would go ice fishing with my father in law up in Wisconsin. I was out in Illinois like I said and didn't get to go here.

### You (2025-09-22T15:01:50.674Z)

Hard to justify.

### Guest (2025-09-22T15:01:50.911Z)

Hard to justify the cold when he can't do fun stuff. In it.

### You (2025-09-22T15:01:53.954Z)

And that is true.

### Guest (2025-09-22T15:01:57.151Z)

So. Well, thank you. Thank you so much for joining today. I'm sorry about the kind of switcheroo. I don't know how to. Family emergency, Wasn't able to join.

### You (2025-09-22T15:02:06.754Z)

Coming back from south high school. Stuff last night. So I didn't. Well, you kind of caught me off guard. As well. I'm sitting here in my hoodie. I went normally wear a hoodie to an interview. I thought this was going to be just a prescreening. HR quick call to see if I would move. I love it. I'm pretty casual. Most of us. Very few of us are measurable. Are wearing. Ties. Business. Cat. Stuff like that. It's one of the things I really love about our culture. It's pretty laid back in that way. Obviously. We work hard. We all get to work. Sorry to cut you off guard. Hopefully. Please don't feel. Pressure. No. You want to make sure that. This is kind of. This is the first. Interview. The journal process. End up with. Members. Part of it. This particular role does. Leadership in the business. Executive leadership. Most of us. Who are product managers. That much we are. They were senior partners. My role. Product manager. We don't really have. Senior leadership. Process. Data management platform. Real estate. There are tons of different Personas, property owners to investors. But we definitely. The folks are using. Even though I am selling into this kind of late, I did have a chance to review. And definitely. I think one of the critical things for this role. Sustainability perspective. That is, we have a lot of experience. A real estate. Impact. Really what works. As you probably see from the job title, is really. You definitely have. Management skill set, so I'm really excited. All right. The format. One thing I really wanted to ask you about. Your experience with. Low code, no code. Tooling for pocs. And stuff. That's an area that I'm very partial to. So I'm going to try to make some time for that as well. Because I'd love to hear your thoughts on that, too. Yeah. Been playing with every toy out there. Awesome. Very cool. So just some core questions that I've got out there. One of the things that would love to learn more about is from your perspective. Can you tell me about a product that you think. Is really exceptionally well designed. In the context of. Your real estate work in the past. Something you really enjoyed using. Technically, just to make sense. What makes it well designed as well. In your opinion. That's a good question. I don't know that when you say a particularly well designed product that anything jumps into mind immediately. I learned many, many years ago. That real estate in general. Is 10, 15 years behind. Technology wise. So there's a lot of non real estate products. That I could bring up. But a lot of the ones that are strictly real estate. Are. Clunky. Although. I will say that there are some new. Product management tools. Out there like competitors trd Emanuel page that have been released in the last few years. That do have a better. Ui. Component in the UX component to it. One of the things. As you can tell by my resume. I've been involved with RealPage. In many different situations. Either join them directly, or I'll just say bought the company I was working with. And I think they're a great example. That. A lot of the software and providers in this industry. Are built. Through acquisition. So everything's held together by. Duct tape and bubble gum. And everything. You can go from one page to another and have a totally different look and feel. And that's always bothered me. I'm not a designer, but I know what I like. You know what I'm saying? I think mobile has had a huge effect. On how people. Work. Whether it's on their phone or. A lot of that design and that simplicity. Is being transferred over to a lot of the products. And that's consider myself to be a minimalist. Option. Where? I don't know where to. You know, if you can show me. A tool that is intuitive. Where? I don't need to be onboarded. And I don't need to go through a training class. And everything else. Then that'll be the tool that I'm looking for. To give you an example, right? Fair enough. Yeah. Yeah. Yeah. Definitely resonates. That's been our experience as well. A lot of folks still on spreadsheets. Yeah. Those spreadsheets are bad by any means, right? But you got whole businesses that are operating on spreadsheets. Oh, yeah. With Rediq, which is. Of course, everybody. Who helped the right. So what we found? That's the biggest thing. You have to meet certain ways. That's a good point. I would imagine. Yes, it's in excel. Imagine you get ordinary. Can you? In a flat file so I can use it in. One of our products. Called HTTPs. Basically the I tool that we have to snowflake ultimately to our data warehouse. We don't appropriately transform. And that's a lot of what they're. Used to. Either pulled up that product PDF reports. If they wanted to. But a lot of times they're working. In this one. Excel file or whatnot. It's a very effective tool for every industry. So. It's not going to go away. Anytime soon. Yeah. So you mentioned with Rediq with regards to. Investors and whatnot. One of the questions that I did have written down that I was curious on. Is context. A couple of years ago, we started getting more into capital markets. And investments. And giving data that would help in the context of underwriting specifically around. The energy efficiency carbon emissions of the built world. Right. So being able to get estimates for things prior to. Actually making investment decision, whereas part of making investment decision. And we, of course, see, like private equity firms. Are doing 50 plus acquisitions per year. So what I want to do is kind of go through, like, a thought exercise. On this, since you already have some experience with it. So, like, setting the stage right. So, like, private equity firms in this hypothetical have 50% plus acquisitions per year. They want to standardize how they assess building performance. During the due diligence period. And currently, each deal team is doing that completely differently. From a product perspective. How would you approach building a solution? That meets the different needs. We actually approached measurable. Back around 2,022. Met with. I think we had a fun call with Matt Ellis, and I'm not sure who else. Was on the call. At the time. And that's kind of what we were looking to do. Right. So, rediq. At the time was strictly. A valuation tool. And then two. Either you buy the product. Some of does. With that. Asset management experience. So one of the things we wanted to do. Is bring in third party data. Demographic data. But utility and ESG data was also obviously one of the things we wanted to do. So the idea was that. We would have either an API. Or some type of a connection so that a user could say, okay. I'm looking to buy Happy Hollows apartments. In tampa bay. And then we can bring back. The data. We can bring back the data. For whatever the competitors are. So I guess. To really get kind of a high level answer. Your question is we would want to make. Necessary attributes. To identify what is a true. Cop. And what we would. Be bringing in relevant data. But I know you don't. You serve every commercial real estate sector out there. Not just multifamily. So clearly you would need to have. Segregation between what? An office building, A skyrise versus the single story office building. All of those different attributes. That would be brought in. So yeah. I guess that's probably. I don't know if that answers your question. I think what it boils down to is. The more granular you can get. Especially for the target. Real estate asset. The better you can better serve. Them rather than just. A generic oh for the state of Florida. Your average electric consumption is blah, blah, blah. That's useless. Right. I think that answered it. Mirrors what we've had in our experience as well. Like when building out our whole building estimates. Machine learning model capabilities. It's getting down to those granular details. Of the locale, the property type. You're totally right. Awesome. I have one question that. You're going to answer. Like, well. Noel had it written down. I'm like, okay. Here's one for you. Let's say you're building a system. Where portfolio managers can generate ESG compliance. Reports across hundreds of properties. Walking through what you think happens technically when a user clicks generate report from the user interface all the way to displaying those results back to the user. Okay? So kind of getting back to what we were just talking about. We would need to know what are the attributes. Of each of the assets. That you have selected as part of that report. It could all be. Particular. Around the us. Or. Aggregated into. Whatever reporting tool that you're using, right? All that data would go in there and said, okay. I need this data. For all of these. Assets. Here as details. Aggregate and go up database. Not. Data. Then the reporting database. Would get all that data. Aggregated together. You're going to have a unique property ID can have all these unique IDS associated with. The property itself. Along with the providers and all of that data. So you can ensure that you've got a true. One to one match between the assets you're trying to get the report from and the data associated with those assets. And then. Aggregate those data. Together. You could either. In a gui on the screen. You could export it to PDF. You could even. Export that flat file if they want to do whatever they want. The position here. Titles in product management are all support. So we add principal product manager. Role for us. But what we're looking for is with somebody who has deep experience in real estate in particular. But then obviously also product experience with. Many years of applicable experience. In terms of actually building out software solutions. So in this particular. Case. It would be the most senior product role as the isu. Definitely we have today. I don't know if that necessarily helps a ton with explanation of it, but. In terms of the scope of the role. How I would see a principal product manager is kind of being familiar. Most of the areas of the business. Which right now I think all of the product managers are familiar with all the different areas of the business. To some extent or another. So in this role, person would find themselves with a lot of support in that regard. But to be able to learn, to be able to also, I think, serve as in a mentor capacity as well for folks that are more junior. I think that's part of it. But there would be no direct reports or anything like that. For principal product Manager. All right. Yeah. Sounds almost exactly like my senior director. Of product management at rediq. Reports. But they were a product holders. And I would say dot is lying. For product managers. But that's just. There, okay? No. Sounds good. It's like. Titles are all across the board. I've seen roles for vice president. And it's like, well, it's you and one other person. A year. Yeah. Right now. We have essentially. Four product managers. We have our director, Product Management. We have. Our cpto as well. Chief product technology officer. But yeah, we're looking on expanding the team, obviously. And then I was actually so even my role, technical product manager. We didn't have a technical product manager until recently, but it was just something as we looked at what I'd been working on APIs machine learning. And various other areas of the business. So it was like, yeah. That's more technical. But I would say most of our product managers are pretty technical. Yeah. Try not to overdo it, though. But I know we're over on time here. Howard. But I can definitely have the under question. So I don't have a hard stop. Okay? Let me see. If. I do really quickly. I think I have. No, I'm good. Cool. So, yeah, I would love to ask you about your experience. With regards to the no code. Low code tooling. It's an area that I've been digging into a lot. You mentioned in your resume, like building full stack apps with no code platforms. Can you walk me through one of your examples? Like, what did you build? What did you use to do it? And. What was some of the key fireworks? Some of the key findings that you had and going through it. Yeah. I've been doing a lot of work, some of it on a consulting basis. I am working with a couple of different organizations. Out there. And I've been using the no code for, like, the proof of Sept. I played around with just some personal products. But I think that the two that I'm working on. And they. Are proof of concept. Well, one of them is proof of. Except the other one's an actual. Product. The first one is. I'm working with a group of people. Who are putting together a valuation model for the hospitality industry. So basically, it's rediq for hospitality. And I was able to use lovable to create a fully functioning proof of concept. So uploading the documents. Taking the historical data. And that extrapolating and projecting forward. There's basically different types of. Or different methods. Of how they can forecast. Their revenue. And expenses. And, you know, so basically, you know, I had each line item has its own drop down box. Where they can select. Do I want to do it? As you know, the cost per room, the percentage of revenue. Or do I just want to manually type it in? And I mean, it works great. And then you got. Your financing and all your assumptions, so there's probably. Six different pages. So. You've got, you know, your property set up. You've got your data upload, your market data inputs, and then you've got the whole pro forma section. That has occupancy revenue. Expenses. I mean, it was. It was fun. Is. I also helped them develop a fully functioning CRM, which is basically a knockoff of HubSpot. But. Only including things that are applicable. To them. Fully functional. I've also integrated with Supabase. So been able to successfully implement authentication. You know, the typical database. Items as well. But I think. The biggest thing that I've learned. Is they work great. Until they don't. And once you hit that sweet spot where.