---
granola_id: 0e422cd9-ec62-4aa4-a3b2-ff509f1f8b2e
title: "Stacey + InnVest Lender UI  - Transcript"
type: transcript
created: 2025-11-19T20:00:29.008Z
updated: 2025-11-19T21:02:43.550Z
attendees: []
note: "[[Granola/2025-11-19 Stacey + InnVest Lender UI.md]]"
---

# Transcript for: Stacey + InnVest Lender UI 

### Guest (2025-11-19T20:00:53.911Z)

Shirt collar. Look at you.

### You (2025-11-19T20:00:56.633Z)

Yeah, this is special meetings, I guess.

### Guest (2025-11-19T20:01:01.351Z)

Actually, I'm wearing a dress. You can't tell that from the upper part of my body. But I don't own work clothes like I used to.

### You (2025-11-19T20:01:09.593Z)

That's true. I still have a few shirts in the closet, but that's about it. So how make a lot of progress in budgets.

### Guest (2025-11-19T20:01:23.031Z)

We are. Yeah. And for me, it's been great time to just. I could never have understood the organization as well. Had I not been here this week, seeing everyone's role, what they do, you know, listening to some of the back and forth on deal conversation and stuff like that. So it's been good. And I know we have a lot to talk about, one on one, and it's not the time, but the one thing I do want to say is yes to all your things. And we can talk about it next week. So, yes, it all goes into the account. Yes, we'll take 20% out. Yes to all. Of it. And you and I can work through what that means. And the count's established. But I apologize. It wasn't. It was unintentional, but it was toned off on my part, and I realized that, so.

### You (2025-11-19T20:02:14.233Z)

Yeah, I realize you had no intention of doing anything wrong. I knew that. I appreciate that. We can work it out when you're done with your meetings.

### Guest (2025-11-19T20:02:26.711Z)

Okay? Did she text Ann or did she email again?

### You (2025-11-19T20:03:40.473Z)

No. I'll put the cottage. We've got the ring doorbell. A different brand. But ring doorbell. And. We're close enough to the road. That every car that drives by sets it off. And easy. It's no big deal. Excuse me. Only on the weekend. During weekdays it's quiet. But I was down the street where.

### Guest (2025-11-19T20:04:08.791Z)

The party house.

### You (2025-11-19T20:04:10.953Z)

No, they are, actually. They tore down the original house and they're rebuilding a larger house.

### Guest (2025-11-19T20:04:11.271Z)

No.

### You (2025-11-19T20:04:19.193Z)

And. The construction traffic. Now, remember, framing and everything. It wasn't too bad. Just like one truck would go in with the grading and everything else. Now they're on the interior. And you got the plumbers, you got the electricians. You got all these different. It seems like it's a school going back and forth, back and forth. It's like, why are they coming and going so often? It's like my form was going, and I don't want to mute the notifications. But they'll get irritating.

### Guest (2025-11-19T20:04:49.111Z)

Did you get your tires ordered yesterday?

### You (2025-11-19T20:04:52.393Z)

Yeah. She's going to get in the stand on Friday.

### Guest (2025-11-19T20:04:55.911Z)

Four new ones are just a couple of one or two, yeah.

### You (2025-11-19T20:04:59.433Z)

Yeah.

### Guest (2025-11-19T20:04:59.591Z)

Four.

### You (2025-11-19T20:05:03.113Z)

But. I am always having a good advice from my dad when they came to Kaiser when I was growing up. And you can get inexpensive tires that are just as good or better than. You don't have to buy Michelins. And if you take a look at the specs, They all have the same warranty, the same rings. I mean, everything's the same. Good years that were on sale. And so it wasn't too bad. Got it for, like, 110 each.

### Guest (2025-11-19T20:05:38.471Z)

That's good. That's very good.

### You (2025-11-19T20:05:40.553Z)

It is. But yeah, I mean, if you go from the Michelins or some of the zoning ones, you paint die 230k40. And you get nothing. In return for?

### Guest (2025-11-19T20:05:50.791Z)

Right.

### You (2025-11-19T20:05:52.233Z)

Other than the name on the sidewall. So. Yeah, it's not too bad.

### Guest (2025-11-19T20:05:58.311Z)

Still, four new tires at one time, even at a good price, is like. It's like those are those unexpected things that you're like.

### You (2025-11-19T20:06:07.193Z)

With the installation, it's going to be just over $500. So, yeah, it adds up. And she needs a bike. Job.

### Guest (2025-11-19T20:06:24.311Z)

And. There is Ms. Stacy now. Okay, Stacy again. Western alliance used to be an appraiser too. Hey, stacey. Whoops. Try that again. How's it going? Good. How are you? Good, good. Do I have camera today? Yes. Excuse all my. Christmas gifts. I've already started coming. This is awesome. Thank you. I just can't take you. I just can't thank you enough for taking an hour to talk with us. Of course. Clearly, it's really important to us. We spent a long time creating the mvp, and I'm gonna introduce to Howard. And talk a little bit about what we built, but Howard is our product manager. And it's something that coming out of real estate, right. And doing real estate deals most of my career, asset management, I never in a million years could have understood the value that a product manager brings to a digital transformation effort. And so part of this is, you know, getting you introduced to Howard, but where we have the MVP pretty much ready to go. And we want to start with the lending community first because it's a higher level underwriting. Right. As we've talked about. And so now we're at like, okay, well, what does an actual lender want in the software, right? And I have obviously put loans on hotels that I've invested in, but I've never been on the lender side like you are right now. And I've never been an appraiser either, even though I worked for CBRE and VAZ and I feel like I got exposure to that, Right? So with that, you know me really well, so I'm not going to go through that. Why don't we do some introductions between you and Howard? And Stacey. Why don't you start, if that's all right? We're both the hoteliers, and we know each other from, you know, years back. Yeah, definitely. So, yeah, I guess, Howard, Diana and I got to know each other here in Chicago when she was living in Chicago. And I moved here in 2012 to take over the Midwest region of the HBS, which is a hotel appraisal company. I had been with them for. I was with them for 16 years. I spent 16 years doing nothing but appraisal, valuation and advisory services for what? The top producing appraisal group in the United States. And then from there I went over and moved over to work in franchise and development at Wyndham. So working for a brand. Got to see that side of the business. And then I moved over to Western alliance bank about a year ago to oversee their underwriting. Team for the hotel group. So we have about a four and a half billion dollar book of hotels. Which is roughly 200 assets and 130 loans, although we just did a big portfolio of, like, 33, so we ticked up above 200 finally. Luckily, it was all one loan, so that's a little bit easier pill to swallow in terms of portfolio management of those assets. So, yeah, that's sort of my where I'm at now, and I still live in Chicago.

### You (2025-11-19T20:10:03.033Z)

Nice to meet you. And we're actually not too far apart, just like on the other side of the lake in Grand Rapids.

### Guest (2025-11-19T20:10:09.351Z)

Excellent. All right.

### You (2025-11-19T20:10:10.313Z)

Yeah, a weird Chicago lane.

### Guest (2025-11-19T20:10:12.791Z)

Our office is in the Loop, and I live in the west Loop. Part time in Avondale, the other part of the time.

### You (2025-11-19T20:10:14.713Z)

Okay? I actually was living down in Kalamazoo for quite a while. It's where my wife was born and Grace. But I was working for a company based in Oakbrook.

### Guest (2025-11-19T20:10:27.511Z)

Yeah. Yeah.

### You (2025-11-19T20:10:34.393Z)

So I was making the drive. The drive? Everything. Every Monday. Work for the week, stay at the hotel, come back for the weekend. And repeat. For close to about a year before I ended up just talking them into letting me stay off a little bit more often. So that family stunner on Chicago as well. So good area.

### Guest (2025-11-19T20:10:54.311Z)

Y. Eah, I would say. So many people do it to putting when I tell people I'm from Chicago, You know. Oh, yeah, I've got. I've got family there. I've got friends there.

### You (2025-11-19T20:11:06.393Z)

Well appreciate jumping on the car a little bit about my background. As Diane mentioned, I am leading the product development here, product management role. But I also come from a rich little state background. I've been in the real estate for 30 plus years. Primarily multifamily space. So multifamily operations, multifamily asset management, acquisitions, dispositions, renovations, et cetera. But about 2,010, plus or minus. Actually started working for real page. Helping. Out. On a project and really. Got bit by the tech. Bug. So for the last 15 years, I've actually been in the prop tech space. With Real Page and a few others.

### Guest (2025-11-19T20:11:56.551Z)

Awesome.

### You (2025-11-19T20:11:57.913Z)

Utility management, asset management. Type of tools. And then in2021, I joined a company called Rediq. And they. Developed an automated valuation model. For multifamily. And they were owned by Berkadia And Berkadia had just opened up a new. Office for. Hospitality. That's how I met Diane and she started.

### Guest (2025-11-19T20:12:26.711Z)

Jared Kelso. Stacy, Jared Kelso was the one to introduce us. Just. I'm sure you know Jared. Yeah.

### You (2025-11-19T20:12:36.633Z)

Diane she was talking about. There's nothing like rediq's model in the hospitality space, which I kind of took with a grain of salt because I think there's an AVM for all asset management or all asset classes. Right. As I looked around and researched, I can't find another tool similar to this. So myself and also our chief technology Officer. Came over from Rediq to help develop this product. Specifically for the hotel and hospitality industry.

### Guest (2025-11-19T20:13:15.031Z)

Awesome. That's great. And so we've spent the last year, or maybe a little bit less than a year, but it's what's coming up on a year working through first the proof of concept, which is Howard did it all in, no code tools. Right. Hard for the most part, if I have that correct. And now we have our chief technology officer and a group of software engineers based in India. And our chief technology officer is Indian as well, which really helps with that. But they have developed. I mean, Howard, and they collaborate every single moment of every single day. On the mvp. And Howard, maybe because we're all from the Midwest, and I'm Midwest girl, too, and my dad worked for Ford my entire life. Howard has this great analogy about, like, the car and the body and the engine. So, Howard, I do think it's a really good way to frame up kind of where we stand. With our mvp. Do you mind sharing that analogy? Because it just so hits home for me.

### You (2025-11-19T20:14:25.033Z)

Yeah. The POC that I put together is very functional. We can take a look at how that works. But the first, learn that we're building for production for client use. Is not yet completely put together. Right. So the analogy is, we've got an engine over here. The engine works great. We've got a body over here. We need to get the engine in the body so everybody can kind of see how it looks. So if we are kind of getting in that, I have an opportunity to take a look at it. I might be jumping back and forth a little bit, but we are actually probably within two weeks of having it ready to. Go. For some select bean testers. And full demos.

### Guest (2025-11-19T20:15:15.831Z)

Okay?

### You (2025-11-19T20:15:15.833Z)

Of the actual tool.

### Guest (2025-11-19T20:15:17.991Z)

And so just to add on a little bit. So the idea is it's just the beginning of the idea, but pipeline management, right. So being able to pull in and track all your loans and who's underwriting what loans and all of that married with an avm. And the idea, the problem we're trying to solve is how manually intensive it is to get data into our models. It kills us. It's exhausting. It's ridiculous that we've been doing it this way. For 30, 40 years, and we've been using AI to extract data from P and Ls. We have, what would you say, our success rate. And right now we're really just working on annual data just to get our sea legs right. We are starting to work on monthly data as well. But Howard, what would you say our success rate is on the data extraction accuracy at this point?

### You (2025-11-19T20:16:15.513Z)

In other words, the mid-90s.

### Guest (2025-11-19T20:16:17.991Z)

Right. And it's good.

### You (2025-11-19T20:16:21.033Z)

All the time. Yeah.

### Guest (2025-11-19T20:16:21.591Z)

It's improving every time. And so that's the part where Howard says it's like the engine and the body. It's like, okay, the engine is the pipeline management piece. We know that actually isn't all that hard to build in software, Right? And then the body of it is the avm. And really, I mean, I know you need to know hotels to do a good valuation, but the mathematics of it, right, of, you know, a por PA r percentage, like the mathematics, is perfect for AI use, right? And being built in technology and in software. So where we've been spending our time over the past four to six months is really getting that data extraction. Doing the wraps on the data extraction. Right. And we are having very good success through use of Claude and other tools. Pulling the data. And, I mean, being in the 90% range, it feels like we're moving in such a good direction that it's, it's all coming together. And what we would love to. Again, part of this calls how, you know, Howard and I are talking a couple weeks ago, and I said, Howard, how Can I help you? What can I do for you? And he's like, can we get, like, a time set with an actual lender? So that as the product manager, I can understand what's important to a lender. Right. Because how I underwrite as an equity person might be very or might be very different than how an appraiser underwrites or how our lender underwrites at a higher level. And some of the metrics and how I think about it as an equity person, and I've been on equity my whole career. I'm always thinking about upside, upside, upside. Upside. Debt is a little bit more like downside, downside, downside, downside, risk. We're all really smart hotel investors, but at the end of the day, we want to build a product that's perfect, like, really what lenders want, and that is reaching out to you to get your feedback on the product and what you would want in a UI and things like that. Ok, so with that, Howard, do you want to, like, try to maybe start to walk through, like, the, you know, the MVP and maybe flip back to the poc? Howard said the best person to demo. It's much better than I am to demo.

### You (2025-11-19T20:18:57.193Z)

Can definitely do that. I'll go ahead. And share my screen. Shut down a few things to make sure that I don't freeze up in the middle of it like I sometimes do. Let me get this closed down. Ok? Yeah, let me go ahead and. Go ahead. Bring this up. So you should be seeing the industry. Dash. Board. So, as I mentioned in the comment,

### Guest (2025-11-19T20:19:42.631Z)

I'm not seeing anything yet, so.

### You (2025-11-19T20:19:44.153Z)

Ok, that's good. Let's give it a second. I see.

### Guest (2025-11-19T20:19:49.031Z)

There it is.

### You (2025-11-19T20:19:50.233Z)

Ok?

### Guest (2025-11-19T20:19:50.311Z)

Got it.

### You (2025-11-19T20:19:50.633Z)

Good.

### Guest (2025-11-19T20:19:51.111Z)

Yep. Now we can see it.

### You (2025-11-19T20:19:52.473Z)

Ok? Good. All right. So I mentioned I'll be toggling back and forth between the two. This version that I have shown here, this is the actual version of the model that. Will be going to Margaret with and testing. This tab, if you can see it. This is the proof of concept that I put together.

### Guest (2025-11-19T20:20:15.911Z)

Ok?

### You (2025-11-19T20:20:16.393Z)

So let's go ahead and jump back. Here. So, as Diane mentioned, it really kind of starts with the pipeline. Which is essentially a list of all the deals that. A user would have. So down here, I've only got one. Report here or one deal. But creating a dll, very simple. You just simply fill in the basic information here, right? Property name, address and city. You can. Go to the property details, select the property type, input the number of units, et cetera. We are including versioning. On here? So it could be as an investor. I might have multiple JV partners that I typically work with. Each one, they have different investment requirements. So I can create a model for jd partner 1. And L1 for JV, partner two, et cetera. And then just tackle back and forth there. Now on the lender side. I'm not sure if that makes a difference. I don't know.

### Guest (2025-11-19T20:21:27.991Z)

Yeah. We very rarely tie our records. To anything except for the entity name in which the hotel is held.

### You (2025-11-19T20:21:39.033Z)

Okay?

### Guest (2025-11-19T20:21:39.351Z)

So it's actually a process that we're trying to go through right now. Relinking thousands of records to. In our CRM to the parent companies. And so that's the issue we're dealing with right now. So I would say. They're Most lenders probably use a couple of fields in that where I have my parent company, but then I have all these different LLCs. For the 40 deals that we have and have had with like MCR, for example, we had 150 unique identifiers on it.

### You (2025-11-19T20:22:04.633Z)

Yeah. Actually. So that's interesting that you bring that up because we are also trying to. Develop a common id. One of the reasons is obviously we're going to be accumulating a lot of data. And we would like to be able to create market data. Which we also have in the game over, because as an. Underwriting tool for investors. They're looking forward, so they are projecting their cap rates. And all these different things. So not only will we have historical data, But forward looking. We are calling it the Census ID right now, but basically our initial goal is to use the star. Report, costar. It's my understanding that a lot of other organizations do kind of use that right now. But I was also starting to see some information that there are other organizations who are attempting to do the same. So we plan on working with them to see if we can come up with that one unique identifier so that we know the Hyatt Downtown Dallas. Might have been a Hilton five years ago. Before that was. Yeah. So we can track.

### Guest (2025-11-19T20:23:36.791Z)

Yeah. I mean, I think star is the only thing that's widely accepted. We don't. You could say star identifier to anyone on my team, and they would have no idea what it is.

### You (2025-11-19T20:23:39.753Z)

At. That level.

### Guest (2025-11-19T20:23:47.591Z)

It's just we don't use it at the bank. Our systems, which I understand most lenders use, Moody's, are all through Moody's credit lens.

### You (2025-11-19T20:23:58.313Z)

Ok?

### Guest (2025-11-19T20:23:58.551Z)

And every single assignment gets a brand new number.

### You (2025-11-19T20:24:03.033Z)

Ay.

### Guest (2025-11-19T20:24:03.751Z)

And tying additional fields to that is impossible. It's insane, so.

### You (2025-11-19T20:24:09.433Z)

That. Makes sense.

### Guest (2025-11-19T20:24:12.951Z)

We will have, like, we just did a portfolio of sinestas, and we had several in more than one market. And we're like, well, which one is the witch? How do we tell them apart? And, like, there couldn't. Like, the records are gonna get confused the entire time they're in our system and on our books. Because they that's just how the system is set up and it is a flaw. I've talked to my other lender friends and that's one of their biggest complaints as well. But then it also gets all of those numbers get tied into our CRM. Which then can have identifiers included on them. But, you know, from a general industry, I think STR is the way to go. You would just have to build something specific for lenders.

### You (2025-11-19T20:24:56.633Z)

Yeah. Okay?

### Guest (2025-11-19T20:24:56.951Z)

And so again, more specific example that would be like, let's take that. So Nesta portfolio, right? So mcr, they may have capitalized some of those deals one off with different JV partners and things like that. Right. And you need to be able to keep track of for the sinesta in Plano. It is this joint venture partnership which includes these entities, right? Those are the borrowers and so forth. And so that's a big process for you, because right now you're going back and trying to link all or roughly 200 or so of your hotels to who the legal entities are, the asset in real estate. Are secondary to us, to be completely honest. The Borrower is our primary. Data point.

### You (2025-11-19T20:25:47.753Z)

So. That's a good point.

### Guest (2025-11-19T20:25:48.151Z)

And it's been my. It's been hugely frustrating for me. As a real estate person to, like, have to get my head around that and be like, well, what do you mean? There's not a place for me to put the brand in? Like, how do I know what you know? Sac San Antonio is. Oh, well, you can go through these seven different steps to look up what the brand is or try to go in the folder. And. Banks are not tech.

### You (2025-11-19T20:26:15.753Z)

Yeah.

### Guest (2025-11-19T20:26:16.631Z)

Advanced or tech friendly. It's all these legacy systems that are just, you know, slow moving ships, so turning ships. And so I guess that's just sort of one of the caveats to lenders. And so, Stacey, if we could then somehow figure out a way to create fields that captured who the borrowing entities are. Right. That are part of the loan, but then also be able to have it so that you could see that it's a Hyatt in Dallas and like the Hotel Y type of things that would be a benefit to you as a lender is that I would say yes. And, and then, I mean, let's continue. I don't want to get too in the weeds on this, but, like, because I know where we only have half our left, because I do have a hard stop at three. But, but I think those are, that's just something to understand about lenders, is that we there nothing is going to undo some of the systems we already have in place. Like we cannot change our credit lens system, all of our financial. Warehousing is done in this system. And it feeds into every other program we have. And so anytime new technology has been introduced, like, the number one question is, well, does it work with credit lens? Okay?

### You (2025-11-19T20:27:42.553Z)

All right. That's good information. And something that might also clarify is what I'm showing you here today. Is a very. Let's just call it a rough. Preliminary version. That's not really beds exclusively told investors you're exclusively Howard lenders. We are going to be making some fine tuning and one of those is what I'm showing you right now, the middle to set it up. I do have a mobile that's already created for lenders, and it does include, like, the loan id, the buyer, the borrower information, all of these things. Sounds to me like that you were mentioning that would be required for the lender. So if there's time, I can pull them up real quick and just show you those fields and you can tell me if the labels are correct. If not, then we can even cover that at. The later time. We're going to end up here with the deal set up. You can have the property details in here. We've got a map here. On the other page there. We'll be able to upload the documents, upload financial statements as well as. Basically any document that's related to the deal. Back on the other moment I was on. I have the screen up where you had the drag and drop or the documents. That was for the financial statements. So that as I'm setting this up, I can drag my historical financial statements that I get from the seller. From the broker. Maybe if it's a lender standpoint, you'll get it from the bottom.

### Guest (2025-11-19T20:29:30.151Z)

Continue forward the email into a record.

### You (2025-11-19T20:29:34.873Z)

We've talked about that would not be difficult to do. Is that how you typically get the most of you to.

### Guest (2025-11-19T20:29:42.631Z)

Ing hand. That's ridiculous and impossible.

### You (2025-11-19T20:29:43.673Z)

Okay?

### Guest (2025-11-19T20:29:45.831Z)

So like we are not the example. But actually the best because we want to bring a solution to groups that have such pain points. So if for your team, but that was. Go ahead. That was something we had at hbs, where we. Any. Any email that, like, was to or from someone would automatically end up in our system. And all of those attachments as well. And now it wasn't going anywhere. It was just a record of it. So, you know, if I couldn't find it, it would end up attached to this person's ID number through their email address. You know, and then if we wanted it on a project record, we would have to include, you know, the seven letter or seven numbers in the subject line to forward it, and so. It made it very easy to find things and reference things. Versus now where it's in period and folders, and those were accessible to everyone. Now, I assume that a lot of these software is like, you take it a step further and then, okay, I'm forwarding this to a specific address with the. Id number. And it ends up, you know, being able to include, rename those financials and, you know, organize the financials using the AI technology. And then it put that in the dashboard or whatever it is.

### You (2025-11-19T20:31:13.913Z)

Yeah. That technology has been around a while.

### Guest (2025-11-19T20:31:18.311Z)

Yeah.

### You (2025-11-19T20:31:20.153Z)

Something we could do. In the earnest versions, there's a lot that would need to be set up, but, yeah, that is absolutely something that could be done. And this is the moment where I was mentioning about before. If you're adding a deal, this is where you can just drag and drop, or you can do the file chooser. You can move on to anything to go and find the file you're looking for. And then when you upload it here. I did need to bring that up, but I clicked. On the habit. There we go. So you can upload the document here. So when I go back. In review documents section here. This link is not activated yet. In this version, you'll see the documents, but where this really comes into play is then once you have the document uploaded, it goes through the extraction. There's some additional setup that needs to be done. So under the valuation section. Now, this is investor oriented, not lender oriented. But if I am an investor, this is where I would go and input my acquisition assumptions. So discount rate or cap rate would make a specification during the deal setup. What version or how do you want to value this deal? Do you want to use the discount rate or do you want to use cap rate? Percentage. For estimating the acquisition costs. Capex, et cetera, and that it will go through and help populate some of this information. Financing, same thing. This is where the buyer or the investor in filling the information here. Equity. Right. So we can go ahead and input. What is the investor equity? Maybe it's 20% or 30%. And then you can list all of your partners here. How many do you have? And you can keep adding partners as you need and then, of course, your asset assumptions. So I'm kind of guilty this very quickly because this is not like I said, something that you would use. But this is where we really get down into the meat of the information. Now, I only have one financial statement uploaded, and it was historical for 2023, but when you upload that information. You're going to have a section at the top that's always visible. You're going to. Up here, you get at the very top. If you can see my cursor, we're going to have these different cards up here. For lenders. We're going to have the debt service coverage ratio. What is the yield percentage? What is the current balance of the long. These are. These cards will be very specific to the lenders and the scripters. We'll also have these key metrics on here, so we'll have some subject property occupancy, ADR and RevPAR calculations, as well as the gross operating profit and ebitda. We've also got a tab specific to occupancy. So you can see as I'm working, that will stay fixed at the top of the screen. So as I go down here and I change any inputs, those will be reflected up here as well. Same thing for the revenue and expense. Or I can just shrink it because I want more space down here to work. But what we can do here is, as Diane mentioned earlier, right now we're uploading full year. But for the lender model, we'll be having each month here. So every month you can upload these statements. And then you'll be able to.

### Guest (2025-11-19T20:34:52.711Z)

Great. We're. We typically work quarterly so that we get T12s, but. But some. Some borrowers do give us monthly data, and that's good to have. We don't. I mean, we would certainly input it if we had it, but they're only tested quarterly.

### You (2025-11-19T20:35:07.833Z)

Okay?

### Guest (2025-11-19T20:35:08.391Z)

And Stacy, like, there could be a future. I. And I really do believe this, like, like, very immediately or like, let's take mcr. Where I don't know how MCR is getting you that data, but MCR could essentially, we could have an API with mcr, and so we pull the data in instantaneously and then share it with you. Instantaneously. Right. Like it it. APIs are not a hard thing anymore. It's not like it was two or three years ago. And our industry stand for. It's Howard. What does stand for? An automatic. What does it stand for?

### You (2025-11-19T20:35:46.233Z)

Automated. I forgot what the period. It's automated data interface. But the P stands for something else. But basically, that's when. You set up a connection. On your end. And. For example, the buyer could set up. A connection there. So all we have to do is push a button. And. It will automatically take the data from them and uploaded into you. So there's no email in the file, there's no dragging and dropping.

### Guest (2025-11-19T20:36:11.671Z)

Right.

### You (2025-11-19T20:36:19.033Z)

It's just a connection that basically goes from the.

### Guest (2025-11-19T20:36:21.991Z)

Yeah, that would. That would be great. I mean, I was able to do that even with my, you know, mortgage lender. Right now, they're emailing everything to us.

### You (2025-11-19T20:36:22.473Z)

Source.

### Guest (2025-11-19T20:36:32.471Z)

So, like, there's so many steps involving them getting something to us. So. But part of that are the banking requirements. As far as I'm aware, like, a lot of it is regulatory of, like, it has to come from them. You know the safety of the upload? You know, so that's why we haven't gone to uploading on some of these large transactions. And making sure that they're secure data sites and things like that. Like. So it's. Although I do think some of them come over via box and, you know. Those types of systems. But, like, that's, you know. And we had someone talk to us the other day. Actually another former HBser that he's working on this essentially SharePoint type program where the customer uses it. It automatically renames and sorts and reads everything. And, you know, and then it uploads into our system. And again, like, our biggest issue with a lot of that is the regulatory how data is received and from who and data validity, because, you know, at that point, if the data gets to us, You know, the. The customer can't attest that they gave us the correct data because they didn't actually give us the data, it went through. One thought about this as as a former acquisition person who kind of had some of these same challenges with data attestation, right at the at the closing table, where you had to attach true and complete copies of the financial statements in a ridiculous like addendums that were thousands and thousands of pages. Okay, so let's take MCR for a minute. I. I don't know if they use profits to order, if they use O tellier, but the way they're getting you that information and maybe MCR isn't the best company to use, but I'll use them anyway. Let's say they're using profit sort, they are going to profit soared and they are downloading that information into Excel and then they are attaching it to an email, right, or some sort of FTP site or something like that, and then they are sending you that information. So again, with this API and like tomorrow we could set up an API integration. With profit stored. Right. And MCR would say profit soared. Send the information over. But like a. Like an acquisition. And what. And what I've seen kind of a lot happen on the operation side is that the underlying physical get attached to the digital that, like, you're not just getting a digital, you're getting. A digital transfer that loads your model, but supported by an actual physical P and L. If this makes sense, that it's like a underlying and then the borrower submits you that to their knowledge this is a true and correct financial statement, just like you have to do in an acquisition. Does that make sense? Like in an acquisition, you have to say, okay, yes, buyer. You know, these are, to my knowledge, true complete financial statements. And that same language could probably exist in a contractual format if this is making sense, like on data transfer, where perhaps the bank could get comfortable because the owner is attaching to that, to their knowledge, this is true, and complete. The physical record is attached like it's there. Like the P and L is there, attached to the digital record for any kind of legal tracking, any kind of, you know, purposes. But yet you have a better. A better tool to ingest all that data. So I just. It's just an idea that I want. To. Yeah. No, it's something that you know that there's going to be people that are not me. Have to opine on. Yeah. The details on like what we can and can't do because we. Since we've talked last day and we did launch a. An AI. Tool for a couple of our groups. Not hotel. Hotel was not one of the test groups. There were three test groups. That are getting. Basically an underwriting. AI supported underwriting tool to test for the next, I think 60 days. 60 or 90 days. And I haven't heard much about it since. That was three weeks ago when they gave it the thumbs up. So I don't even know if it's launched yet, but I can check. But ultimately that. So there's capabilities for this type of technology to come in. It was met with a ton of resistance, like, okay, a ton. And because it essentially, they were willing to do a test for us that was basically free. It, you know, for three months. They? That's how we were able to sort of, okay, let's do it. We might be able to do something like that too. And I was actually trying to just brainstorm because I know Western Alliance. I mean. I mean, banks are banks, right? And it's really a difficult environment. Like, we're starting. Out. So if you guys wanted to explore the idea of a white label to, you know, something where for initially, we're working with you just to make sure we didn't get that, you know, we're working through the technology piece, and somehow I'm just trying to think of an idea. Right. That we're. Working underneath your team with the understanding that maybe we always support you under a white label perspective because you're one of the first groups that test this with us, eventually we'll go off. Right? I mean, it's our plan to try to solve this problem for the industry so that it's right. But if it would help your cause at all, I think we would be open. We would be totally open to the idea of, like, the white label or trying to work under your security. I'm trying to get creative about it, right? The other thing the bank's investigating is just using Copilot because we already pay for that. But building a tool within that is also, like, I can't even get it to make address labels for me, so I'm not. Like. You know, it's not. It's certainly not close to being a useful. Technology yet. And so it's. So I think there's. The hotel team is. Is certainly open to it, and we're a really good test group as well. But. But I think, like, from what I see so far, The lender is gonna want things that are a lot different than your acquisitions owner. Yes. Like these are two different users. And so building a tool that is trying to do it all for both users. Is difficult and you're have challenges because we're so much different in our lenses. So much different, which is what I mean. That was actually one of the things I've learned this year is how different it is. I was very naive to that. And so having. Right. So that's why we're. Chat. We are hoping to reach out to because we want to build. I mean, we think maybe adapt to the right place to start because that's a higher level underwriting. But we're not lenders. Right. And now you've been a lender for a year and you're, and you are understanding. Like with the lens needs to look like. And I'll share with you like, we aren't doing a lot of the underwriting. We are relying on the appraisers. Right. And I wondered, Howard, to hear that borrowers directly. Yeah, because not. Not every bank is like that. Though I know Wells Fargo has a group that does their own underwriting and independent underwriting. I'd also probably have something to do with this type of hotel we do and type of owner we work with and. The debt size that we work with, Howard, we, we typically are 15 to 50 million, you know, very. I don't want to say safe, but like only good Berends only good owners, it takes a lot of the risk out of the equation. And so we get comfortable with the pro forma we get from MCR or Rockbridge. Because, number one, they have a third party appraisal or feasibility study. Number two, they've got a track record of really owning and operating hotels effectively, and. You know, doing a really good job with it, choosing the right partners, and they have the financial wherewithal to be able to fix things if things go wrong. And, like, that's honestly the primary. Primary requirement for us lending on a hotel. We will end up very risky asset as long as the borrower can. Sort of, you know, from the takeaway of what we're looking for, we care a lot less about. Where our pain points are. The data management data entry. And then. But once we get there, our systems are set up for us to see a lot of these things already. We can see the debt yield instantly. We can see that the covenants are breached. We can see all these things because covenants are, you know, DSCR and debt yield are different for every asset that for us to be able to look at it. And so we don't really need a software to do that because we have three places where we can look that up instantly. In our existing software that are not going away. No matter what new technology we bring in. So ultimately, our biggest benefit here is, number one, it being able to do a backup underwrite for us, you know, team in investigating and looking at deals. The originations team. And then essentially doing the portfolio management and being able to spit out, hey, this is not good. Covenant preached. Covenant breached. Covenant preached. How are we. What's the remedy? What's the remedy? What's the remedy? Here are your options. Like, that's the. That's what would be most useful to us on the lending side.

### You (2025-11-19T20:47:10.393Z)

Okay? All right. Yeah, that does make sense. So that was brought up in the previous call as well. So this is what I was referring to. If you can see your screen now. Do you see input set up? Okay, this is the setup modal that I was referring to earlier that is specific to the lender. Has a lot of the same information. Some of it's a little bit different layout. But here in the lower details page, this is where I mentioned we would have whatever the specific loan number or viral or ID whatever it could be in here. They're contact information. We gather the originators servicer here's where you can enter your brand franchise even the management company the asset manager. Some of these may or may not be useful. And then over here, on the loan terms, where we would have the loan amount, we would have all this information, whether it's fixed or floating things that you mentioned that you already have in the system. But down here we call this. Indicate whether it's a recourse, whether it allows prepayment, yield, maintenance. Et cetera. And then. So once you get that set up, upload the documents. Essentially, you would then be back here. At the InnVestAI. Dashboard. This is probably what you had mentioned before. If you want to see a roll up in a portfolio. I'm glad you mentioned this, because this is something that we will have in version one. Is we've got a lot of different columns that the user can add. And again, we have to get a few things in here specific for the lenders, but then those could be like the debt service coverage and everything else. And you could literally go through here. And create groups of properties. So if you need a portfolio view, whether it be by borrower or even by city location, I mean, you can group these individual want to here. And of course, you could filter based on whatever the information you have in here. And that you will be able to get that portfolio. View. Now. The question I have. Is. Of course, you've got all of these different metrics, but when you're looking at a portfolio, Do you want to see all the individual assets? Within that portfolio and then have a visual media. It'll show the GUT service coverage ratio in green if it's in compliance. What if it's not a compliance? Would you ever see an average amount of those?

### Guest (2025-11-19T20:49:58.071Z)

So when you are so our. Our systems already do that.

### You (2025-11-19T20:50:01.593Z)

Ok? Ay.

### Guest (2025-11-19T20:50:02.071Z)

Like we. I can look up real time. What, the entire HFF book? Is doing on a. On a portfolio basis. When I say portfolio, like there's. There's two meanings. It's our entire portfolio, but we don't really use that term in banking. We. It's our book of business. But we do have portfolios within the book that are anywhere from two to 35 hotels. And in those hotels, we're not looking at those on an individual basis. We look at each credit, whether it's one hotel or 35. As a as two metrics. Debt service coverage ratio and debt yield. And so those are what they're being judged on. In terms of the health of the portfolio.

### You (2025-11-19T20:50:47.673Z)

So it would be a roll up. It wouldn't be like you said, you don't look at them individually. Okay, that's very.

### Guest (2025-11-19T20:50:53.991Z)

Not, and not if there's more than one asset per credit. But the 140 credits that we have, we do look at those as a roll up. Like that's we're looking at our total book is running this debt yield and this debt service coverage ratio. And we want the ability to segment it as needed. And right now we're doing all that in Excel.

### You (2025-11-19T20:51:08.393Z)

Okay?

### Guest (2025-11-19T20:51:14.871Z)

By hand.

### You (2025-11-19T20:51:15.913Z)

And how would you. How would you segment.

### Guest (2025-11-19T20:51:16.471Z)

Because.

### You (2025-11-19T20:51:17.753Z)

It.

### Guest (2025-11-19T20:51:18.951Z)

There's like, we segment in a couple different ways. Full service versus select service. Stabilize versus non stabilized, urban versus non urban. So we, so ultimately, like we have built a model.

### You (2025-11-19T20:51:31.113Z)

Right.

### Guest (2025-11-19T20:51:35.671Z)

Within hff. That is a critical spreadsheet. That we're hoping to get into Live Dashboard. We have a data team working on that internally. That would become our database Central, or HFF database. Nothing is tied to any of that data, though. And it's. There's no click through like I can't get from. So again, it's just one more system that the bank is building that's going to be separate from our other five systems.

### You (2025-11-19T20:52:06.153Z)

Yeah. Yeah.

### Guest (2025-11-19T20:52:06.391Z)

And, you know, that's where this would sit. And so when I look at this and I look at my team having to input data for New Hook for another hotel, input it for a fifth time. They're going to lose their minds.

### You (2025-11-19T20:52:18.793Z)

Y.

### Guest (2025-11-19T20:52:19.191Z)

And, and so there has to be some way for it to either link into our existing stuff or take one data point and be able to pull that stuff from an already existing system, whether that's our CRM or credit lens or, you know, It's in tableau as well. But I. I don't know. You said you're. You're so. You're massive pain points are data management and data entry. Right? Right. The bank has. It calculates the dsdr. You guys have. No. In fact, you have multiple systems that are doing that, but. It doesn't quite get you to the. Maybe some of the hotel metrics you need. Not metrics like dscr, but metrics like full service Lex service, correct brand, urban suburban. That's. We're keeping that all separate on this other master worksheet.

### You (2025-11-19T20:52:58.953Z)

Eah.

### Guest (2025-11-19T20:53:15.591Z)

But is is credit learn something that's internally built by your bank, or is it software that's beauties? It's Moody's. Moody's. So if we could create an integration with Moody's. Right. I'm just trying to think out loud for a second where we're able to. Push information into Moody's about hotels. That would be something that would. There's nowhere to put it. Spend one of our huge issues. Like, I can't even. I can't even input financials without spreading financials. I cannot input a typical hotel Usai. Income statement or profit loss statement. Into Moody's, okay? There's not enough. I don't have enough additional revenue sources. Got it right. Yeah, it's built for commercial and so we have made it, made it fit. We've put the round, you know, peg into the square hole in Moody's, but we've all sorts of issues. Like, we just did a training for our credit lens team that does a lot of the input. For us. And, you know, but they. None of them knew what, like, we had to, like, literally do what. What is a hotel. You know, like, that's not what this system is built for. And, and we have. We're, we're one of the, like, biggest users of Moody's Credit Lens. Like, they're a lot, but there's a lot of banks. They are notoriously hard to work with, and everyone hates it. It is the. It is the, you know. It's the yardy of debt, right? We cannot. There's no getting around it. It's. It's the necessary people that we all are stuck with, and until someone comes along and disrupts it. And then. But then we have this. It also warehouses all of our loan documents and everything like that. It's built specifically for banking, even, but it's. Built by Moody's and care about it. So, like, especially, they don't care about hotels, right? I mean, that's right. Right. Over and over. But this product is like a rounding error for them, even though they have all these important users. They don't have invested in the technology. It's like using a DOS system. Like I haven't used a system like this since I was in freaking eighth grade. So, you know, like, it's 20 year old technology. I was in eighth grade more than 20 years ago, but like, it's. It is has now been updated. They haven't invested in it. They're not gonna invest in it. Even if we're. Even if we were all like, we're not. We're done. We're going somewhere else. They'd be like, no, you're not. You know what I mean. We're still go. You know, and that's. This is exactly how you already use, too, right? Yeah. Okay. So I think that's. And I just. We. I've got about four minutes left, but. But that's really the. So you know the data management. Data entry. Data. Data management data entry. It's like you guys are stuck using credit lines. It is sufficient for what the bank needs. As far as looking at the DCFS and the debt yields and all of that, it's more your pain points and we're screening deals by hand. Like, we're going in and we're spending a lot of hours and a lot of times looking at deals. When. Okay. Could I. Here's an opportunity. Transaction in Dallas. Los Calinas. They're doing a renovation. We're doing an Excel spreadsheet by hand, calling people in the market, trying to do some of that early screen. A lot of that's falling on me, which is fine, because I've got the easy phone calls I can make, and looking at star data, which is going away. And, you know, I. We won't have star reports to look at. Going forward. And so. Like, that's the other pain. Point is, okay, how are we. How do we become more effective in screening a deal? And how will this look for us? And that's the thing, that there is software that's out there that people are using. I have people actively using that software. That is literally, they get all the due diligence. Send it. Send it out, comes back overnight. And, you know, they have a thumbs up, thumbs down. Should we pursue this deal? And if we do, here's our metrics. Here's what you could reasonably expect in hospitality as well. Right? They have a group that's doing that for you in hospitality, okay? Not for us. No, but peers in the industry. Oh, for peers in the industry, but not Western groups. Got it. Beauty groups. Lenders aren't using it yet, though. We are slow. Okay?

### You (2025-11-19T20:58:16.233Z)

So if it takes overnight, it sounds a little like they're probably.

### Guest (2025-11-19T20:58:16.311Z)

Got it. That's interesting.

### You (2025-11-19T20:58:22.953Z)

Outsourcing from probably somebody out there is copying and pasting.

### Guest (2025-11-19T20:58:23.111Z)

Some of it is. Some of it's being done in India, some of it's. But some of it is done through AI. I've heard both. So. So this has been super helpful for us. You took a full hour of your time. How might we follow? I mean, we have a lot of takeaways to think about. But if we were to come and say, you know, maybe as we advance the MVP over the next few months, if we were come to say, Stacy, the bank is doing pilots and other asset classes. Would you consider doing a pilot with us where we try to solve your specific problems? Right. And maybe it's, again, white label, but we're. We're benefiting because we're learning a lot. Perhaps you're benefiting because, you know, we're trying. To solve this for you in hotels. Is that. Do you think that would be an option at this point, or is it something that. So I. I can't imagine we'd do two simultaneously, although I can ask, like, all. Brian Danmeyer, who's handling the other one, sits here in Chicago, and so I can. Go to him with the ass like, hey, while you're doing that, can we do this? And. But again, like, because there was so much pushback on it,

### You (2025-11-19T20:58:36.313Z)

Yes. Sorry.

### Guest (2025-11-19T20:59:38.631Z)

Yeah. You know, letting two AIs into our system. Oh, my God, the computers are gonna steal it, you know, so that's like, the biggest concern is, like, how do we keep them from. How do we keep someone from taking all our data from, you know, using all our data and selling all our data? And that is really the. One of the big concerns that everyone has is where does this information go? And, you know, how do we protect it? And so I'm not sure if we can get to. I'm happy to ask, though, because I think piloting it within my team would be a very easy. But I think there's, I mean, I don't know, like, we would have to do something almost custom built and because, you know, I think for more today, like it's a. I think we just have much different needs. Than I think where. Where you're at today. And. And so I'm. I'm happy to, you know, continue to pursue that, for sure. And then just please, for just my benefit. And I hear hard to get to AI pilots going at the same time, but am I missing the AI pilot that's being run is on the commercials like other commercial. It's like three. It's three. It's not all real estate, it's three business. Lines because we do way more than commercial real estate. I think it's like aerospace and technology. It's like, I don't think a real estate line is part of it. It's like C and I. It's three smaller groups. Okay. That. That helps me understand. So it's not like there's another hospitality, but. But there's an AI pilot that's going on that has caused everyone so much headache because of the, like, the pushback that the bank may just feel like, let's just get through. Like, we can't. Take on another pilot program at this point because, okay, that's helpful. But if there's any team that could get it done, it's hotel, because we are high performing and we ourselves contained. And all. And again. And remember, like, this is our mvp, right? So it's been described to me in my life. It's like, this is your scooter. It's not design. You know, we're not trying to design yet the Chevy or the Cadillac because we really want real customer feedback on this. Right. So what we showed you was the scooter version. And we're, as we work through the, the version rollouts, it will look very different and could, I mean, and I know we're saying potentially customize it for you. Right. But it would help us in the development of all our products. Right. Just. To be able to start working with a customer. And if we're custom designing it for them, we're doing that. But we're also learning a lot through the way about the process and what's needed out there. So. And I'm sorry to cut you guys off, but I have to jump.

### You (2025-11-19T21:02:35.273Z)

I really need to go, so thank you very much for all your help.

### Guest (2025-11-19T21:02:37.351Z)

Okay. Thank you. All right. I appreciate it. Have a good day. Bye. Bye. Bye.

### You (2025-11-19T21:02:38.953Z)

Thanks.

