# InnVestAI product roadmap and API strategy planning

**Date:** 2025-08-12 00:00:00 UTC
**Meeting ID:** d8370b24-ebdb-436b-ba88-2a7bb0146647
**Synced:** 2026-02-05 14:46:48

---

# Transcript for: InnVestAI product roadmap and API strategy planning

### Guest (2025-08-12T21:28:58.488Z)

I don't think that's a great place to be. Coming up. This divergence. The miners out.

### You (2025-08-12T21:29:02.646Z)

Good afternoon.

### Guest (2025-08-12T21:29:04.568Z)

Of here. Could be about to change.

### You (2025-08-12T21:29:07.126Z)

How's everything going?

### Guest (2025-08-12T21:29:09.048Z)

And I thought market intense.

### You (2025-08-12T21:29:11.686Z)

There. There's your weekend. It was good.

### Guest (2025-08-12T21:29:16.728Z)

It was good.

### You (2025-08-12T21:29:16.886Z)

I was over the weekend. I was busy.

### Guest (2025-08-12T21:29:17.288Z)

I was away for the weekends. I was busy.

### You (2025-08-12T21:29:19.126Z)

But good.

### Guest (2025-08-12T21:29:19.528Z)

But good.

### You (2025-08-12T21:29:20.086Z)

How about yours?

### Guest (2025-08-12T21:29:20.488Z)

How about yours?

### You (2025-08-12T21:29:22.086Z)

Same. Dealing with the heat. Where were you?

### Guest (2025-08-12T21:29:27.208Z)

Where were you?

### You (2025-08-12T21:29:28.646Z)

Just stayed at home. Michigan. But got a little heat. Oh. How is it there?

### Guest (2025-08-12T21:29:34.488Z)

How is it there?

### You (2025-08-12T21:29:36.486Z)

Actually, today it's not bad. We've got some storms going through right now. But we were up very close to triple digits. Over the weekend. But very humid. We always got the humidity here. From the great lakes, anyway. Nathan doors. Yeah.

### Guest (2025-08-12T21:29:57.048Z)

Indoors.

### You (2025-08-12T21:30:02.006Z)

So congratulations. On being able to. Host that session at the conference coming up. Yeah. Moderator.

### Guest (2025-08-12T21:30:12.088Z)

Yeah.

### You (2025-08-12T21:30:13.206Z)

That was somewhat unexpected.

### Guest (2025-08-12T21:30:13.848Z)

That was somewhat unexpected.

### You (2025-08-12T21:30:14.406Z)

But it would be a good time.

### Guest (2025-08-12T21:30:14.808Z)

But it would be a good time to try to weave in some InnVestAI sound bites.

### You (2025-08-12T21:30:15.526Z)

To try to weave in some InnVestAI. Definitely. It's amazing.

### Guest (2025-08-12T21:30:22.488Z)

It's amazing how just AI is just saturating and taking over the entire world.

### You (2025-08-12T21:30:22.806Z)

How saturated and taking over the entire route. I got three different emails.

### Guest (2025-08-12T21:30:30.648Z)

I got three different emails.

### You (2025-08-12T21:30:31.206Z)

Today from excel.

### Guest (2025-08-12T21:30:31.608Z)

Today from Excel, inviting me to demo their new AI compatible spreadsheets.

### You (2025-08-12T21:30:33.686Z)

Demo there. Compatible.

### Guest (2025-08-12T21:30:39.288Z)

I got an email, I got a text, and I got it on my computer directly.

### You (2025-08-12T21:30:40.006Z)

I got a text and I got it on my computer. Directly.

### Guest (2025-08-12T21:30:44.808Z)

Pretty amazing. How they. I'm sorry.

### You (2025-08-12T21:30:47.206Z)

They just want to make sure they get through.

### Guest (2025-08-12T21:30:49.608Z)

Yeah. Well, they definitely did.

### You (2025-08-12T21:30:50.406Z)

Three times.

### Guest (2025-08-12T21:30:50.808Z)

Three times. One day.

### You (2025-08-12T21:30:52.966Z)

Did you have this?

### Guest (2025-08-12T21:30:52.968Z)

Did you test it? Did you demo it? No, of course not.

### You (2025-08-12T21:30:56.646Z)

But I was just impressed that we're pushing so hard.

### Guest (2025-08-12T21:30:56.968Z)

But I was just impressed that they were pushing so hard.

### You (2025-08-12T21:31:18.006Z)

I'll try to do that tomorrow.

### Guest (2025-08-12T21:31:18.648Z)

I'll try to do that tomorrow.

### You (2025-08-12T21:31:19.766Z)

Yeah. So waiting for Vinode. There he is.

### Guest (2025-08-12T21:31:25.128Z)

Hello? Hello?

### You (2025-08-12T21:31:28.486Z)

It does look like we've got a DNS issue on the email servers. So I sent you the error messages that I got off of Godaddy.

### Guest (2025-08-12T21:31:42.808Z)

Yeah. Okay?

### You (2025-08-12T21:31:45.766Z)

Hello. Everybody.

### Guest (2025-08-12T21:31:46.408Z)

Hello, everybody. Hello.

### You (2025-08-12T21:31:49.686Z)

What does it mean if you're reading?

### Guest (2025-08-12T21:31:49.848Z)

What does a DNS issue mean? So that's your domain name service? Which is registered with code id, which is pointing to our aws. Now, that's why I was saying if we could just probably get some more information from Microsoft wizard email provider, what exactly they need.

### You (2025-08-12T21:31:57.366Z)

The court. Microsoft whether forward exactly with configuration.

### Guest (2025-08-12T21:32:13.128Z)

We'll configure it accordingly.

### You (2025-08-12T21:32:16.886Z)

Yeah, it looks like a couple of SPF records that are incorrect.

### Guest (2025-08-12T21:32:18.408Z)

I mean, I can make this.

### You (2025-08-12T21:32:25.286Z)

Sales.

### Guest (2025-08-12T21:32:25.368Z)

Code id says right.

### You (2025-08-12T21:32:25.846Z)

Right.

### Guest (2025-08-12T21:32:28.648Z)

Yeah. I don't know whether heading just the ad. We'll fix the issue. But I'll have that added for sure.

### You (2025-08-12T21:32:37.766Z)

I didn't know we migrated to aws. I thought Godaddy was still the email host, but that's fine. But that means. Yeah. You're the only one that's got access to it. Right now. I guess for the DNS settings. Okay?

### Guest (2025-08-12T21:32:54.728Z)

Yeah. I think our email provider is Microsoft. Right.

### You (2025-08-12T21:33:02.006Z)

It is. Actually, technically, it's Godaddy. And then.

### Guest (2025-08-12T21:33:05.848Z)

Now coded just as a domain name.

### You (2025-08-12T21:33:08.166Z)

Well, they did have the email. All too, but they partner with Amazon. So yes. It was an Office365 email, but the DNS servers and everything were hosted by GoDaddy.

### Guest (2025-08-12T21:33:19.368Z)

35. Yeah. DNS was hosted by Code ID because our domain was registered and coded.

### You (2025-08-12T21:33:31.366Z)

Was in starting contact. Yeah. I think when. Diane, is that correct? When you got the domain, you got the email and everything all in the same place.

### Guest (2025-08-12T21:33:41.928Z)

I did. Yep. Email was from Godad itself. Okay? I thought it was from Microsoft. Token. So wasn't it a combo? Right?

### You (2025-08-12T21:33:52.246Z)

Combo, right? That's what you're saying, right?

### Guest (2025-08-12T21:33:53.768Z)

Howard. That's what you're saying. Right.

### You (2025-08-12T21:33:54.486Z)

It was some combo package.

### Guest (2025-08-12T21:33:54.968Z)

It was some combo package. That you got the domain, and then it included a certain number of email addresses.

### You (2025-08-12T21:33:56.486Z)

That you got the domain. And then it included a certain number of email addresses. Yeah. So we actually got seven email. In our package. So there's two left. I was also going to set up Raj and shivam with their InnVestAI but I can't do that. Until the DNS is resolved. All right.

### Guest (2025-08-12T21:34:31.208Z)

Well, I was hoping probably Max Outcode. Resolve that, and then there would be one side on my plate. But yeah, okay. I'll look into it.

### You (2025-08-12T21:34:38.646Z)

Okay? You didn't have anything to do tonight. Right. All right, where should we start today?

### Guest (2025-08-12T21:34:50.328Z)

All right, where should we start today? Maybe Vinod with you. Because your team has been busy. Right.

### You (2025-08-12T21:34:56.806Z)

Doing cell migration.

### Guest (2025-08-12T21:34:57.048Z)

Doing some migration. Team has been busy for sure. Stage environment is right now. The login is broken there. Some redirection that I need to do from Google and Microsoft.

### You (2025-08-12T21:35:08.646Z)

That I need to do from Google in Microsoft. And so on.

### Guest (2025-08-12T21:35:14.968Z)

Console. Say. I'll look into that.

### You (2025-08-12T21:35:17.926Z)

But there will be still a problem.

### Guest (2025-08-12T21:35:18.488Z)

But dev environment is still up. I'll probably do you want to see a quick demo or I should give you yeah.

### You (2025-08-12T21:35:25.446Z)

Or I should give you.

### Guest (2025-08-12T21:35:28.008Z)

That's great. Ok? Vinod while you pull that up, I just wanted to ask. Right now. I know there's a staging, production and development environments, but all this is. We don't have any customers, so there's not any huge risk of assistant failure or something. But what is the mechanism for ensuring that?

### You (2025-08-12T21:35:38.566Z)

I know there's a stage of production and development. Customers. There's not any huge risk and failure or something. But what is the mechanism? For ensuring that that sort of thing that's called.

### Guest (2025-08-12T21:35:56.968Z)

These sorts of things are caught before they happen.

### You (2025-08-12T21:36:00.566Z)

Ideally right.

### Guest (2025-08-12T21:36:01.128Z)

Ideally. Right. Or call it quickly. Yeah. You don't have any monitoring in place, right?

### You (2025-08-12T21:36:07.126Z)

Now because we are not on production on that server. It doesn't make sense.

### Guest (2025-08-12T21:36:07.448Z)

Now. Because we are not on production or dev server. It doesn't make sense. But for our website particularly, right?

### You (2025-08-12T21:36:12.086Z)

For our website.

### Guest (2025-08-12T21:36:14.648Z)

I have the monitoring setup right now.

### You (2025-08-12T21:36:15.446Z)

Right now. So if anything goes down or through the alert,

### Guest (2025-08-12T21:36:16.248Z)

So if anything, the website goes down or the form throws an error. I'll get the alert on my mobile directly. Through message service. But as far as the production application goes, there can be various monitoring.

### You (2025-08-12T21:36:29.286Z)

As far as the production application goals temporarily. Tools that we can use.

### Guest (2025-08-12T21:36:36.568Z)

Tools that we can use. Definitely one that I just said. I get the message on my mobile.

### You (2025-08-12T21:36:39.846Z)

The message.

### Guest (2025-08-12T21:36:42.728Z)

The other one is different. Dashboard.

### You (2025-08-12T21:36:45.766Z)

Which provides something called palm oil to make sure that the platform is solid.

### Guest (2025-08-12T21:36:46.248Z)

Which our infrastructure provides and they call Grafana. There's something called cloudwatch. And then to make sure that the platform is solid. We. We have different testing. That we do. So code testing, then there's end to end testing. Then there are various steps that we take when we build the code. Yeah. So, yeah, basically we have to have the monitoring in place and that can be different. Monitoring whether your environment is down, whether the performance is low.

### You (2025-08-12T21:37:13.766Z)

We have to have the monitoring monitor environment is.

### Guest (2025-08-12T21:37:22.648Z)

Whether some code is broken, whether you are having your low test coverage.

### You (2025-08-12T21:37:25.046Z)

Having. So we have to make sure that it plays consult ing requirements.

### Guest (2025-08-12T21:37:29.368Z)

So we have to make sure that is in place once we go on production. So that is not really required on Dev and Run, but for the website right now. We do have the monitoring in place.

### You (2025-08-12T21:37:39.126Z)

Yeah.

### Guest (2025-08-12T21:37:39.688Z)

Yeah. Okay? And I know that the thing that are most likely to break when some kind of new development or change is being made and pushed out.

### You (2025-08-12T21:37:41.126Z)

The thing that are most likely to break when some kind of new development is being pushed out.

### Guest (2025-08-12T21:37:50.968Z)

Just make sure to lean on Mark and me and Diane, as well as your internal team to make sure that all that is anything.

### You (2025-08-12T21:37:53.206Z)

As long as your internal teacher and Troy tested.

### Guest (2025-08-12T21:37:57.528Z)

Fully tested. Before we roll it out. Obviously it's not as big an issue now.

### You (2025-08-12T21:38:00.966Z)

To building off the correctly configured holy product stuff on top of it.

### Guest (2025-08-12T21:38:01.208Z)

But as we start to building blocky. Correctly configured before we put up stuff on top of it.

### You (2025-08-12T21:38:07.046Z)

Definitely. So we have to have the minor testing.

### Guest (2025-08-12T21:38:09.208Z)

Definitely. So we have to have the manual testing.

### You (2025-08-12T21:38:09.286Z)

We have to have automation testing.

### Guest (2025-08-12T21:38:11.288Z)

We have to have lot of automation testing.

### You (2025-08-12T21:38:11.606Z)

How many automated.

### Guest (2025-08-12T21:38:13.848Z)

All the testing would be automated.

### You (2025-08-12T21:38:16.566Z)

Place for sure.

### Guest (2025-08-12T21:38:17.048Z)

So that would be in place for sure.

### You (2025-08-12T21:38:19.926Z)

As we develop continuous pictures on the state environment.

### Guest (2025-08-12T21:38:20.728Z)

And as far as we develop, I'll continue rolling out features on the staging environment. Go there, play. And that's the thing we were trying to do yesterday by releasing on this stage environment.

### You (2025-08-12T21:38:28.246Z)

We are trying to yesterday by anything.

### Guest (2025-08-12T21:38:37.608Z)

Yeah. Okay? Yeah. So for what do you call confidence level purpose for us as well as for the users.

### You (2025-08-12T21:38:45.926Z)

For us. As a whole thing. Things.

### Guest (2025-08-12T21:38:51.608Z)

We'll have the monitoring in place. For different things. From the rolling feature, rolling our perspective. We'll have the core testing in place. As well as we'll do the manual testing. We all can kind of do the manual testing.

### You (2025-08-12T21:39:07.366Z)

From that end. Okay? Cool. I just wanted to touch on that.

### Guest (2025-08-12T21:39:10.888Z)

From our end, okay? Cool. I just wanted to touch on that. Sure. All right. What's your going through the dinner? Yeah. So I'm coming from the dev environment.

### You (2025-08-12T21:39:20.246Z)

To be one of the just working content.

### Guest (2025-08-12T21:39:24.168Z)

And one of the vital parts or just working on the dev environment One and a half hour bag. So I'm not sure what is the state of the environment, but I hope it is good. And I'm able to Demo might be broken, so. Okay, so I clicked on the Google login button. So I'll land here on the Gmail sign up sign in.

### You (2025-08-12T21:39:44.806Z)

Which I'm using right now.

### Guest (2025-08-12T21:39:48.648Z)

Which I'm using right now. So I just added this one. I don't know whether we'll like it or not, but if. Suppose there's user who is logging in our platform.

### You (2025-08-12T21:39:52.886Z)

But something. Excited and don't think Bible kind of thing.

### Guest (2025-08-12T21:40:00.968Z)

First time. There are no deals added.

### You (2025-08-12T21:40:02.406Z)

Other production or some kind of.

### Guest (2025-08-12T21:40:03.448Z)

There's no deal. Pipeline or anything. I thought probably we should show some kind of.

### You (2025-08-12T21:40:06.486Z)

Demo or poor that use of employment. Skip it.

### Guest (2025-08-12T21:40:10.168Z)

Demo or tour of the application. And user can always skip it. If I skip it? I basically land here, which is basically a blank page.

### You (2025-08-12T21:40:18.246Z)

Anything.

### Guest (2025-08-12T21:40:20.328Z)

Because I have not created anything.

### You (2025-08-12T21:40:20.726Z)

Coming to at first time. Basically, speed is quick for.

### Guest (2025-08-12T21:40:23.288Z)

But if a user is coming to our platform first time. They'll basically see this quick tour here, and there's a way to skip it.

### You (2025-08-12T21:40:31.686Z)

People that always.

### Guest (2025-08-12T21:40:34.968Z)

And if we don't like it? We can always remove it.

### You (2025-08-12T21:40:40.246Z)

And always discrete fasting where you can create something.

### Guest (2025-08-12T21:40:40.328Z)

Just like I thought we could have. And there's always this great your first deal button where user can create the deal. Because the logging into our platform first time. Like I don't have anything right now and that's why I see it. But if I have deal, then I won't see that.

### You (2025-08-12T21:40:50.806Z)

I don't have any right now, and that's why I see it. But if I have dreams, I will see that. Let's go there.

### Guest (2025-08-12T21:40:58.968Z)

Thing.

### You (2025-08-12T21:41:00.646Z)

Quick intro here. I click on that.

### Guest (2025-08-12T21:41:02.328Z)

So let's go there. Quick intro here. I click on that. There is this read New deal. I kind of broke it a little because it was becoming a big. And then there was a scroller coming by, probably breaking it into different screen.

### You (2025-08-12T21:41:21.606Z)

Two screens.

### Guest (2025-08-12T21:41:22.488Z)

Would help. And anyway, it was going in the two screens and how we can kind of improve it from here.

### You (2025-08-12T21:41:24.966Z)

From here. This is first draft. So.

### Guest (2025-08-12T21:41:30.648Z)

This is first draft. So say. Edit.

### You (2025-08-12T21:41:44.486Z)

I think you're doing, but not there. And competitive.

### Guest (2025-08-12T21:41:46.568Z)

Optional. So as soon as I fill it, I see a green button. Up there. And then obviously there's an X button here. And then it says what we're going to do next. And this basically address. I don't have that Google in here, but I do have a drop down for the state.

### You (2025-08-12T21:42:01.766Z)

Who the land was popping up here.

### Guest (2025-08-12T21:42:03.928Z)

I'll have the Google address popping up here. That's the improvement we have to do. Next is document so I can upload the documents here.

### You (2025-08-12T21:42:10.406Z)

So I can upload the documents here. Please don't drop them here.

### Guest (2025-08-12T21:42:20.008Z)

These two documents. I can drop them here. So the list of documents will come here. It also shows you the size here. It'll allow you to upload PDF as well as the images.

### You (2025-08-12T21:42:34.726Z)

Before. I happen to see it on someone else's website.

### Guest (2025-08-12T21:42:36.888Z)

On the documents. And I've never raised this before, I just happen to see it on someone else's website. Is there the option in our roadmap to also include that you can email.

### You (2025-08-12T21:42:40.806Z)

To also include that you can email. An attachment. Into.

### Guest (2025-08-12T21:42:48.888Z)

An attachment into InnVestAI. Does that make sense?

### You (2025-08-12T21:42:50.086Z)

If you have it attached to an email, you can just send it right to an sai.

### Guest (2025-08-12T21:42:52.168Z)

I think it's dealt that lets you if you have it. Attached to an email, you can just send it right to InnVestAI.

### You (2025-08-12T21:42:58.486Z)

Document in the email, and they'll be able to hire those documents.

### Guest (2025-08-12T21:43:01.368Z)

So they have all the documents in their email and they'll be able to add those documents via an email to their deal, something like that.

### You (2025-08-12T21:43:07.926Z)

That's what you're saying. Yeah.

### Guest (2025-08-12T21:43:12.248Z)

That's what you are saying. Yeah. We can definitely do that, but right now,

### You (2025-08-12T21:43:18.566Z)

When I was going through somebody on a platform.

### Guest (2025-08-12T21:43:20.168Z)

Poc, but I caught my eye when I was going through some of the other platforms.

### You (2025-08-12T21:43:22.806Z)

I'll add it onto the trello for.

### Guest (2025-08-12T21:43:26.888Z)

So I'll add it onto the Trello board. And the parking lot. Yeah.

### You (2025-08-12T21:43:30.566Z)

Making sure that there's some clear indication.

### Guest (2025-08-12T21:43:31.368Z)

That's definitely a good feature to have. The hardest part about that is making sure that there's some clear indication in the email of what a document is and where it goes.

### You (2025-08-12T21:43:35.766Z)

A document is where it goes, right? And we have to have some kind of email has to correctly.

### Guest (2025-08-12T21:43:41.688Z)

Right. Like document has to correspond to a deal or a property. And we'd have to have some kind of. You have to have that the person sending the email has to correctly abide by the formats. That's a challenge, as we've had with doing email.

### You (2025-08-12T21:43:47.286Z)

Abide by the format. That's a challenge we have. So what is the business case?

### Guest (2025-08-12T21:44:02.088Z)

Cool. Yeah. We can upload the documents there. We create a deal. Let's see.

### You (2025-08-12T21:44:06.566Z)

Diane and drew. Can I ask real quick? What's the business case? For emailing documents.

### Guest (2025-08-12T21:44:11.448Z)

Okay?

### You (2025-08-12T21:44:13.606Z)

That's really kind of old school. I got the son. And it was old school.

### Guest (2025-08-12T21:44:21.448Z)

Oh, is it? I didn't even know that. I got the sense that it was. And if it's old school, then please correct me.

### You (2025-08-12T21:44:26.886Z)

Go ahead. I was going to say, emailing documents takes more effort than dragging and dropping or just uploading them directly. I'm just struggling to see why we would want to do something.

### Guest (2025-08-12T21:44:29.048Z)

Yeah, I got this. Go ahead.

### You (2025-08-12T21:44:40.406Z)

This is a case where I would suggest that we don't do anything yet. Wait and see if anybody asks it.

### Guest (2025-08-12T21:44:49.368Z)

Okay?

### You (2025-08-12T21:44:51.526Z)

I think that's a good idea.

### Guest (2025-08-12T21:44:54.728Z)

That's good. I think that's a good idea.

### You (2025-08-12T21:44:55.526Z)

Single page has everybody.

### Guest (2025-08-12T21:44:57.368Z)

Because again, on our side,

### You (2025-08-12T21:44:58.646Z)

Email, everything. But it's a nightmare.

### Guest (2025-08-12T21:45:00.088Z)

Single pane has everybody email everything. And I used to have everybody email everything.

### You (2025-08-12T21:45:02.566Z)

And having them, you can send them an email and say, click this button.

### Guest (2025-08-12T21:45:04.088Z)

But it's a nightmare. And having them just. You can send them an email.

### You (2025-08-12T21:45:07.206Z)

And it'll take you to a portal. And you drop from that, it's almost the same thing.

### Guest (2025-08-12T21:45:10.408Z)

And say, click this button.

### You (2025-08-12T21:45:11.206Z)

Okay?

### Guest (2025-08-12T21:45:11.768Z)

And I think you to a portal. And you drop the file. And it's almost the same thing. Okay?

### You (2025-08-12T21:45:16.246Z)

Cool.

### Guest (2025-08-12T21:45:20.968Z)

Cool.

### You (2025-08-12T21:45:22.086Z)

Documents are upload.

### Guest (2025-08-12T21:45:22.808Z)

So that deal got created here. In rdl pipeline documents are uploaded.

### You (2025-08-12T21:45:25.526Z)

This was one active thing in total, I don't think service. We have the excel inspection service running right now.

### Guest (2025-08-12T21:45:29.928Z)

This shows one activity. Total deal. But yeah. I don't think the extraction service. We have the excel extraction service running right now.

### You (2025-08-12T21:45:34.726Z)

But I think it's not. Currently working. And then we also have two models.

### Guest (2025-08-12T21:45:39.368Z)

But I think it's not.

### You (2025-08-12T21:45:40.166Z)

Now instead of another one is wave transformer just to have all back options.

### Guest (2025-08-12T21:45:41.848Z)

Correctly working. And then we also have two models. Now, instead of one, one is called Layout lm, another one is Table Transformer. Just to have a fallback option.

### You (2025-08-12T21:45:49.046Z)

But we are kind of still playing and mind building them. However, there also self hosted when they are not giving.

### Guest (2025-08-12T21:45:53.448Z)

But we are kind of still training and fine tuning them. However, they're also self hosted but they are not giving a great result right now.

### You (2025-08-12T21:45:59.606Z)

As we train your father.

### Guest (2025-08-12T21:46:03.048Z)

But I think as we train them further,

### You (2025-08-12T21:46:03.526Z)

It's the documentary. Improve ment of time. We spend a lot of time.

### Guest (2025-08-12T21:46:07.928Z)

It's going to eventually improve. Taking a little bit of time. We spend a lot of time on the training and extraction. I think we do need to spend some more, but, yeah.

### You (2025-08-12T21:46:12.566Z)

I think we don't need to spend some more. But yeah. Your deal is going to be this one. I think I showed you last time. As well. You can always show all the columns.

### Guest (2025-08-12T21:46:21.368Z)

Your deal is created here. This one I think I'll showed you last time as well.

### You (2025-08-12T21:46:23.526Z)

You can have more details here once you click on this.

### Guest (2025-08-12T21:46:25.768Z)

You can always show all the columns. You can have more details here. Once you click on either this View Details button or on the Deal, you learn to the Deal Detail page.

### You (2025-08-12T21:46:32.006Z)

To create the entry page again. Since the extraction service is not working, some of the CRM.

### Guest (2025-08-12T21:46:39.288Z)

Again. Since our extraction service is not working, some of the fields here are not visible.

### You (2025-08-12T21:46:40.246Z)

And how. I'm not sure if it is. We still have time to improve.

### Guest (2025-08-12T21:46:44.968Z)

And Howard. I'm not sure if it is.

### You (2025-08-12T21:46:46.246Z)

It's been for sure.

### Guest (2025-08-12T21:46:48.568Z)

I mean, we still have to improve this page for sure.

### You (2025-08-12T21:46:51.126Z)

And then from here.

### Guest (2025-08-12T21:46:53.768Z)

So that. And then from here.

### You (2025-08-12T21:46:54.246Z)

Opening for my paint. It's just dropped to is still working on it.

### Guest (2025-08-12T21:46:56.488Z)

You can go open a page. Again. It's just a first draft. We are still working on it.

### You (2025-08-12T21:47:00.566Z)

I'm trying to power again. Discuss this together.

### Guest (2025-08-12T21:47:04.888Z)

I'm trying to have it again. We'll discuss this together if there's any modification. You think.

### You (2025-08-12T21:47:05.126Z)

With this. Anymore. Do you think? It's done. What I'm thinking, probably this be is more space because there's going to be a lot better than this.

### Guest (2025-08-12T21:47:12.088Z)

It's done. We'll do that. But this is what I'm thinking. Probably this page needs more space because there's going to be a lot of data in this.

### You (2025-08-12T21:47:18.406Z)

Some kind of implies and completely new windows so that.

### Guest (2025-08-12T21:47:23.608Z)

Some kind of opening this in completely new window so that user can work easily.

### You (2025-08-12T21:47:24.886Z)

Is. Here. These are all pulled out.

### Guest (2025-08-12T21:47:29.928Z)

Again.

### You (2025-08-12T21:47:31.286Z)

And these kind of.

### Guest (2025-08-12T21:47:31.608Z)

Tabs here. So yeah. These are more to left and these kind of.

### You (2025-08-12T21:47:41.446Z)

Toggles go one at a time.

### Guest (2025-08-12T21:47:42.008Z)

Just not make the list long enough. They toggle so only one at a time opens.

### You (2025-08-12T21:47:43.286Z)

Opens. Are what to do there.

### Guest (2025-08-12T21:47:48.968Z)

But a lot to a lot of work to do there. And back to Dashboard, we basically take us back to the deal. View page.

### You (2025-08-12T21:47:50.406Z)

Basically take us back. To the tew page. And of course, you can add it into it.

### Guest (2025-08-12T21:47:59.768Z)

And of course, you can add it and delete.

### You (2025-08-12T21:48:00.486Z)

That's where we are. The major work that we are doing is on.

### Guest (2025-08-12T21:48:03.528Z)

So, yeah, basically, that's where we are. The major work that we are doing is on.

### You (2025-08-12T21:48:11.286Z)

The threat, and hopefully that should be as well as seeing the data right now.

### Guest (2025-08-12T21:48:13.528Z)

Training, our models and the data extraction. And hopefully that should be up very soon. As soon as that's done, we'll see the data all around the application.

### You (2025-08-12T21:48:20.006Z)

It's kind of showing if I intend data. Okay?

### Guest (2025-08-12T21:48:24.168Z)

Right now. It's kind of showing you the limited data.

### You (2025-08-12T21:48:25.286Z)

How is the third engineer working for you?

### Guest (2025-08-12T21:48:27.448Z)

Okay? How is the third engineer working for you? Vinod? Yeah.

### You (2025-08-12T21:48:31.606Z)

Is coming up to this brand. As well.

### Guest (2025-08-12T21:48:35.208Z)

I think he's coming up to this bid as well.

### You (2025-08-12T21:48:37.126Z)

What kind of that sink. And then something we do in terms of. Okay.

### Guest (2025-08-12T21:48:40.248Z)

But yeah. Other two are kind of that synced in, and they're really doing great job.

### You (2025-08-12T21:48:45.126Z)

What you call onto right now.

### Guest (2025-08-12T21:48:47.768Z)

Okay?

### You (2025-08-12T21:48:47.846Z)

I'm going to make that I will. Come on. It's staging environment as well.

### Guest (2025-08-12T21:48:48.968Z)

So yeah. Whatever you saw on Dev right now.

### You (2025-08-12T21:48:50.966Z)

So you can organize it.

### Guest (2025-08-12T21:48:52.328Z)

I'm going to make that available on staging environment as well. So you can log in anytime and play around. But again, it's not up for the feedback.

### You (2025-08-12T21:49:02.806Z)

Starting in terms of completely done and probably think I can provide you backward right now.

### Guest (2025-08-12T21:49:03.048Z)

Yet because I know there's a lot of work to be done. Once certain features are completely done, then probably you guys can provide your feedback.

### You (2025-08-12T21:49:11.206Z)

Separate things.

### Guest (2025-08-12T21:49:11.688Z)

Right now. It's just that it would have a look at one of the separate environment.

### You (2025-08-12T21:49:14.006Z)

Okay? Cool.

### Guest (2025-08-12T21:49:18.888Z)

Okay?

### You (2025-08-12T21:49:19.286Z)

That looks great. And by the way Vinod, I did see your address bar and I am actually logged into Dev. It was pretty easy.

### Guest (2025-08-12T21:49:24.008Z)

Okay? That looks great. Yeah.

### You (2025-08-12T21:49:30.726Z)

No authentication, but yeah. No, that looks good. Yeah.

### Guest (2025-08-12T21:49:39.768Z)

That also needs some work. But for now it is good.

### You (2025-08-12T21:49:42.566Z)

When you're ready. To show us that dashboard that you're building to build the checks in.

### Guest (2025-08-12T21:49:45.608Z)

The node at some point in the future, when you're ready, can we add on to the call to show us that dashboard that you're building to build the checks in? I mean, it may be too way too early at this point, but when you get to the point where you feel like it's actually up and functioning and working. Do you think you could show us how that works?

### You (2025-08-12T21:49:51.606Z)

Way too early. At this point, but when you get to the point where you feel like it's actually up and functioning and working, do you think you could show us how that works? So we all kind of have a sense of it.

### Guest (2025-08-12T21:50:04.408Z)

So we all kind of have a sense of it.

### You (2025-08-12T21:50:08.086Z)

When we were talking about how, during the question, how do you make sure that we're checking that things are working, that you're monitoring?

### Guest (2025-08-12T21:50:10.248Z)

Not sure what you mean. When we were talking about how you will Drew, raise the question. How do you make sure that we're checking that things are working like that? You're monitoring, right? If there's any errors.

### You (2025-08-12T21:50:22.166Z)

I heard that there's some sort of dashboard that you will be using to that is ready.

### Guest (2025-08-12T21:50:26.248Z)

And I think I heard that there's some sort of dashboard that you will be using.

### You (2025-08-12T21:50:29.606Z)

Can you demo that? What that looks like?

### Guest (2025-08-12T21:50:32.008Z)

And so when that is ready, can you demo that for us?

### You (2025-08-12T21:50:35.366Z)

I'll show you all if you want to control project or something.

### Guest (2025-08-12T21:50:35.928Z)

Or show us what that looks like. Definitely. Okay? I'll show you all monitoring tool.

### You (2025-08-12T21:50:42.486Z)

Okay?

### Guest (2025-08-12T21:50:42.808Z)

Probably send you some messages on your mobile directly.

### You (2025-08-12T21:50:42.886Z)

Thank you. Okay? And then. Howard, are you still waiting for. Because you're actually getting ahead of us. To the engineers now.

### Guest (2025-08-12T21:50:47.448Z)

Okay? Thank you. Okay? And then. Howard, are you still waiting for. Because you're actually getting ahead of the engineers now, right?

### You (2025-08-12T21:50:52.886Z)

Right. With the product piece of it. And writing it all out with the definitions are.

### Guest (2025-08-12T21:50:57.768Z)

With the product piece of it. And writing it all out with the definitions are. And you have a name for it.

### You (2025-08-12T21:51:02.806Z)

Or something like that. Prds. Yeah.

### Guest (2025-08-12T21:51:07.048Z)

Pdv or something like that.

### You (2025-08-12T21:51:07.686Z)

All of the prds are complete. For the mvp.

### Guest (2025-08-12T21:51:10.648Z)

Guaranteed.

### You (2025-08-12T21:51:11.686Z)

What we need to do. So Vinod, just. Can you confirm that Raj and Shivam have access to that folder? On the team site because I did give them access using their Gmail so that they can make sure that they stick as close to the P.O. but. The things that I'm working on right now is, yes.

### Guest (2025-08-12T21:51:37.528Z)

Update it down.

### You (2025-08-12T21:51:38.646Z)

We need the actual definitions. Because in the PoC, a lot of the stuff I did was hard coded. Those five cards on the top. I mean, nothing was actually really calculating. So I got your response. And then Drew and Mark, if you have had a chance to do it. To take a look at it. Mark. I did send a copy to you. Yeah. I'm just concerned of it. Now that we've discovered that we may be having email issues, I just want to make sure you got it.

### Guest (2025-08-12T21:52:08.968Z)

Yeah. That's on my list. I'm not going to do that tomorrow.

### You (2025-08-12T21:52:17.846Z)

That's really what I'm working on right now. From the development standpoint. I'm also then now working on the long term roadmap. I know, Diane, you and I spoke about this already. I did send an email with the screenshot. Again. If it doesn't sound familiar, let me know. But, Diane, you obviously got it because we talked about it in the call today. And again, I'm not sending that out as.

### Guest (2025-08-12T21:52:43.368Z)

Okay?

### You (2025-08-12T21:52:50.806Z)

Asking you to put it in the deck. It's just for your reference. You can use it. You can modify it. You can delete it. Whatever you want to do. Right. And this is the AI roadmap to include in the pitch deck. Just so everyone is humbling, Howard did some work on it.

### Guest (2025-08-12T21:53:05.528Z)

Right. And this is the AI roadmap to include in the pitch deck. Just so everyone is following, Howard did some work on it.

### You (2025-08-12T21:53:07.286Z)

And. And condensed it in a way that would look good. And a pitch deck.

### Guest (2025-08-12T21:53:12.328Z)

And condensed it in a way that would look good.

### You (2025-08-12T21:53:13.126Z)

It's more than just the AI.

### Guest (2025-08-12T21:53:14.888Z)

In a pitch deck.

### You (2025-08-12T21:53:15.046Z)

It's pretty much everything.

### Guest (2025-08-12T21:53:16.488Z)

So.

### You (2025-08-12T21:53:18.086Z)

For the POC MVP version one. And then the fourth group is everything beyond version one.

### Guest (2025-08-12T21:53:21.288Z)

Okay?

### You (2025-08-12T21:53:27.126Z)

Could be in there. Just take a look. I didn't put comments on the calculations.

### Guest (2025-08-12T21:53:39.528Z)

Howard real quick. Howard.

### You (2025-08-12T21:53:40.966Z)

Per decent the document.

### Guest (2025-08-12T21:53:42.008Z)

I did put comments. On the calculations. PDR that you sent. I put comments in the document.

### You (2025-08-12T21:53:47.206Z)

I will have to. Okay. I have not opened it.

### Guest (2025-08-12T21:53:52.008Z)

I will have to. I'm still. I still am. I've been swamped with some other things, but I'll get. Yeah, I'll try to get to the others this week.

### You (2025-08-12T21:53:53.206Z)

So I'll take this week. Okay? Cool.

### Guest (2025-08-12T21:54:00.088Z)

Okay?

### You (2025-08-12T21:54:00.646Z)

So yeah. We do need that. Because that's what Vinod and his team are working on right now. Obviously. So we have to just make sure we're all lined in the calculations. And then the other things, just kind of working on the user and account setup. Requirements. And then, of course, the user agreement terms of service that we called, spoke about this morning. Research on third party platforms. Like we were talking about.

### Guest (2025-08-12T21:54:36.408Z)

And you've also done a lot of great research on third party platforms.

### You (2025-08-12T21:54:38.086Z)

Juliet. And then there were a couple others that you had looked at. One for tracking capital investment to a platform.

### Guest (2025-08-12T21:54:39.368Z)

Right. Like we were talking about. Now it's escaping. It's Julius. Right. And then there were a couple others. That you had looked at. One for tracking capital investment into a platform. Right. And then another for banking, if I remember.

### You (2025-08-12T21:54:48.806Z)

Another for banking, if I remember. Yeah. The Julius is the data science.

### Guest (2025-08-12T21:54:57.288Z)

That being sent.

### You (2025-08-12T21:54:59.126Z)

And it is something that would actually or could plug right into our investment model and be what we use. The other ones that you're referring to are things that we would use to manage, InnVestAI. The Brex would be our banking. It's an option. Don't misunderstand me. I'm not saying it is our bank. Could be our banking, right?

### Guest (2025-08-12T21:55:26.488Z)

That's it.

### You (2025-08-12T21:55:29.206Z)

Yeah. They specialize in SaaS.

### Guest (2025-08-12T21:55:32.728Z)

It could be our bank thing.

### You (2025-08-12T21:55:32.966Z)

Online banking requirements.

### Guest (2025-08-12T21:55:34.008Z)

Right.

### You (2025-08-12T21:55:36.406Z)

So yeah. Those were just sent kind of informational, FYI type of things, but yeah. I am also keeping an eye out for things similar to Julius that something like that. Could take us years to build out. It's a huge program. It's been around for a while. It's not new. They've got a lot of huge industry names. That use it. And there are a few other things. So it comes down to that age old buy versus build versus partner question, right? And in this particular instance, I would say, yeah. We would definitely want to partner with them. Or be a client of theirs. At the Enterprise level.

### Guest (2025-08-12T21:56:25.448Z)

At the Enterprise level. Is what we're talking about, right? Right.

### You (2025-08-12T21:56:29.846Z)

Those two documents, the reports. You said they were wonderful.

### Guest (2025-08-12T21:56:29.848Z)

Okay? And Howard, those two documents, the report you sent that were one or some 2005, one from was from 2009 that talked about, like, errors and spreadsheets.

### You (2025-08-12T21:56:35.606Z)

It talked about like errors. Very interesting.

### Guest (2025-08-12T21:56:44.888Z)

I finally got to reading those, and they were very interesting.

### You (2025-08-12T21:56:46.566Z)

Not that I'm aware of.

### Guest (2025-08-12T21:56:48.168Z)

Is there anything more recent off that you're aware of?

### You (2025-08-12T21:56:49.926Z)

Anytime that I research that. Those are the ones that come up. So there are a lot of articles. Out there. But they reference those same studies.

### Guest (2025-08-12T21:57:09.768Z)

Got it. Ok? Yeah, I did. I just found this. An article from 2024. It says 94% of business spreadsheets of critical errors. I mean, I. I wonder. I honestly, like, what was saying 2005. I mean, I guess, yeah. This is 24. So this is a more recent, but it's referencing the same. I wonder if it's referencing the same 2005, 2009 research. Because 94 is the exact same number that was in that paper.

### You (2025-08-12T21:57:44.486Z)

That one sounds different. Yeah.

### Guest (2025-08-12T21:57:45.208Z)

It was a study that was done in Hong Kong.

### You (2025-08-12T21:57:45.606Z)

Because this.

### Guest (2025-08-12T21:57:46.568Z)

It doesn't say when, okay? So maybe. Yeah. I'll forward this around.

### You (2025-08-12T21:57:52.566Z)

Yeah.

### Guest (2025-08-12T21:57:53.128Z)

It looks like it's a more current one.

### You (2025-08-12T21:57:53.446Z)

Good ammo for the presentations.

### Guest (2025-08-12T21:57:54.968Z)

Yeah. That would be great.

### You (2025-08-12T21:57:55.446Z)

Why you need to leave.

### Guest (2025-08-12T21:57:56.488Z)

I'll send this out. Now. Yeah.

### You (2025-08-12T21:58:02.726Z)

Okay?

### Guest (2025-08-12T21:58:07.768Z)

Okay? Well, then I'll jump in next. I'm working on the operating agreement this week.

### You (2025-08-12T21:58:10.486Z)

Because I have more time. Than he does this week.

### Guest (2025-08-12T21:58:13.368Z)

I'm going to take that off Drew's plate because I have more time than he does this week.

### You (2025-08-12T21:58:14.326Z)

So I hope to have that. Kind of reviewed and recommendations on option A or B for the various provisions by end of day Friday.

### Guest (2025-08-12T21:58:18.968Z)

So I hope to have that kind of reviewed and recommendations on option A or B for the various provisions.

### You (2025-08-12T21:58:26.246Z)

Setting up a call.

### Guest (2025-08-12T21:58:26.888Z)

By end of day Friday, and I am setting up a call with my friend Stacy Neldoni. Who? You guys, that name may sound familiar to you.

### You (2025-08-12T21:58:29.046Z)

Ing guys that make me sound familiar to you? She was with you. She has three years and years.

### Guest (2025-08-12T21:58:36.328Z)

She was with hvs for years. And years.

### You (2025-08-12T21:58:38.726Z)

She's with western alliance bank.

### Guest (2025-08-12T21:58:39.448Z)

But she now. Do you know her?

### You (2025-08-12T21:58:40.566Z)

And so I just wanted to get that in front of her because they're one of the larger banks.

### Guest (2025-08-12T21:58:42.408Z)

Yeah, yeah, yeah, I know her. Yeah, she's with western alliance bank. And so I just wanted to get in front of her because they're one of the larger banks.

### You (2025-08-12T21:58:45.846Z)

In the lending business. So coordinating a call with her.

### Guest (2025-08-12T21:58:50.648Z)

In the lending business, so coordinating a call with her.

### You (2025-08-12T21:58:53.446Z)

And confirming that we still have this call with Joseph Craner on Thursday at 5:00.

### Guest (2025-08-12T21:58:58.168Z)

I am confirming that we still have this call with Jessica Kramer on Thursday at 5:00.

### You (2025-08-12T21:59:00.406Z)

And if we do, I'm just going to have a sense of this.

### Guest (2025-08-12T21:59:04.888Z)

And if we do, I'm just going forewarn you, Howard Got a sense of this?

### You (2025-08-12T21:59:05.766Z)

She's a very talker. Come from the northeastern.

### Guest (2025-08-12T21:59:10.728Z)

She's a very brisk talker.

### You (2025-08-12T21:59:11.766Z)

Ly. She's very quick, and she also does like to talk a lot about her background as well.

### Guest (2025-08-12T21:59:12.808Z)

I mean, I should have come from the Northeast originally. She just. She moves through things very quick.

### You (2025-08-12T21:59:20.406Z)

So it depends up on that.

### Guest (2025-08-12T21:59:21.048Z)

And she also does like to talk a lot about her background as well.

### You (2025-08-12T21:59:23.926Z)

She's an interesting person to talk to, but she's got a fascinating background across travel clinic across seven rooms across being early on Singapore Beach Group and then working with Infinity Tech.

### Guest (2025-08-12T21:59:24.088Z)

So I just. Just heads up on that. As she's. She's an interesting person to talk to, but she's got a fascinating background across travel Click across seven rooms. Across being her own founder at a company, early on being with Newport Beach Group and then now working with Infinity Tech.

### You (2025-08-12T21:59:42.806Z)

And the Sasha group. So that's what I.

### Guest (2025-08-12T21:59:47.448Z)

And the sashi group.

### You (2025-08-12T21:59:48.006Z)

Want to try to communicate.

### Guest (2025-08-12T21:59:49.208Z)

So that's on my plate. So what do we want to what do we want to try to communicate? To her on Thursday. We wanted to be. We blocked a full hour at her request. I hope it's more conversational than presentational. She does have that original, original idea book that I put together, so she has that from a while back. We can get into some.

### You (2025-08-12T21:59:55.606Z)

Her request. I hope it's more conversational. Than presentational. She does have that original, original idea. A book that I put together. So she has that from a while back. We can't get into some. I think what we want to do is almost walk through that original book. And just say the hospitality industry is a decade behind the broader commercial real estate industry.

### Guest (2025-08-12T22:00:18.008Z)

I think what we want to do is almost walk through that original book. And just say the hospitality industry is a decade behind the broader commercial real estate industry.

### You (2025-08-12T22:00:27.446Z)

Multifamily. We have nothing.

### Guest (2025-08-12T22:00:29.208Z)

Broader CRA industry has dealpath has these AVMs for multifamily we have nothing.

### You (2025-08-12T22:00:29.686Z)

We believe we can create who we are creating it. Right. We don't believe. What? You totally are creating it right now. Overthrew. See the mvp.

### Guest (2025-08-12T22:00:34.328Z)

We believe we can create. We are creating it. We don't believe. We literally are creating it right now.

### You (2025-08-12T22:00:39.606Z)

We think monetizable offered.

### Guest (2025-08-12T22:00:41.368Z)

We're through. Poc into mvp.

### You (2025-08-12T22:00:43.446Z)

I'll say 100 million. I know.

### Guest (2025-08-12T22:00:44.328Z)

We think it's highly monetizable.

### You (2025-08-12T22:00:46.246Z)

That's a cringe word. Cringe worthy number because it says sky high.

### Guest (2025-08-12T22:00:46.968Z)

Upward of. I'll say it. 100 million. I know, it's cringe. That's a cringe worthy number because it's so sky high.

### You (2025-08-12T22:00:52.246Z)

And then let her ask ask questions. That she wants to see. Part of the POC ket. Jump in there and show her quickly but not do a full walk through of the poc. And she's trying to manage. She is comfortable getting us in front of.

### Guest (2025-08-12T22:00:57.288Z)

And then let her ask ask questions. If she wants to see any part of the poc, we can kind of jump in there and show her quickly, but not do a full walkthrough of the poc. And she's trying to vet if she is comfortable getting us in front of.

### You (2025-08-12T22:01:14.326Z)

The sashi group. And their last name is Escape. Their last name says keeping Me Right Now.

### Guest (2025-08-12T22:01:17.928Z)

The founders of the Sashi Group. And their last name is. Their last name is escaping me right now.

### You (2025-08-12T22:01:19.366Z)

Their brothers. So that's what we're doing.

### Guest (2025-08-12T22:01:24.328Z)

They're brothers. So that's what we're doing.

### You (2025-08-12T22:01:28.566Z)

I think we're okay to use the original original product and why I say that I spent so much time pulling quotes together from Dealpath and redIQ.

### Guest (2025-08-12T22:01:30.408Z)

Do we want to use the deck that we worked on last week? I think we're okay to use the original original deck. And why I say that is I spent so much time pulling quotes together from DealPath and redIQ, like quotes of how happy people are with the product.

### You (2025-08-12T22:01:39.526Z)

Like quotes of how happy people are with the product. And so for her, at this point, I think that might resonate. And women were still working on the final for the investors.

### Guest (2025-08-12T22:01:48.008Z)

And so for her, at this point, I think that might resonate.

### You (2025-08-12T22:01:52.086Z)

And the final coachbook for clients, but I think the quotes are pretty impactful.

### Guest (2025-08-12T22:01:52.168Z)

And then we're still working on the final pitch book for the investors and the final pitch book for clients.

### You (2025-08-12T22:02:01.046Z)

And videos are nice.

### Guest (2025-08-12T22:02:01.528Z)

But I think the quotes are pretty impactful. And the videos are nice too. At the end, if we have a few minutes to watch them.

### You (2025-08-12T22:02:02.326Z)

Too. If we have to watch them. So, Diane, if I can also add a little bit and I'm sorry. Some other things that we talk about that I really stood out to me.

### Guest (2025-08-12T22:02:19.528Z)

Yeah.

### You (2025-08-12T22:02:21.286Z)

She is focusing on potential VC funding. They focus more on the early rounds. Like from Seed to Series A. And she basically said also the fact that there are five founders is an issue. With them. In that. It's too much equity, dilution. So she spent a lot. Quite a bit of time. Really kind of talking about VC funding and. I think she's an excellent resource. In getting a company up and running. I mean, she is many times. We talked about marketing and a few other things, but she always kept going back to the VC funding and the early seed rounds. And how we would need to get some angel investing so that we can get up to ARR and then we can start talking about seed funding. And so, before we get on the call, I just think everybody should be aware of some of those objections. And things that she. Mean?

### Guest (2025-08-12T22:03:35.368Z)

Oh, and again, Howard, will you just summarize?

### You (2025-08-12T22:03:36.806Z)

T.

### Guest (2025-08-12T22:03:37.368Z)

I mean, that's kind of the way it is. We're going to hear that from a lot of people. That's kind of how the process is designed.

### You (2025-08-12T22:03:45.686Z)

Around.

### Guest (2025-08-12T22:03:49.528Z)

I've been getting that same run around many, many times. Of like, well, come back when you're at a million.

### You (2025-08-12T22:03:55.366Z)

And what seems around.

### Guest (2025-08-12T22:03:57.448Z)

And, well, you need money to get to a million. And then what's it worth when you're out of money? You assume a Catholic, a multiple, which is cap rate, right?

### You (2025-08-12T22:04:01.286Z)

Multiple. Is it for the two?

### Guest (2025-08-12T22:04:08.008Z)

On. ARR. Is it 1? Is it 2? Is it 10?

### You (2025-08-12T22:04:10.886Z)

People. Right.

### Guest (2025-08-12T22:04:13.448Z)

Depends highly on what people believe your growth is going to be.

### You (2025-08-12T22:04:14.966Z)

And like I said, she's got a lot of experience. She had some really great ideas. So I'm not trying to dissuade anybody from looking at this possibility. I just wanted to make sure everybody was aware that she did bring up a couple objections. Know, the one about the founders was concerning to me. 100% true. Even if it doesn't work for her or whatever she's working on. She knows people like her network is really big.

### Guest (2025-08-12T22:04:40.008Z)

That is 100% true. And even if it doesn't work for her or whatever she's working on.

### You (2025-08-12T22:04:45.366Z)

And so in the front box.

### Guest (2025-08-12T22:04:45.768Z)

She knows a boatload of people like her network is really big.

### You (2025-08-12T22:04:47.366Z)

Regardless of if it comes to any kind of funding, real funding opportunity here.

### Guest (2025-08-12T22:04:50.968Z)

You want her in the front box? Regardless of if it comes to any kind of funding, real funding opportunity here.

### You (2025-08-12T22:04:52.726Z)

Or not. You just want her in the box. To make potential future introductions. As well.

### Guest (2025-08-12T22:04:57.688Z)

Or not. You just want her in the box. To make potential future introductions. As well.

### You (2025-08-12T22:05:05.526Z)

That's it. For me on my side.

### Guest (2025-08-12T22:05:09.448Z)

Yeah, I think that that's it.

### You (2025-08-12T22:05:10.486Z)

Okay?

### Guest (2025-08-12T22:05:10.648Z)

For me. On my side.

### You (2025-08-12T22:05:11.846Z)

We hope that's been about different entity that I wanted to try to preserve next step with that.

### Guest (2025-08-12T22:05:15.608Z)

Okay? We spoke last week about different API connections that we wanted to try to pursue. Is there a next step with that?

### You (2025-08-12T22:05:23.126Z)

Yes and no. Yes. We do want to have API connections. But we don't know who to pursue until we have users tell us who they want to connect to. Some of the bark is kind of.

### Guest (2025-08-12T22:05:40.488Z)

Well, I mean, I think we know that someone like Alark is kind of.

### You (2025-08-12T22:05:41.606Z)

An obvious one that people value.

### Guest (2025-08-12T22:05:46.568Z)

Somewhat obvious one that people value. Some of the other ones may be a little bit more questionable.

### You (2025-08-12T22:05:51.606Z)

Customer data or pulpit hit up.

### Guest (2025-08-12T22:05:52.568Z)

But. But I think that we need that. We need that initial push for data or pull for data.

### You (2025-08-12T22:05:53.686Z)

Yeah. Something like that. If you know somebody. And they're willing to share their data with us.

### Guest (2025-08-12T22:05:59.368Z)

Well.

### You (2025-08-12T22:06:01.926Z)

Whatever arrangement it's going to be. That would be great. I would certainly say we can do that. And then making those connections is not a difficult thing. The question I have is what did the business terms, what are they going to charge us for, right? And then once we get beyond that. I know Diana's mentioned procore. I mean, there's other ones out there. But because we want to make sure that there's a demand for it before we start.

### Guest (2025-08-12T22:06:31.048Z)

Yeah.

### You (2025-08-12T22:06:31.126Z)

Going through all of that.

### Guest (2025-08-12T22:06:31.288Z)

No, I mean, I think. I think.

### You (2025-08-12T22:06:35.446Z)

I think it's kind of more like a step two. Step one is no, right?

### Guest (2025-08-12T22:06:37.368Z)

Right. But procore is great, but I think it's kind of more of like a step two. Step one is, don't we just need to get a data provider to get the sort of wheels.

### You (2025-08-12T22:06:39.366Z)

To get a different provider to get the external turn in here. Do you have a few that are very good.

### Guest (2025-08-12T22:06:47.128Z)

Turning here.

### You (2025-08-12T22:06:47.526Z)

Definitely all luxury part, right? But, Drew, you have connections.

### Guest (2025-08-12T22:06:49.608Z)

Drew has a few that are very good as well. Like lark? Yes.

### You (2025-08-12T22:06:51.846Z)

Well you have on the charity.

### Guest (2025-08-12T22:06:52.408Z)

Definitely. We all agree, Lark.

### You (2025-08-12T22:06:52.966Z)

Right. You already have an API with charity.

### Guest (2025-08-12T22:06:53.928Z)

Right. But, Drew, you have connections. Well, you have one with Cherry, right?

### You (2025-08-12T22:06:55.766Z)

But then you have medallion, right?

### Guest (2025-08-12T22:06:58.488Z)

You already have an API with cherry. But then you have medallion, right?

### You (2025-08-12T22:07:04.486Z)

Along with a platform.

### Guest (2025-08-12T22:07:05.528Z)

I've talked with Brevana Medallia.

### You (2025-08-12T22:07:06.726Z)

But it does have a good step back to what's the need and who's it for, what's the business goes.

### Guest (2025-08-12T22:07:09.368Z)

A lot of other platforms. But it does kind of come back to the what's the need? And who's it for? And what are the. What's the business case? I think, as far as getting data into our system, right?

### You (2025-08-12T22:07:22.406Z)

To concept data. But that will just get on the reports.

### Guest (2025-08-12T22:07:24.488Z)

Lark is and market data is one. STR comp set data is another, but that one is we'll just get from the STR reports.

### You (2025-08-12T22:07:30.166Z)

Is that?

### Guest (2025-08-12T22:07:32.408Z)

And then the third piece is the financial data. Which is going to come from profits or M3, the, etc. But in lieu of having access to that, to those systems and to that data directly,

### You (2025-08-12T22:07:40.966Z)

Access to those systems. To that data.

### Guest (2025-08-12T22:07:49.288Z)

What about chad? I'm sorry. Matt chav a.

### You (2025-08-12T22:07:51.926Z)

Curves and stuff like that.

### Guest (2025-08-12T22:07:54.008Z)

Yeah. No.

### You (2025-08-12T22:07:54.326Z)

That's also like ice.

### Guest (2025-08-12T22:07:54.808Z)

Chatham on the chauffeur curves and stuff like that. That's a good one. We could also. I mean, there's also, like, I use Oanda or currency conversions.

### You (2025-08-12T22:08:05.526Z)

Hours.

### Guest (2025-08-12T22:08:06.408Z)

But those all have a cost to them. To plug into the like. Awanda is like $3,000 a year.

### You (2025-08-12T22:08:08.326Z)

Subscription. API.

### Guest (2025-08-12T22:08:11.928Z)

For the data and enterprise subscription, and then it's, you know, some additional amount for the API. So I think that's something we would, you know, win. The time is right, we would do it.

### You (2025-08-12T22:08:12.326Z)

Because I think that's something. We do it. To think about setting up 14.

### Guest (2025-08-12T22:08:20.808Z)

I think the other way to think about setting up or being able to talk more about APIs is what systems are going to want to tap into the data that we're creating, which is the underwriting pro forma data.

### You (2025-08-12T22:08:24.006Z)

Are going to want to tap into. Tap into the data that we're creating. Which is the right format. Data, right?

### Guest (2025-08-12T22:08:34.568Z)

Right. If like and that Silicon Toby is would be an example like we would want to pull.

### You (2025-08-12T22:08:40.646Z)

We want to hold that data. How do they impact that LBIR system?

### Guest (2025-08-12T22:08:41.048Z)

If Sunstone or whoever's doing making pro formas in InnVestAI. We would want to pull that data out and make sure that that pro forma is in our is in Hotel Bis for comparison. Purposes. If an operator, like if David's in, is doing their own. Doing pro formas in InnVestAI. They use profit. Sorry. So they're going to want to make sure that their data is pushed into profit. Zord. Right.

### You (2025-08-12T22:08:56.326Z)

That they have resort. Ed another way we can take them out.

### Guest (2025-08-12T22:09:03.368Z)

So that's. I think, another way we can think about being able to talk about and utilize APIs is to make sure that we can get our data into other systems.

### You (2025-08-12T22:09:04.726Z)

Is to get to where we can get out there into other systems.

### Guest (2025-08-12T22:09:12.968Z)

Very easily. And I don't know what kind of system is broke. We'll use brokers.

### You (2025-08-12T22:09:15.846Z)

I think.

### Guest (2025-08-12T22:09:16.008Z)

Use, but that would be another option. Right. But we saw the client list that Lark has. I think, Drew, you shared that.

### You (2025-08-12T22:09:20.246Z)

A quarter of those system would be.

### Guest (2025-08-12T22:09:22.008Z)

And it's an amazing list.

### You (2025-08-12T22:09:23.286Z)

In great.

### Guest (2025-08-12T22:09:24.248Z)

I mean, if we can get a quarter of those people to use our system, we would be in great shape to raising capital.

### You (2025-08-12T22:09:25.686Z)

So at least that's kind of the safest one at this moment.

### Guest (2025-08-12T22:09:30.488Z)

So at least to me, that that's kind of the safest one.

### You (2025-08-12T22:09:31.126Z)

20 days.

### Guest (2025-08-12T22:09:34.488Z)

At this moment. Of all the 20 names that we've been throwing around.

### You (2025-08-12T22:09:36.646Z)

In the next month.

### Guest (2025-08-12T22:09:38.328Z)

And we want to start doing demos in the next month.

### You (2025-08-12T22:09:39.606Z)

It may make sense to try to have those discussions with Morgan said that they would give us access to data.

### Guest (2025-08-12T22:09:44.408Z)

It may make sense. To try to have those discussions with Lark. I mean, they've already said that they would give us access to data for free.

### You (2025-08-12T22:09:46.806Z)

For free. If the user is already one of their customers.

### Guest (2025-08-12T22:09:53.288Z)

If the user is already one of their customers.

### You (2025-08-12T22:09:54.246Z)

To pull their data selectively.

### Guest (2025-08-12T22:09:57.528Z)

Like it seems like we have an opportunity.

### You (2025-08-12T22:09:58.486Z)

For 50 of the best potential clients.

### Guest (2025-08-12T22:09:58.728Z)

To pull their data selectively for 50 of the best potential clients.

### You (2025-08-12T22:10:02.646Z)

So why would we try to have a little bit of.

### Guest (2025-08-12T22:10:05.848Z)

We would dream of. So why wouldn't we try to have those discussions?

### You (2025-08-12T22:10:06.806Z)

Represented to me. Right. Mark doesn't have an API.

### Guest (2025-08-12T22:10:09.608Z)

Now.

### You (2025-08-12T22:10:10.326Z)

Because there's not like an API sense of data that's being transferred on a very, very regular interval.

### Guest (2025-08-12T22:10:10.648Z)

That's already done. Ryan's already sent it to me. Right. Lark doesn't have an API because there's not. Like an API really only makes sense. If you have a ton of data that's being transferred on a very, very, like, regular interval.

### You (2025-08-12T22:10:18.646Z)

Given that. Their spreadsheet, maybe a couple thousand type of ten cards.

### Guest (2025-08-12T22:10:23.368Z)

Given that lark only up. It's like their spreadsheet of all their data is only like, maybe a couple thousand rows and maybe like, 10 columns.

### You (2025-08-12T22:10:27.606Z)

So it's not enough. That they need to be formal. And it also gets distributed once a quarter. So he has like a flip, like Excel export file.

### Guest (2025-08-12T22:10:32.568Z)

So it's just not enough that they need an API. And it also only gets distributed once a quarter. So, no, he just has an Excel, like a flat, like Excel export file that we upload.

### You (2025-08-12T22:10:38.326Z)

He already sent me the last three quarters. 2024. 2025.

### Guest (2025-08-12T22:10:43.288Z)

He already sent me the last three quarters.

### You (2025-08-12T22:10:44.566Z)

Into 2020 and so we can use these as a spells.

### Guest (2025-08-12T22:10:45.128Z)

So he sent me, like, you know, end of 2024. Q1 2025. And Q2, 20, 25, and he's, you know, so we can use these as. We can show that we have, like, we'll get a, you know, chronological progression of updated data.

### You (2025-08-12T22:10:50.326Z)

We destroy that we have like it will get chronological progression of updated data and I'm certain updating that one as well. So when we.

### Guest (2025-08-12T22:11:00.488Z)

And I'm assuming when he does the Q3 update, he'll send me that one as well.

### You (2025-08-12T22:11:02.326Z)

Just get lifted up.

### Guest (2025-08-12T22:11:04.168Z)

So when we can. And it'll be in a consistent format so we can just get loaded in.

### You (2025-08-12T22:11:05.686Z)

That's already done. To me. It's not an ebi. But accomplishment system.

### Guest (2025-08-12T22:11:09.528Z)

But yes. That's already done. LeBron's already sent it to me. It's not an API.

### You (2025-08-12T22:11:13.526Z)

Is there away from that, the software engineering side that we could just pull off? It's only just state static data, like a market or something like that.

### Guest (2025-08-12T22:11:14.328Z)

But it accomplishes the same thing. Powered in Vinod. Is there a way from the software engineering side that we could just pull up? Maybe, even if it's only just state static data like a market or something like that.

### You (2025-08-12T22:11:24.646Z)

So that we could get a visual of what our data might look like. In investing.

### Guest (2025-08-12T22:11:29.688Z)

So that we could get a visual of what the Lark data might look like in InnVestAI. Yeah, well, that's where I was going when we're doing these demos, whether it's Thursday or any other day.

### You (2025-08-12T22:11:30.486Z)

That's where I was going over, doing these DevOps. Thursday or any other day. We can actually show part of our demo. That we have access to the data that is already uploaded because it just makes technology that was more real.

### Guest (2025-08-12T22:11:40.008Z)

If we could actually show as part of our demo. That we have access to this data and that it's already uploaded.

### You (2025-08-12T22:11:45.366Z)

We can do. It's another thing to show what we have.

### Guest (2025-08-12T22:11:47.288Z)

The technology that much more real. It's one thing to say we can do it. It's another thing to show them that we have it. Yeah. We have all this. It's just a matter of time. We are kind of just getting started.

### You (2025-08-12T22:12:01.046Z)

Two use cases for the market data. I mean, at least putting into an arbitration level.

### Guest (2025-08-12T22:12:05.608Z)

There's kind of two use cases. For the market data.

### You (2025-08-12T22:12:07.526Z)

So we don't mind doing protections from occupancy.

### Guest (2025-08-12T22:12:08.328Z)

I mean, at least to one, is to put it into the penetration model. So don't mind using or doing their projections for occupancy ADR rev poll, then using the data as the benchmark.

### You (2025-08-12T22:12:14.646Z)

Benchmarks.

### Guest (2025-08-12T22:12:20.568Z)

And then the other one would be more of like a period or gasping, whereas they can say, okay.

### You (2025-08-12T22:12:24.486Z)

I want to see forecast five years. How did it change from the last 12 tests?

### Guest (2025-08-12T22:12:28.088Z)

I wonder if this market looked. I want to see. What's the forecast for the next five years? How did it change from the last forecast?

### You (2025-08-12T22:12:37.766Z)

Can be used in our database.

### Guest (2025-08-12T22:12:38.008Z)

Here through the data you shared, right? The lab data. Can we use that in our database?

### You (2025-08-12T22:12:40.726Z)

And that's it.

### Guest (2025-08-12T22:12:45.688Z)

And use it across application. That's it. That's the intent, yes. Okay? Cool. Yeah. Put that in and put that in as soon as possible. And again, the two use cases being that it should. If you look at the poc, we'll see a row where it says Market Lark Hotel Horizons Data.

### You (2025-08-12T22:13:04.086Z)

For historical and future. That's going to be like GitHub.

### Guest (2025-08-12T22:13:07.128Z)

The Lark data should populate that row for historical and future that's going to be the basis onto which users.

### You (2025-08-12T22:13:12.806Z)

And see on the start. Of these to say, like all those dashboards you created, that was just samples.

### Guest (2025-08-12T22:13:15.848Z)

Then do their own projections for occupancy, ADR and Earthar. And then the other use case is to say all those dashboards you created that were just samples but showed. Look at this market. Look at that market. What's the chain? What's going on?

### You (2025-08-12T22:13:21.206Z)

That showed. Look at this market. Look at that market. Like, centrally. What's going on? As well.

### Guest (2025-08-12T22:13:31.208Z)

Lark should be the basis for that.

### You (2025-08-12T22:13:32.006Z)

Complicated.

### Guest (2025-08-12T22:13:32.408Z)

As well. Sounds good. Sounds good. Yeah.

### You (2025-08-12T22:13:35.446Z)

I had skin.

### Guest (2025-08-12T22:13:35.608Z)

I mean, see, this is not really complicated, Data. It's very simple. Extraction.

### You (2025-08-12T22:13:39.926Z)

Industry that we're partnering with.

### Guest (2025-08-12T22:13:41.128Z)

I can also think that just telling the industry that we're partnering with Lark.

### You (2025-08-12T22:13:45.926Z)

Show people that we're here.

### Guest (2025-08-12T22:13:48.408Z)

And it just gives us more credibility. It just sort of shows people that we're real, that we're here, that we have their endorsement.

### You (2025-08-12T22:13:49.446Z)

We have the endorsement. Those things that they matter when we're doing demos.

### Guest (2025-08-12T22:13:56.008Z)

It's just, you know, those things I think matter when we're doing demos.

### You (2025-08-12T22:13:58.726Z)

Well, drew, though.

### Guest (2025-08-12T22:13:59.688Z)

Sure. Yeah. I can give it a try.

### You (2025-08-12T22:14:01.366Z)

Do you already, with your product, have these graphs?

### Guest (2025-08-12T22:14:01.768Z)

Let's see. I'll spend some time on it. Do you want to get?

### You (2025-08-12T22:14:06.886Z)

Or anything. Okay? That you had in power. Bi we could just embed it in our website.

### Guest (2025-08-12T22:14:14.168Z)

Now. We just haven't.

### You (2025-08-12T22:14:15.206Z)

Okay?

### Guest (2025-08-12T22:14:21.128Z)

Now we haven't gotten to it. It's super easy. But it's just like, having gotten to it. I could create. I could probably create a couple of pivot tables that would very easily show the kind of thing we're looking for.

### You (2025-08-12T22:14:27.846Z)

We're looking for.

### Guest (2025-08-12T22:14:36.088Z)

To show again. How is a market projecting over the next five years?

### You (2025-08-12T22:14:36.726Z)

Years.

### Guest (2025-08-12T22:14:42.168Z)

And then again, how did that change from the last projection?

### You (2025-08-12T22:14:43.126Z)

Well, that would be very helpful for us, just from a development standpoint and getting the requirements.

### Guest (2025-08-12T22:14:44.888Z)

Or the last two projections. To see is it trending up or trending down?

### You (2025-08-12T22:14:50.166Z)

So yeah. I mean, if you could just put something together. So those Lark Sample spreadsheets. They're in the team site, right? You uploaded them to the team site file, okay? Yeah, okay. That's right. Yeah.

### Guest (2025-08-12T22:15:07.688Z)

Then the email here. Email, right.

### You (2025-08-12T22:15:08.406Z)

I've got that flagged on my email.

### Guest (2025-08-12T22:15:10.568Z)

Yeah.

### You (2025-08-12T22:15:12.646Z)

Okay? Okay?

### Guest (2025-08-12T22:15:24.968Z)

Okay? And so is there anything else? Mark's doing the conference. At phoenix. On an innovation panel. That's exciting. Yeah. No, that should be a good one.

### You (2025-08-12T22:15:36.486Z)

Remind me again, what was the date?

### Guest (2025-08-12T22:15:38.408Z)

Hopefully we could spread the word about it as best AI there.

### You (2025-08-12T22:15:39.686Z)

It's october 6th. Okay?

### Guest (2025-08-12T22:15:42.008Z)

Yeah.

### You (2025-08-12T22:15:44.006Z)

I had the six in my head, but I was thinking it might have been September, which would set me into panic mode.

### Guest (2025-08-12T22:15:45.128Z)

It's October 6th and 7th. Sixth and seventh.

### You (2025-08-12T22:15:53.686Z)

All right. Cool.

### Guest (2025-08-12T22:15:54.248Z)

No. Yeah. You got some breathing room.

### You (2025-08-12T22:16:00.246Z)

Conferences.

### Guest (2025-08-12T22:16:00.248Z)

Yeah.

### You (2025-08-12T22:16:00.726Z)

I also wanted to mention that.

### Guest (2025-08-12T22:16:00.888Z)

We'll have a lot of fun. SMT developed by the time. So on conferences. I also wanted to mention that.

### You (2025-08-12T22:16:06.566Z)

Blueprint is a real estate technology conference. And one of the angel posters that I mentioned, Allison Reed, introduced me to Alex Sharkman. He was with Revolution.

### Guest (2025-08-12T22:16:11.688Z)

That blueprint is a real estate technology conference. And one of the potential angel investors that I've mentioned, Allison Reed, introduced me to Alex Sharkman. He was with Revolution. He's moderating a panel at Blueprint about hospitality.

### You (2025-08-12T22:16:22.406Z)

He? Printed about hospitality. And Carolyn Roster, who is the VP of Dispensations for Peach Trooper, is on that panel.

### Guest (2025-08-12T22:16:32.888Z)

And Carolyn Roster, who is the VP of dispositions for Peachtree Group, is on that panel.

### You (2025-08-12T22:16:36.326Z)

So I just wanted to draw that connection, that someone that we potentially want to be an angel or we may approach as an individual investor.

### Guest (2025-08-12T22:16:41.688Z)

So I just wanted to draw that connection, that someone that we potentially want to be an angel, or we may approach as an angel investor.

### You (2025-08-12T22:16:45.686Z)

And InnVestAI is on a blueprint, is moderating a blueprint panel. Someone from the Peachtree Group is on that panel.

### Guest (2025-08-12T22:16:51.368Z)

In InnVestAI is on a blue pin is moderating a blueprint panel.

### You (2025-08-12T22:16:54.086Z)

Just because it's all connected.

### Guest (2025-08-12T22:16:56.648Z)

Where? Someone from the Peachtree Group is on that panel. Just because it's all connected.

### You (2025-08-12T22:17:01.206Z)

To the conference. Yes. It's a conference.

### Guest (2025-08-12T22:17:02.888Z)

Blueprints are what?

### You (2025-08-12T22:17:03.526Z)

Yeah.

### Guest (2025-08-12T22:17:06.248Z)

Blueprints is a conference. Yes. It's a conference. Yeah. I see it here.

### You (2025-08-12T22:17:10.406Z)

Really?

### Guest (2025-08-12T22:17:11.688Z)

Carolyn's married to Gab. Also Babe, David and Moisture, who I used to work with Davidson. Oh, really?

### You (2025-08-12T22:17:16.726Z)

Small world.

### Guest (2025-08-12T22:17:17.288Z)

Yeah. I'm assuming it's the same one. Yeah. Small world. Yeah.

### You (2025-08-12T22:17:25.126Z)

All right. Zoo. You had a busy week, right? Stuff going on.

### Guest (2025-08-12T22:17:31.288Z)

All right. And then, Drew, that leads you. You had a busy week. Right. Stuff going on left and right.

### You (2025-08-12T22:17:36.646Z)

I also tried to.

### Guest (2025-08-12T22:17:38.568Z)

Well, yeah. It's partly. It's like kids are back getting ready for school, and then I also am trying to complete a proposal.

### You (2025-08-12T22:17:40.886Z)

Customize.

### Guest (2025-08-12T22:17:46.088Z)

For a customer in Australia. That would be a big deal if we were able to capture. And then we're also doing stuff on the PoC and some other things, just a whole bunch of things. So just kind of think isn't. But hopefully I'll be caught up by the end of the week. And then can we kind of refocus on reviewing some of the pdr? Yeah.

### You (2025-08-12T22:18:02.646Z)

Just have up to Howard for getting that done. Because she's software team.

### Guest (2025-08-12T22:18:08.728Z)

Just hats off to Howard for getting that done.

### You (2025-08-12T22:18:09.206Z)

At this point. On that.

### Guest (2025-08-12T22:18:10.968Z)

Because he's actually ahead of the software team.

### You (2025-08-12T22:18:13.766Z)

's my job.

### Guest (2025-08-12T22:18:15.528Z)

At this point on that. Prv.

### You (2025-08-12T22:18:19.286Z)

I see that. I was responding to somebody on LinkedIn.

### Guest (2025-08-12T22:18:23.208Z)

Yeah.

### You (2025-08-12T22:18:23.526Z)

That Diane and I are supposed to meet with on Thursday, but she just said, I sent you the invites, but they got bounced back for some reason.

### Guest (2025-08-12T22:18:24.408Z)

You're on mute, Howard.

### You (2025-08-12T22:18:33.366Z)

But no, I was saying that technically, that's my job. Is I have to be looking like six months to a year ahead to get all of that ready for the development.

### Guest (2025-08-12T22:18:40.728Z)

Someone reached out to me. Too. And it got bounced back.

### You (2025-08-12T22:18:44.006Z)

So if I'm not six months to a year ahead, then you guys need to slap me upside the head and tell me to focus and do my job.

### Guest (2025-08-12T22:19:02.168Z)

And you know what? Actually going back to the Lark thing.

### You (2025-08-12T22:19:03.286Z)

This would be totally Marxist, but if they're in a couple screenshots,

### Guest (2025-08-12T22:19:04.168Z)

For a minute. Once we do get the Lark data in InnVestAI. I don't know. This would be totally Mark's decision, but if there are a nice couple of screenshots,

### You (2025-08-12T22:19:08.086Z)

We could take of the learned data. What? The screenshots of our underwriting software.

### Guest (2025-08-12T22:19:15.048Z)

To take of the Lark data, kind of with one of the screenshots of our underwriting software.

### You (2025-08-12T22:19:15.846Z)

It would be great to maybe shoot them. As well, just so they can visualize what the partnership could look like with their data.

### Guest (2025-08-12T22:19:22.728Z)

It would be great to maybe shoot them over to. Ryan and maybe to Dan as well, just so they can visualize what a partnership could look like with their data in our software.

### You (2025-08-12T22:19:27.766Z)

In our software. Model. Okay? Look at this. It looks awful data in that model.

### Guest (2025-08-12T22:19:35.368Z)

Model. It just might be a little like, hey, look at this.

### You (2025-08-12T22:19:39.366Z)

Okay?

### Guest (2025-08-12T22:19:39.768Z)

It looks awesome. Lark data in that invest model.

### You (2025-08-12T22:19:42.006Z)

All right, everyone. Thank you. So the next time we'll talk, Jessica goes forward.

### Guest (2025-08-12T22:19:44.008Z)

Yeah. That sounds good. Okay?

### You (2025-08-12T22:19:48.406Z)

It's Thursday at 5:00.

### Guest (2025-08-12T22:19:48.808Z)

All right, everyone. Thank you. So the next time we'll talk is assuming this call with Jessica goes forward is Thursday at 5:00.

### You (2025-08-12T22:19:52.566Z)

And then we'll bring her from there. Sounds good.

### Guest (2025-08-12T22:19:59.368Z)

And then we'll regroup from there.

### You (2025-08-12T22:20:00.006Z)

All right.

### Guest (2025-08-12T22:20:03.048Z)

That's good. Sounds good. Sounds good. All right. Have a good night. Bye. Thanks, everyone. Bye.