---
granola_id: aa3dc08d-bcca-4e15-8871-adbf1554575e
title: "Weekly sync product & tech - Transcript"
type: transcript
created: 2025-10-31T13:59:45.536Z
updated: 2025-10-31T14:38:30.427Z
attendees: []
note: "[[Granola/2025-10-31 Weekly sync product & tech.md]]"
---

# Transcript for: Weekly sync product & tech

### Guest (2025-10-31T14:00:34.272Z)

Hello? Hello?

### You (2025-10-31T14:00:36.513Z)

Good morning. Good evening.

### Guest (2025-10-31T14:00:39.632Z)

Hello? Hello? Good morning. Good morning.

### You (2025-10-31T14:00:42.673Z)

Tom. How you doing today?

### Guest (2025-10-31T14:00:45.152Z)

Yeah. Great. How are you doing?

### You (2025-10-31T14:00:46.433Z)

Good.

### Guest (2025-10-31T14:00:50.112Z)

Nice. We are still waiting for. A couple of more folks see if they are able to join. Okay. Raj is here.

### You (2025-10-31T14:01:14.753Z)

Evening.

### Guest (2025-10-31T14:01:18.192Z)

Hi. Guys. Yeah, I think we can get started. So I'll provide you a quick update. So we have been focusing on the feedback that rope provided. I think most of that is already fixed. The few items that we are still working on. Apart from that, we are also looking at the Year zero feedback that you had provided. It's just getting started with that.

### You (2025-10-31T14:01:58.113Z)

All right.

### Guest (2025-10-31T14:02:01.232Z)

And then we. I believe we do have a few questions. In regards to what is in the PoC. And then, you know, there are some fields that we find in the financial documents. And I think they should be part of the performer. So Shivam will show what all fields we found so far. And that is really it. I don't think we have anything to demo apart from whatever fixes we did for Draw. That's new, not new. So I think it should be good from that front. And then whatever you want to go over, Howard.

### You (2025-10-31T14:02:46.353Z)

Sounds good.

### Guest (2025-10-31T14:02:49.392Z)

Cool. Cool. Yeah. You want to probably. You can bring up the things that we are discussing earlier. So what I was telling was I went through multiple. Let me say this, PNLs. And I found that under non operating expense, Let's first go through our poc. So we have under non operating expense, we have management fees. Real estate taxes. Insurance and other non operating. So in. This PNLs. We have property and other taxes. Which can go with real estate taxes.

### You (2025-10-31T14:03:36.593Z)

Yes.

### Guest (2025-10-31T14:03:37.392Z)

Are we good with this, Howard?

### You (2025-10-31T14:03:38.433Z)

Yes.

### Guest (2025-10-31T14:03:40.672Z)

Gotcha. And the insurance can go with this. Insurance? That's fine.

### You (2025-10-31T14:03:44.833Z)

Yes.

### Guest (2025-10-31T14:03:47.232Z)

And what about this? Incentive management fees. What I suggest is it's same as management fees. Because in this PNL we have incentive management fees and a management fees.

### You (2025-10-31T14:04:04.033Z)

That's something that we should ask Drew. I would think that they would be lumped together, but since they're separated on this financial statement,

### Guest (2025-10-31T14:04:17.312Z)

Actually, it's zero.

### You (2025-10-31T14:04:17.473Z)

We may to lump them in with something else or create a line item. So yeah. Is there any data? I see you've got the line item, but I see it's all zeros. Are there?

### Guest (2025-10-31T14:04:32.672Z)

Yeah. Insurance is also zero. And about this rent and lease, should we have another line item for this?

### You (2025-10-31T14:04:43.073Z)

Yeah. Yeah, let's. Let's. Let's get with Drew on this, because I think when I put the POC together, the model that I based it on. Well, it was. It was actually based on the document that Drew gave where it's the. Industry standards for. The accounting. And I. I think what I have in the poc is the top level. But I think there were some sub line items that would roll up and maybe, I think maybe that the property or the rent and lease and also the incentive management fees might be part of those, so. Yeah, Drew. Drew is going to be the one who can give the correct answer to that. So, yeah, I would just jot down all your questions in an email and send it to Drew, but please copy me as well. I want to make sure that I. Understand it as well.

### Guest (2025-10-31T14:06:03.392Z)

Year. And other fields too in the Ambridge file. We got some movies like other expenses can go with other non operating. We got this new field like owner expense.

### You (2025-10-31T14:06:12.113Z)

Yes.

### Guest (2025-10-31T14:06:17.152Z)

So I think what I was thinking to sum it up with other expense, but I think it's better to have different line item for these fields.

### You (2025-10-31T14:06:28.273Z)

Have you come across it in other financial statements?

### Guest (2025-10-31T14:06:33.712Z)

Actually, I went through. One more we have done here. And this is another one sfo. And we have rent here. Probably just rent. And these two. With these three, we are good. And like, yeah, I went through these four only here we don't have much property tax, insurance and other. We got here.

### You (2025-10-31T14:07:01.153Z)

The reason I ask is I don't want to create a line item. Based on just one company's because they may have something unique to their particular company.

### Guest (2025-10-31T14:07:15.072Z)

Yeah.

### You (2025-10-31T14:07:16.193Z)

I don't know. We may have a miscellaneous line item, or maybe there might just be, like, a bucket that we can take all of those and combine them. And another reason is if we create a line item for one client, If we. If we display that to other clients, they're going to say, what is this? Why is this line item here? Right. It might cause confusion. So, again, Drew is the expert on the financial statements here, so let's. Let's try to get as much information from him as we can.

### Guest (2025-10-31T14:07:57.472Z)

Okay. It would be great.

### You (2025-10-31T14:07:59.393Z)

All right.

### Guest (2025-10-31T14:08:00.432Z)

So let's compose a list of all these line items, send it across. Also send what you just proposed and, you know, let it come back with the answer.

### You (2025-10-31T14:08:04.913Z)

Yeah.

### Guest (2025-10-31T14:08:09.792Z)

Yeah. Gotcha.

### You (2025-10-31T14:08:14.673Z)

And yet. I mean, Drew helped me put together the poc and basically, anything that's in there was at his directive, so. So, yeah, he. He would need to be the one that tells us, you know, maybe we combine. Certain line items. Into one. On here, so. Yeah, let's just see what he's got to say.

### Guest (2025-10-31T14:08:41.872Z)

Gotcha. Okay, great. Yeah, that's what I wanted to ask. And won't create it here. Raj, you have anything? Just. Like out shared the latest beyond. 3 less of 2 things regarding the through rotation formula. That would be. If you can go through. Some of the key points we will be working on. On the pro rotation. That we are going to. Kind of. Not equine, but kind of going. It's not very clear. I don't know. How were you able to understand what he said? Actually, he's trying to say that. Howard, can you go over the PRD that you send? Like, can you cover the few main points and key points? So it would be great. Yeah. The EA0 that you send. Right.

### You (2025-10-31T14:10:00.273Z)

Yeah.

### Guest (2025-10-31T14:10:00.752Z)

Yeah.

### You (2025-10-31T14:10:02.433Z)

I don't have it open in front of me, but I can. I can just kind of summarize everything. Years.

### Guest (2025-10-31T14:10:10.592Z)

You can bring it up. Shivam or Raj, if you have that open in front of you. Okay, I have. Is that visible? Yeah. So.

### You (2025-10-31T14:10:32.353Z)

Yeah. Okay. Yeah, that's good.

### Guest (2025-10-31T14:10:39.952Z)

Where should we start?

### You (2025-10-31T14:10:43.313Z)

Well, anywhere you want. Let me just give you a little bit of background so you have an understanding what year zero is. So when an investor is underwriting a deal, doing it, their analysis. And they say they. They will designate a hold period. So a hold period, or the term is how long do they plan to own this property? And they have to make certain assumptions. Doesn't mean they're always going to hold it for whatever they say in the analysis. But in order to calculate a valuation, you have to have, you know, how long am I going to own this? You know what? What is my purchase price? And then that hold period determines, you know, you make certain assumptions, saying, I think in five years this will be worth X dollars, right? And that's how you calculate your irr. All these different financial metrics are based on that. Now the. The year, year one through whatever the hold period is, let's just say five years. So year one through five have to be full years, not a partial year. So that means the year that I buy the property, Is considered years zero. Unless I buy that property on December 31st or January 1st, right? If I buy the property the first day of the year, I will own it. For the entire year. So that's why when you read the prd, basically it says unless you buy it on these two days, you're going to have a partial year. So the year zero, then, is essentially that partial year, so. So that for. For the year zero, you're going to have your year to date. Data, which is the previous owner. Right. So let's just say I'm going to buy the property. On July 1st. So the previous owner owns it from January 1 through July. June 30. And then when I buy it, I'll own it from July 1st through the end of the year. So the year to date column. Is historical. It's what was done under the previous owner. Then the year, then the projected column or the pro rata column. From july through december. Is when I own it. But it's only half a year. So that is why we call it years zero. Okay, so then I estimate. Or forecast just like I would with anything else. What I think that remainder of the year is going to be. And then year one through year five, I do. It's just business as usual. So that's the concept of what year zero is. And it's really easy to calculate. You don't calculate that pro rata. Period from July through December. What I'm going to do is I've got that column that's inserted now, and let's just say I bought it in this year 2025. So I would go in. I've got all of this documentation, I've got all of this historical information from the previous owner that I'm going to use to forecast all of 2025. So I do the exact same thing in that projection column as I would for year one through five. I would put in my occupancy and all of these assumptions based on what I see. So now I've got my own forecast for 2025. I've got the financial statements that show the historical performance from January through June. So all I do is I take what I estimated for the full year. Subtract the year to date. And that difference is that pro rata column. Right. So the year to date plus the pro rata will always equal my 2025 projections. So it's actually a very simple process. To do that. But the whole thing about, you know, we have to be able to extract the year to date, month. And then just project the. The rest of the year, so.

### Guest (2025-10-31T14:15:46.352Z)

I guess we are already extracting those months. We just need to add logic for that.

### You (2025-10-31T14:15:54.593Z)

Yeah.

### Guest (2025-10-31T14:15:55.872Z)

So this is what you're trying to say, right?

### You (2025-10-31T14:15:57.713Z)

Y. Eah. Yeah.

### Guest (2025-10-31T14:15:58.752Z)

In this column. Y2D. This is the column. Where the owner still holds the property, right?

### You (2025-10-31T14:16:06.913Z)

Yes, yes.

### Guest (2025-10-31T14:16:08.672Z)

Okay. And this is going to be an assumptions.

### You (2025-10-31T14:16:11.633Z)

Right.

### Guest (2025-10-31T14:16:13.872Z)

Okay?

### You (2025-10-31T14:16:13.873Z)

So let me, let me point out real real quick that and I mentioned it in the prd, but just to make sure that that drop down box in the year to date. Is only for testing in the PRD that would nor that we're not building a drop down box there. We would just be putting in the month of whatever we extracted. So when you upload the financial statement in my previous example, you would have gotten a statement through June of 2025. So that June that you see in the header that we're extracting is what would be displayed there, not the drop down box. Okay? And then. Then we've got the logic that says if year to date is. And it says June, you always assume the last day of the month. So you. You. You know that the next the 2025 projector would be July through December, right? Yep. Fully automated. No, no drop down boxes. So what. What we want to do, though, and what you see in the prd, again, this is something I want to clarify, is that, like I said, the. The year to date is historical data. It's just not a full year. It's a partial year, so it needs to be in that blue section. The 2025 projection and the pro rat of those next two columns. Are not forecasts that are used in the valuation. So we need to come up with a different color. Background to set those apart from. From the rest of the model, whether it's maybe no background color or whatever. I didn't. I didn't specify what background color it should be, but.

### Guest (2025-10-31T14:18:19.312Z)

So these two are supposed to be with a different background color.

### You (2025-10-31T14:18:22.913Z)

Yeah, yeah. Yeah.

### Guest (2025-10-31T14:18:24.912Z)

All four cars, right? All forecast will be one color and then the story will be one color has two colors.

### You (2025-10-31T14:18:30.353Z)

Yeah. Yeah. Yeah, actually, I, I, I think I'm, I'm wrong. I think only the pro rata the October through December would be a different color because the 2025 projection is part of the forecast. But it's just year zero in or it's just the.

### Guest (2025-10-31T14:18:34.272Z)

No.

### You (2025-10-31T14:18:49.393Z)

What's used to calculate so that 2025, October through December is the year zero. Column.

### Guest (2025-10-31T14:18:58.032Z)

So we want that in a different color.

### You (2025-10-31T14:19:01.153Z)

Yes.

### Guest (2025-10-31T14:19:03.072Z)

Okay. So historic in one color. Year that the property was purchased in one color.

### You (2025-10-31T14:19:11.633Z)

Yeah.

### Guest (2025-10-31T14:19:11.792Z)

And then rest of projection in one color. So we have three colors in the header now.

### You (2025-10-31T14:19:17.233Z)

Yeah. Or. Or we do a border or something. Or a combination of the two. Maybe a slightly different background color and a border around those two headers. Just something to make it stand out that you've got your historical up to this point. Then you've got these columns that you're using to calculate years, zero. And then you've got your year one through one every year. As your projection. So yeah, it basically is showing there are three steps the user has to take to get to the valuation.

### Guest (2025-10-31T14:19:47.632Z)

Ok? Ay.

### You (2025-10-31T14:19:57.153Z)

Okay?

### Guest (2025-10-31T14:20:04.032Z)

That's it. From my side.

### You (2025-10-31T14:20:09.713Z)

Yeah. The only thing. That really needs to be calculated for the year to date is the number of days. And that would be. And it's stated in the PRD, that would be inclusive of January 1st and the last day of the month. Right. So you need to make sure it's not just. I mean, basically through December 31st of the previous year would be your subtraction date, but other than that. The remaining calculation is. Like I said, it's super simple of just taking whatever I put in for my 2025 projection minus year to date gives you that difference between the two. So there's that. And also, like I said, the logic where if they're closing date is on December 31 or January 1, you don't even need those columns. They wouldn't be displayed. So we need to build in that logic as well.

### Guest (2025-10-31T14:21:12.192Z)

Yep. Makes sense.

### You (2025-10-31T14:21:17.553Z)

Now. Just listen to what I've got to say. But don't worry about the engineering, because there is an alternative. Which would be super simple as well. It's just almost. Basically all we would need is a checkbox. But there's what they call the fiscal year. Right? So we're basing this on a calendar year of January through December. But some buyers. And each buyer can do it their own way. We'll work on a fiscal year. And the fiscal year would be based on whatever the closing date is. So in my example that I just gave you, if I'm buying the property on July 1, my fiscal year would be from July 1 through June 30, in which case I would be using a full 12 month period. I wouldn't have a partial year. It just means that my years, my fiscal years would cross over the calendar years. But in that case, if we have that checkbox as well, Where if a user wants to go on a fiscal year. They just check that box and we wouldn't have to do any type of pro rata calculations. So we'll probably incorporate that before version one. But I want to get user feedback before we do anything else on this. So just as an FYI, that's something that likely will be added in.

### Guest (2025-10-31T14:23:02.432Z)

Okay? Cool. Yeah. Anything else, guys? Howard, so if you could please. Provide that there are more. Like whatever demo we have to complete. Probably you can have the fresh look now because we have all the code push to stage. So if you do it now, so probably you'll cover what Drew had mentioned in his feedback, and then also your feedback related to UI and, you know, matching it to the POC and all that.

### You (2025-10-31T14:23:42.433Z)

Yeah, yeah. No, I can go ahead and put together notes on that as well. I just. Yeah, I needed to get this Year Zero out of the way. I also need to update the formula prd. But you've already got the formulas you need in the prd, so it's just a matter of me checking off a box to make sure it's complete. But other than that, I'm not done with the year zero.

### Guest (2025-10-31T14:24:15.232Z)

I mean, I just want to. Be ahead of that December 1st deadline. And I know you know that if I can knock it out before that, That will. Great. And then these guys can go out and do whatever they want to do.

### You (2025-10-31T14:24:28.593Z)

I was going to say, I think we are much closer to being able to get that done. So I'm not concerned about the December 1st. I mean, we've got all the parts. We just have to put them in the right order on the ui.

### Guest (2025-10-31T14:24:43.472Z)

Okay? Sanskrit. Sanskrit.

### You (2025-10-31T14:24:49.873Z)

Cool.

### Guest (2025-10-31T14:24:50.832Z)

All right.

### You (2025-10-31T14:24:54.193Z)

My favorite meeting of the week. I always love to go.

### Guest (2025-10-31T14:24:58.672Z)

Yeah.

### You (2025-10-31T14:25:02.273Z)

All right. Any other questions or anything else?

### Guest (2025-10-31T14:25:08.832Z)

Same. You're saying something you cannot hear you. I see your lips moving. No. Okay. All right. Thank you. Thank you, everyone.

### You (2025-10-31T14:25:23.393Z)

All right. Have a great weekend, guys. We'll see you.

### Guest (2025-10-31T14:25:24.432Z)

We'll meet next week. Okay?

