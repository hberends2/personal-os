---
granola_id: 8518b186-5cdc-429f-a621-bc3ca2b106f0
title: "Team Meeting - Transcript"
type: transcript
created: 2026-01-20T15:59:06.538Z
updated: 2026-01-28T17:10:00.979Z
attendees: []
note: "[[Granola/2026-01-20 Team Meeting.md]]"
---

# Transcript for: Team Meeting

### You (2026-01-20T16:00:39.306Z)

Good morning.

### Guest (2026-01-20T16:00:44.677Z)

Good. How are you?

### You (2026-01-20T16:00:45.866Z)

Do.

### Guest (2026-01-20T16:00:46.037Z)

Hey, guys.

### You (2026-01-20T16:00:47.786Z)

G.

### Guest (2026-01-20T16:00:48.277Z)

Hey. I denied entry to your note taker, Diane. I hope. Good. Good. I have to. Actually, I don't know if I'm going to continue with that note taker. I might look at other ones. But. All right. Thanks, guys. I thought it would be good if the three of us chatted. Okay?

### You (2026-01-20T16:01:07.146Z)

Yeah.

### Guest (2026-01-20T16:01:07.477Z)

So we can talk about, like, there's things all around for each of us. But the three things I wanted to cover today. One is any updates on the settlement agreement or anything. Sherban, you know about the settlement agreement. Second is kind of, you know, what logistically needs to be done as far as, you know. I started to research how to transfer the GoDaddy domain. Howard, you and I have been talking about what infrastructure we want to use, right? You know, just kind of like all of that. And then the third is how within I'll say by February 3rd when there's hard and I have an introductory call with Sloan Dean, who I'm asking for help in, in terms of, like, recommendations of people to talk to, that we have a short pitch deck and a proof of concept where you are, Howard, that we can show him to try to get him excited about the idea. So those were the three things that I wanted to cover, but. This isn't so. And. But anything else you guys want to cover as well, we should talk about. Sure. So I'll. I'll start with the settlement. I have not heard anything yet. It's been less than a week, so I. I just don't check. I'd send it last Wednesday to him. And I think it was even. Late at night, perhaps when I sent it. So I'm not. Surprised I haven't heard anything yet. Hopefully, I will hear something this week. A lot of times when it gets to this stage, the lawyers just want to get it off their plate. So, you know, at this point, hopefully it's. It's moving. I would suspect they're going to have changes to it, just wording changes or, you know, maybe changes to the mechanics of how something's transferred or, or whatever. So I will, you know, let you know when I, when I get it, but just when we get to the point of signing and what, how I view this as being signed is. Is basically, it'll be turned into a PDF and he'll coordinate getting the signatures on his. And I'll get your two signatures. Just. It'll be only the signature page. You just sign it, scan it, send it back. I'll compile a fully executed copy and send. It to their side, and I'll send it to you guys for your records. But once we get it executed, there will be, as you saw, like, time, like, deadlines. Like, certain things need to be done. And I kept them tight because I want them. I don't want to give, like, oh, over the next 30 days. I want them done, like, immediately so we can get this completely behind us, so. Five business days is what I put in. If they don't change it, let's assume that that would be the timeline. It won't be tighter than five. I mean, that, that, that would be crazy, but. So basically, within a week of, of signing, you will transfer all the domains that are InnVestAI. So if you have InnVestAI InnVestAI InnVestAI dot com. I don't know which ones you have, but all of them will get transferred via GoDaddy to, you know, and if they don't have an account, they'll have to set up an account first so you can transfer through their their portal. And I did. Very cursory. Before I even propose that in that settlement, I just Googled it. Like, how would you transfer? And the first thing was like, hey, go, dad. He's got this thing. It's like their email address. Your email address. Boom. And I'm like, okay, that's probably the easiest, so. We'll do that. Then, Howard, on your side, the GitHub, however, we provide them access, you know we'll provide them access, they will have the five business days to copy it over and let us know that it's done, and we will then delete it from our X or for. I don't know how that would work if whether we can just delete. I would assume we can delete the repository and say, okay, you guys moved it over. We're, you know, we'll give them a final warning like, hey, tomorrow at this time, we are deleting it. So, you know, let us know if you haven't copied. Something because we're. We're going to delete it, and so we'll remove it. So then we'll just. I think those are the only two thing. Oh, and then any. Logos or anything like that. That we have. We could probably. You can, if you have electronic JPEGs or anything like that, a PNG file or something, just email them to me. I will send them over to Aaron and say, hey, these are all the electronic copies of the logos that we have, and here they are. We also then have deleted them. From our system. So you know you have them, and we're not using them. We don't have them. And then once all that is done, then we can just start over. So I know you have, like, in exchange or something reserved or the. So we would. I don't think there's anything we. If there is, we'll look into. Is there something we need to file in Delaware for a dba? And if. So we'll just deviate and exchange as well, or whatever the, the, the, the domain is. And then eventually, once we get through the Driftwood period of March I think it is, or whenever the sixth payment is due, then we can do a name change. And we don't have to dissolve anything. Like, in Delaware. We can just. I'm sure there's a form you file in Delaware. It's like, hey, we're doing a corporate name change, and we'll change it from InnVestAI to In Exchange or whatever it is so they match. So there's. Not, you know, that confusion and update the bank account and so forth with the new name. What about the website? Because we do have just one, you know, a landing page. Just say coming soon. I don't know. Howard did for InnVestAI and I think so that's going to be theirs. When they, when they take, when they take over the InnVestAI domain, I imagine they will have access to whatever HTML landing page is on there, and that's up to them, whatever they want to put on there. But it's through. Good. As long as your names are. Your names aren't on there. Like it doesn't say Diane and Howard and Vinod coming, you know. Okay. Yeah, that. That's just going to be on them. And they. And I did. I did the good thing. Did you turned off the auto? Renew because in my it sort of gives a sense of urgency for them to get this done because I said they. You know? I. I think I put it in the email. End of february. And by the end of February, this site go, you know, becomes probably available if it. If it's not transferred and you guys aren't paying for it, so they risk losing it after that time period. And then I have a question. There is a very large hotel conference next week in Los Angeles. If Drew goes, He lives in Los Angeles, so it's pretty easy for him to go. But he. He knows the data people. He doesn't have as many contacts as Mark does. Mark maybe actually meeting with people. And since we don't have an agreement signed, what happens if he disparages next week and. It's before we get the settlement agreement signed. I don't think he will, but. We. I mean, we could deal with that if that happens. I mean, they've not signed anything. Like, you guys, I guess, are free to disparage each other, but I would not do that because it would could potentially blow up the settlement and maybe for the same reasons that that. Are looking to settle this as well, that they don't want to blow it up. You know, they're this close to getting the source code and the logos and everything. Why would. You know. They may just. If I were them, I would just. If I'm saying anything, I would just be, like, rolling out. What? Proposing what they're doing. Like, hey, we're InnVestAI and, you know, this and that, and we're, this is a product we're developing and blah, blah, blah. And I don't think they're going to be like, and we got it because the, you know. Did. Diane and Howard were being jerks or whatever. I don't think. You know, it wouldn't look professional in a way. Like, why would I want to do business with these guys, that this is how they're like. Yeah, I don't think. I'm not worried about Drew. It's. It's Mark. And maybe I'll ask Howard. You know Mark now as well as I do. Howard. I mean, do you think he would do something like that?

### You (2026-01-20T16:10:43.386Z)

Maybe over drinks. And they make comments. But we have no way of knowing. We have no way of proving.

### Guest (2026-01-20T16:10:47.877Z)

Okay? Right. Okay?

### You (2026-01-20T16:10:52.826Z)

Unless somebody comes back that you guys know and they say, hey, Diane, I talked to Mark. I don't think there's anything we could do about it.

### Guest (2026-01-20T16:11:04.837Z)

Well, I won't ruminate on a fan. I'll just kind of move on. I just wanted to mention it, and so. Okay, so. Is there anything else on the settlement? How do we. Do you want to talk about Vinod as part of the settlement or should we talk about that? So Vinod, as you saw, is not listed on anywhere on the agreement. So we don't have to get him to sign off. Because the way that the agreement is structured, Since we don't have to dissolve InnVestAI llc, the agreement is them relinquishing their rights. So it doesn't say anything about you guys and who owns what. It just says they're relinquishing their rights to Invest the entity. InnVestAI llc. If now the node is still wanting to, and I gather he is still wanting to sort of say, guys, I'm, I'm out, we can then execute a separate very simple one paragraph sort of he is relinquishing his rights and ownership and all that in Invest, and we can get that just signed separately with him. So at the end of the day, It, will it? Until we get, let's say, a new operating agreement in place, it's just YouTube. And then once we get the operating agreement in place, it'll be laid out under the terms of that new operating agreement so he doesn't have to be involved in this settlement. He. It's not. Going to hold it up, you know, or anything. And then I just thought it'd be cleaner. If he wants out to, then just have him sign a sort of single page, sort of half, you know, half a page or whatever, relink, reinforcing his rights to the llc, okay?

### You (2026-01-20T16:12:56.426Z)

Well, you still haven't have to be involved somewhat. In that he is the only. One who has access to the GitHub. So in order for us to transfer that over, he's going to have to be involved. To do whatever needs to be done.

### Guest (2026-01-20T16:13:13.077Z)

So I would say. Sort of let him know. I hope he knows what's going on. If not, bring him up to speed quickly because there will be a five, let's say a five day window. So you're on the hook. You two are on the hook. To get that transferred, or this thing could blow up. And if it requires the no, then Vano's going to have to operate quickly or maybe ahead of time. I don't know if he. Can Howard, give you rights to it, like, now or this week before we get the sign. So then you can do it. But he's going to. Or if not, if it's something only he can do because he's the only one knows how, I would, as soon as possible, give him a heads up that this is coming and at any time within the next couple weeks, we're going to need him to do, you know. XYZ to get this transferred over.

### You (2026-01-20T16:14:01.626Z)

One thing we have been doing. Is. He's trying to keep himself out totally. However. I mentioned. Diane and I were chatting about this online, about how we could approach. This. I think. If I were to talk to the Lord. We still do. I mean, we've got a good relationship. I'm not worried about it. But I think anything having to do with separation. It's kind of like he wants proof. He wants a copy of this or he wants that. I suggested that maybe. Like you and I have a call with the Node and he hears a coming from you and not me. And that way he knows that. He knows to do anything. I had told him that that's the wand, that I'm going to go, that we're going to have to. Allow. Them to. Folks to have over to their account, et cetera, et cetera. I think he's expecting it, But I was kind of thinking that if you were explaining it to him, It might be better. I would like. I would prefer that he gets them the access. That way I can do it and I know it'll be done. So that is an option.

### Guest (2026-01-20T16:15:43.077Z)

And I'll tell along on that meeting like, hey, the. The easiest way to keep you out is to give Howard actress and let Howard do everything.

### You (2026-01-20T16:15:43.146Z)

But.

### Guest (2026-01-20T16:15:52.357Z)

And not have us rely on you for anything to do this because. He's going to get pulled in. If it's something that he did or didn't do that's holding this up, then we can't. We. They're going to be like, who's doing this? Or tell, you know, I don't want them dragging him in because he's. Holding this up.

### You (2026-01-20T16:16:13.386Z)

We have a future working full time. So typically when we have a car like 5:30 or 6 in the evening, is that okay with you?

### Guest (2026-01-20T16:16:25.877Z)

Yep.

### You (2026-01-20T16:16:26.586Z)

I'll. Go ahead.

### Guest (2026-01-20T16:16:27.797Z)

Can. Is he available tomorrow? Or today.

### You (2026-01-20T16:16:31.626Z)

I'll pay them after this call and find out and I'll tell. Maybe we need to speak ASAP because we're ready to wrap this thing up, but we've got specific instructions regarding the GitHub.

### Guest (2026-01-20T16:16:41.797Z)

I can't do today. Because I have a school board meeting tonight, but tomorrow I am available in the evening, so if he can do tomorrow, it'd be great. And then I'm traveling the rest of the week and wouldn't be available till Monday, so I could do Monday in the evening as well. But hope hopefully tomorrow would be great.

### You (2026-01-20T16:16:44.026Z)

Okay? Okay? Pretty much any day after 5:30. Give some time to get home. So tomorrow I'm sure it's going to be fine.

### Guest (2026-01-20T16:17:06.677Z)

And. You. Do you also want me to bring up or mention like. Hey, Vinod, once we get this agreement out of the way. We will create another one for your review so you can sign off and be out. Like, release it. Like, is he. Is he wanting to do that as well, or do I. Should I not mention?

### You (2026-01-20T16:17:34.266Z)

I still want to salvage him. So I won't log. He is going to have to know that if he chooses. To completely walk away from the Obviously, I have to sign that. But if there's still any option where he could come in and pick up where he left off.

### Guest (2026-01-20T16:17:57.557Z)

I would if it were me. My, my thought would be. He should exit. And then if we need him for something, we can. He could be a contractor.

### You (2026-01-20T16:18:12.426Z)

Cat. Cat.

### Guest (2026-01-20T16:18:13.237Z)

But I would not want him involved in ownership of the company because, you know, for lack of a better word, if he flikes out again and is like, oh, now this is happening and I don't want to be involved, you can't have it like, oh, this investor wants everyone to sign something, or this. I1 he's like, well, I can't be dragged into that or be involved that. You can't have that. Like, unknown. You're either in and you're. Or you're out. And, like, as an employee, like, and maybe it's a contract employee, but he gets a certain smaller percentage. Of ownership. Does that make sense? Like so that it's a non voting right or something along those lines. So. So that's the other thing I want to bring up, but I would say the only. I would. I wouldn't make anyone employees, for one. No one's an employee until you're bigger. Because as I know, I'm hiring an employee in three weeks. With employment comes workers comp. Insurance comes unemployment insurance comes a lot of dol like regulatory stuff that you have to comply with. And he lives in one state and you live in another. I and I'm dealing with this. I'm going to have to get workers comp in Ohio and New Hampshire and unemployment. Only in one or not the other, you know? So those are costs that you do not need to make because you don't have. You shouldn't have employees right now. If he was an employee. You could grant him stock options, you know, that would be in the pool, but it would be very. You would have to be careful because when you raise, when we raise funds, like, say, a Series A, they're going to require us to create an option pool. And if you've already diluted some of those options, you're just going to dilute yourself out further, right? This is. This is going to sound tough. Quit trying to be equal with everything and sharing the love. Right. If you want this to be your I company, that's successful. Basically the three of us are it. And he can be a contractor and he'd get paid, like, as a contractor. Like, if we have to pay him, that's an expense. He would get monthly checks, like, so he's going to get paid more than we are early on as a contractor, you know, or whatever. But this whole, can we salvage him and, you know, share the love and it's just going to be a headache. It's just the only thing on the flip side to consider is that let me just try to put this as clearly as possible. We did a good. We did a great job with the POC last time around. Howard did an awesome job, and we did a good. We did an okay job with the mvp, partly because we wanted a perfect mvp, and we just kept working and working on it, but we weren't really honest with ourselves 100% about the data ingestion. Like, how hard it was, what our success rates were. And Howard can speak to this more than I can, but when we go out, I mean, we have to start to talk to people in the industry, right? Like, I have three people in my mind that are, like, they're going to give me good feedback, good advice. Where to go how to do this, but I think this time around, we might want to try to partner with someone who's already ingesting data. But the point I'm trying to make is Vinod did get us to the point where we had developed the software so we'd be much faster in bringing him back to get to that same point, and then instead of spending all of our time on data ingestion, try to go to, like, there's probably three or four groups that we could go to and see if we can work on a partnership where they help us with the data ingestion. Howard, can I just turn that to you for a second and you can. Like. Like, I might be wrong on that, but I just. That's kind of in my head. Like, if we want to speed up the version of the mvp, than trying to find someone that we can work with who's already ingesting successfully the data. Would be a win for us. But also that already did the work of creating the hotel acquisitions model in software. Do you want to also be careful that you can't just have. No. Recreate what he just did. You could open yourself up to another lawsuit from those guys. All right, you gave us the code, but no, just recoded the exact same thing. That's. That's not going to. That. That would not be a good thing.

### You (2026-01-20T16:23:04.426Z)

Doing what you did before. I do realize. I think, now that you mentioned it. If we're resolving InnVestAI. Or handing over the same something anyway. Regardless whether he face or go.

### Guest (2026-01-20T16:23:28.997Z)

I don't think so. Because the InnVestAI name and logo was with the llc. You're turning that over? The. Turning that over to him?

### You (2026-01-20T16:23:34.826Z)

Y. Eah.

### Guest (2026-01-20T16:23:44.117Z)

Or to them. And he my understanding is he wants. Out. Like, it's just. I mean, it's almost.

### You (2026-01-20T16:23:53.626Z)

Yeah, he does. He does.

### Guest (2026-01-20T16:23:55.237Z)

It's too late for him to almost change his mind now and say, no, I want in. And now I want to be involved and have a say in how this settlement goes with Mark and Drew and this and that. Like, I've been operating under the assumption that. Mark and Drew, RSJ on one side and gets you two on the other because Vinod wants out and it's really just an after sort of thought that he's going to sign something, relinquishing his his rights as well.

### You (2026-01-20T16:24:23.146Z)

One thing I was never truly comfortable with was. The workaround that we had to do with the node to make him a partner by having his wife sign on, and then he had to do all that. If we start all over again. I don't know. Whether that was done correctly or not, could have done something that would it be something that. We would all have some type of liability. If something. Happened. So. I would agree. With like that. We probably don't want to put him in any type of. In the ownership position. And I do agree. With. Partnering with. A technology. That's already. Doing us. We're not radix. We have this exact same conversation. About? Should. We. Try to do something, even House. When. AI and other technology. Are making us call the information. All these companies that can do this data extraction. It's from the people. There's barrier of engineer so low that it's who can work fast to think who can do it cheapest. Right. It's one of those things where the cost has just spiraled down. So I think. Outsourcing that or partnering with somebody is probably the way to go. So that leaves us with the model. And that means. And I've said this before, it's kind of harsh. The road is a grateful darkened year. But he's not the only great full stack engineer. Full tech engineers. Our dime a dozen. There's a lot of them out there. And. I do think that some of the things that the Lord was doing in the model different from the POC. Kind of bothered me that he was kind of going off on the road doing things based on when we've done that Rediq. I don't think. That getting a fresh set of eyes. From. Full stack engineer who doesn't come in with any biases on what he's done in the past or whatever. Might actually be better.

### Guest (2026-01-20T16:27:03.637Z)

Okay? You are the technology lead. Or I'll say you and Sherban are the technology lead. I just know I. I mean, I want to, because we will start this process in February, is there are three or four groups in particular that I want to kind of talk to and think about how to approach them because they're already processing data. And one of them is hot stats, which we talked about a fair amount. During the past year, but they were while we were working on InnVestAI last year they were acquired by a very successful revenue SaaS platform called Dueto. And also they just recruited a woman from CBRE who ran hotel research named Rachael Rothman to be their chief operating officer. So, like, they are someone that is on that list, and Otellier is someone that's on that list. And so there are groups I'd like to talk to about the data processing side of it, and I don't know how those conversations will go. Right. It's exploratory, but. To use. Something that Howard mentioned, which is good for us, where there's multiple people doing it and it's becoming commoditized and the costs are going down. I just want. To be clear, when you say partner, really? We just need a vendor to pay. We want to license their technology. Do we do not maybe partner and offer any equity, any options, any investment. Wait, wait, wait. We can't. No, no, no. Wait. I just want to say, though, because as someone who knows hotel, I think maybe we should take a full like and maybe next week a full hour. And I can walk you through what Active does and how the data looks and things like that, because they are in certain areas, well, more advanced than a simple just scraping data from a PDF. So I don't want to rule that out. I want to keep that on the table. Right. We may go the route of just someone who scrapes the data, but in the hotel industry,

### You (2026-01-20T16:28:41.546Z)

Right? Right. Right.

### Guest (2026-01-20T16:29:20.837Z)

Where the pushback will come are from customers. Are people not believing that the data can get pulled into the model accurately because of how complex the data is? So for now, I just like to keep both options on the table. Not rule out one or the other. So again, whether it's activable or whoever, why can't you just license from either one? Like, I just. But I first have to just. And so as a, in, in a business perspective, I have three or I at this point is going to be. We have three conversations. The first conversation is February 3rd with Sloan. Sloan is a very good person. He's very connected in the technology space. He knows this inside and out, and I just want to get his feedback on it, and I want. And, Sherban, you should join that conversation if you want to, because that might be a good way for you to hear what he has. To say. The second conversation is going back to Driftwood and having a conversation with the gentleman named Pranag who runs all of their like AI and I want his opinion. And the third is I want opinion of a man named Ben Rafter who is a former startup. Person and is now at Hotel Equities. Those three people I want to hear from and get their view on it, and then from there, just have us think about what they say because it may inform our decision one way or the other, but they know hotels inside and out and we'll have opinions on this that are important because they're the leaders in technology and hospitality. And then from there we. Then we take it to the next step. Which is. Okay, maybe it is a simple scraping of PDFs, right? That. That may be, but maybe it's something different because maybe the investor that is behind Dueto might want to invest in. In exchange, right? And if they do, if they would. And their complementary products, then maybe there is an easy. Data interface solution that could be created through an API or gentech relationship or something like that. So what I'm asking is nothing's off the table. Nothing is decided up front. But first step, three conversations. And for those three conversations, what we need is a simple pitch deck and a good poc, just like when Howard when we showed Manny that poc Remember, from Driftwood, and he was very complimentary and said, you come a long way in a short time. Like, those are the two things we need to be able to take to these street people.

### You (2026-01-20T16:32:15.706Z)

When I say partner, I don't mean it in an equity share or anything like that. When I look at.

### Guest (2026-01-20T16:32:24.357Z)

I didn't get that from you. When Diane's partner. That's what I think she means.

### You (2026-01-20T16:32:29.226Z)

Ok? Ay.

### Guest (2026-01-20T16:32:30.197Z)

Because partner, I mean, if dealing out equity like crazy, so. No. Well, I'm looking at like who When I look at. Okay, so if Hot Stats was acquired by Duetto in April or May of last year, then. And they just then added someone I know as the chief operating officer. Right. And they're already ingesting. Hotel PNLs and are kind of becoming the go to source for hotel operating comps, then I want to know who owns Duetto, because like, you know, if they're trying to think about how they grow hot stats, then this could be a complimentary product that sits on top of it or adjacent to it or something like that. So that's why I research those things. And why and why again, I want to. It's hot stats. It's atelier. It is. The third is someone I don't think will go for it, but it is Cindy. Estus Green, name of her platform is totally blew out of my head. And then Sloan mentioned Canary Technologies, which I don't. Quite understand, but that's. I want to pick his brain a little bit more on why he mentioned Canary. So what? Does that make sense? You're naming a bunch of companies. Do they all. Are they all doing the same thing? Yeah. And for four into in slightly different use cases, but so hot stats. Was purely data. Dueto is different. Duetto is workflow automation. But on the hotel like operations revenue side. Right. We're capital markets, so it's. But if they're ingesting all that data already right through now their acquisition of Hot stats, then this would be a complementary product for them. Same with Otelier. They're in Otelier has fantastic relationships with the hotel Berends So therefore they add I mean, I have good relationships, but they have really good, like, vendor relationships established with the brand. All the Berends already. So and I know Ali Malou and I know so it's the same thing. He's already ingesting the data, and that's where. I mean, it wasn't perfect, right, Howard? Like the data ingestion. Like maybe we were overstating our success. And. And that's what I thought Drew was going to do, but Drew didn't step up and really do that. It was all the node using Claude. To extract with AI, right?

### You (2026-01-20T16:35:27.546Z)

Well, not entirely.

### Guest (2026-01-20T16:35:29.397Z)

Okay?

### You (2026-01-20T16:35:31.386Z)

Anyone seems implementing very similar to what we had at rediq and what our competitors. Do using kind of an OCR machine learning basis. It wasn't just simply having Claga or another AI. Extract the data. Which is not what we want to do. Because. What? It's not accurate. Number two, we have no control over what's under the hood because we're basically taking the stock and sending it outside. To canalmic clog and then getting the results back. We would have trouble selling that.

### Guest (2026-01-20T16:36:13.557Z)

The approach that I. The approach that I would take. Is. It sounds like if you. If it sounds like you have, like. If you know all the data that you need coming in, right? And you needed, obviously, to come in accurately and. And fast. Right? So you look at. These. These people that do that data ingestion, all these companies that you're naming, and you find out. Who is the one that can get us that data? The cheapest. Or the easiest. Or create the most strategic advantage from a, from a relationship where they, their customers could be our customers as well. Because the owner operator community is a big community. So it's not just there's, there's the data piece of it, but there's also like, who has the best reputation, who has the best customer roster, right, so that you can be leveraging their relationships with this product. Well, you can.

### You (2026-01-20T16:37:22.826Z)

Would be a strategic partnership with somebody else. Not necessarily a partnership. But one of the questions I have, Diane, companies are extracting the data in with over. Certain specific. I guess I'm quite clear on that, because our model is just taking a financial statement from a broker. Or somebody else extracting that data.

### Guest (2026-01-20T16:37:51.077Z)

From a. It's from a management company, technically. Right? Right, Yeah.

### You (2026-01-20T16:37:52.906Z)

From a management company where you've got a financial statement, historical operating statements. And extract that data and put it into the model.

### Guest (2026-01-20T16:38:01.237Z)

Yeah. So let me walk you through. I remember the name of the third company. So first I'm just going to go to atelier, okay? And I'll leave Malu. What he's doing. He has a business intelligence platform for hotel operations. He started in the night audit business. Digitizing it. So he is pulling up P and Ls. And the day I walk you through what Actable's information looks like he's doing it like Actable. He has team in Sri Lanka. 100 person team. And they are ingesting information from the property management system and pulling it off and combining it with STAR data and other revenue data. Right. And he sells it as operational bi. He also has a budgeting platform. Right. Where that's not completely dissimilar to what an underwriting platform would look like. That's that's otelier. Second is duetto and hot stats. Hot stats. Up into the point of the acquisition was nothing but just data. No workflow automation, nothing. Just data, that's all they did. And they're originally UK based, but their uk and the US, which is interesting that they're, I mean, UK based when Duetto came and purchased them. Dueto is also a SaaS platform, so workflow automation, but their niche is hotel revenue. Revenue management, and they bought Hot Stats to create a more cohesive and holistic ecosystem of hotel data. But that's. That's the nuance, right? And so I'm sure they have plans for Hot Stats because Dueto is software, Hot Stats is data. Third is Cindy has to screen and she's at Calibri. You have met Jeremy Gittleman, Right? When we talked to Mark Woodworth and John at Woodworth Core. So Jeremy worked at Calibri. Calibri is just data. They have had no success with workflow automation. Rah Hotel revenue is what their specialization is and branded because Cindy is very focused on showing all the detail in hotel revenue. But they expanded to start to import P and L last year again so that they can provide comparables. Right. But they're nothing but a data company. So those are the differences. Right. You have two companies that are workflow Automation, one of those workflow automation companies. The information part of the information we would interact with them is just the hotel P and L data, but again, they're pulling star data and all of that as well. And then the third is and probably the group that I think would be the least interested is Cindy and She's literally just pulling hotel data. So no workflow automation. We're workflow automation. We're capital markets workflow automation. Right?

### You (2026-01-20T16:41:22.906Z)

I guess we'll kind of take into different tackling, two different scenarios here. What I am concerned with or what my goal is from a technical side, is taking a documented financial statement and extracting the data. So I'm talking about the mechanics of getting that data, right? So that's where we can talk to. Multiple vendors out there that specialize in data extraction. Doesn't have to be hotel or anything. They will just be a company that we would contract with. We would be their client. Where they extract that data. That's what I'm talking about. I'm just in that financial data. For our model so that our clients can then. Come up with their valuation. We market data is also very important. Get that from Star Whoever. So I have two data sources that they need. For our model to work. And spit out evaluation. I share the five ghosts. Those tend to be like, strategic partnerships. Or perhaps somebody who admires right now for the PoC and then build it out. Right. So I don't want to kind of cold world it too. It's like, well, if they do such a very good job on extracting financial data, when we pair them a fee for them to extract our data.

### Guest (2026-01-20T16:42:47.637Z)

I.

### You (2026-01-20T16:43:00.026Z)

We could probably get a reduced fee. Because then you have that crumb selling opportunity, that strategic partnership. I agree with you. I don't want to close any doors.

### Guest (2026-01-20T16:43:11.557Z)

Would, so, but. Me either. That's the same. So that's the same. Like, it could go the route that we literally just, you know how what you're saying is the raise to the bottom and if we could keep the open doors on potential strategic relationships as well, because of the crossover between clients and capital. But if you guys will bear with me. Three conversations just to start, right? They're exploratory conversations. And what we need for those three conversations is a pitch deck and a good POC that we can walk these three people through. And then just going to be conversation, we're going to tell them what our vision is. What we think we can what what we want to do for the hotel capital markets and why we believe it can monetize and be successful. And then we want to hear from them. What they think is the best way to go about, like, you know, the data. The data ingestion and again, even the client crossover, because this is where I really know this industry, and there's so much. Client crossover that you might just have a way to accelerate your GTM because of the client crossover. The way that I was thinking about this, I think is more in line with the way Howard was thinking about it. Is. It sounds like we just. We. We need to find a data. Ingestion, whatever provider and not a workflow person. If we're going to be in the workflow space. We need to build something that works first. And then we can say, hey, we got this product. Look at how it works. Because if I'm pitching an idea and I don't, and I'm going to a workflow company and say, I got this idea for workflow on the capital markets or something that could be complementary to what you're doing, but you're not doing it yet. And boy, look at what a great money maker this is. Give me advice on how to build it. A. They're going to say, like, what? You don't have anything if you don't know how to build it yourself yet. And two, you just told them something that they're going to be like, yeah, that is a great idea, Diane. We think we're going to do that. Why in the world to build something without. It yet because this is where I go back to. I mean, like, Vinod could get us there faster. If not, we need to figure out pretty quickly how to replicate what we did on the mvp. And I don't. I'm worried we're going to spend six months getting there on the mvp. I would rather take an actual mvp, as imperfect as it would be in to talk to those groups too, right? Because what part of in the back of my head is is okay, if they have funding sources, then those funding sources may be interested in us as well. And so it may not be an immediate thing. Right. You just talk to them, and then maybe it's. You pay for each P and L that's extracted and we prove ourselves. But then we're setting ourselves up for the potential to have strategic investors that would want to be invested in us because they see the crossover benefit with their current platform. When does the. When does the revenue come in? Like I keep hearing about. We want strategic investors and more investors. And that's money. Yes, it comes in, but that's equity that goes out. When does money come in? So profits come in, and so when does the revenue happen? So in my opinion, once we get to an actual mvp, we need two to three. Groups. And Driftwood would be one of them. Hotel equities is where Ben after works. I hope he's one of them. And maybe we can do it with two. Or maybe we need a third. And we ship it to them. And they are investors in the hotel industry, right? They will give us feedback. They're very technology oriented. They believe in the future of technology for hotel investing. And then they start to give us feedback which we can then incorporate and keep the iteration of the product moving. Once we get to the point where we have real customer feedback, then we need to decide where we enter the space. We were thinking we enter the space with the debt and structured finance angle because it's the highest level of underwriting. They do it very, very quickly. And that is. That's where we were. As Mark was talking to lenders And Howard and I had conversations with lenders, too. But that is where we need to pick a point to enter the market to try to get customers. And those customers might be early investors as well. The debt, unstructured finance. We were talking to Access Point Financial. We were talking to Western Alliance Bank. I was talking to. And I'm sorry, I'm closing my eyes because I'm trying to think of this Peach Tree Hotel Group. Driftwood is also a lender. So the product they could use in their lending platform. And so then they start to use it probably at some sort of discounted revenue level until we've done our reps enough that the product feels like it can go out to a broader source of customers. And then we need to think about bringing someone and it's too early for customers. But I do think, and Howard made this point to me over and over and over again, so it's now sticking in my head is, we're going to need someone who understands SaaS sales to help actually lead sales at some point. Where we were challenged is, I thought Mark was going to do that. But Mark is really a deal guy, right? And so SaaS sales is different. Than hotel deals. So that's when to answer your question, when does the revenue come in? I would see if we can get the MVP up and running very quickly and we spend six, seven months iterating with a handful of clients so that the product is good. Then we start to approach banks, lenders, private, private lenders, special servicers, and see about entering the space at that high. And then we keep going down the food chain like, there's always something that we need to be doing and investing in to get ahead of the game. Does. Does that answer the question? When it comes to the sales part of it. I may have been mistaken, but I'm assuming Diane, that's you. Well, yes, you're going to be selling when it comes time. We do not want to hire just some sales SaaS guy who is not in the hotel industry, doesn't have the contacts and starts going. Eventually, I will need to work with someone who's in SaaS sales. I've never done SaaS sales. Right. So I have contacts. And Peachtree was ready for us to present it to their Jet and Structured Finance Group last September. But we couldn't get it out the door because of a perfect mvp. Challenge that we were having internally. So, yes, I have all. I have amazing contacts. But eventually, and probably earlier than anything else, we will. I mean, Howard, do you want to jump in here a little bit? Because you were someone who talked quite a bit last year about having someone who can sell SaaS versus just someone who understands. Real estate.

### You (2026-01-20T16:51:35.386Z)

When we get to a point where we can pay a salesperson. When we are. To that point, we would need somebody who has sales experience and prop tech experience. Somebody who can come into. The role and if the guard. Running. They'll have contacts. Maybe not necessarily in the hotel space. But if they know we'll figure it and have some software in the past, that is the ideal candidate. But. Yeah. We're going to have to get those first few clients ourselves.

### Guest (2026-01-20T16:52:23.317Z)

And I plan to. I mean, do you. You guys heard me loud and clear, right? I've already had conversations. Right. Once we have the conversation with Pranag at Driftwood, then what I hope the next conversation is, is to have a conversation with the full, broader technology team. Because right now, in house, they are working. On an underwriting model to be part of their digitalization efforts. I mean, that could be. We could have. If we had not blown up, we could have been that solution for them. But they'll have that underwriting model done before we have our MVP done at this point. Which goes back to is should we just go to Vinod because it's probably the fastest way to get an MVP or. Do we go find another full stack engineer?

### You (2026-01-20T16:53:08.826Z)

Well, or any other for tech engineer if we don't want to bring the more back. We're studying sweat equity. He's not going to do that now. Nor are we going to be able to go out to the market and bring in a full stack engineer. That's going to do it for split equity.

### Guest (2026-01-20T16:53:35.877Z)

Right.

### You (2026-01-20T16:53:37.386Z)

So either way. We can take the first step until we have sufficient funding. In order to pay a salary. Doesn't have to be quite at market. But certainly a salary plus equity in order for those folks who employees. And I know like you mentioned about not funding to the equity, I don't think any remorse is diluted, but just the reality is. That your first few Q employees, in order to get them in the door, you're going to have to offer them. A slice of the pie. It's not going to be. 5, 10, 20%. It's going to be a pool where they get maybe 45% or something like that, but it's got to be some type of inequity position that they can get in.

### Guest (2026-01-20T16:54:34.757Z)

A couple.

### You (2026-01-20T16:54:34.826Z)

Talk about it, but fish are funny. Not just these stage ones. We don't have to have. A bank account that can handle payable of these positions.

### Guest (2026-01-20T16:54:50.917Z)

Yeah, at some point. When we keep talking about. Investor, this investor that it's going to have to be like, you have to go out and do the Series A and convert all these safe notes and convertible notes or whatever into equity. Because people aren't just going to keep doing safe notes and be like, yeah, because then you could just keep doing safe notes and no one ever gets equity because we never have to do a Series A. That was not the plan. Our plan was a traditional we spend a couple of years with a core group of clients that would be investors. And my only caveat is I want to keep that strategic investor door open because of what we learned over the past year, but you go out and you find people and you try and, you know, $100,000 a pop or something, and they're part of this core. Customer advisory investor team. And then when you're ready, you do a Series A. And then when you're writing next, you do a Series B. And Howard has told me over and over again at some point, high chance that I'll speak to myself because I know we all have different time horizons, but that I would get kicked out because I would be replaced by someone in a CEO position that they might want to run the company, but that. That was always my vision. On it. Is that this is big enough, and it's also. Domestic to international. Easy enough to scale that way, especially with hotel Berends being international. But. But this is where our chicken and the egg was. It's like, okay. We couldn't all go on working for free, right? So we needed to raise money. But I mean, I don't know what I'm saying here. So I. Which is why I keep going back to Would it be worth it to try to go back to Vinod and say understanding full Stack engineers are. It's not a completely unique skill set. But since he is the most familiar with it, Is it worth the time? You know that he could do this much faster, but Drew might be courting the note as well. Like, I don't want to take that off the table, because if I were Drew, that's what I would be doing. I would be trying to get the note on Art on their side. I just think. Vinod brings too much overhead to justify it with all the. Because it's his own doing, right? He's not willing to just be Vinod in the company. He. He's got to go through his wife and this. There's just too much. Hoops and headache down the road. In my opinion, for it to be worth it. My thought is. And it's not employee based. But you, You. You offshore the development. Cheaply. You could probably do it for. You can get and I have to double check, but I think for like 20, 30 a year you could get a full time offshore. Employee.

### You (2026-01-20T16:58:21.386Z)

Good.

### Guest (2026-01-20T16:58:21.717Z)

And not be employees because you don't. Like I said, you don't want the employee headache yet. We're not capable of it yet. To have withholding taxes. And now we got to add the payroll Software to the QuickBooks account, and then we got to get the unemployment insurance and this and that and. Those are just overhead costs that are wasted at this point. We don't have a product yet. You know, it's just I. Why I thought was you guys had the idea. You guys are designing it. You have, you could you have like requirements and inputs and not, you know, here's the data in this is. What functionally is going to happen? Here's what's going to look like out, and then you're going to explain that. To the developers to say, I need a piece that takes this. Data that looks like this, whether it's a P and L statement on paper. And you need to build a data ingestion module that takes this and turns it into this, you know, populate the database fields or whatever. Then the next module takes the data out of the database that's already been ingested. And verified and everything like that. Like, that's one piece. The next box takes it from the database, does its appraisal analysis and spits out an appraisal. Like, you know, to very simplify this, and we find someone to build this piece and we. And when that piece gets built, we find someone to build this piece. And it could be the same person that builds both, but it's that we do that through contractors that we can find cheaply that can write in Python. Or whatever other language it is. But as Howard said, AI is taking over. So all that work is going to be so commoditized with software developers, the costs are just going to plummet. And you may need that architect to help you lay out the architecture, but when it comes in the coding piece, that's the. That's fast. Because those, even those developers could be on Claude or ChatGPT or whatever, and they're not typing in the code, they're just typing in prompts and pulling pieces out and pasting them together and testing to make sure they work. And that's what gets you to that MVP stage. Quickly. And then you. And then you worry about later tweaking it. You. You roll like you said. You roll it out and Driftwood says, be great if it did this. Or instead of, you know, this is not useful. And then you just have a tweet and. And so that for not look for people to hire. In and give options and this and that, and ask for sweat equity and this to get them just to build these chunks of pieces to get you the mvp.

### You (2026-01-20T17:01:09.626Z)

One thing to keep in mind is the original proof of concept that I put together was put together unlovable, which is really a cool design. For people who have low coding experience. And that was perfect for me at the time. I have moved everything. Forward into quad code, which, as I just mentioned, a lot of the code is out there. That's probably exactly what they would do. Is go with something like claude code or codex from OpenAI. It was entirely feasible that the proof of concept that I've built could be our working model in level and hiring somebody to come in. And rebuild it like the nerb is doing. I think the first thing we do is have an engineer come in and review the code and say, yes, this needs to be changed. Or. This is fine. Do what we do with that. That's probably where I would start is somebody, a folks act, come in here and take what I built and replicate it. I think we need somebody to take what I built and just make sure that it's ready for prime time.

### Guest (2026-01-20T17:02:23.957Z)

It would be helpful for me. To have a meeting where I can see that. Because right now I'm just. I have zero concept in my mind what you guys are trying to do and to be able to see a workflow charter presentation or something. To now wrap my mind around. Oh, that. And then maybe I could say, oh, yeah, like you said, Howard, I can help you. I could even help you build this piece, you know, or send this tool, or get you a Python program that takes this input and spits this out, you know? I mean, that's.

### You (2026-01-20T17:03:03.786Z)

I will send you. I will set you up over here, in here. I'll send you an email. Diane, I sent you on right before the meeting. You're already set up. It uses two factor authentication, so you just log into your email. Literally email with an eight digit code. But what I want them to an ad is a user. It generates them a digit code so you don't get this email out of nowhere from Super Base, from eight digit code. Dang it. To meet the very first one. Then when you go in. And put in your username and hit the button. Thirty seconds later, you're going to get the email with a different code. Use that one. So every time that you log in, you have to get the digit code. But that'll keep everybody else out. Only the three of us can get in there. Email right after this call. With the eight digit coke, but I'll send you. With the link there. It'll take you to it as well. You can start seeing it. 's not usable waste. So whatever you need to model, I'm going to see. And vice versa. It's a long way to be seeing the same thing. But it was at the point now. Where the data that we'll be using for the revenue expenses of sale. Power decoded data. I don't have the extraction piece. But you can do everything else. You can create a deal, you can modify and deal, or you can go in there and import things like the loan terms and all of that information. You can do the forecasting, you can test everything out. The only thing you can't do is upload a financial statement, have the data extracted. Into the model yet. We're not to that point. Unlike the original plc, all of the calculations are working now.

### Guest (2026-01-20T17:05:07.477Z)

Good for you, Howard. That's positive.

### You (2026-01-20T17:05:11.786Z)

Like the size KPI cards over at the top. Calculate the ROI encoded for center be just as an example.

### Guest (2026-01-20T17:05:13.317Z)

Yeah, yeah.

### You (2026-01-20T17:05:20.586Z)

Now it'll actually calculate everything. So. You can put in your purchase focus function, you can put in your financial assumptions, your exit function starting X. Don't forecast and you can see everything. Calculate on the slide. With the bse.

### Guest (2026-01-20T17:05:40.997Z)

Okay? Okay, so I have one other question about my. Well, my uncle, who is a SaaS GTM person, has been helping me with all the GTM work on this. It's been. It's been very helpful. We have spent days together going through this, trying to define what the custom we know what the customer base is, but put it in a way that a pitch is good for a pitch deck and the full GTM work has done sitting behind it. Where should we. What is gtm? I'm not familiar with that. Go to market. Oh, okay. Okay. Right. Defining, like, who the customers are and the way that, I mean. And Howard really understands this is, like, because we're coming from a capital markets perspective, a transaction triggers a flywheel effect where workflows start going amongst all the Personas, but they're all based on essentially the same core. Data and underwriting. It's just being replicated. So my uncle's doing a really good job of helping to, like, lay all this out in a way that would be good for. I mean, just for future investors, right? But where? And I've done a lot of work around trying to size the market. The tam, the ARR. I talk to my uncle, if we even need to include that. Where do I save that for you guys to see? Like, Howard, what should we do as far as setting up new shared. Platforms that we used to do on teams. I would wait until we get this. Settlement behind us because you're going to lose your email in about a week or two. You're going to lose in detox and InnVestAI. So we're so to the extent, Howard, that you have those as like your user IDs in your PoC or whatever you were just telling me about. The AT code. You guys are probably change those back to, like, personal emails if you want to keep working on it.

### You (2026-01-20T17:07:55.706Z)

N.

### Guest (2026-01-20T17:07:57.157Z)

Okay?

### You (2026-01-20T17:07:58.106Z)

It'll come. So, Diane, you've got your Gmail address. Michael, use the address you've got. We're not going to do the NFCI as far as document sharing. We can use Google. It's super easy. You don't have to have a Gmail address. But Diane, you and I multi email address.

### Guest (2026-01-20T17:08:19.157Z)

I use email exclusively for my personal email. I've never used a Google platform because I'm a Microsoft guy.

### You (2026-01-20T17:08:22.266Z)

Okay?

### Guest (2026-01-20T17:08:25.877Z)

But my. My kids, or Emma and Meg, my wife, you know, the teachers, they use Google and they always like, why don't you use Google Drive? Or this and that. And I'm like, I don't know. I just. So if you guys want to do something there, that's fine. I'll learn the Google stuff.

### You (2026-01-20T17:08:39.466Z)

Y. Eah, I'm the same way. That Michael talks for years. And years. But then I work for company that was seen in Google Workspace, and I'm like, wow. At least when it comes to document sharing. So much easier. And working in documents at the same time. In microcraft you can pull in Conrin. So you can make different things, but in Google. You can see where the other person's cursor is. You can see in real time if they go in and type something, it's just so much better. And it doesn't have to be a Gmail address that you shared with. You can share it with anybody, with any address.

### Guest (2026-01-20T17:09:22.997Z)

So I just put in the chat my Gmail address. So use that for that ID you were going to send me with the code, the eight digit code. You that way I can also keep this sort of separate from my from my business stuff too. So I don't fill up my my business inbox with a lot of InnVestAI stuff or whatever, so if we could set it up, it would be good. Because, Sherban, there's, like, for you, there's a lot of information. Howard, I mean, you know all of this, too, because you've been with us for. We've been together for a year, but some. Really good backup information on, like, the market, who the real estate groups are that are doing this, but not on hospitality, who the hospitality groups are that are doing this, but don't do capital markets. And so it's I mean, almost having you go through it from the beginning would be a helpful exercise because we're going to be explaining this to people. Right. And I know I'm focused on investors and I am focused on customers, too. I just feel like we need a core set of two or three customers initially to just help us iterate on the product. Iterate. Iterate. Quick iterations. Quick iterations. And then once we're ready with the mvp and we've got the data ingestion.

### You (2026-01-20T17:09:26.266Z)

Okay? All. Right.

### Guest (2026-01-20T17:10:39.077Z)

Down because the data ingestion is one of the core elements of this product. Then we start to take it to lenders. Just what we were going to do. We're just now, what, six months behind. It sounds like, and I'll look at whatever Howard you sent me, but it sounds like we're not that far off, let's say, from. I would like. I said I would want to focus on. Developing, getting a working suit. The NUTS model from data. Even if the data is we pull a file from this directory, like at first, when we have like three customers, we're not scaled. We could easily take a customer's file and populate it and even massage that data first for our rudimentary model to kick them out a report, right? And then it's like we go to. Once it works, right? And not perfect, but once we get an MVP that works, Diane, you take it to Driftwood or whoever and say we develop this. This is the point. This is our intent with this. Like, is that digitized and appraisal or underwriter for credit, you know, whatever, however you want to describe it. Can you play with this and give us your feedback? Like the. Like you guys, way back last September, talking about going to beta testing, right? So this is the beta, right? So can you give us your feedback? Oh, listen, we then. Or Howard, you know, the tech side of it is working on getting those tweaks in while, Diane, you're identifying the customers and getting those contacts down. And now who we're going to sell it to. And then we start selling and we get a few customers in, and they like it. And they like it. And now we're generating revenue. We haven't asked any for any investor dollars. We haven't given any equity away. This is just what we're doing now. It's getting steam and we need to scale. Right? We can't massage this anymore. We can't just keep taking one offs and massaging. We need an automated way to pull this data in. Right. And now. Now is when we look into who is the best data ingestion vendor to help us automate this data process. What's it going to cost of monies to scale it up? I think we can have some of those exploratory conversations on the data ingestion. I really want to have those in February by asking Driftwood Sloan and Ben Rafter. I just they know this industry so well that getting their input will be important to our decision making. So we will not. I mean, I don't know if we'll. We'll have something close to the mvp, it sounds like from Howard, but I don't think we're going to nail the data ingestion in February. But I think their viewpoint of the data ingestion might help set our direction on which way we go. And the other thing I want to say is one of the things I think I'm doing for driftwood in Q1 is helping them set up their internal valuation process for their 50 hotels, which they're working on a model. Right. But that is something that, in exchange, I have to get used to. The new name Right. If it had been built out or when it will be built out could help speed that up for them. So they're at a good period where this could be a timely conversation. If we can build something that really helps them that, you know, it just might be that there are really great test customer for us. On this, they are going to want to do it in their own model format, so. And that's what they're working on right now. But what we've got to get down is the data ingestion, right? And the formulas work correctly. Like, we have to get that down to the point where we're really not making that that mistakes on the data ingestion in order to prove out that the product has viability. So, yeah, for the data ingestion piece and maybe this document. It's in. This is. What are the data inputs that we need for Power's tool? And where do they come from typically? And if it's like, we need this, a profit number, a revenue number, cost, and it comes from this spot on a financial spreadsheet or whatever. Great. But when I if we're going to partner with a data ingestion or use a data ingestion firm, they're already going to have they're the ones that already figured out how to take the paper or whatever and get it into the database. And all we're doing is getting an API that says we're going to pull this data from this database and throw it into our model. And then we focus on the capital markets workflows themselves, which. There are hundreds of them. Right. We'll be working on this for years. It's not just the under. Underwriting is just the foot in the door. It's the very first thing. And then there are all the other capital markets workflows. That are out there. I just want to be clear on that. Right. It's just this is the first step of what, in exchange will be. Well, yes, but let's. Let's get the first step done first, right? And working and. And generating revenue. And then we can worry about step two, and then we'll build upon that. Because I know you have this vision in your head of what it could be. But let's. Let's narrow our. Focus to get something working first.

### You (2026-01-20T17:16:28.666Z)

Elephant one more time.

### Guest (2026-01-20T17:16:30.357Z)

Exactly. And then from really my role, as opposed to just offering advice to Howard on the tech side and so. And maybe helping where I can from just like Treasury Management, cfo, you know, we'll need and I Once we get our operating agreement in place, you know, I. I'll use the EIN number I'LL get a corporate credit card, because to get your QuickBooks account, we need a corporate credit card. You're right. You know, so. And then start managing the inflow and outflow and we'll develop processes on when we have an expense. This is the approval process we need to go through. So someone's not just saying, oh, I just bought this tool or I just signed up for this. And, you know, and I see money leaving the bank account and going, where's that going? You know, I'm not. Because we have the account set up with Brax would be for And Brex has emailed me several times. On. This is for the three of us to sit down and go through an educational like, this is a product overview. These are all the things Brex can do. Brex has the ability to have an associated credit card, pay bills. And so that is something I'd like to do. I mean, it's probably the you know, the highest priority is getting ready settlement. Settlement is one. And then second is getting ready for this call with Sloan on February 3rd. Because he's just so committed to technology, and I really want his opinion. And then it's easy for me to schedule someone from Brax to walk the three of us through. The mechanics of the banking account and the integrations and all of that. Because we'll need the ability to make ACH payments out of that account. Because we're not going to run the right paper checks. And you guys and maybe myself are going to. And if Brexit can do a business credit card, that's no fee, great. Because then that we can set up the auto pay out of the Brex account very easily. And I already paid Howard like his expenses from last year. And Howard, that came through to your account just fine, right? And you just did an electronic ach to his account. Yeah. So good. And that's what I was. That's what I was like. Because you guys may have expenses that come up. That you don't have the corporate credit card because we only really need one, and it's really for online stuff and licensing. We can handle the rest through expense, reimbursement or. Or any. Or if it's online, you could type in the corporate credit card information, but. But yeah, and it sounds like to get money to you guys out of that account without, you know, fees and so forth, they go wire fee to wire it out or. Or whatever. It's a wire fee. But anyway, Howard was the one who surfaced. Brax. And it was a. I mean, it's very impressive for. For what it is. So I'm looking forward to you guys seeing it and then whoever. Is this an actual, like, not. I'm sure it's a real bank, but with. With physical location, or is this like an. Ally Bank. Where? It's an online only bank.

### You (2026-01-20T17:19:56.666Z)

Actually, it's very specialized. It's word for software startups website. I'm using them, but it's perfect for us. So yeah. If an empathy is very low. Yeah, it's really designed to be a full financial suite for SaaS, type of software companies.

### Guest (2026-01-20T17:20:26.197Z)

And it's already set up and working and functioning, which is good. I'm probably not the person to be managing it. And you guys need to, you know. All three of us. Yeah. So my focus will be initiative. Settlement, for one. Obviously, I will also. Howard, I'm going to send you a. Since you're the. I know, the one that dealt with this, I'm going to send you an updated reproposal. Now, the nodes out. I know we. We said if the node's. Out. We can. We can revisit that. But while. Diane, while you're on, one thing that I was doing some research on is. I know. It was like, well, I don't need to vote. You know, I just want the money, The. The economic interest or whatever. If it's not a deal breaker for. You guys, I think.

### You (2026-01-20T17:20:59.386Z)

Go.

### Guest (2026-01-20T17:21:17.797Z)

It's not because I want to vote, but it's just from a compliance standpoint. Easier if we don't have two levels worth of membership interest, because I did some research on that. There's tax implications. Is this capital or is this profits? Is this it? If we were all in one class of stock. It's like a K1. Everyone gets a K1 at the end of the year, as opposed to. What was this? Was this. And. And it's just there's different compliance issues. So that. That is. I'll throw that out there. You guys can discuss that offline as well. But just to. Just to have it as voting stock. And it's not obviously enough to give me sway over anything. You guys are going to have the lion's share of the stuff. It's just more of a simply when it comes time at the end of the year to file our or to have an account and do our LLC tax return instead of having to worry about two classes of interest. That's. That's what I was proposing. And, Howard, is this a good time to talk about where your head is? Because we had a conversation. What was it, two weeks ago now? And I know you're, you know, thinking about your consulting business, or do you want to wait to another time to have that conversation?

### You (2026-01-20T17:22:17.146Z)

Go. Go. It's no change. From our live conversation. Just to let you know what's going on. I've got two other. Opportunities. We'll call it that. One of them would be very similar startup type of situation. In a non competing and the honor is a direct competitor for an IQ that there would be in the multifamily space.

### Guest (2026-01-20T17:23:09.557Z)

In multifamily. Right. So that's actually. Not competing as well with us. It's a different sector.

### You (2026-01-20T17:23:19.626Z)

The second one, the Rediq competitor, could potentially be an employment. Opportunity. Very interested, but they're not moving very quickly. The other one. I don't foresee any issues. This is not a 40 hour a week. Requirement. Neither. Would be the other one. I'm not meeting. Our company in exchange, if that's what we're calling it.

### Guest (2026-01-20T17:24:01.877Z)

It is. That's the new name.

### You (2026-01-20T17:24:04.586Z)

I'm still committed to getting this thing out. The question is if either of these other opportunities. Flash out to be actual income. Right now. So if there's enough to review there, then I'll probably be spending some time there, but that's about it.

### Guest (2026-01-20T17:24:25.877Z)

No, that's great, because we all. I am a side. You know, we. This is. No one's like, so. No, that's. I don't. I'm not against that at all. Congrats. You know, I hope it works out, like, because, yeah, we're all doing this sort of on the. On the side as well, so to speak.

### You (2026-01-20T17:24:44.746Z)

At some point it'll be a full time job. But Cross Bender is when we get there.

### Guest (2026-01-20T17:24:51.957Z)

Okay? Okay?

### You (2026-01-20T17:24:57.546Z)

Mentioned earlier. They have to be.

### Guest (2026-01-20T17:25:05.317Z)

No, I'm good with that, too. But how do we get that set up free, right? I mean, it's a free tool. Or is it not? I don't know.

### You (2026-01-20T17:25:12.026Z)

Not for the business workspace, so that we can actually manage the in exchange.com email. It's $14 a month per person. So it's inexpensive. But that comes with all of the Belgian working with the Google suite. So they get all the email, everything, calendar, everything else, whether you use your email or the calendar or not. But that's one thing I like about it as well, is that I use Apple. I've got nothing but Apple devices. And. Connecting to my Gmail account. Was so easy. It's not a big deal at all. The Microsoft account wasn't bad, but it kept dropping. I look at one frame with Microsoft. They have to delete it. And it's just a pain. Just Microsoft.

### Guest (2026-01-20T17:26:12.437Z)

Can you? When you said manage email. Can we, if it's a business account, can say we all get in Exchange email addresses in exchange.com or whatever. Can you, can we run those through, like, the Google Workspace? Is, is the Google Workspace basically the competitor to Microsoft SharePoint? Is that sort of.

### You (2026-01-20T17:26:36.586Z)

Actually, yeah.

### Guest (2026-01-20T17:26:37.397Z)

Okay?

### You (2026-01-20T17:26:39.226Z)

So we'll have shared storage so we can use super docs. For the sheet becomes Excel. And one thing, too. It's just like SharePoint. So you can upload actual Microsoft Word docs. Actual Microsoft Excel docs. It's not exclusive. You don't have to do everything in the Google. Products either. So PowerPoints, anything that we put together, it's just like another. It's going to be just like another SharePoint site where we could just use that as our central location. I only bring up things I have a lot of. Multiple people working at the same time in a document. Like, if we want to work on the pitch deck or if we want to work on marketing things, we can all be in there at the same time on a video call, making changes, live in real time, and it's just so much easier. And gemini. So much better than copilot. If you're into the AI portion, it does a tremendous job of making PowerPoint. Or version of a PowerPoint or. Spreadsheets to say. If you don't know what you're doing on a spreadsheet, describe what you want. You can watch it go through and fill it in, and boom, here you're up and running. I just think it's better than Microsoft, in my opinion.

### Guest (2026-01-20T17:28:11.237Z)

So yeah. So. I'm all for that. I would say again, let's get through settlement operating agreement. Rec training. Orientation. If we can get a credit card through Brex, great. You know, if it's a no fee, because I know that we can get like a. I use. I just have a Capital One Spark card and I get. It's no fee and I get one and a half percent cash back, so I every like. Last year was I got 650 in cash that I it and it doesn't come they don't write you a check. You basically put it it's a credit on your next statement or whatever. So but but if it's if we can do it seamless through Brexit, I'M you know, I'm fine with that as well. And then once that's in place, we would get QuickBooks account and it would be. The. The middle tier, not the entry level, but one up. Because one up get goes from one to three users, and since there's three of us, that would work. And I would get, I would set that up and, and I would be in charge of, and we'll link the BREX bank account to it. So then our transactions just load in there. You guys would have all the visibility. You probably would have the ability to make changes. Although I would say process wise, let's only have one person in it. Coding transactions. And as the sort of GCC cfo, that would be my role, that I would code that stuff and create the reports and so forth. But yeah, once we get that credit card in place, then. Howard, all. By all means, yeah, let's use the Google. And we'll through the Google workspace and. And we'll get Diane, we'll convert the. GoDaddy credit card is not won't be yours anymore. It will put the corporate one on there so it renews the indexchange.com now comes out of the corporate account, you know, and not your personal stuff. And yeah, we'll, we'll transfer all any charges that you guys have for tools onto the. On the card, and just that whole. All that back office stuff, I'll take care of. And once you guys log on and change the credit card information, and then I'll just code those to the different accounts. Software and apps. Expenses, we can have some meaningful reports. You guys can focus on your. Your pieces, Howard on the product, Diane on the pitch, selling, you know, and all that stuff. Right? And for me, that's like the. I mean, not that the bank account isn't important, but, Howard, kind of what we went through last year when you and I were kind of showing that. Lovable. Poc to people. Right. That and I'm not going out to the entire world, but three people initially. Right. And I just want to make sure these happen in February. So which is Sloan, which is Driftwood, who's going to be pronog on it. And it's been Raptor. Those are the three people I'm focused on first. And then Ali Malu might be fourth, but I just want to get through those three kind. But both of you listen. But it's really more about like the hotel industry and the nuances of the hotel industry and what they think about that data ingestion piece because we don't have a viable product unless we nail the data ingestion. And I just again, want to explore all options, which are just vendors that could do it. Or again, maybe strategic relationships that could take us someplace faster. So my. And when I said I don't need to be there because it's really. Your guys are the. I'm just the back office guy. My February slammed. I'll be in Nashville on the third. So, like I said, don't. Don't ever try to meet my schedule and have me. Be the bottleneck like you guys run with those meetings. My only thing is when if you're talking to a data person, The way that I would approach it. If you got. So you got this pitch deck, or if you're going to take that, say, hey, this is what I'm working on, guys. You know, this is. In exchange, this is the purpose. We want to take data and digitize it and, you know, create an appraisal. Report for underwriters or whatever. I, you know, and, and then I would just say I'm looking for your feedback or advice or whatever. I know you guys are leaders in this on how we, this front end part, how we get this data, because, you know, this is crucial to us to have reliable, accurate data, you know, from various sources, you know, then. Put into a specific format so our model could take it and read it. I'm looking for your advice on maybe what's the best way blah, blah, blah, and let them then talk. Let them say, well, Diane, we, you know, we have this blah, blah. And if they say, we could do that for you, my first response to that would be, hey, that sounds good. What would, you know, what would a license cost or what would API fee cost for us to, you know, have access to that? Not. Hey, do you want a partner? And start talking strategic. Just let them tell you what they do. Yeah, we could be that. That we could get data. We take it from all these sources and we formula. We got a product that does this. Great. What would that cost? You know? And then. And if they're like, yeah, it's like $100. A month, you get full access and API, or you have 1,000 calls a month or whatever it is, and after that it's a dime a call or whatever. Great. Take that information. From the meeting. But at that meeting, do not raise the Especially the initial meeting. Hey, instead of us paying you, how about we partner and you invest? Those are not conversations for that meeting. That. That's just my take. That is my. Because if we find what you have those three meetings and then we can compare, or you guys with more knowledge can compare. This is the capabilities of these people. They get data from these sources and it looks like this, and it's going to cost this. And if we find one that has that works. We can afford that. Great.

### You (2026-01-20T17:34:17.546Z)

Five.

### Guest (2026-01-20T17:34:37.877Z)

They're just a vendor of ours now, and that's it. And they've helped us with the data piece and we're off and running on our stuff. But. And we don't need. They don't need to be an investor or a partner for. They want to make money. Right. They want another customer. We're another customer to them. And. And great. Okay? That's how I would approach those meetings. That's how I'd approach them. So again, you don't understand. The first three people were approaching are more like advisors than they are vendors. Right? They are people that I trust that are speaking up and hospitality that are leaders. We're just getting their advice. They're not the vendors themselves. We're just getting their advice on the vendors. We're getting their advice on the product. Right. That is what I want to do, which I've always wanted to have a very strong advisory council. I've said that from the very beginning, that when I see how others have had success. They have a strong advisory council. And so having Driftwood, having Sloan, and having been Raptor, almost like advisors, is a fantastic start to a 2.0 strategy for us because they're three true leaders in hospitality technology. And then I hear what you're saying. Don't approach the vendors. As strategic partners. But I want, again, for you guys to hear me that let's keep all options on the table, because I'm the one that understands the industry the best, right? And I'm the one who understands who's in it and how people think about it and where. So we'll just. We're going to explore all the options, which are just vendor relationship. Eventually, we will explore all the options. And getting advice from people is important to us because the hotel industry is just such an interconnected industry. And these are really smart leaders that could help us craft what we want. And I agree they'll probably be like, oh, talk to so and so at XYZ Company. They do data like that. They'd be able to help you with that or whatever. Yeah, those have ideas, right? If they say, that sounds good, this would be my approach. Do you need an. Like, do you need an investor? It's. I would like to invest in that. We'll keep that in mind. Yeah, well, we don't know. There's no ask yet. We don't even know. What, like, you can't just throw out one and a half million dollar valuation. We don't know, like, how much we need to do, not negotiate a deal for investor dollars, like. Driftwood and say, well, they're a good partner, so we need this. So I'm coming back with this money in hand, like, and we've agreed to take X from them in structure like this. You can't have that conversation without getting Howard Buy in anymore. And with that, and if it's a consulting agreement. It's separate. There's no. No more bartering to your services for investors. In the same hearing me, right? That these three people are very, very important to me. So I hear what you're saying. No more me figuring this out all on my own. Yeah, Sherban, you've got to hear what I'm saying, too, is that we can't go without funding forever, right? Howard needs to start to be able to make a living, and it would be really nice if we could start to pay him something, because. No, I'm. I'm not saying. Returning money. Diane, I'm not saying we turn down the money. I'm saying you cannot agree to anything in that meeting. You can say, oh, well, we'll take that. You know, like, what do you offer? You know, we're willing to invest X. Okay? You can't say yes. And come back and say, I just got another 100,000 without talking. Maybe the answer is yes. But you have to have that conversation with. The rest of the group because under the operating agreement, that's 100% unanimous vote. Even if it was, and even that's how you had it in the previous one with Mark and Drew in the draft. Dilution because that's all dilution. Right. Howard going to get diluted out. I'm going to get diluted out with every investor dollar that comes in. You need their buy in, the rest of the people before you can walk. And you cannot do another driftwood agreement that includes your services as part of the investment. They are going to be if they want you for services. Great. You have a consulting agreement separate from the investment agreement. And you guys are hearing what I'm saying again, right? Because I am trying to figure out how to get it from a business perspective from we just lost everything and how do we put a 2.0 strategy together? And there are people that are very important to me that I believe will help us get to a point where we're ingesting the data better, which we learn we didn't do very well. Right. We were. We were. It was okay. But had we taken it out and failed at a level that it would have been hurtful for us. So I need you guys to understand, and I don't know. What the future looks like, right? How? I don't know what I'm saying. How is that not understanding? We understand that. I'm just saying you cannot agree to something in that room without talking to us. Right. And it just feels like what you. What I'm hearing from you guys is there will be. No investors, there will be no dilution. And what I'm trying to. That's not what we're saying. There. There will be. Right, Okay.

### You (2026-01-20T17:40:12.346Z)

No. Yes, we already stepped up.

### Guest (2026-01-20T17:40:21.797Z)

Okay. Because, like, I don't know what the conversation was. Sloan, we'll. We'll be like, right. What? I'm going into it initially as. Let us tell you what our vision is, and let us get your feedback, your reaction, your advice. Right. I listen to an entire podcast where we interviewed Ben Rafter. And everything that Ben had to say. So my request to Sloan is I want your advice. And please make an introduction to Ben Rafter for me. If I have Driftwood, I have Sloan and I have Ben Rafter. And they're giving strategic input on how to make this come to life. That's very important. To me versus just being the three of us working on our own little world. Right? Like, the hospitality industry is so interconnected that having these people be advisors to us is very important. And I don't. And I just don't want to get into a situation where I come back and say, ben Rafter wants to be an investor. Right. And I bring it to you guys, and you guys say, no, because it's dilution. And it's like, okay, we're going to have to have dilution because we need money to support the growth of the product that. I mean, we can't. That's. Yeah. And. We agree, but we have to come to an agreement as to what that dilution looks like. We can't have you come back and say they just offered us. I just walked in the door with $100,000 at a 1 $1 million valuation. This is great. Well, we didn't agree that that was the. I brought that idea back. And I wasn't the one who came up with the pre money valuation. Drew was the one who came up with the pre money file. It's. You guys make it sound like I did so much of the cine vacuum, but Drew. Gave us the safe note agreement. Drew came up with what the pre money valuation should be. Right. We did talk about this. So, I mean, and what I want to be clear is.

### You (2026-01-20T17:42:08.426Z)

One. Yes. We're not saying that, though. I just want to be very clear. We're all on the same page. We just want to make sure that everybody has a voice in the final decision.

### Guest (2026-01-20T17:42:37.237Z)

But are you guys hearing me? Because what we couldn't get past Howard was this. Like, are we bootstrapping or are we raising money? And what I'm trying to say is we cannot bootstrap this thing. Like, I just don't, okay?

### You (2026-01-20T17:42:39.946Z)

That's who. I hear you. Agree. Saying otherwise.

### Guest (2026-01-20T17:42:54.277Z)

I mean, you are getting an influx of 60 grand as soon as we get this settlement agreement, right? I mean, I'm paying as almost as much as driftwood. There's me in my house and there's driftwood and there's always 1.5% of the company for that. And what you're going to own, like, a lot of the company, so. And I realize you're working for us, which is great, but I just. I just want to be clear. I'm not okay. Bootstrapping. And I don't know that Mark ever heard that. From me that I wasn't. And I didn't hear from him that he was going to bootstrap it. I thought he was going to go talk to the Florida angel investors and he was talking about trying to raise chunks of money, 3 to 400k in chunks to try to do it, 3, 4. Months in advance, and then it all imploded. So I just hear from me, clearly, I don't. I don't believe in a bootstrapped opportunity here, which means we will be diluted. I just want to be. If we're going to have dilution, I want it to be with people who. Are very strategic to our growth. Right. That makes, if I can, that it makes sense as far as customers or overlap or things like that that help us grow faster because there's so much work to get done, and I don't want to be sitting six months from now where we are and not have made any progress on it. So.

### You (2026-01-20T17:44:25.466Z)

The work we're all on is engaged. But I think what we're saying is, yes, we expect to raise money, we expect there to be dilution. But we all have to be in agreement as to the terms to mean this is no different than taking out a loan. We just need to make sure that we all are in agreement in terms for the terms. Of the fundraising. Any startup is going to do that. Every single one. You have to be all in a good.

### Guest (2026-01-20T17:45:00.357Z)

We need to understand our cost first. Also, we need to know what. What are. What is our burn rate? What are we going to spend this on? Because that helps. Like, know. Well, great. We just diluted X percent of the company for X dollars. But if that bought us one month's worth of. Burn rate. It's not worth it, right? We should have asked for 10 times more for that same dilution because we need at least a year's worth or whatever. You know, we have to understand cost before we understand what our capital needs are to go seek investors and then work out what the valuation is and what the dilution everyone's comfortable with is. That kind of puts us. But we were there. We had all of that, right? When it blew up, and learning five co founders doesn't work. But we. What we need to now figure out is how to get from a proof of concept into an mvp. And that's. I'm not the technology person, right? Like, I'm going to be relying on you guys, but I will be also. I want to hear what Driftwood has to say. Their technology team. Has to say about that because they may have input or introductions or things that we are not thinking about. And I'd like to hear what Ben Rafter has to say about that as well, because he is, like, a technology person. So I just. I just want to be clear, like you guys might be thinking of this. As. Some like scrappy little three person startup than it is. But the hospitality industry is a big industry and this could scale pretty quickly if we do it right with thinking about the right groups to work with to help us get.

### You (2026-01-20T17:46:41.786Z)

I think we're all aligned on that. I don't think there's any work to do whatsoever on that.

### Guest (2026-01-20T17:46:43.157Z)

There. Okay? All right, good. So what do we want to do? Howard do you want you to set up? See, the node can meet with you and I tomorrow. Is that okay?

### You (2026-01-20T17:47:03.946Z)

Reach out to the Lord, make sure. No problem. I'll give you the information. Right now, and it's not an issue. I just want to make sure that. He? Is willing and able to do what he's done to get that over. Not edge and whatever. So I'll get that taken care of. Diane. I put the link to the Google workspace in the chat. I think that's something just for operation standpoint between, from what we do now in terms of having a common work area. We can do that now. I was wrong. There's a starter package where it's only $7 per person. And then at some point, we can go up to the standard that has a few more bells and whistles. But I think that's fairly inexpensive right now if you want to. Unless saying we have to get that done today. But it's very easy. In fact, in terms of setting up the emails is way easier. Than from Global ID than to pass you off to Microsoft. And you have to do here and you log really confusing. They're from. Everything is done within the Google workspace.

### Guest (2026-01-20T17:48:26.197Z)

How can I help you with that? From a money perspective? Is that something? Because there is money in that Brex account. So is it. But there's no credit card, so. So you follow a good corporate practice. If we're going to do like, let's say before we get the. The easiest way would be to get the corporate credit card, right? So you could. You don't have to wait for me or the settlement. I mean, to do that. If you want to get it done like, hey, Brex, we want to add a corporate credit card to this account. You could do that and, and put. Those fees when you register on that card and have it auto paid out of the account. That way. For any other. And this is, this is. Would be going forward. Any, like, personal expenses that you need to get reimbursed for out of the BREX account, a receipt has to be submitted to the company.

### You (2026-01-20T17:49:08.826Z)

Learn.

### Guest (2026-01-20T17:49:20.197Z)

And someone's gotta. There's got to be like, yep, I approve that expense and do that. We need a record of, you know, money going in and out of there, of that account. Okay, that's Chris. But then how does that leave out? How do we actually do this? Like, or do we just wait a couple weeks and not worry about it? I mean, I. I'm fine with waiting a couple weeks for it.

### You (2026-01-20T17:49:44.746Z)

Today. But I think what you just mentioned. Let's go ahead and get that Brexit credit card. I think you said you had to have a $2,500 securities deposit, whatever you want to call it.

### Guest (2026-01-20T17:49:53.237Z)

Yeah. So what I think I'll do is, just so you guys hear, this is move 2500 into. I guess. Well, I'm gonna ask Brax what to do, but they need it in a separate account, and then. Well, then, let me. Let me stop you there. I think it might be easier just to get. A Capital One card. They don't require any money up front. Why would we take money that we could use to pay other expenses and have Brex say, well, we got to secure your credit card with this amount? Like, I wouldn't do that. Well, then, you know what? I'm just going to leave it. Be. I'm not going to worry about. We just won't do it for now. We'll just use our Gmail. When we get the the settlement behind us and the agreement behind us, I will just log on to Capital One and just sign up for just another Spark card under the name of Whatever, you know. Well, I guess right now it's InnVestAI with the ein number of that and. It gets issued, like, right away. I'm a huge. I'm a big customer of Capital One. I have two credit. My personal and my business are with them. They're going to approve me in a second for, like, $10,000 a month or $10,000 credit line, and we don't have to. Have any 2500 deposit, right?

### You (2026-01-20T17:51:11.386Z)

Yeah. I wish assumed you'd have to have the Ein for ad assets. I mean, we don't have any type of asset of revenue at this point.

### Guest (2026-01-20T17:51:21.397Z)

Capital one. You see the. Well, they will. They, like when I signed up, there's a form, they feel like, what, your equity, you know, not equity. What's your income? And blah, blah, blah. And they use that to set your credit limit. And my first year, I was like, zero. Like, I don't, you know. I have zero income, you know, or this and that. And then I'm sure they. They'll probably credit, you know, run a credit check on. On me. But they know me, so it's like they're going to. It's going to be easy to get that up for you, I'm sure.

### You (2026-01-20T17:51:38.346Z)

Cat. Okay? I'm open to whatever works.

### Guest (2026-01-20T17:51:54.277Z)

Okay, so then, Howard, how do you and I start to work through the. Because I know I. We pitch really well together. So how do we. Are you ready to walk us through or if it's just me, walk me through the proof of concept that you've developed. I know you shared it with us. I pulled all the pitch deck stuff. My uncle has been a huge help. I just need to sit down and, like, spend. It's. It's 12 to 16 slides at the highest level you could possibly imagine, so I need to share that with you. Where you and Sherban. How. How do we go about getting ready for. This call with Sloan on February 3rd.

### You (2026-01-20T17:52:35.626Z)

I can walk you through. You can walk in here at any time and take a look at the model. But I can certainly walk through. And show how we could do demo. Obviously you're not going to do a full.

### Guest (2026-01-20T17:52:51.877Z)

Right.

### You (2026-01-20T17:52:52.666Z)

Every single field and watch it go through. Now. I could do that. I kept saying the same thing before. You don't have to have a fully functioning model. You can raise money on an idea. You don't have to have that. It's definitely at a point where I could sit down tomorrow with anybody and walk them through.

### Guest (2026-01-20T17:53:07.717Z)

Right.

### You (2026-01-20T17:53:15.866Z)

And get that done.

### Guest (2026-01-20T17:53:18.037Z)

Okay? Do you think we could set up a time? Maybe next Monday and then in Sherban, if you're back in town and you want to join us, I'll walk you through where we are with a pitch deck. Walk us through or where we are with the proof of concept, and we just. It's like a working session to get ready for these three calls. Yep. Yeah, I have time. Monday. How about 11am on Monday? Let's see. Monday the 26th. Yep, that works. Howard, does that work for you? Howard, do you mind sending the invite out? Because I don't even know if I have teams under my Gmail to set up a conference call.

### You (2026-01-20T17:54:05.146Z)

I'll send them out, but we can start using Google Meet for the video conference.

### Guest (2026-01-20T17:54:08.437Z)

Okay? Okay, so we will talk next Monday at 11. In the main. Well, maybe we'll have more information on the settlement, but the main goal of it is to a working session to work through just for us to see the proof of concept and for you guys to see the pitch deck. Sound good. All right. Very good.

### You (2026-01-20T17:54:31.626Z)

All right.

### Guest (2026-01-20T17:54:32.597Z)

Thank you.

### You (2026-01-20T17:54:33.626Z)

Thanks. See you later.

### Guest (2026-01-20T17:54:33.717Z)

Thank you. Have a good one.

