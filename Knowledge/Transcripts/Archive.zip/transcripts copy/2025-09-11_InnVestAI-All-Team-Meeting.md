# InnVestAI All Team Meeting

**Date:** 2025-09-11 00:00:00 UTC
**Meeting ID:** 3034af6b-8f2f-4208-9bcb-083d4fd594d2
**Synced:** 2026-02-05 14:46:48

---

# Transcript for: InnVestAI All Team Meeting

### Guest (2025-09-11T21:33:24.562Z)

Great. I feel like I should just sing the song that's been stuck in my head all day. Long is it? Kpop demon. I don't know if you guys have three kids that are like, between 13 and three. So all that. Anybody? All he was doing Our House is Kpop Demon Hunter movie that came out that I'm sure no one would have heard of if they don't have kids of that age. Very catchy songs. That are just stuck in my head at this point. I literally just like, anytime there's silence,

### You (2025-09-11T21:33:33.683Z)

I don't know if you guys have. Three ice cream kids that are like food search can free. So all that anybody, while he was doing. I'm sure no one would have heard of. They don't have that age. Very strong. I literally. Anytime they're silent, they come on.

### Guest (2025-09-11T21:33:56.482Z)

They? Come on. It's horrifying.

### You (2025-09-11T21:33:57.443Z)

It's horrifying.

### Guest (2025-09-11T21:33:59.842Z)

It's awful.

### You (2025-09-11T21:34:00.243Z)

I got to step away for one minute. I'll be right back.

### Guest (2025-09-11T21:34:02.242Z)

Okay?

### You (2025-09-11T21:34:02.483Z)

Okay? I'll leave everything running.

### Guest (2025-09-11T21:34:03.442Z)

All right. Okay, I'd like to. Just two more. Maybe one more minute, and then we'll start.

### You (2025-09-11T21:34:05.043Z)

Okay? One more minute. And then roll cards.

### Guest (2025-09-11T21:34:14.722Z)

No way anyone needs to be. We're good. I'm going to jump on the other call. Just to see if anybody's there. Thank you. We have a mock coming in. Hello. How's it going? Good. How are you? Good. Great. Okay. This is a serious crew we got going on in the head, the A team.

### You (2025-09-11T21:34:35.763Z)

This is a serious group.

### Guest (2025-09-11T21:34:42.962Z)

We have one more. Howard, do you know if the node is joining? A chance.

### You (2025-09-11T21:34:47.603Z)

I don't know.

### Guest (2025-09-11T21:34:48.882Z)

Okay? Well, why do we get started? Because you have a quorum here with four of us, and there's one of our co founders maybe a few minutes late. You met me, right? And we did the demo. So why don't we do mind to avi introducing yourself and then Drew and everyone else just do a quick intro of yourselves as well and then we can start the demo.

### You (2025-09-11T21:35:11.043Z)

Just do a quick interim of your pelvis as well.

### Guest (2025-09-11T21:35:16.002Z)

Okay. Love that. Okay? Yeah. So I'll start. I'm from london originally. And that's why I'm cool. No other reason.

### You (2025-09-11T21:35:24.403Z)

That's why.

### Guest (2025-09-11T21:35:27.522Z)

And I've built a company that creates interactive decks. I'm very excited to show you guys about it. We've been around for a couple years. And I'm excited to work alongside you guys. I don't know. There's enough. We're good. You'll get to know me more. It's all right. Well, abigee. Do you mind, though? Your team is still very. It's your soul in an early stage, right. And you're a very small team like we are.

### You (2025-09-11T21:35:53.123Z)

I.

### Guest (2025-09-11T21:35:56.162Z)

Yeah, we're five people. And yeah, we're pretty early stage, but I hope we're always at an early stage. It's kind of one of those where we want to be lean operation always.

### You (2025-09-11T21:36:04.243Z)

'm.

### Guest (2025-09-11T21:36:15.202Z)

So we. We are an early stage in as much as, you know, the company's two years old and, you know, we've kind of been growing our team slowly but surely over the course, over the last, like, six months.

### You (2025-09-11T21:36:17.043Z)

In as much as the average company. Of course. Like, six months.

### Guest (2025-09-11T21:36:28.802Z)

Prior to that was just me.

### You (2025-09-11T21:36:28.963Z)

Prior.

### Guest (2025-09-11T21:36:30.402Z)

But, yeah, that's. That's us. Okay, great. And, Drew, do you mind going next?

### You (2025-09-11T21:36:32.963Z)

Okay? Great.

### Guest (2025-09-11T21:36:35.762Z)

Yes. So my name is drew wallace. I have my own company separate from this that does. It's. It's very complimentary to investai business intelligence data analytics for hotel investors.

### You (2025-09-11T21:36:41.843Z)

Separate from that. Analytics program.

### Guest (2025-09-11T21:36:51.042Z)

So what investai is focused on is more investment management. Acquisitions, underwriting. What my company does is more of like your operational asset management. Working with asset managers and operators to aggregate different data and do analytics on it. I've been doing that for about five years. What's the company? Cool hotel business intelligence solutions. Business and some of those traditions. Howard.

### You (2025-09-11T21:37:28.403Z)

Yeah. Good evening. Hope we're not keeping you up, too. Howard behrends. In charge of the product. Been in the prop tech product management space for about 15 years. And prior to getting into the tech side. I was actually in commercial real estate for about 18 years prior to that. My background. Is multifamily of Harvard communities. So the hotel world is new to me. But it's real estate is real estate. Still brick and mortar. And everything else. So happy. To be here. And good to meet you.

### Guest (2025-09-11T21:38:13.362Z)

Likewise. Likewise. All right, Mark jumped. Up. Just in time. Okay? Well, he may rejoin, so why don't we just go ahead and get started? Ok. So I love the variety of hits. I think this is great. And hopefully we can kind of. The node is going on now. Here we go.

### You (2025-09-11T21:38:35.763Z)

There we go.

### Guest (2025-09-11T21:38:39.682Z)

We were just doing intros and getting ready for the demo. Sorry for being late. I just reached back. No problem. You know it is our chief technology officer. And all things software engineering, technical Benode and Howard's territory. And then Mark and Drew and I are more on the business side.

### You (2025-09-11T21:39:01.043Z)

And I know on the big slide.

### Guest (2025-09-11T21:39:04.242Z)

Okay. Nice to meet you.

### You (2025-09-11T21:39:04.483Z)

Okay?

### Guest (2025-09-11T21:39:07.042Z)

Likewise.

### You (2025-09-11T21:39:07.283Z)

Likewise.

### Guest (2025-09-11T21:39:08.082Z)

All right, so, yeah, so, like, serious variety over here. My goodness. Okay, so you'll all be able to, you know, pick apart our product from various different angles and hopefully enjoy it from various different angles.

### You (2025-09-11T21:39:08.163Z)

All right.

### Guest (2025-09-11T21:39:20.562Z)

Too, so.

### You (2025-09-11T21:39:22.323Z)

So.

### Guest (2025-09-11T21:39:22.722Z)

The thesis behind kind of the Consultant interactive deck.

### You (2025-09-11T21:39:24.003Z)

I can.

### Guest (2025-09-11T21:39:26.482Z)

Is relatively simple. The. The commercial real estate. And, Howard, you'll notice better than anyone here.

### You (2025-09-11T21:39:30.483Z)

Commercial real estate. And how a business.

### Guest (2025-09-11T21:39:35.522Z)

Do you want to know what's the industry? And as well as kind of many other private investing industries have been using the same method of presenting deals to investors.

### You (2025-09-11T21:39:37.923Z)

Many other. Investment.

### Guest (2025-09-11T21:39:45.922Z)

For the past 30 years. Right, you'll have come across. There you go. Howard is attesting to this.

### You (2025-09-11T21:39:47.843Z)

S.

### Guest (2025-09-11T21:39:54.322Z)

Right. The old PDF in an email attachment method.

### You (2025-09-11T21:39:58.483Z)

In an.

### Guest (2025-09-11T21:40:02.002Z)

Which. You know, I kind of. I like to bring myself back to 1993, which is on the PDF.

### You (2025-09-11T21:40:05.683Z)

I like. Myself back.

### Guest (2025-09-11T21:40:10.882Z)

Was invented. And think, like, yeah, you know, that was probably really cool.

### You (2025-09-11T21:40:12.003Z)

And think like, yeah.

### Guest (2025-09-11T21:40:14.962Z)

When instead of, like, having a piece of paper, you know, or a little booklet, like, suddenly you were able to put that book on the screen. That was probably awesome in 1993.

### You (2025-09-11T21:40:16.243Z)

Instead of. Suddenly. Network on the screen.

### Guest (2025-09-11T21:40:26.642Z)

However, it's no longer 1993.

### You (2025-09-11T21:40:26.723Z)

However, it's no longer.

### Guest (2025-09-11T21:40:30.162Z)

It is now 2025.

### You (2025-09-11T21:40:30.563Z)

It is now.

### Guest (2025-09-11T21:40:32.562Z)

With 32 years on, and somehow still we're, you know, we're getting excited about the, you know, the PDF, and we still haven't moved on from the PDF being the chief way of presenting information to your investors.

### You (2025-09-11T21:40:34.883Z)

And somehow. PDF. Chief way of.

### Guest (2025-09-11T21:40:51.042Z)

And as anyone who has any sort of technical bones in their body, And I feel like Vinod has turned off his camera because he's laughing so hard. And the notion of people still using Vs and I'll never get there.

### You (2025-09-11T21:40:56.723Z)

Turn up.

### Guest (2025-09-11T21:41:05.202Z)

Love that.

### You (2025-09-11T21:41:05.843Z)

That.

### Guest (2025-09-11T21:41:07.602Z)

And, you know, as soon as you think about it for more than a second, it's just nuts, right? It's ridiculous that that's how we're communicating, especially considering the fact that when it comes to communication technology as a. As a species, we're actually really, really good at it.

### You (2025-09-11T21:41:07.763Z)

And. If you. Communicate. About? When it comes. To technology. As a. Way.

### Guest (2025-09-11T21:41:24.562Z)

Right? I mean, the fact that there are five of us speaking face to face from various different corners of the world.

### You (2025-09-11T21:41:29.123Z)

From various. Corners of the world.

### Guest (2025-09-11T21:41:34.242Z)

Is an amazing proof that we are incredible at communication.

### You (2025-09-11T21:41:37.683Z)

Communicate.

### Guest (2025-09-11T21:41:38.882Z)

Technologically speaking.

### You (2025-09-11T21:41:39.043Z)

Technology.

### Guest (2025-09-11T21:41:40.082Z)

The fact that you can log onto your phone and, you know, type of post that, you know, suddenly goes out to thousands, and if you're really famous, millions of people in one shot.

### You (2025-09-11T21:41:40.243Z)

The fact that you. Type of.

### Guest (2025-09-11T21:41:50.882Z)

Is just proof that we are incredible at communication.

### You (2025-09-11T21:41:51.843Z)

Group that we all be.

### Guest (2025-09-11T21:41:53.842Z)

Right? You can send instantly. You can send videos and images and emojis to your grandmother. Like, we're really good at communicating and communication, technologically speaking.

### You (2025-09-11T21:41:54.243Z)

Right. Video. S.

### Guest (2025-09-11T21:42:05.442Z)

And yet, when it comes to the gazillion dollar industries that are real estate and investing kind of more, more broadly.

### You (2025-09-11T21:42:07.043Z)

When it comes. Real. And investigate.

### Guest (2025-09-11T21:42:17.842Z)

We're stuck in 1993. And it's kind of like.

### You (2025-09-11T21:42:19.923Z)

And. Difficult.

### Guest (2025-09-11T21:42:22.722Z)

For God's sake. Like, that 's kind of how I. How I frame the problem over here. It's like. Like, seriously.

### You (2025-09-11T21:42:29.283Z)

Seriously.

### Guest (2025-09-11T21:42:30.562Z)

Anyway.

### You (2025-09-11T21:42:30.643Z)

Anyway.

### Guest (2025-09-11T21:42:32.002Z)

I. So I was my, my background kind of career wise is that I was working as an investment broker. So I was, I was doing institutional capital raising, took my real estate deals and primarily multifamily, but also with a lot of hospitality and industrial, all sorts of different commercial asset types. And, and my job was made much more difficult than it had to be.

### You (2025-09-11T21:42:35.923Z)

It kind of draws. Usually. But also.

### Guest (2025-09-11T21:42:56.002Z)

And presumably, you know, most, most of the people here will understand this, like. If you're presenting a 75 page PDF to an investor alongside this big, complicated spreadsheet. You know, and all sorts of other different, you know, tongue sheets and accounting documents and, you know, renderings and architectural. Right. Also you kind of plonking it all in the inbox of an investor, and then you're turning to that investor and you're saying, you know, do you mind reading all of this? Information and making a decision based off of it.

### You (2025-09-11T21:43:14.883Z)

Other different. Investment, and then you'll cut into that.

### Guest (2025-09-11T21:43:35.922Z)

On, you know, as to whether or not you're going to invest $30 million into my deal. It's not surprising that most investors, a lot of the time, are just going to be like, I've read the first line, and I'm, I'm not bothering. Right? Because it's so much work and so much effort to read all of that information that it's just, it's not worth it. Like, why on earth would you, would you put in so much effort into something that you're not necessarily going to. Going to do? Right? And so what we basically said as a. As a kind of young bunch. We. We said okay. People spend approximately seven and a half minutes a day. Okay. The average person spends seven and a half minutes day reading text. Like reading. People spend two and a half hours a day. Flicking through social media. Right? That's like 10 times the amount. And so we kind of said, well, what if we stole a whole bunch of principles from social media? And figured out why social media is so compelling. And so addictive and so engaging in terms of information. What if we stole a whole bunch of ideas from there? And applied them to commercial real estate deals.

### You (2025-09-11T21:44:52.963Z)

Commercial.

### Guest (2025-09-11T21:44:55.202Z)

Right? And thus was born the interactive debt. Right? That's all to kind of get to what. What we've. What we've built out.

### You (2025-09-11T21:44:58.003Z)

Interact with.

### Guest (2025-09-11T21:45:04.802Z)

And we basically realized there are three things. And I'll run through this really, really quickly and then show you. There are three things that social media does brilliantly that regular text cannot do. The first. And they all begin with a. So you should be able to. And the first is. And Mark is back. The first is attention. We call attention, which basically means things move, things are vibrant. There's something. It's interesting, right? We love looking through things, you know, through social media, at vibrant pictures and images and, you know, people doing ridiculous things. Like, we're very. We're very into that, right? Our brain is very. Easily tripped by movement.

### You (2025-09-11T21:45:33.523Z)

The skin.

### Guest (2025-09-11T21:45:48.882Z)

And the second thing is access. Okay. And so this is a little bit more of a complex concept, but it's basically that people love flicking.

### You (2025-09-11T21:45:52.723Z)

This is a little bit more technical than basically.

### Guest (2025-09-11T21:45:59.122Z)

Okay. People love to have the access to explore, right? So you click Read more if you like. If you like a post. And you have access to ignore. You flick straight past the post if you're not interested in digging in. Right. And so that means that what social media does that book can't do, is that it? It presents a small amount of information and you make a decision as to whether or not you want to. You want to read more and kind of dig deep into that.

### You (2025-09-11T21:46:07.603Z)

Inflict. Ing. Out that look. S. Addicted to the.

### Guest (2025-09-11T21:46:25.682Z)

Piece of into that post. Right. Whereas if you don't, it's very easy to flip past right here, this access to way more information, but without getting slapped in a face by it. And the final one is action. Right. And this one actually really is interaction.

### You (2025-09-11T21:46:33.923Z)

Way forward.

### Guest (2025-09-11T21:46:41.522Z)

And that is that your. Your brain is such that when you read a piece of text, when you read a piece of information, it comes into your brain on the right side of your brain.

### You (2025-09-11T21:46:50.803Z)

That comes into your.

### Guest (2025-09-11T21:46:53.682Z)

And generally it basically just falls out quite, quite soon afterwards. Right. We're very good at reading the book and forgetting all. We just read like, you know, we're not. We're not. Unless we're, like, very compelled by the content, it doesn't move into our brain properly.

### You (2025-09-11T21:47:07.763Z)

Corporate property.

### Guest (2025-09-11T21:47:08.402Z)

Now there is a brilliant way to trick your brain. Or trick people's brains into engaging with the information on a neurological level, and that is something called interaction. So while social media does. Which is this kind of brilliant stroke of genius that Facebook came up with in 2009, which is they add a little button. Right. It looks kind of like this. The. The like button. That you have to. It means that you have to interact with. With every post that you see. Right. And what do I mean by that? You either like the post. Right or you don't like the post, but either way, you have to make a decision as to whether once you have looked at this information, you now have to make a decision about it.

### You (2025-09-11T21:47:43.603Z)

You have to make it to success.

### Guest (2025-09-11T21:47:50.562Z)

Do you like it enough to press the little thumbs up button, or do you not like it enough? That you're gonna flip past it. And what that does is it actually brings it into a different part of your brain, from the right side of your brain to the left side of your brain. That's low prime memory. And it's also actually much more addictive. That's where all the chemicals, like, dopamine and stuff tend to be released on that side of your brain, and that's why social media is so addictive and so good, actually.

### You (2025-09-11T21:48:07.843Z)

Like german.

### Guest (2025-09-11T21:48:16.642Z)

Anyway, having said all of that, Our thesis very simply to kind of summarize, is if we can make a boring document.

### You (2025-09-11T21:48:22.883Z)

Doing good.

### Guest (2025-09-11T21:48:28.322Z)

Much less. Boring in terms of just text and images, and much closer to what a social media scrolling feed. Looks and feels like, then you're gonna get a lot more engagement from the people reading it. Okay? Let me show you one. I hope when you see it. You will understand. Even better. I'm actually gonna. I'm gonna refresh the page over here. Because I want you to. I want you to see that there's. There's immediate movements. Okay, Do I need to zoom in a little bit? There's immediate, there's media movement in terms of this kind of typing out. We do for some of our deals, like we'll put in a video on the, on the front page, right? This one, this student didn't have a video. The one Diane I showed you. Oh, that was a great one. You showed me the hospitality one. Yeah. So I'll show you that one in a second, but I want to show you this one just very, very quickly. Okay. So there's a couple different things that I want you to notice. Okay? So number one, things move. There's constant animation. Number two is access to way more information. Okay, so what happens over here is that you get a kind of basic snapshot of the executive summary. You then click into this full summary thing and you get to read more information. Right. I always joke that investors are an inherent contradiction.

### You (2025-09-11T21:49:47.283Z)

Information.

### Guest (2025-09-11T21:49:53.522Z)

Both want a lot of information because they want to know the deal has a lot of, you know, research that's gone into it. There's a lot of detail behind it. There's a lot of analysis that's gone into it, but they don't want to read any of it. Right. So what? You have over here is you have the kind of clarity aspects of it. Kind of, you know, snapshot version. Followed by lots and lots of detail and people can read through. And that's the theme essentially, of, of the entire, of the entire deck, right? Where you have simple, you know, kind of easy interfaces where you can click in and find out much more information about the timeline of, you know, of construction. Right. So if I were to have all of these open, that would be a lot of information that's slapping in the face. When you're able to click into what you care about. And, you know, expand or collapse the various areas of interest, you kind of, you know, slap yourself in the face. With information, but no one else has to do it for you. And you know, the same is true when it comes to things like this, where you can, you know, portray entire portfolio s with simple, nice sliding, as well as, you know, clicking to reveal more information. You know, there's tabs that you can go across. I was like, you could. This one slide has just a ridiculous amount of information at the hit. There's, like, I think, like, 10 to 15 properties on each of these things, and each of those properties. Has its own, you know, set of. Set of information that's associated with it. So there's a lot going on over there, but very simple, very easy to use. And again, that's the idea here, right? So over here, you get, you know, you get faced with Jack Roberts, lovely face and his title. If you want to read all about Jack Roberts and what he's been up to in his life. You click on his card? It now gives you lots and lots of information about agrobits. And that's great if you want to know all about Jack Roberts. And if you don't, you move on. Right. That's kind of the way that this all goes. I. I'll show you very quickly. Well, you can. You can see this with interactivity, et cetera. I'll show you the deck that I had showed Diane, because it's. It is indeed, hospitality deck. So this is a. This is a resort that's being built in Jamaica. We're there for seasons and in one hotels, etc, etc, and then you get to see, you know, this, this concept really at work. Right. So lots of information over here. Plenty to, to dive into and, and, and explore. But here's a snapshot. There's no need to go beyond what, what you absolutely want to. Feel the need to. Okay. And you move along over here and kind of carousel form. Very easy to navigate, very simple. Look. You know, I feel like you guys are getting the point. But, yeah, you know, again, if you've been in this is in that. Here we go. Right. So you have the map, and you can, you know, play around with the map and interact with the map and even use the. The. This guy. Who doesn't. Who doesn't love this guy. You know, and now you can use them directly online. Thank you. Director itself. Right. I need to make it bigger. And you can make it smaller. Etcetera. What. What you will essentially, hopefully start to realize is that. Investors experiences of interacting with deals. Is going to change markedly. Right. Investors will have a much more enjoyable time interacting with deals. And that is going to be significantly. It's gonna be. It's very, very valuable to anyone who's presenting deals to said investors. The last thing I want to show you is this, which is. Old numbers. Right? Apart from the fact that this entire deck is live, and whenever there's a change made, people are seeing the most up to date information. This is even more live you guys can go into the back end, change a number, and it automatically populates into the deck. And so if something changes in terms of you know, whatever you're you're doing you get a discount on the land or or or the development cost change or you know, whatever whatever it is, numbers that changed, you can put that in directly, and it automatically populate populates in the deck. It's it's a it's a real game changer. As far as the industry is concerned. Yeah. That essentially is that. There's there's more I could talk about As you could probably tell, I could talk for hours about this kind of But The story We go back to so the video piece of it and then the drill down into numbers, those are two very different things. But can you speak to that a little bit? Because you know, we're starting to, I I mean, this video is great. Right? Video content is really what's capturing people's attention these days. And then also, you know, we're very focused on the fact that our our platform will actually will be drilled down into numbers as well. Via a cloud based AI platform. Yep. And then pull that into someone's underwriting model. And so could you just maybe talk a little bit more about those two things? Yes. Okay. So video is certainly a simple one. I'm gonna actually pull up. I just pulled up a different deck. That where this guy this is a kind of multi family development deal, but what this guy did is he filmed a video of himself at the site and I mean, the best is not quite it's not Hollywood actor level. But he certainly, you know, is standing in the right place. Which is the Agda site, and he's talking about the site. Right? And it's a it's a very compelling way of being able to tell investors about about the the project or whatever it is. Of course, the the point over here is to recognize that our video capability, right, you can create a a really really great video. And and put plunk it in right over here. Ultimately, the the the technology is all about the ability to add video into into the deck itself. As far as the numbers go, and and by the way, that you know, like, video in the background of things. So, you know, so you'll have seen on the over here. You know, to have to have video in the background is it it's subtle, but it's you know, but it it draws the eye in. There's lots of different decks that we've done various different you know, types of videos and placements of videos, etcetera. The as far as the numbers go, Okay. So just help me understand, Diane. Your creating you and what what what exactly does the AI do ultimately? Well, if you are familiar with someone different platforms, what we're trying to do is create pipeline manage initially, this is the initial module. Is pipeline management combined with an AVM under So it's like a deal path plus a redIQ. Or a deal path plus an archer. And then our future modules will be will also involve, like, renovation costs, which are pips. They have a big brand component. Right? You were talking about Four Seasons and things like that. Like, the brand brand piece is very big. For hotel investors, and we will be looking to see if we can create some sort of integration, like, with Procore or you you know what mean? Gonna be looking about integrations, future integrations with Harvey on the legal side. So we're trying to become command central for hotel capital markets, if that makes sense. Yep. And at some point, we would really like to if you fast forward five years, our vision is to be a marketplace where hotel deals actually transact because we have these decks. Right? And so a pain point I've had as an investor is you get a deck like this in PDF format from a broker and then you need to capitalize a deal. So you have to create a pitch you know, another PDF book that you have to send out to 15 or 20 investors while you're trying to capitalize the deal. You have to send it to lenders. Right? And so there's multiple pitch books floating around about the same deal that took a considerable amount of time to create. And then if there's an error, I mean, just I mean, I it's just I I have felt the pain of creating or having been on maybe, I'll say, like, the disposition side and having to review a broker offering memorandum and catch it all and write. And it's such a just such a static old process. And so we ourselves are trying to make that a very dynamic process. And we're we we've got a good grasp of the numbers and the models and things like that. But it's more like the video you know, the yes. The presentation piece of it is something we haven't thought that that much about at this point in time. Is is in some always only as good as the way the present And I think yeah. We have a number of different ways of presenting like, the the the kind of you know, what I showed you over here with this, you know, in terms of collapsible number charts as well as, you know, interactive kind of playing around with numbers. There's a lot that we can do. I mean, you know, graphs like like this that kind of, you know, switch between charts and graph. There there's a ton that we can do in terms of presentation numbers, and that's that's our that's our area of expertise is being able to present complex information with clarity. And then in this Real quick. Just is the content of each debt well, I guess not the contents, but the the mechanism like, the framework into which you're putting the content, is it consistent from deck to deck. Like, I guess, do your customers have to take all their stuff and does somebody have to put it into your framework or is it is there is it more direct? Okay. So the process the process goes that it it somewhat depends on what the client has as far as content. Is concerned. Right? So we have two kind of we we have two options of, like, you either you put new structure there, the content and you just provide you provide us with the ready made content, and we interactify it. Right? So we we design it and then we put it into interactive form. And the other is you give it to us entirely raw, and we put together the content and the structure And and then that, do the design and the and the tech implementation. And the the process is extremely simple for the for for you guys in as much as we do all the heavy lifting. And we have so so we we do create we create custom code for every deck, but we also have some stuff that's kind of templates there and, you know, we're we're we're changing the design for every deck. So the process on our end is is a it yeah. It's a creative process, but also a systematized one. You know? We try and try and find the right balance. You know?

### You (2025-09-11T22:02:28.065Z)

So, Drew, I had a

### Guest (2025-09-11T22:02:28.681Z)

Got it. Okay.

### You (2025-09-11T22:02:30.165Z)

I'm sorry. Did you have another question?

### Guest (2025-09-11T22:02:31.141Z)

Sure. Go ahead.

### You (2025-09-11T22:02:31.805Z)

Yeah. I was gonna say I had a very similar thought. Excuse me, while I plug this in. About the data

### Guest (2025-09-11T22:02:39.381Z)

Yeah.

### You (2025-09-11T22:02:40.795Z)

So as I'm as I'm looking at this, what I'm seeing is a tool that would be almost exclusively for a broker.

### Guest (2025-09-11T22:02:49.651Z)

Yeah.

### You (2025-09-11T22:02:51.005Z)

Right?

### Guest (2025-09-11T22:02:51.751Z)

Like it'd be perfect for a broker.

### You (2025-09-11T22:02:53.355Z)

Perfect for a broker. But you're gonna have multiple data sources, most of which are outside of InvestAI. We'll have

### Guest (2025-09-11T22:03:04.661Z)

Yeah.

### You (2025-09-11T22:03:04.865Z)

financial data, and market data. We'll have the numbers but all of those other slides that have the photos and everything else that will be coming from a broker. And I'm gonna I'm gonna kinda play devil's advocate here for a minute because I can tell you that there will be an issue of data sharing. So how how do we get our data the financial data, which is the most sensitive, from us to you and then the broker would get it. That's that's a kind of along the way of or the the line of Drew's question is, where will this data reside? Do we have to give transfer the data to you? Or would it all reside on our servers? I'm just questioning how would this would be coordinated between multiple multiple entities. Right?

### Guest (2025-09-11T22:04:05.471Z)

Okay. So I I'll as far as where the data stored, yeah, you get you you definitely have to share the data with us. And it gets stored within our system. However, it doesn't go beyond that. Right? So it's get it's it's you know, we're happy to sign confidentiality and stuff like that. You know, we we are essentially I mean, you can think of us as a graphic designer in a sense. Like, show your data to the graphic designer in as much as they need to be able to present the data, because otherwise,

### You (2025-09-11T22:04:34.135Z)

Yeah.

### Guest (2025-09-11T22:04:34.501Z)

they'll we'll be we won't have anything to present. But, yes, it will get it'll it's all stored within our servers, but that it's it's well protected and

### You (2025-09-11T22:04:43.665Z)

Yeah.

### Guest (2025-09-11T22:04:45.221Z)

yeah. Not not to be shared elsewhere. As far as it being a a good tool for brokers, I I think you're right. It is a great tool

### You (2025-09-11T22:04:48.305Z)

Okay.

### Guest (2025-09-11T22:04:52.531Z)

for brokers. It's also a wonderful tool for people who are raising capital. Right? And that that actually is our on the real estate the kind of multifamily and stuff. Side of things, that's our best use case right now is operators and and general partners who are syndicating funds or raising capital that are going to investors and presenting them this data. And and this this interface. We've yeah. Thank god. We've seen a lot of success in that.

### You (2025-09-11T22:05:19.235Z)

Yep.

### Guest (2025-09-11T22:05:21.671Z)

In that space. Yeah. That that makes sense. It's the other user group real estate that I could see using this. I mean, it looks like that's the one that you know, the ones you showed us are all GP, your default, or your voice capital. Yeah. Very interesting tool, Avi. I'm just curious to understand few more pieces of it. How about that download PPM? Does it download a PDF or PPT version? And what about the QR code? So the the data PPM data PDF version, although we can hook up anything we want to it. It just happens to be a PDF on this one. The QR code pulls up a QR code. So the reason that we have a QR code over here is that people who are because because we're creating mobile version as well, so anyone who is kind of presenting on screen or something like that, can say, okay, everyone whip out your phones, scan this, and and you can follow along. That's that's the reason we have it. Makes sense. Yeah. But it go it goes it goes to the same site. Okay. How does it get delivered to the client? Right now, I see a site called vbvvec Yeah. Something. So is that the incline or that's you who is kind of That's the client. That's the client's name. So we we create a custom domain to the client. And that is where the is that's where it lives. And we make sure, by the way, that it's it's all non non indexable So so that search engine search engines can't pick anything up, which kind of goes back to the confidentiality thing. And spam bots can't can't access or anything like that. Got it. That makes sense. Can you connect, like, say let's say something like this, you know, restaurants, very important if you have a high end restaurant in a hotel that you're tracking its social media, you're tracking its TikTok views and things like that. Does this have a sophistication to be able to pull like, live you know what I mean? Live streams of of what's getting posted. About the hotel, the resort. I mean, so there's some hotels where that's not at all critical, like, you know, a a mundane, mid scale extended stay hotel. But there are other hotels where the f and b needs to be very, very dynamic Right? And you're trying to create impressions and things. So do you can you connect with this with social media? Directly? That's a really good question. That's a really good question. We've never tried. But I'm sure we can. We can give it a go. I love that use case. Yeah. That's fun. And for my team, also, just I just you know, when we saw the person that was gonna tour tour this property, I just wanna mention and and put the idea out there that you know, disposition work is very hard, and it takes a big toll on the operating team, especially the general manager and the of sales to have to tour all those people through the hotel. It's stressful. They feel stressed. They feel like they're gonna give out wrong information. And I could really see a future where, this gets kind of created where the operator, right, just does one video, and it's very comprehensive. And maybe there are some interviews with the director of sales and marketing, and, you know, you can start to use unstructured forms, to capture that voice video and and things, which right now, again, it hasn't changed in over thirty years. And I've been on a new broker tours with prospective buyers just to know how strong you have, you know, eight to 10 people trekking around a hotel day after day after day for a period of two or three weeks. It's just I I think this could be like, this the concept of trying to create more of this in the cloud. Really help the transaction industry in general. I I think you're absolutely right. We actually I have a partnership with a company that does interactive tours Mhmm. Where where they essentially have like, you click a button and then you you get the the tour, and then you can choose which room you wanna go to next. Then you can click on people and ask them questions, that kind of thing. As we do have a partnership with that, and if if you were interested in kind of offering this up, having conversation with them, can happily hook you up. That's a group from The UK. Yeah. Very cool group, actually. Mhmm. So so I'll make that intro if you're interested. Yes. Thank you. Yeah. We would like that intro. Right. Great. Happy, Ali. So, yeah, there there's a lot that we could do over here. In terms of interactive presentation. Let let's talk very quickly about business. How how can we integrate this into your offering what what were you envisioning? So what we had talked about before is, again again, having been on the sell side, a broker OM would cost anywhere from 10 to 15 k traditionally. Yep. And you pay that regardless of whether the hotel transacts or not. I think you were talking about your pricing strategy. Right? And so your pricing strategy is around 5 k. I remember. Right? So that Correct. The platform is using this has the ability to maybe mark it up and then almost replace what a broker can provide. For the the same amount. Right? It is that that's essentially what we had talked about. That's exactly Right. That's exactly right. And right now, you are working across property types, and we saw that beautiful resort, but you're doing work in all all sectors, multifamily. Industrial office. Right? Right. All all the sectors. Correct. Right. Correct. As well as as well as investment banking, as well as start ups. Yeah. We're we're trying to yeah, take take on the full private investing gamut. Right. Does your platform have the ability I saw a platform few years ago. It was called Zach. And that was designed to improve board meetings. And so the text was very much like you would read online with blue links. It could take you to source documents. Does your so, like, for example, say you're looking at a resort in or a property to buy in Boca Raton, Florida, and you have all the supply and the comps and everything like that. And a new story pops up about, you know, a new property being proposed to be built and you wanna go read that article. Is it do you did your platform have that, or do you see that functionality in your road map? Going forward? Does that make sense? Like, kind of like the idea that the way people read now is we've gotten so used to reading news stories the way they're formatted on the screen with the click through ability to get to the original source. Document. Mhmm. Do you that makes sense, right, what I'm trying to explain? Yeah. What I I think what you're saying is hyperlinking to the original article, which is absolutely that we can that we can do very easily. Yes. I wanna jump in real quick because we're we have a usual weekly call that is that, you know, we're we schedule this during our usual weekly call. I Dan, I wanna be able to follow-up on is it but mean, this is very interesting. I think what you've done is really impressive. We're still very much in the development stages of, like, what we're of the of the product. And I think there's definitely potential fit particularly if there's customer overlap. I can you send us some of the things like if you I mean, link to your site or some some follow-up information or something like Certainly look at cross selling opportunities for in the near term. Until we're in a position where we have the complementary features that would fit, you know, like, into what you're talking about. It could be it could there would certainly be, like, a white labeling opportunity or something like that. But in the short term, again, that that's, like, several months away for us. So in the short term, it would be great, like, if, you know, to to get to cross selling. I think there's a lot of hotel, hospitality brokers, that could leverage this hospitality investors that sort of thing. Yeah. Happy to help collaborate collaborate with you on that. And vice versa, if you you know, talk with your development groups, brokers, etcetera, you know, please keep us in mind as potential, you know, potential customers. Absolutely. Yeah. I love that. I think that's great. I think your product is really impressive. It's nice. It's really Thank you. Thank ninety three. We're with you on that. Yeah. Yeah. Alright. Well, I appreciate it. Bye. Yeah. Yes. Alright. Bye bye.