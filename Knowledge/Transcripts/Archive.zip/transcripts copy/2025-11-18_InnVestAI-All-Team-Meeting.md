# InnVestAI All Team Meeting

**Date:** 2025-11-18 00:00:00 UTC
**Meeting ID:** ff95e6e2-6f46-4595-9a67-baab3270c6ca
**Synced:** 2026-02-05 14:54:33

---

# Transcript for: InnVestAI All Team Meeting

### You (2025-11-18T22:30:59.876Z)

Hey.

### Guest (2025-11-18T22:31:03.075Z)

Hello. I think it's Tuesday.

### You (2025-11-18T22:31:09.716Z)

That's embarrassing. I can't even keep.

### Guest (2025-11-18T22:31:11.955Z)

But I'll take a happy Monday. Any happy days Good.

### You (2025-11-18T22:31:14.836Z)

Yeah, that's right.

### Guest (2025-11-18T22:31:18.595Z)

Day. Happy Monday.

### You (2025-11-18T22:31:20.276Z)

Yeah, I did. What? It is the same.

### Guest (2025-11-18T22:31:26.915Z)

Yes.

### You (2025-11-18T22:31:28.836Z)

Working from home, not going into the office. They just kind of, like, blend into each other.

### Guest (2025-11-18T22:31:29.235Z)

I agree. Yeah. Be thankful you don't have three kids throw in the mix. Where? I'm assuming you don't have three kids to throw into that mix.

### You (2025-11-18T22:31:42.356Z)

I had three kids, but they're all groomed. On.

### Guest (2025-11-18T22:31:45.875Z)

Oh, all right. Well.

### You (2025-11-18T22:31:53.636Z)

Youngest doctor just moved out. August. Mid august.

### Guest (2025-11-18T22:31:58.195Z)

Nice. Got, like, a big transition.

### You (2025-11-18T22:32:03.236Z)

Yeah, it is for her. But, yeah, officially entered the empty nester group. There's.

### Guest (2025-11-18T22:32:13.795Z)

Nice. Hit. Node. I think we should think about finding a different time because. This time is no more working for me. Yeah. And Friday would be best. And then I can do it anytime during the day. Tuesday and Fridays, then. At Thursday and Friday. Thursday or Friday. I think we should just do it one day. One day. Yeah. Well. Let's see. What the needs are after we figure out what we're doing here. I guess we'll know. Diane's note taker is on here, so I'm assuming. She's reading these things. Where is diane? Have either of you guys talked with her? I think Howard was saying, she's in Miami, right?

### You (2025-11-18T22:33:20.356Z)

She mentioned something last week about that budget. Meetings.

### Guest (2025-11-18T22:33:25.955Z)

She hasn't been in a call in quite some time, right?

### You (2025-11-18T22:33:28.276Z)

Yeah, it's been a while.

### Guest (2025-11-18T22:33:29.635Z)

How long has it been?

### You (2025-11-18T22:33:35.236Z)

I don't think Machine either of the calls last week. Was she on last Tuesday? Maybe. We did okay. Yeah. So, what's been a while?

### Guest (2025-11-18T22:33:41.235Z)

Now. I don't think so. Yeah. All right. So. I said in that in my prior email. Right. Or I think we have talked multiple times now about. I guess. The sort of roadblock or obstacle or that we're at as far as how we proceed. I think at this point, it seems like. Diana's executed the safe note with first wood and. I don't know if she's already getting paid the money directly to her personal account or not. I would. Does anyone know? Yeah. Do you guys know if she's doing that?

### You (2025-11-18T22:34:41.156Z)

She has been disgust. Ed.

### Guest (2025-11-18T22:34:44.275Z)

I don't know either.

### You (2025-11-18T22:34:46.276Z)

The only thing. November and December. We're going to be installments. And I don't know if January is going to be just lumps on the boards for us. What is left or not? I don't know. That's as far as pyramids. That's all I know.

### Guest (2025-11-18T22:35:03.475Z)

Does anyone concerned about that? I mean, ideally, that's all amount should come to the InnVestAI. And I think what Drew suggested is the right approach. If she needs, we could loan her and then, you know, however we could manage afterwards, either she gives back or whatever best way possible. But, yeah, I think that's the ideal way. Which. Doesn't seem like it's gonna happen that well. Yeah. I mean, we would. We. Ultimately really just need her to be present so and explain to us what has been going on on her end. We also need some kind of. Communication with Driftwood at this point. Has anyone spoken with Trifwood?

### You (2025-11-18T22:36:01.476Z)

The only time. Way back in. I'm going to say April. She set up a car with Manny. Who's your cto? And then. At a later date we had. A larger team call. I think we had more of them.

### Guest (2025-11-18T22:36:26.995Z)

I never spoken with any of anybody from there.

### You (2025-11-18T22:36:29.076Z)

Okay? All right. I don't go back and see who was in attendance? I thought we had more than just Diane and myself on it, but, yeah. There were two calls, but that was way before any discussions about the safe note started.

### Guest (2025-11-18T22:36:47.795Z)

Bereno. Have you spoken with them? No, never. Haven't. Yeah, same. So what are they invested? It's what? So what did they invest in if they haven't spoken with any of us? Yeah. I mean, at this point, I mean. Howard. I know we spoke yesterday. You know, Mark and I have spoken as well. I'm sort of at a loss. For what to do here. The company, obviously. Is supposed to act like we are supposed to be a team and design. We're not just a team. We're partners in the business. Yeah, business partners and all owners in the company that have invested time and money. And food is now a part of that. But it's unclear what their expectations are. Whether they are going to pay us or pay Diane. So I'm. And the company needs, obviously, money to continue. Right? I'm not paying anymore. I'm done. I mean, the team in India, any of the product, any of it needs money. And also, I mean, in addition to that, I mean, you know, because we're partners in this business. We have certain responsibilities and liabilities to driftwood. And we don't really even know what those are. At a minimum, we're responsible for the taxes. For the money that Driftwood gave us. Yeah, just so everyone's aware of that. Yeah. Diane takes 15, 16, $17,000. And she takes all of that as. Distributions. We collectively as a company. I'll have to pay taxes on it. If it's taken, we're all on the hook for 20% of. That 75,000? Yeah. Taxes associated with that. Yeah, and we need to find a CPA or somebody that can do those books for us. So. One of the times where we discuss is. Get the llc agreement signed. Or agreed to signed open a bank account. Benode Howard. I mentioned that in my email, but you guys both sounded like. You were up the mindset to give Diane more time. Which. I don't necessarily know if there's any benefit to that. Again, I think more time for what? Yeah, and that was kind of my more time. For what?

### You (2025-11-18T22:39:43.876Z)

I was not guessing to give her more time that she's going to be in Miami this week and probably wouldn't have the time. To. Look at it. Or. Would wait until she gets back.

### Guest (2025-11-18T22:39:59.635Z)

Yeah, right. The bottom line is that we all have other things in our lives. And we're all finding time to join this call at 5:00 or whatever the time zone is. So I just. It's. It's concerning. That she's not on these calls. Yeah. So a couple of things. One is I said, let's give one more time because I'm not sure. We can just sign without her and, you know, move forward. She needs to sign as well, right? And what terms is she gonna sign on? Because we already have conflicts. Whether, you know, she wants to review more, she has more points to add or whatever, right? I do not want to sign something that is not finalized. That's what my, you know, keeping time meant, right? But no the proper protocol. Is to sign these documents before we're signing save agreements. Because the SAFE agreements are supposed to be subject to documents. That talk about how this company is governed. So, yeah, we've gotten ourselves in a position where someone has signed a safe agreement and we don't really have any rules to govern what that safe agreement is subject to. Yeah. Mark proper would have been the day we all five people got together. And probably we should have said LLC sign within a week or so. Which we haven't. We, I think with this, with this LLC agreement, if we. Are going to proceed with the business, we just have to. Diane is not here right now. So we have to. I think she's just away for a week or something. I can probably try to ask her, like, when she's gonna be back. I can reach out to her, call her or text her.

### You (2025-11-18T22:42:15.556Z)

Yeah. I don't know. She may be back by Thursday. I don't know.

### Guest (2025-11-18T22:42:16.195Z)

And hopefully.

### You (2025-11-18T22:42:19.396Z)

I didn't ask her if she flung the entire week. All I know is that she had to go to meet with Driftwood. So, yeah, we could find out. And she'll be back on Thursday.

### Guest (2025-11-18T22:42:30.595Z)

So one. The other one is. Can I suggest that we try to stop. Having these sidebar conversations, and then we include all of us in all communication, because I think that. That generally causes a lot of. Friction. Or miscommunication. Yeah, well, there's no communication if we're not all included in the emails. Yeah. You have to have communication to have miscommunication. Technical. I agree to that. I think that's a good idea. Yeah. I don't know which side talks you're talking about. Mark. One is just Mark was having talks with Dripwood or other site talks. Well, no. You just said you're gonna email Diane about when she can join the. I said I'll text her a caller when she can join because she's not replying to an email. Right. We've already written her emails. She's not replying. Email. So that's what I said. Ok. Yeah. I mean, if we. 're saying is that if you email her and ask her when she could join our scheduled calls, It would be good to copy everyone so that we can all be on the same chain and understand what's going on, because right now, there's just sort of too many side conversations. I can do that. I just thought probably texting a calling would be like getting immediate answer because we do need the answer soon. But I can drop email first and then, you know, reach out on phone or text if she doesn't reply. Thank you. Yeah. And maybe just copy one. Copy me on that. Just on your. If you send a text. That way. There's two things on it, just so there's multiple. Mean? You said, right? That you are not gonna fund the theme anymore. I. I think till now it was all your expenses, right? We were doing on AWS or India team or GitHub or whatever, right? So if that is not the case, then we should think about how we gonna handle that. Because right now, I do have your credit card on AWS. I do have your credit card on GitHub. Yeah. And I would be fine to keep using my credit card if it were getting paid. If the balance every month were getting paid from a company account. But the balance is also getting paid from my personal account. As is the team in India is getting. It's all coming from my personal account. Which I don't want to do anymore. And I've already exceeded the 7,500. And we are probably by next month will have exceeded the additional 7,500 that Mark said he would contribute. And if there is no money left over, or if there's only $2,000 a month left, over. That's just not enough. So. What then? What do we do? I don't know. I think we would theoretically, if. Diane has said previously that she felt like she could get other groups to invest. However, it seems very clear now that. It drifts wood investment was more, or at least as much. Contingent on the work that she is doing. And not in the product that we are creating. And so. I didn't think that we would get a bunch other companies to invest without more to show for to begin with, but now that really seems to be the case. I don't think we can resolve Driftwood thing without her. So she has to be here to, you know, so that we can kind of decide what to do. Because she only holds all the answers, right? Nobody was with her during prefrontal Cor. But as far as the funding and all goes, I think. Probably you and Mark could also try out something like she was doing. I know she got that money into her account, whatever, but she was able to do, like, at least 75. That gave us some hope of survival for some time. And I was hoping probably you guys could do probably have similar network who could support us. For some time. Then there would be good workaround rather than, you know, funding from personal accounts. And we do have a product ready. We can demo it as is right now. Yeah. I mean, I. We. I have not looked at it in the last couple days. Because I just have not. I've been honestly too frustrated. And unsure if there is a reason to continue to look at it at this point. I think that we still have not, at least from my perspective. I mean, it is. I think what we're doing is great, and it's made a lot of progress, and it is very close. If we were to dem. I can just having demoed my own platform, you know, 500 times. I can say with confidence that if we were to demo to somebody, they would look at calculations or rows or sections that are still incomplete, even if it's only, you know, one out of 10, and that's. That's what they would see. I mean. Is that where it is today? Benard? Yeah, it's like 9 out of 10 things seem to be there, but the 1 out of 10 that are not are going to be noticeable. We can figure out exactly what is noticeable. I think you had some feedback which mostly is resolved. Howard has sent some feedback which is completely done UI UX work. Whatever few points we have to resolve, we can do that within a week or less than a week. Just figure out exactly what needs to be resolved for demo and we can do that. Well again. I met with someone a month ago. And the idea was to try to. Be done. Done. By this week. So that we can set up a meeting and whatever feedback was provided, that's done. Probably couple of items. Left. And yeah. Kind of done. Ok, but it needs to be fully done before we can do these demos. Yeah, I mean, it's fully done. I mean, Mark, here is the thing about software. There will always be bugs. There will be some part broken. There won't be a Software which is 100% completed. There will be times when the application will be down for some time. So it's not going to be perfect all the times. Well, yeah. That's why I had suggested we do a video. So that we can sort of have it controlled environment. But if Drew is saying that, you know, is a 10% error ratio, just to paraphrase. Then we need to correct that. We can't present this to the CEO of a major institution. Until. We believe it's working correctly. Yeah, so that's what I'm saying. Just rather than going in all direction. Let's figure out exact. Things that needs to be resolved. We'll get it done, and then, you know, just let's close that demo part and, you know, move forward. All right? But we're on a very critical calendar right now. Because next week is Thanksgiving. Yeah, the week after that. Is december. And then after that, people start, you know, stop working for the year. So we had talked about this a month ago. It just. We really don't have a lot of time. If we don't, if we want to try to do a demo in 2025. Start demoing at least for a couple of people. Get their feedback. I do not. I'm sorry, but we can have the CEO of major banking institution. Give us feedback for things that we know aren't working. Most of the things are working, just smaller things are not working. You don't need to demo what is not working, just demo what is working. And so this is a roadmap map, and this is work in progress.

### You (2025-11-18T22:50:54.596Z)

Yeah. And we should be talking to the CEOs. We need to be talking to the people who are actually going to be using the tool.

### Guest (2025-11-18T22:51:05.795Z)

Yeah.

### You (2025-11-18T22:51:05.796Z)

If you come to the CEO, they're going to say, hey, this looks great. I love it. But you need to go and talk to so and so to see if they can use it. Right. The CEO is not going to write check after launching a demo. Never has.

### Guest (2025-11-18T22:51:21.075Z)

I don't think you're right, Howard. I think that there are some differences.

### You (2025-11-18T22:51:26.996Z)

Let me just say. Mark.

### Guest (2025-11-18T22:51:28.195Z)

Please.

### You (2025-11-18T22:51:28.356Z)

I've been in software for 15. Years.

### Guest (2025-11-18T22:51:31.875Z)

Okay?

### You (2025-11-18T22:51:32.916Z)

Some software. Is not at all. Like selling hotels.

### Guest (2025-11-18T22:51:38.595Z)

I don't sell Hotel Tower. That's not the business I'm in.

### You (2025-11-18T22:51:41.716Z)

You said you disagree with Howard Saw. How many software products have you sold in the past?

### Guest (2025-11-18T22:51:49.955Z)

I was with a company for several years. We sold software.

### You (2025-11-18T22:51:54.436Z)

How many softwares did you sell? How many campaigns?

### Guest (2025-11-18T22:51:56.995Z)

We ran a business. Howard, Howard, there's no point in debating this. I met with the CEO, who I know. He said. Can I finish my thought?

### You (2025-11-18T22:52:04.356Z)

Lark.

### Guest (2025-11-18T22:52:08.035Z)

Are you sure? Thank you. I met with the CEO. He said he was very interested in this. And he said he wanted to arrange a team. Of his senior people. To see this. I just grabbed what it did. And he said this is what he's looking for. And he said he would like to participate. And he would arrange a meeting with all of his colleagues. So we could do a demo. In an effective fashion. So I think that is an incredible opportunity for us. But it needs to be right. Interject here just from Because I have been doing my software business for five years now. There is a big difference between selling. If you are selling software to a technology person, to a technologist, You can talk. You can speak to the things that are done. In progress. That you know your roadmap if you are selling software to a layman, which we mostly are, because real estate, these hotels, specific small real estate companies don't usually have any technology. People. Access Point Financial case in point. I met with them a couple months ago. And as maybe 15 people at their company, not a single one has technology anywhere in their title or job description. They are real estate finance people. That's it. Will really shorten this thing. Drew, just go ahead, point exactly what you need to be done for the demo. And I'll get it done. Hopefully in few days. Just exactly what is needed for the demo. Just don't go around and add a lot of things. What do you think has to happen for the demo? Just those items. All right, let me. I can. Input some documents. And put in like a pro forma and see if these calculations pop the way I'm looking at the most recent one that I had done. Andrew, let's use only the documents that we are going to use for demo. We'll use the same documents that you are kind of testing on. So that, you know, it behaves. Same. Just collect the documents that are we going to use for demo? Let's get that done. And you know. Let's schedule the demo. Start scheduling them. Let's see what happens. I do think that once we're all at a level where we're confident with the product, Doing a video would be a smart thing to do so that we don't have to deal with the conditions that you airline Benoit. Yeah. So I should be saying don't do a video. Mark, you. You are the salesperson. If you think video is the best, let's do video. Yeah, it should be your decision, not mine. Rules or hours or anyone. No, that's my recommendation, is for us to do videos so that we have a controlled environment and we know the presentation is going to go perfect and we don't have to deal with Internet outages or freezes or any of the things. That invariably happen.

### You (2025-11-18T22:55:36.756Z)

Yeah.

### Guest (2025-11-18T22:55:38.355Z)

That's do. All right. Ok. Is that something? I will go through, create a new deal, see what things are still outstanding. Video. We can. I can really cheat on browser too. I can just put the right calculations if you need the video today. Like if I'm recording video today, I'll just modify the number on browser itself if we need to. And you have the video ready by tonight. Let's sit. Make that video Correct the numbers that are not showing correctly. And go from there. We are just doing video. Right. Can you guys hear me? Yeah. Yep. Ok? Yeah. I mean, Howard or I would probably do the recording. That work for everybody? Yeah, sounds great.

### You (2025-11-18T22:56:40.276Z)

That's a good idea. So along with what you're saying, a demo is a scripted thing that you do over and over again to different audiences. So if you've identified a financial statement that works. Consistently. The new Muzat financial statement for every demo. Same thing for all the other documents that we need to put together. For the demo. So another thing is. The data is going to be so small on the screen, nobody's going to be able to read down that quickly unless there are some right, to make sure that the numbers are summing and dividing and all of these things are correct. What they want to see is doing something. So if you upload the document, it extracts the data. We go to the performer page that data is showing on the screen. We don't have to keep jumping back and forth and say, here's the number, here's another.

### Guest (2025-11-18T22:57:41.475Z)

Yeah, yeah, I agree. We don't need.

### You (2025-11-18T22:57:43.556Z)

Numbers, right? So we don't need to get down into weeds. But we do need to have little self the cards at the top of the page. They do have to be populated. We have to show some KPIs that are up there right now. I think most of them are zeros from what I saw. So those are the things we need to get working.

### Guest (2025-11-18T22:58:04.995Z)

I will try to create a new deal that might be part of why this is not. These are not updated. This is an old deal. So I'll do a new deal and see if everything, you know, see what is still outstanding. And we can get it. I mean, yes, we get it. Correct. Ed asap. In the next seven days. Really? As far as. The. I mean the business part of this conversation. I mean, Vinod, you're gonna email and text Diane and tell her. She needs to be on the next call. And I think, unless I don't think any. The rest of it has changed. I don't think the rest of what we've discussed has changed. We have the, you know, nine or ten things that. We've agreed to. Money needs to be deposited to InnVestAI. You know? Several things need to be put into the. Llc agreement. And we need to get that signed so we can open that account. Right. I think that that's what we need. I mean, ideally her to agree to. I don't know what we'll do. Already has received the money. From her personal account. Or if, you know, if she's not willing to, you know, doesn't agree to the things that we've put in the llc, which I mentioned to her. I think everything she's asked for is in there. I don't think there's anything that disagrees with anything she's requested. Or asked for. So. Hopefully we were able to agree, because, I mean, ultimately, without agreeing on that, there's no business. Right. There's no company. Right? Right. And if we. If we don't, the guys. If we don't hear from her. In. The next, you know, by Thursday. I mean. We can figure out then what to do. I don't. I mean, that means we. Maybe we reach out to Driftwood directly. Maybe we sign the LLC agreement on her own. I don't know. We can, I guess, discuss what that is on Thursday. Yeah, let's try to get around the call and then, you know, figure out this drift out. Thing. Yeah. I'll draw the email. I'll drop the text as well. And hopefully she would be available whenever. If she's available tomorrow, you guys can hop on a call. On similar timings. Yeah, I'm. I'm generally available tomorrow. I cannot do tomorrow night. You cannot. I can. Not. Wait. I can do tomorrow earlier in the day. Or we just keep our Thursday. You are available. Early. During daytime. Because I can make myself available daytime. That's the possibility. I'm just saying, so that we get. Get going. Yeah. Tomorrow. I mean, I have things going on. It depends what time, but I can, you know, try. Okay, Let me figure out. I'll let you know.

### You (2025-11-18T23:01:54.436Z)

Back then after 2:30 I'm not. Available.

### Guest (2025-11-18T23:02:01.635Z)

And otherwise we do our Thursday usual time. And you guys have the video maker software or something available with you. I do. Yeah. I have a. Okay?

### You (2025-11-18T23:02:17.076Z)

Yeah. I think we should have something we can use.

### Guest (2025-11-18T23:02:24.515Z)

All right. I'm go test. I'm gonna go test the rest of the platform and see what we can. What else needs to be done. Yeah, just specific to the video demo we need. And yeah, you can add definitely the other feedback as well, but just to get past this demo blocker, Right. Yeah. Let's complete what is remaining for that video demo and then we continue working. All right.

### You (2025-11-18T23:03:02.516Z)

Ok?

### Guest (2025-11-18T23:03:05.235Z)

Thanks, guys. Thanks.