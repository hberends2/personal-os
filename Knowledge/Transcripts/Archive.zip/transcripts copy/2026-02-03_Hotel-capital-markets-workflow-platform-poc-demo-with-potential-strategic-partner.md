# Hotel capital markets workflow platform poc demo with potential strategic partner

**Date:** 2026-02-03 00:00:00 UTC
**Meeting ID:** d82606e5-7e60-449d-a1f6-3b7918621e8d
**Synced:** 2026-02-05 14:54:33

---

# Transcript for: Hotel capital markets workflow platform poc demo with potential strategic partner

### You (2026-02-03T16:00:08.939Z)

Hey. Good morning.

### Guest (2026-02-03T16:00:12.459Z)

Hello. Guess I'm gonna let notetakers in.

### You (2026-02-03T16:01:29.099Z)

Good morning.

### Guest (2026-02-03T16:01:30.539Z)

Hey. Good morning. Hey, sloan, how are you? Good. How about my camera's off. Hold on.

### You (2026-02-03T16:01:35.979Z)

Likewise. Good morning.

### Guest (2026-02-03T16:01:38.219Z)

There we go. Hi, Howard. Nice to meet you. Foreign. Did you survive guys today? I am in atlanta.

### You (2026-02-03T16:01:49.259Z)

Michigan.

### Guest (2026-02-03T16:01:49.339Z)

And Howard is Howard.

### You (2026-02-03T16:01:51.739Z)

Yeah.

### Guest (2026-02-03T16:01:56.219Z)

Oh, okay.

### You (2026-02-03T16:01:58.939Z)

Too much.

### Guest (2026-02-03T16:01:59.819Z)

How much snow is on the ground up there, or have you thought out at this point.

### You (2026-02-03T16:02:04.059Z)

It's been really rough winter. I think2011 is the year we moved back from.

### Guest (2026-02-03T16:02:07.099Z)

Bad question.

### You (2026-02-03T16:02:11.019Z)

Texas, of course, in that year, it was like the worst. It's been fairly mild, but this year it's been steady snow. Bitter cold.

### Guest (2026-02-03T16:02:27.499Z)

Yeah.

### You (2026-02-03T16:02:27.739Z)

Dfw.

### Guest (2026-02-03T16:02:34.299Z)

Oh, okay. Yeah, same. I live. I live in the m street. Although last week we got hit with this. Whole storm. Well. Weekend before last week. And you know, you remember it, you know, everybody, everything shuts down. But everything's thriving. It's 70 degrees here today, so, you know, schizophrenic.

### You (2026-02-03T16:02:51.899Z)

That sucks. Us? Yeah. I was in flower mound. And then. Moved over to color. Actually, the color area was the last place. But, yeah, kind of miss it. But, yeah, I always used a joke down there that the most powerful person in Texas is the meteorologist because literally have to hint that bad weather is coming and everything shuts down.

### Guest (2026-02-03T16:03:05.899Z)

Okay? And everything's just. Yes, there I. There I would say, you know, Wednesday, Thursday. Last week, my kids. My kids were out of school Monday through Thursday, and they finally went back Friday. They could have gone back to school win today. But, you know, down Howard. You know, there. There's one small piece of ice on the sidewalk, so they can't. Heaven forbid they go to school. Are you always in the M Street area? For some reason, I thought, you know, I used to live in Richardson. That's what I thought. Before that, I was in Atlanta, actually, originally from north of Atlanta, but I moved here 13 years ago from. From Atlanta. I was living in Brookhaven. But my Berends live up in northeast Georgia and Hammersham County. Got it. Got it. And I am in Alpharetta and I lived in Plano Frisco when I was in Texas. So a lot of commonality. Traded places. Yeah, yeah. I've got cousins that live in Alpharetta and then Forsyth county and then got good friends all the way up and down the 400 corridor, so. And my dad's got three sisters. Two live in Gainesville and then one live up in Habersham, so. You have a lot of family here? Y. I do, yeah. We come back. We were back for Christmas. We brought the kids. And then, actually, my cousin, who lives in Alpharetta, hosted the family for the big. And then we'll be back this summer. Great. Well, so thanks for taking the time to talk with us. Howard and I are partners. And the story about Howard and I came to partner is when I worked at CBRE, I spent two years putting this idea together and presenting it to CBRE. In the context of CBRE, you should invest 2 to 4 million into an actable or an OTELIER and turn the operational BI platform around to serve the capital markets. And I studied this in depth. I studied all the broader CRE platforms like DealPath and Deal Cloud and RedIQ, which is a multifamily underwriting platform. At the time, it was the market leading multifamily underwriting platform and all of the brokers and the appraisers the multifamily brokers and appraisers at CBRE loved the platform. So CBRE declined to move forward with that. And, you know, that's just cbre, and it's really its lack of commitment to the hotel sector, as evidenced by that, that they just shut down the research group. But after I left, I didn't know that. Yes, they did. Rachel Rothman joined Hot Stats as the CEO. I saw that. I didn't realize that was part of the causation. I sent her a note. But I didn't realize cbre shut down. The research group. Yeah. So they're going to stop selling lodging data in general. Like, I'm not sure what I understand is the VAS division, the vertical, so the appraisal Vertical. Right. Which is Tommy Crozier. I don't know if you know Tommy or not. I do. Okay? He is his vertical, and that's the vertical I worked in, is going to be responsible for processing the benchmark or data. I think they may be shutting. The bigger, you know, the economic forecasting by market down. Because I don't know who would do it. With Rachel leaving, Robert Mandelbaum retired. Yeah. Yes. Yes. And I am very, I don't want to say I'm very close, but Mark Woodworth is a mentor of mine because he, you know, obviously, he sold PKF to CBRE and then saw what happened year after year after year. But when CBRE declined to move forward with the strategy, which I feel, so it's just something I can't let go of. I'm that passionate about it, and I'm going to figure out a way to get this off the ground. But I was heartbroken, and Mark really helped me process that. You know, just like to say, okay, well, this is cbre. And you have to understand how it's structured. He remains a really good ally for me and has always been interested in an underwriting platform. But so. So to continue the story really quickly, When I left cbre, right at the time I was leaving cbre, Jared Kelso left Cushman and joined Berkadia. Berkadia at the time owned Rediq. So it was Jared Kelso and ironically, on the exact same day that introduced me to Howard, and he also introduced me to Carlos. Junior because Carlos junior And Driftwood was an investor in a platform called Revere, which is kind of like a digital capital market platform that sold to Light Box. But Jared made the introduction to Howard. At the time, Howard was still at Berkadia. We got to know each other a little bit, and then Howard is. Is. Our identified pivoted over to you to tell the rest of the story because it's. I mean, you. About you and your transition at Berkadia and leaving and things like that.

### You (2026-02-03T16:08:50.459Z)

Yeah, sure. So Berkadia purchased Wetiq primarily for internal use. Processing the rent rolls and the financial statements, extracting the data. But we kept on. Servicing our external clients. And as diane mentioned, cbre was one. Jll. You name it. Most of the major brokers used Rediq for their multifamily. We called it the worst kept secret in the industry. But there were issues contractually with REDIQ not having access to any of the Berkadia third party data because CoStar and those types of companies. Considered rediq to be a reseller. If we were to get that data. And when I joined rediq, at the time, they were strictly evaluation model. You were either a broker or you're an investor. You use the model to come up with your valuation. You buy the property or somebody else buys it. You're done with Rediq until the next deal. Then I realized that. Most of the data that they were already gathering could be used the entire lifecycle of the asset. So you could continue to use RedIQ in many of its different features. From the time you start looking at the deal all the way to the time that you purchased the deal and then dispose of the deal seven, ten years later. But in order to do that, we really needed to bring in some third party data. We didn't have enough in house data for market comps, things like that. So Berkadia is so runiq to a company called Radix. And Radix is a third party data provider for multifamily. And everybody thought it was going to be the perfect merger of the two products. However, Radix was up to their eyeballs in the class action lawsuit with Real Page Indirectly. But they were losing clients. They were bleeding cash. So what happened is, instead of this great merger, Essentially, they took all of the developers from rediq. Radix had to do a complete pivot on their core product and. Rediq just kind of got put on the back burner and languished. So in January of last year, they basically. Laid off pretty much everybody on the rediq side. Except for one engineer to keep the lights on. And everybody else went there. So what? IQ was not able to. Continue with the development of a lot of the features. So that's what Diane and I kind of got. Reacquainted, reached out and decided to go ahead and help her to build. Essentially, I'm not going to save the rediq of the hotel industry because rediq at the time of the sale. This was another thing is that they were built on an old net infrastructure, a lot of manual processes behind the scenes and rediq by a couple of our competitors. What I wanted to do is. To ring Rediq up into the. Modern age and expand the capabilities. And so working with Diane on the hotel side allows us the opportunity to do that. To use in certain cases. I call it AI Augmentation. Right. AI is a tool. It's not the end all, be all, but it does do an excellent job. With certain aspects of the data within the underwriting process, and then to build this tool that is focused specifically on the hospitality industry. Which not only allows us to do the valuation model. But there's a lot of ancillary features that once we get that core product done for the valuation model, It opens the door to. A lot of different things. Just like rediq, we can go for the asset management. Segment. And have them continue to use this model to monitor their performance. As they go through the lifecycle. Things like marketplaces. Lenders. We've identified seven different Personas that would be. A. Prime candidate for using this tool, not just a broker and. An investor.

### Guest (2026-02-03T16:13:59.579Z)

I've got a plumber at my rental property that's imminent. Can I. Let me take this real quick. I apologize. Hello. Don't be very mindful of having rental properties. I don't even know if I'm making money on these things, you know? It's like everything cost a fortune. Don't get me started. Anyways, sorry. I got a new tenant and one of them, and we're trying to get the gas on. Them like. It's amazing how much you have to pay for these inspections. Sorry. So back. I guess this is really good context to understand, like the path. You guys have been on. Is. Where do things stand today? I know, Diane. You had given me a little bit of a preview last time. And do you. Do you have, like, a working product? That you build. I'd be curious to maybe you guys step me through a demo today. Yep. So what we'll do today? Well, first, let me answer where we stand. I mentioned that we broke apart from two of our co founders over Thanksgiving. We're finalizing that settlement. It was just simply that we had five total co founders. Equal percentages. It wasn't going to work out. It was a. It was a rookie mistake on my part. I, you know, I thought it would, but I learned a hard lesson. And we also, you know, like we were talking about on your podcast where we were talk where you were mentioning the number one reason why startups fail, right? Is, you know, not enough capital or not being able to raise capital. Right. And people issues and that. And that's what we had. We had two partners that wanted to bootstrap to. That couldn't afford to bootstrap. So we had a very different vision of how we were going to capitalize the company. And we also had very different visions about the mvp, what it should look like, how early it should go, how quickly it should iterate. So that is pretty much behind us. We'll be signing the settlement agreement in the next week. Or two. As part of that, we had to put all the work we did on the shelf. But we've gone back in, and Howard, who is a product manager, who's an actual product manager, has gone back in and rebuilt the poc. So we do not have an MVP yet, but we do have working POC that was easier to recreate because we'd already gotten through the work creating it last year. Today we have that POC to show you, and I also have a really short pitch deck to show you so you can see what our vision is, what we think the ramp on revenue is. You know, how we view it moving. From a B to B SaaS platform to ultimately five years out of transaction management platform. So that is where we are. And you know my goal. Sloan is. You just. You're a very unique person. There aren't many people like you that have capital markets and operations experience and revenue experience. Right. You're. You're so deep in revenue. And there is not a capital market solution out there for hotels. Flat out, it just does not exist like homegrown stuff. And but it there's nothing that you can just go license. Right. And, you know, we are. Are we somewhat competitive? Because I know you're friends with Chad Sorensen. Like, with profit. It. I mean, we're not trying to fill per se. I think so because they're more focused on their advisory business. Right. Right? I mean, you know, where, like, Michelle Russo has their product, Chad Scott theirs, it's almost more like. A Trojan horse to feed their services businesses. Although I do think Michelle Russo is really trying to push her be. I forget the name of the BI product. Single pane. Yeah. Single pain. She's. And she's the lone investor, obviously. She's. She's got a lot of money, so, you know, I don't know if you've had conversation. She's the only one that I've Howard not demoed it. But she's told me all about it before. Yeah. So I would assume that's the only thing that competitive is in that. Yeah. And we'll go through the competition because we've done all the work. There's one really interesting platform called Bridge. They're on the lending side, but just to clearly differentiate. Howard and I are solving the capital markets workflow, fragmented data silo. That's the problem that we're going after, right? It's a 50 billion dollar industry. And we'll show you just looking at transaction volume. It's a 50 billion dollar industry on a bad year. But why don't we do this? This is what I'm going to share my screen and I am going to flip to three websites super quick. I'll do it in under a minute. But the reason is what we want to be is a purpose built. For the hotel industry deal path. Plus RedIQ Plus Paraview Deal Path is the leading pipeline management CRE platform in the in the US. It's amazing. It's a JLL Spark company and we literally have a blueprint. Right. It's just we need to do what they're doing. But their platform doesn't work for hotels because our data is so different. We need then is the underwriting piece of it, which you tack on. It's a natural progression through when you're doing deals to now have the underwriting in a SaaS based platform with the ability to, you know, push and pull from Excel because people are really tied to their Excel models. And the last when we say asset management, it's not just operational asset management, it has a component, but it also is the real estate asset management. Right. So think, what's my cash on cash return? What's my basis? You know, you know what? I mean, like, so that you are actually digitizing those very manual and painful workflows. So at the end, you have an end to end acquisition to disposition, capital markets workflow automation. So really quick, let me share my screen and then Howard will share his. Okay. Can you see my screen? I can. Okay? So this is deal path, right? It is a very large. It's domestic and global pipeline management platform beloved by many institutional investors. Blackstone was a big part of launching this platform. It's a decade old, so we're a decade behind essentially. It pulls in all kinds of OM information. It has some direct API connections with JLL cbre. It tracks your deals from essentially the moment that. The offering memorandum is sent out and the data is sent out. And then it gives you tools to manage through the deal, letter of intent, investment committee meetings. I mean, it's a really amazing platform. And so this exists. It monetizes. It successfully monetizes. And so we are looking like, to create a ver. A part of our product that is the deal path for hotels. Rediq. This is what Howard was talking about with Radix, right? They have since been leapfrogged by a company called Archer. And Howard can talk all about this, but when I was doing all the work at cbre, they had a very significant market share for multifamily underwriting, and so this. Is the underwriting component that we're going to create our own underwriting component for hotels that looks as much like Excel and what a hotel underwriting model in Excel. Is and has been for 40 years, just in a SaaS platform. And this is Paraview. Paraview is an institutional asset management platform. And again, it's, it'll have operational because we can't ignore 40% of, if not more of the value in our investment comes from operational iq. Right. And how we invest and manage. But this work of, like, constantly updating the returns and the basis, it's a lot of manual, painstaking work. So the original vision is Deal Path plus Rediq plus Paraview for hotels. And all these platforms exist, are monetizing, and have pretty much been in existence for a decade. So, Howard, do you want to flip over? I'll stop sharing. What it Who? So Dillpath is a JLL spark company. Have they gone through like a series ab? And then like. And then who owns you said Rediq is bought by Rediqs.

### You (2026-02-03T16:24:49.579Z)

Yes.

### Guest (2026-02-03T16:24:57.339Z)

And then pair of you how are they capitalized? Like so Pearview I believe is still in pre seed it's former Goldman Sachs executive that left Goldman. I'm sorry, I'm trying to get to. Me one second. And rediq. Come on, diane. My control. Let me just stop sharing so. Clearly Redeepath is already Series A, Series B, it might even be Series C. It's very large. JLL Spark Radix now owns Rediq and they own it outright, although Howard can probably comment if there's any other investors. Paraview is still in pre seed and the CEO is a former Goldman Sachs investor that saw the problem on asset management and they are having great lock or success with the small institutional investment managers. So many of the companies that I did deals with when I was like at Waterton Argosy and like Seth Singerman in Chicago. So they are targeting that. And you know that it would be like, Noble would be the perfect client for Parabu, Right. As an example of who they're going after. Howard, anything to add on as to who owns Radiqs or more Intel?

### You (2026-02-03T16:26:35.819Z)

A sole proprietor. Well, there's a partnership there. 's the CEO and co founder. He is from kosovo. And. The vast majority of. The employees of this in Kosovo. Which is one of the reasons why he downsized. Saw the RedIQ employees were domestic, and so by shifting the engineering from the US To Kosovo, he obviously got a lot of savings there. Berkadia is still. A minor. Owner. Less than 50%, but still they own a significant portion of the company. In exchange for the use of the tool. At the time that he shut everything down, I did have two business analysts that reported to me, and he had taken them to start working on. Financials. In order to go and get some additional financing. I have been keeping an eye out for the last year. Have never seen any type of an announcement anywhere publicly that they've been able to obtain any additional findings. So I don't know what the status of them are. There are a lot of people that were saying that they didn't expect them to last throughout 2025.

### Guest (2026-02-03T16:28:01.819Z)

Okay?

### You (2026-02-03T16:28:03.979Z)

So I don't know how their financial position is. But I do know that they will only serve as multifamily. There is no chance for them to go out. One of the things that Rediq was looking at was obviously hotel when I know with Diane. But we were looking at other adjacent assets with self storage and student housing, a few other things like that. But at this point, they're completely out of the picture in terms of competition.

### Guest (2026-02-03T16:28:43.819Z)

Yeah. I just asked because so often in these things, like adjacent or often your best partnerships or funding mechanism, right? Right. And that is, you know, all three of these are adjacent Cs, or, you know, you're really trying to represent, bring what they're doing in a divided way and not for a hotel. Into, you know, so it's just, you know, I. That's why I was curious how they're structured and the conversation you've had because, you know, it's almost like deal path or Rediq or Parabu. Like, being a partner with you would probably be the path of least resistance, right? For. Right? And that's why I do have and wanted to just kick some of these ideas around with you. That's why Otelier is on my mind so much, because of the. There's an adjacency, right? They serve. Property operations, but they have P and L data. And so if this were a sister company. And then we solve the capital markets workflow automation problem. Right. It goes hand in hand. They're kind of. They're the same customers, basically. And then what I see happening is because I've worked for big companies. I worked for Lund Lease. I worked for Clearing Partners and cbre. So when I look at these really big companies, What you need is our futures. We're going to need to create API integrations with dealpath and dilcloud and you know what I mean. So that if I am Argosy and I have three hotel investments in my portfolio, I want PEAR review to work. But it's not going to work for hotels. So this came for me, this theme came out of cbre, where one of the technology leaders said, diane, you have to think of it as like Switzerland, right? You're going to have a lot of API integrations and you're, you know. And so what I see is you're a middleware. Yeah. Yeah, in some way. Yeah. But. But none of those groups can come and solve the problem for hotels, because our data is very, very different and just more of like they live in this kind of somewhat of a similar ecosystem. And as you raise capital, convincing the investors that are invested in them. And or these companies, if they have the capitalization and the means to invest in you, is a lot easier convincing. Right. And the one company. And then Howard can do the. The demo. The one company I have on my. My radar screen. I'm thinking like an acquisition person already. Like, what's your disposition? Or your series A strategy is fifth wall. And fifth walls are prop tech company, investor, very large one. Right. And they have six hotel investors in their fund. Marriott, Hilton, mgm, host. They're passive, though. That's the only thing. Just keep that in mind. It's a way for these big C corps to sound like they're staying relevant because they use cash in their balance sheet debt, but they're not. Really active. You know, it's like, oh, we have a strategic just like they have. I think they also invest in Plug and Play too, and a couple of others that it's their way to say, well, as new tech companies come into the travel vertical, we're an investor here and then we get first found. You know, so it's more passive is what I found in talking the Fifth Wall and Plug and Play. But definitely it's. They are investing. It's just passive balance sheet money. Right? And we see and when, if we have time to get to the pitch deck, you'll see that our vision has us working with three. I'll call it Lighthouse customers. Right. Customers that are actively using our product, helping us get through the MVP of any particular module or stage, and that it's customer driven. From day one that we're creating what the customers want, because I hope that those customers may even be interested in investing a bit like what Driftwood has done. Right, so Driftwood is 75. You get a design partner and a co investment, one in the same. And if they're investing in you, they're going to be more committed to the design process. Right. And so that's a vision. I mean, if we could get there and get three Lighthouse customers that are investing in us and they are then the place, like, where we can innovate. I don't even know if you have to have three. If you just get one to start. If you get one. And they're highly committed and they commit capital and time and energy and because iteration is so important in innovation that that would get you going. You don't. Yeah. I mean, yeah, three is better than one, but one's good enough. One is good enough. So now that's probably a good place to go to the. To the actual poc. And remember, we had to. We. I say that Howard because Howard is the technology lead. How do you rebuild proof of concept over the holidays? So someone told me a year ago when I started this, when Howard and I and we all started this, that they said if, you know, a year from now you're not ridiculously embarrassed of the POC folks, then you probably work fine. If you saw the original pitch deck that Uber had, it was really embarrassing too. But look, there are multibillion dollar company. Right? And so I just want you to right. So this isn't beautiful, but it's a company that tried to have the perfect POC or mvp. Probably never reached. You know, it's just about get out there.

### You (2026-02-03T16:34:41.499Z)

You're absolutely right. In fact, this is still work in progress, obviously.

### Guest (2026-02-03T16:34:43.659Z)

All right, Howard, take it away.

### You (2026-02-03T16:34:46.939Z)

And one thing I want to emphasize is that we didn't recreate what we did before or replicate it. We're filling in a lot of cracks that were in the original POC that is out there now. I don't want to go down any rabbit holes when I'm demoing this thing.

### Guest (2026-02-03T16:35:02.779Z)

Okay?

### You (2026-02-03T16:35:04.939Z)

I have a tendency to get into a lot of detail. So raise your hand. Get my attention if I'm getting too deep into it.

### Guest (2026-02-03T16:35:15.899Z)

That's all right. Yeah.

### You (2026-02-03T16:35:18.779Z)

Okay?

### Guest (2026-02-03T16:35:19.179Z)

And I've got to stop about 10 before the hour because I got to do a little prep for my next meeting, so I got about 15 here, so.

### You (2026-02-03T16:35:19.579Z)

All right. Yeah. So let me go through this real quick. So this is what we're calling the pipeline. Which is your typical. This will be the list that I, as a broker, investor, lender, et cetera. These will be the deals that I would be working on. And of course, it's very customizable here. I can choose which columns I want to include. Change the order of them so I can add anything that I want to this, and then, of course, I can group them. I can filter them. So basic functionality here. But one thing I also want to emphasize is Deal Path is a pipeline tool. Of course it's got jl behind it. And it's really kind of, I wouldn't say, almost like the Zillow of commercial property. But they don't really have a whole lot of secret sauce. So by focusing on the hotel industry, we are leaving the door open to not only including the clients pipeline here, but. We could do essentially what the deal path and the other companies do by including other deals in here. Which is very beneficial for the existing customers. Because obviously, anytime you're acquiring an asset, I don't care what type of asset it is, whether it's hotel or office, multifamily. You're going to compare that property to your competitors. So the more we can do to populate this with competitors, the less manual work the users would have to do. Once you get into a deal here, you can add a new deal. I'm going to take you to the edit details. It's the exact same morning. So if I'm creating a new deal, I just go and fill in this information. You can see it's all the basic information that you need, including what is the property type, status, extension or full service, et cetera. Going on to the next page, then one of the things we haven't touched on yet is because lenders do not have to get into the minutia. In terms of the underwriting, for example, the food and beverage. Right. They just want total food and beverage. They don't need to know if it's a kiosk, if it's a full service restaurant. Everything else, there's a lot of brokers and investors will do. So this particular modal that I'm showing is geared Howard a lender. Using. Our model for theirs. So. Here again. So that's why we have the loan details here. We would enter the information here, and it's probably not going to let me advance further because I don't have the loan number and everything else. The next screen is the valuation assumptions. So that is, whether I'm a broker. Investor. Lender, et cetera. That's where I put in all of my loan details, which my interest rate is. Is there an interest on the period? What is my going in cap rate, what's my exit cap rate, all of that information that you would use. And once you get that filled in, then you can go to the actual valuation model. So, starting off, we're going to have an opportunity for them to import market comps. Some of this. We will be using some third party data. We've talked to a few people, we've got some people in mind for strategic partnerships. They can manually interview if they want to. Over here there's a button to add a property so they can manually input whatever comp they have. Once that's completed, the next option is the valuation assumptions. So there's two places to input all this. When I'm creating the model, I can use the mobile and input my initial assumptions. But those always change as I'm going through here. So I've got my acquisition assumptions here. So what do I expect? My going in cap rate, what's the discount rate, et cetera? My financing assumptions. What's the low value ratio? What's my interest rate equity here? I've got my partnership breakdown here. I can continue to add partners as I go. I may have multiple small investors. I may have one that fills up the basics, so you can keep going. There, and then my exit cap rates. Now, all of this is dynamic, right? So as I'm going through here on some of the next slides, if I need to make any changes, I can. And then when I'm done, for example. Today, I might be assuming an interest rate of X percent leaves down the road. As I get closer to closing and I'm actually working with a lender, I'm going to get a better idea. So these are the things that are always going to change. Then when I go start working on the model, we've grown, we've got it broken down by occupancy and revenue in one session, expense on the next. So one thing you'll see is this top section here is static on all these pages. This is where I can monitor. Anytime I make a change down here in my assumptions for either the occupancy or the penetration. Down here for the revenue. Those changes are going to be reflected up here in this table. So I've got my key metrics. The penetration data, my revenue. And I can expand this down so I can see other details like the food and beverage, other operated several, and then the same thing on the expenses. Where I can. Break down, see the detail for my other operated distributed, et cetera. So there are options as well here. So when I'm going through, for example, the occupancy, I can choose do I want to have a flat growth assumption, which means whatever I put in this box here, if I want to assume a 3% each year, I'll go ahead and input it there. And it's going to change my assumptions all the way through here. Or I can just do something for year over year growth where instead of just one value being born across, I can go here and I can change whatever I want. So if I can put my 3% in this year and maybe 1.5 the next year, et cetera, et cetera.

### Guest (2026-02-03T16:42:03.659Z)

And I just want to jump in with one statement, and that is it may not look at, look like exactly in this version of the PoC, but we want this to feel like an Excel underwriting model for our customers. Right. They're used to underwriting in Excel. So, you know, we. Everyone has their own model. Everyone thinks there's secret sauce to their model, but we don't want this to feel like Argus, where people are like, what the hell? This is meant to be just like their Excel. But we're pretty populating all the historical. We'll pull in the trailing 12, right? We're taking that manual. Process of having to update this data over and over and over again. We're going to digitize that workflow and that, and that is our vision. And that's. But that leads us to we strategic partnerships. Right. And potentially working with someone like an atelier that can help us with the data extraction or the data. An API is the historical information come from now. So like if you have a design client.

### You (2026-02-03T16:42:10.779Z)

Yes.

### Guest (2026-02-03T16:43:12.539Z)

And you don't have those Data feeds or APIs built. Is it just like you're uploading an Excel file of historical.

### You (2026-02-03T16:43:14.299Z)

Yes. Yes. An API.

### Guest (2026-02-03T16:43:21.259Z)

Okay?

### You (2026-02-03T16:43:24.219Z)

It's a term that a lot of people throw, right? But, you know, everybody wants to have an API, but they don't really understand what an API is. An API is great when you've got one client who will continually uses a product over and over again. In the case of an investment model like this, a broker is going to be working with multiple sellers. Right. So broker has to get the data from the seller and then the broker has to be able to upload it here. So if we were to have an API, it would have to be with the broker. And not those individual sellers, right? Into your company. Right.

### Guest (2026-02-03T16:44:08.859Z)

Or the management company. And so maybe that makes sense to you because, you know, who does the seller get the information from? They get it from the management company. And where does that come from? It comes from profit, right? I mean, download into Excel doc and then, you know, send the PDF or the Excel doc. So, yeah, you've got to have some way to easily upload and Screen scrape either PDFs or Excel. And in the Excel documents often are not comma eliminated, so it's got to be in.

### You (2026-02-03T16:44:15.179Z)

Yeah. Y. Eah. Yes. Yeah. We actually have already done that.

### Guest (2026-02-03T16:44:43.419Z)

A, you know.

### You (2026-02-03T16:44:43.739Z)

I don't have a connected to this proof of concept, but that's exactly what we did at rediq. That's what Archer is doing.

### Guest (2026-02-03T16:44:49.579Z)

Okay? Yeah. What we had built in, like, Remy, where we had, like. We didn't have. We had, like, a general. And you probably doing this, like, where we had certain file types that would just go via email.

### You (2026-02-03T16:45:02.939Z)

Yeah. Y. Eah. Y. Es. Yeah. So email is a possibility here. We've got just the direct upload, drag and drop, et cetera. Once you bring them into here, then it goes through the processing.

### Guest (2026-02-03T16:45:09.579Z)

And then they would just get automatically uploaded.

### You (2026-02-03T16:45:20.219Z)

One of the things that we're looking.

### Guest (2026-02-03T16:45:26.139Z)

Have you guys looked at for people that have used, have you used this to say this is how much time and this is how much better the underwriting process is than just using.

### You (2026-02-03T16:45:30.539Z)

Yes. Yes. Yeah. That's really further valuation. That's the selling point. Right. No more cutting and pasting and all of that.

### Guest (2026-02-03T16:45:44.619Z)

And I have that. Right, but how much time does that save then, on average? So just a couple points. I'll jump in here. And that is there is an actual industry reporter. So hotels is going to be more than this. 25% of our time is spent doing nothing but manipulating data just to get it into these type of workflows. I would also say that, you know, this as being. You think all that time goes away or is saved, like for the most part. Or it's used in a better way. Right. It's used on higher value work. But that and I did it. I mean, I was the one doing it, you know, until 2:00. In the morning Toothpicks in my eyes Copy paste, copy paste. But we want that pain point to go away. And then, you know, this being in capital markets, you look at hundreds of deals just to close a couple, right? That's a pain point. So we're speeding up the process. We will speed. Up. Also the diligence and the closing process. We're going to speed up the deal process. And then at a later date, I can show this to you. It's again, it's almost a decade old, but at cbre, when they were looking at the multifamily space and what they were going to do, they thought about buying rediq. So they broke it down into very granular statistics. How much time does an analyst spend on a deal? If they had a tool like RedIQ, how much time would they save? And it's really interesting just to see how they looked at it on the multifamily side, because it's the same mechanics for us, right? It's just worse because our data is even more complicated and operational. But how big do you think the TAM is for something like this? So all of a sudden, you know how many actual subscribers would actually subscribe to something like this? Like, if you do like it? Yep. So let me do you have time? Because I know you have a hard. I got a hard stop in three minutes. I didn't know if. It's a long explanation. Let me just. So, in our plan, the kind of way we. Well, I think that within five years, you could be looking at easily 20 to 40 million in ARR. Right. The Tam. Actually, I just pulled it from jll. The transaction. Volume, which is we're in a bad year. We're 50 billion globally, right? Back in 2015, at our peak, we were close to 100 billion. So I consider that, like, the transaction triggers the workflows, and then from there, like, it just. It's a flywheel, right? The manage seller, the. Management company, the buyers looking at it, the lenders, the appraisers. Right. It's his flywheel that's very, very in the Berends which is very, very interconnected. So I think that, you know, my estimate is actually really conservative because I think you can scale this thing pretty quickly domestically to globally, But. Our first two years. What we're looking for is can we raise 1.2 million for the first 18 months, and can that get us to clear 1 million in ARR by the first year? That's just the core modules of pipeline management and underwriting. That would give us probably 12 customers for users each. At $15,000 per year. That's kind of how we're looking at it. So two. Just two years. Right. Just let us put our heads down, work with the customers, and build the product. Then you transition to a transaction management platform and this is already happening. VTS has done this on the office side deal path is doing this and then you flip your pricing to be bips on transaction volume. So you now providing the tools and then you're actually become the brokerage. Yeah. So 10 bips. I mean, can you share shift? I mean, because that's kind of what it is. 10 bips from the process, right? From the broker process or the lender process. Because now they're using your tools and they're much more tools. You might not only be brokerage, you might want to be origination on. The debt side too. Yes. Yes. So that's why I. This is. It's very scalable. And I think it's scalable within really the first five, you know, five years. What's been the reception as you pitch this to pe? Everyone loves the idea. Everyone loves it. And I can show you when the next time we sit down. Like. Like quotes from customers of Deal Path. Right. And these other platforms. Obviously we don't have customer quotes yet because we are at the poc, but everyone loves this idea. And that's why I'm so committed. I want to bring this to life. Right? Yeah. I think that's the biggest selling point, is your passion for it. I mean, frankly, you know, that's, that's, that's what, in the long run, pull through, you know, how can I be helpful? I. Mean, this. This gives me kind of a better understanding at what you're doing and visually see it. You know, can you let it just sink in? And you are not. You're very well networked in the hotel technology space, right? So part of me thinks, all right, should I talk to someone like Ben Rafter? Because what Howard and I have, he's got the product knowledge, and I have all the domain expertise. On, on the workflows. We've never done a startup. We're not startup people. Right. So we need somehow to find some startup expertise to layer in. And I, when I think about potential strategic relationship with Otelli, because I've gone down the road with Actable and they don't want to do anything. So if I approach Ali Malou at Otellier, if I went to Ben Rafter first, and he's a customer, right? And Brumington may have been a customer, I don't know. But I'm just trying to think about who do I go talk to. Because what relaxing right now is startup expertise. And I think it has to be someone that you have a deep relationship with. So as I've looked at starting a business, I'm a little bit rare in that I've got a really big public Persona. You guys don't have that equivalent. And so that's where I would say, Diane, for you is like, who do you deeply trust and have deep long term relationships with that is adjacent this to like a PE fail, like if you were really close with Mitch Shaw, for example, or you're really close with and that's who you you convince because you're selling. Not only the idea, you're selling yourselves. And someone who's going to, you know, test with you. I mean, one of the things instead of just co investment, you know, on a design partnership, you just that it's for free. But the big to have a great design partner is not co investing, it's actually giving you the time, you know, because most of these groups aren't going to have the people or the resources to, like, iterate with you. And you need, like, that person who's, like, really passionate. And that's only going to come through in, like, a deep friendship relationship, you know, As I was adding advisors for my new business, I. I only h. There's only really three advisors that I was interested as one, like a deep friend that I really, really trusted. And that's probably more important than any because they're going to invest the time in you Two was someone who could cut a big check and maybe they were in category one. But it didn't matter. Or third was someone who has a big cachet to help me raise around that, you know, and I think for you, You need. You need somebody that, like, you've got a deep relationship with, because you don't. You guys don't maybe have quite the. You know, like, if I go to fifth wall, I maybe get a little more. Because just. You have a tremendous public Persona. Right, right, right. That you could almost kind of monetize. So maybe you gotta. I don't know who in your background. Is that person. But that can be almost like your advocate. Maybe you give them equity in the company, too, as part of this. Right. And I tried that with Mark Gordon. Right. And that it didn't work just because we couldn't align on he didn't really wanted to bootstrap and I don't see a path where we can work for free forever. Right. Strategic relationships where maybe they hire you, you know, maybe you're giving up 30, 40% of equity. For more current income. Right? You know, it's like you draw. You both draw some, you know, significant salary. And that's why, you know, it almost feels like a deal. Path to Rediq a PEAR review. Or going to Michelle Russo or something like that is, like, the best path. You don't like the idea of atelier? I'm just curious. Your response? I don't know. I don't know well enough. And we weren't a client. At remington. Okay? Would you be open enough to at this point after hearing. And we didn't get to show you our pitch deck, but to introduce me to Ben Rafter because Hotel equities is. Yeah, yeah. Ben's great. Yeah. Yeah. I mean, I think you're going to find with him his time. Yeah. He didn't. Even want to be CEO of a hotel equities. I mean, he only did the deal because, you know, he's the primary on our springboard and PPC really liked him. They didn't have good CEO succession. I think they're going to recruit a new CEO in the next year and I think he'll move on. Like a chairman role or. I mean, he's amazing. I don't think he's going to have the time. You know, I'm. He'll give you a half hour just because I asked him to, because we're friends, but he. The problem with him is. Time. You know he doesn't have any of it. For any. Not even for me. So I just caution you there. Yeah. I mean, tremendous thought leader, but. Right. And that's what I was thinking. If I could. If Ben thinks the idea is interesting, then if he and I have met. Ali, I worked with them pretty closely when I was at CBRE because they were the company that I was trying to. Get CBR to invest in, right? But if someone in a le circle would say, ali, you really should listen to this. This is a good idea, right? Then I can re pull up my relationship with Ali and I have a customer of his that is saying, this is a really interesting idea. I'm happy to I'LL definitely if you want to send me like the deck and then I'll not only email him and cc you also text him. I just saw him in LA a couple days ago. I mean, we're good friends, so. And I respect the hell out of him, so I just caution you that he's even like time is, like, almost for nobody, you know? I mean, I'm an investor in a staffing company that I've been trying to get into, hotel equities. And he's been giving me a bit of the ignore, and he knows I'm an investor in the business as an example, so I just caution you. But he's great if you can get his attention. Right. Okay, great. I appreciate that. And then if you could just. Again, now that we've explained it, Lena, just sink in, right? You may have some ideas that pop up. I worked for Michelle Rousseau, so I'm one of those people that did a year rotation in Hotel Ave, and I probably wouldn't go back. To her because of. Of just some of the interpersonal challenges there. Yeah, I've heard things. I only know Michelle peripherally, so I can appreciate that. Right. But I think the groups I have on my mind, and I know we're really at the top of the hour, is otelier because they can. They have the data. Hot stats because they were acquired by Duetto. Right? So that might change. Right. Cindies is green, who could be a fit. Although I don't think she would understand the capital market. S workflow needs, like, someone, like. So she probably figured out, although I think she's diluted herself down. I don't even know if she has control of Calibra anymore. And, like, she definitely doesn't have 51% equity because she took on capital from that Chinese group.

### You (2026-02-03T16:58:39.099Z)

Yeah. Thank you very much.

### Guest (2026-02-03T16:58:39.499Z)

But you should definitely. She'd be great to talk to too. I got. I do have to run. I apologize. No. Thank you for the follow up. I'll at least get you into in front of Ben and then I'll keep thinking about it too.

### You (2026-02-03T16:58:49.099Z)

Yeah. Thank you.

### Guest (2026-02-03T16:58:51.499Z)

Thank you so. And we really appreciate your time. And I am going to get this off the ground. There's just. I. It's too important. We really need it, so thank you. Fair enough.

### You (2026-02-03T16:58:57.259Z)

Five. Yeah, likewise. Thank you.

### Guest (2026-02-03T16:59:01.579Z)

All right. Nice meeting you, Howard. Bye.