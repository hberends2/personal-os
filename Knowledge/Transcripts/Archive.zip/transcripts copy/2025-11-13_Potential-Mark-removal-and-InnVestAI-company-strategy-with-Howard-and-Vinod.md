# Potential Mark removal and InnVestAI company strategy with Howard and Vinod

**Date:** 2025-11-13 00:00:00 UTC
**Meeting ID:** f5e4a31c-0243-47aa-94f0-df0706f5565f
**Synced:** 2026-02-05 14:54:33

---

# Transcript for: Potential Mark removal and InnVestAI company strategy with Howard and Vinod

### Guest (2025-11-13T17:20:30.279Z)

Think, because I haven't been able to show you guys yet. But I'm confident that by, like, around the first of the year, I'm going to be able to show you how just the relationship itself will help us grow this business in the industry. Right. It's not just a matter of me getting $8,500 a month. It's like, who can they introduce us to? How can these other companies that they're working with, this. Are trying to put together an advisory panel of the best technology companies in the space. We get to participate in that. That's very valuable to us. So to me, it's splitting hairs. And I was all back my mind we have to start paying ourselves. We can't continue to work for free. And so this was I was trying to figure out how to just get at least my cost covered so that then the next safe node investors could be focused on other people. And we didn't have to, you know, then say, okay, now this Safe Node investor has to go to pay, you know, these five or six people. Could I ask that in the next, like, in March? Potentially. I just would ask that you guys spend some time come January understanding what they can offer us before.

### You (2025-11-13T17:21:56.120Z)

We make an app or something like that.

### Guest (2025-11-13T17:22:00.839Z)

So I'm just curious. What? I work for them like you. Stop working. They don't InnVestAI. Well, what my ask is, once we get a bank account, I will ask them to deposit the balance of the safe note into the bank account. But I don't have a bank account. Right. So. And I have to pay mortgage and I have to feed my kids and I can't let this run for two months. Where I'm going to ask for them to deposit the full 75k. But I just. I mean, I guess I just have to ask for a little bit of trust because we're just starting out. It's not like we're an established tech company or even an established startup where we have a lot of power. We don't do an llc, so definitely now. Company. Yeah, I'm just. I was asking you just to kind of separate these two things, right? You are working for them. They pay you for that work. And then they are interested in investi. They invest in InnVestAI. They become our investors. Just clear path. So that, you know, they kind of stay invested even though you are not working for them, right? For suppose for any xyz reason. Right. So if when we have a bank account, right, which I don't think we're anywhere near close to having, the bank account that Drew and Mark are thinking that we're going to have, I would ask them to put the balance of the 75k in. I was just trying to come up with. A short term stopgap agreement. On the other it was a simple as me trying to get creative and figure that out. Eventually. I don't know how to describe this, but we're going to need about 500 to 750k and working capital. You add yourself and your Howard me, and you add the software engineers in India and you add Carrie for some marketing support and a few other things. And we quickly get up to needing about 500 to 75k on working capital. Part of that, right? So are we taking a risk? I mean, a little bit, but, I mean, trust in me that I have spent two years trying to build this relationship with them, and I. I really wouldn't do anything that I thought would hurt InnVestAI. But now let's get into another topic, if that's okay, now that Mark is on the phone. I'm sorry, not. Howard on the phone. It's been a long day. I'm sorry. I'm very, very tired. So at this point, I am not comfortable moving forward with Mark as a co founder. I don't believe he's the value that he needs to add. I think he creates more problems and solutions. I think Drew's getting caught up too much in Mark's ego and a lot of sidebar conversations, and I want to find a replacement for Mark. I have a few ideas on who that could be, but Mark and I don't work well together, and that's not going to change going forward. And I see this as, like, a marriage. Once we sign this LLC agreement, If we need to remove Mark, it's a divorce versus dating right now. And I know that is going to be probably going to be really uncomfortable. But he's just not adding that. He's not adding the value that we like. I need him out trying to help us find investors. I need him out trying to help us find customers. And he says he's doing it, but he's just too egotistical and cagey, and I don't think that from a culture perspective. I just don't want him in the mix going forward. I want Drew to stay, of course, but this dynamic between True and Mark, I don't know how this is going to play out. What we're going to have to do, or what I'm going to have to do to affect that is pay mark back the 7500k he's loan the company, plus interest. I need to figure that out. To do a clean break. And Howard and you. I mean, I guess the three of us need to do some work to understand if there's any legal risk associated with this. But I don't believe there is because we're having all the IT rights, right? You've built this really? Your baby? When it's all said and done, the technical LLC is undermining in Delaware, and I was the one who applied for the EIN number, so those are in my name at this point. I'm going to change a lot of things. And I wanted to bring that up with you. And I guess Howard Howe helped me out here. Am I saying this a good way? We've had so many conversations about it this morning. What might I not be saying? Correctly. Is there anything to add to it to make. It. Better, clearer.

### You (2025-11-13T17:27:47.000Z)

No, I think you're stating it correctly. It's just that. I don't have any idea how we're going to go about this. I agree. I think it needs to be done. But, yeah, there's going to be. I don't see any way that we can do this without getting ugly. And one of my concerns is, and I thought about this after you and I spoke, that he's got the money to lawyer up and we don't. And since we do not have an llc, he would not be coming at InnVestAI llc. He would be coming at Diane, Howard, Vinod, and Drew. So again. I really think that we have to have a conversation with an attorney to make sure that we don't screw up and end up being liable to him for some type of. Separation or something like that.

### Guest (2025-11-13T17:29:00.279Z)

I agree with that. I did do some quick searching this morning. Like under Delaware law, If you don't really have an LLC agreement, there's not that much to go on. I mean, we do have written. I have written email back and forth. That was my intention to give him 20% of the company, but that doesn't seem to be enough under Delaware law to give him a substantial case. But that doesn't mean he couldn't become litigious like you're saying and just lawyer up and cause us some problems on the front.

### You (2025-11-13T17:29:34.600Z)

Didn't you get the ein under Georgia?

### Guest (2025-11-13T17:29:40.599Z)

No, the EIN is a federal. It's the federal tax number. So we incorporated in Delaware, and then I had to apply. Then I had to apply to Einstein or National. Maybe I need to go back and then check that. But it was part of the whole setup package that I did.

### You (2025-11-13T17:29:45.960Z)

Right. Okay? So we do have a Delaware corporation, then, right? Okay, I misunderstood. I thought the LLC was part of that process and that since we didn't have the LLC sign, that we didn't have any type of. I don't know if that doesn't put a wrinkle in it or not.

### Guest (2025-11-13T17:30:08.439Z)

Yeah. So we have a corporation, InnVestAI llc, right now, and. Please don't. This is not my intention. My intention was to add you guys. Right? I was just trying to get the name locked down at the time.

### You (2025-11-13T17:30:34.040Z)

And that's fine. If it's just you, then yeah, okay.

### Guest (2025-11-13T17:30:35.959Z)

Right. And if Drew and if Mark wants to go after me.

### You (2025-11-13T17:30:41.400Z)

As long as it's Mark, then that's good.

### Guest (2025-11-13T17:30:44.759Z)

Yeah. And truly, if Mark wants to go after me, let him. Because he can have the $500 in my checking account right now. That isn't going to cover groceries until Monday. So I have not. I mean, he can. He can go into litigation with me, into perpetuity. I have nothing to give him at this. Point in time. By your point about talking to an attorney is spot on. You need legal advice, real legal advice on it.

### You (2025-11-13T17:31:13.880Z)

Yeah.

### Guest (2025-11-13T17:31:14.519Z)

But now let me just back take.

### You (2025-11-13T17:31:16.200Z)

Conversation with Mike.

### Guest (2025-11-13T17:31:17.399Z)

It. I don't know if my Sherburne will do it for us anymore. I totally screwed him over, right? And I feel bad. Between everything that was going on, I thought I was kind of hitting a pause button, but the pause button just kept going. Longer and longer and longer. And then before you knew it, it was two months, and we never. I never really gotten back to him.

### You (2025-11-13T17:31:43.480Z)

Yeah, I wasn't thinking about hiring him. I was just thinking about if you still had contact with him and you could just ask him.

### Guest (2025-11-13T17:31:50.679Z)

I do. I'm just worried. Right because of the way I treated him.

### You (2025-11-13T17:31:55.320Z)

Yeah. Yeah. Okay. No, that made. That's fine. That makes sense.

### Guest (2025-11-13T17:31:59.799Z)

But maybe. Vino. Can we just turn this over to you? I mean. As I say all of this, do you ever reaction? Do you feel that's a bad idea with Mark? A good idea with Mark? You're indifferent with Mark. What are your. What are your thoughts? I don't know. I just wanted everybody to come together, even after this. Because rather than dealing with all these things, we would be rather focusing on other things. And now we'll have a deal with all this thing that, you know, I'm definitely not prepared. And either I thought. Thought of this. Yeah. I would definitely. I would definitely like to get out of all this, you know? Attorney, law and lawsuit and all the situation because I'm already an immigrant. I'm an H and B visa. And that will screw me big time. I get a lawsuit for any reason.

### You (2025-11-13T17:33:10.280Z)

Yeah.

### Guest (2025-11-13T17:33:21.399Z)

We should just move forward with Mark.

### You (2025-11-13T17:33:26.360Z)

We could.

### Guest (2025-11-13T17:33:27.879Z)

That's my personal thing I'm saying. You know I'm on immigration visa, right? If he says that. You know, if he includes me in that lawsuit for any XYZ reason, we entire family will get screwed up with time for sure.

### You (2025-11-13T17:33:46.760Z)

Present him with an option. And if he turns it down? Then that would put the onus on him. You know, if you want to stay, here's your role. If you want to go. Then. Then you sacrifice everything here. And like I said before, maybe giving a small percentage for what he's done up to this point. So that he can potentially get something in the future for what he's done. But for example, you know, like I said that when I looked at the LLC again when, when we were having on conversation with Drew last night, it states very clearly that he is in charge of sales and go to market and you know, and I said I. I wouldn't sign an llc. With that in it. So, you know, there we could potentially say, okay, you are strictly capital markets. All you do is fundraise. And in lieu of a salary compensation, you get a percentage. And. And just say and leave it at that. That's your role. You go.

### Guest (2025-11-13T17:35:04.279Z)

The only challenges. We can't leave our fundraising future up to him.

### You (2025-11-13T17:35:08.040Z)

Not. Not exclusively. That's another thing.

### Guest (2025-11-13T17:35:09.879Z)

Okay? That's what I do. Not understanding. Like, if he brings money, we can't say you're responsible for fundraising, and then he literally never does it. Right? And we're totally screwed because that's what's happened. He's literally not done it.

### You (2025-11-13T17:35:23.240Z)

No, we could. We could set expectations or, you know, like, you know, you have to reach, you know, at least this amount of fundraising or whatever in order to maintain it. We could. We could absolutely do that. I would treat it like an employee.

### Guest (2025-11-13T17:35:25.319Z)

Can't. We have multiple people.

### You (2025-11-13T17:35:39.720Z)

You know, give them his. His requirements. You know, any salesperson's going to have a quota. And if he doesn't need it. That's it.

### Guest (2025-11-13T17:35:54.519Z)

I mean, what is the intention here? We want to keep him out of sales. Can't we have multiple people of sales like Diane Drew and him? Sales and fundraising. The problem is Drew and Mark and I. And I'm so sorry about this. We're not. It's not coming together. It's not clicking. Like we can't come to agreement on anything. We really should have had a plan at this point that says our intention is to fundraise X, then try to get customer revenue of why by this period. And Mark and my opinion, he wants to bootstrap the whole thing. And I think that's very unfair to you guys because he. I mean, it's all on your backs. He's not doing any work, and you guys are working full time. And that's not. To me, that's just not a fair situation. And we've been living under it for a very long period of time. Tell me one thing. What if we just don't do anything on InnVestAI? We leave this as is, we register a new LLC with different name. This morning. Yes. Let's not do anything with Invest. And then let's register a new name, start working. From there. He doesn't have to do anything with that. New company. I guess that's what we need the legal advice for. My only thing on that is InnVestAI is such a good actual name for us, right? That I'm very sure about this company does. And we also have domain name. You can use that anytime in future, but for now probably just. Let it remain. There not do anything there. And then silently, kind of. Yeah. Will you register an llc? Is that what you're saying? Under another name, yeah. I could be our domain name. But the corporation name could be something different.

### You (2025-11-13T17:38:08.360Z)

Yeah.

### Guest (2025-11-13T17:38:09.399Z)

Yeah, yeah. Domain name. We already. You have the domain name.

### You (2025-11-13T17:38:11.960Z)

Yeah.

### Guest (2025-11-13T17:38:13.319Z)

You also have the llc. So he cannot use that domain name, he cannot register that llc. But we just don't work or, you know, develop the technology on InnVestAI. We develop it on a different name, different company. Let's go from there then. He doesn't have to say anything. Like, do whatever. There's no. We haven't signed any document, so. Sir, we are not working.

### You (2025-11-13T17:38:35.720Z)

Yeah, that's a very good point, Diane. It's, it's like. I mean, we've seen it with JV partners, You know, all of the hotels, you know, their owned. The ownership is one. But then they are, you know, it's basically a dva. So I think. I think the note's got a great plan. I mean, we could make up any name, call it whatever we want.

### Guest (2025-11-13T17:38:59.639Z)

Yeah.

### You (2025-11-13T17:38:59.960Z)

But then we'd have a dba as well. Dba as InnVestAI.

### Guest (2025-11-13T17:39:05.559Z)

Okay? Okay. Remove all the technology, whatever we have done on that domain. Good. Because at the end of the day, like, practically, I don't even like you and even owed you and Howard have created all the technology infrastructure to me. You actually own that? Like I had. I don't. I don't claim to any of that. I mean, you guys are the ones who have done the work to create it. So. Now that then the challenge becomes Drew and what what Drew will do in all of this project. Mark. So wherever Mark goes through will go. So just. Okay? I think 8 to 90% chances. Is like he'll just move with Mark. But then we cannot tell this to true as well, because he'll tell Mark. But eventually Mark will come to know, right? It's. He deals in the same business that we're gonna deal. Probably. He might create a new Mark. Could be competition for us. That's what I raised to Howard like. Like he. And Drew have been part of all of our discussions. They could be competitors to us. But the one thing is, I don't think I'm gonna tell you this flat out. I don't think Mark actually understands the business that we're trying to create here. I don't think he could describe it. Adequately the frustration I've had with the pitch deck. I just want to, like, I should have a pitch deck by this point, right? And the pitch deck is woefully inadequate. It's only 12 pages, and it still misses, like, four pages that a pitch book needs to have in it. So I feel like. Sometimes he does these things purposely because if I don't have. We don't have a pitch book, we don't raise money, and then, you know, he continues to just benefit from the fact that you guys are all working full time. He's doing close to nothing and benefiting from it. On your backs. Yeah. Soul Party is not my only bet on him. Was he as a good network and probably he could bring in good sales at some point of time. Right now he has not done anything for sure. And Howard, could you. Do you mind. We chatted with. Can I bring up the Jim Alderman conversation, or can I bring. I mean. Or should we just table that?

### You (2025-11-13T17:41:27.640Z)

Sure. Yeah.

### Guest (2025-11-13T17:41:30.999Z)

I introduced Howard, too, another colleague of mine. His name is Jim Alderman. He's currently head of residential at Airbnb. He is a mark. He could replace Mark as far as relationships status in the industry. And he's honestly much nicer and much more collaborative. We kind of talk today, I don't know. About I would get twice this week about a lot of different things. People he could introduce us to that could be investors, that could be advisors of ours as we develop the strategy. Airbnb is actually trying to develop something internally, an AVM of sorts, for a mezzanine fund that they're working on that he's trying to figure out. And basically I'm closing my eyes is when I say this, because I'm just trying to say I was flat out and said that I have nothing to offer right now. I just wanted to get his sense if he'd be even interested, and if he is interested, I'm not sure that we would. Do the 20% split because this whole part time, full time thing. It is a big deal. Like if someone isn't working full time, you know, like eventually you're going to be full time. But not. Howard already is full time. Right. Last thing I would say. Whatever we are planning next, just don't add more partners. I think with three are enough for now. We'll start. We'll see if we need to add more because it becomes two years. Like dealing with five partners is a mess. Wherever is coming on board we shouldn't bring in as a partner. Probably in less security or we'll have to figure out something. But too many people is a headache. Because then decision making becomes big challenge. Just, you know, we could see we didn't make any progress on marketing, sales, anything here. We don't want to repeat that mistake again. Ok, that's good feedback. I mean, is this a huge mistake, you guys being. Speak up if you. I mean, if you believe this. To kind of. Yeah. The best thing would be if you three could work well together. Really? I mean, I always thought that this is. We're gonna do great because I thought you guys have good chemistry. You go well and you'll move in the same direction, But I understand, you know, when we work together, the different. You know, we can go in different directions. I had similar situations in previous companies. Howard knows. Like, I was brought in with one of the guys, but we couldn't work together very well. So I understand sometimes. In work, it can happen. But, yeah, I mean, if you, like, 100% decided, no, I'm not gonna work, then I don't have anything to say. I guess it's not. Maybe I shouldn't have been so definitive. I mean, it's the three of us. It's our company. I'm not ready to put my future in Mark's hands. It scares me too much that he's just. I've said this to Howard, like, he's like a bad actor. He's like a bad seed. And when you put a bad seed in a company, it kills your culture and that's. What I feel about him is that. Let me tell you a story just really quickly, just because maybe this will resonate over summer. I had lunch with the chief Investment officer for Peachtree Hotel Group, Brian Waldman. He's in Atlanta. Brian and I know each other. Honestly, Mark has a stronger relationship with Brian than I do. But we both know each other. And so during the lunch, I pitch and I pitched, and I was trying to pitch the idea that. We were 2550% through the MVP. I forget what I called it at that time, but we needed about 175k in capital to get the MVP to the finish line. And would that be something they would be interested in doing? Right? Like doing the same thing I'm talking about with Driftwood, a CIA where there are customer and investor and advisor. They invest. And Marc's talked about this too. Like the idea of you're just gonna need a bunch of hundred K safe notes. Right? So in my mind, it was almost like 200k safe notes. Brian said, oh, 175k. He's like, really? That's nothing for us. Like, we should talk because, like, we spend way more in technology than that. He said, I think it would be a better fit initially in our debt. Unstructured. Finance team. So I'd like to, like, get you guys set up and introduced, and you guys can show us where you are with the mvp. And that was all great, right? But when I was telling him about the partners and I was throwing through and I told him about you, and I told him about Howard, and I told him about Drew, right? All positive at the very end of the launch. Brian looks to me, he's like, I just have one question for you, Diane. He's like, I don't get you and Mark. And I'm like, oh, well, yes, I know. I'm like, but, you know, he is a capital markets person, and he does know a lot more people using circles and he's like. Yeah, it's just the temperaments. He's like. That's what I don't get. He's like. You do know that Mark's reputation, right? What's Mark's reputation? And he said, well, Mark's known as being a hothead and that. He's known as hanging up on people, like, in the industry, right? And really off guard at that moment, like. And I tried a song, mellowed because that's what people have told me, like. Oh, Mark's mellowed in age. He's not like he used to be. Because that's what I said. Mark's middle of an age. He's not what he used to be. Right.

### You (2025-11-13T17:47:49.560Z)

Like that.

### Guest (2025-11-13T17:48:05.319Z)

But there was a day when Drew and Mark and I were on a call and we were having a huge dispute, and Mark raised his voice. To me throughout the entire call, and I got so tired of it at the end, I said, all right, Mark, well, now we need to turn this around because you owe deliverables to us. You owe deliverable to us about what the fundraising plan is, what? Who you're going after. As top customers, we are asking the technology team for tremendous transparency and what they do every single week. And you're not showing that same transparency on the call. And I said it all. I mean, almost like this. I was very matter of fact, because I was pissed as hell. And he said, diane, don't you ever. Talk to me that way again. And then he hung up on me. And so in that moment, that conversation with Brian Waldman came flooding back into my head like, crap. He literally just hung up on me. Like, that's not. I mean, there's one time where I had to cut a conversation short with Drew and Mark, but it was just because I was so stressed about how I'M gonna feed my family, right? That. I was just getting too emotional, and I had to say, I can't. I'm too emotional. We're gonna pick this back up. But I didn't hang up on him. Am I being petty? It's just I'm not sure I wanna go into business with someone that hangs up with people. And then. This is the last thing I'm gonna say. It also triggered a memory that I had when Mark and I were young and he was a broker at Son of, like, Goldman and. I worked at a company called Lunley's. Sonnenblick sold us a hotel. It was the Doubletree, Crystal City. And they did a good job on the acquisition. We sold it two years later. It was a 40 some percent IRR good investment. We, as a company had a history of retaining brokers. Like, if they sold us something and we did a quick flip on it, we would use them for the disposition. We had done it, like, three times in a row. And so I told Mark, I'm like, yeah, I think we're gonna use sonnenblick. Right? You guys did a great job for us. I had no reason to doubt why we would not. And we would not engage son Blake. But as it goes in corporate culture, I was not the portfolio manager. I was not the final decision maker. And they decided to go with Jaill on the disposition. Mark erupted on me and yelled and yelled at me about that situation. And I remember being upset about it. But in retrospect, now that I'm older, I was the client. Right? I was still the client. We were still in blood business going forward. And Mark dressed me down in a way that was one of the most unprofessional dress downs I've ever gotten. And so when I said Marks outgrown that, he's gotten mellower with age, I was repeating. What some people told me, but the moment he hung up on me, I was just like, wait a minute. If he just did that with me, is there a chance he could do that with customers like he did to me when I was in my late 20s, early 30s? And this is why I'm starting to get really concerned because he's volatile.

### You (2025-11-13T17:51:03.640Z)

Position to give.

### Guest (2025-11-13T17:51:46.039Z)

Abrasive. He just doesn't produce, and I can't get him to produce. Right. I wanted to tell that story because it's just been something that has been weighing on me. And it's like, okay, we do this, and we're married at the hip with Mark for the next ten years. With whatever we are thinking. We are not just losing Mark, we are also losing True. Right. Brew Also a lot of connections and he has a big network as well. So we are kind of losing two main. I mean, not main, but two people who has a lot of network. So, I mean, just think through once more if there's any way we can work this out. If not, then, you know, we don't have to.

### You (2025-11-13T17:52:36.040Z)

So Benode I agree, but not 100%. I think Drew could be salvageable. I don't. I don't think it's guaranteed that if Mark leaves, drew it as well. You know, Drew has a business.

### Guest (2025-11-13T17:52:49.639Z)

Okay?

### You (2025-11-13T17:52:52.040Z)

And he realizes the mutual benefit he would get out of it. I think he would be mad. I don't at first, but, you know, if we can prove that we work much better as a team without him than with him. He might. Not just pick up his toys and leave either, so I don't know. I think there's a good chance he would, but I also think there's, you know, a chance that he could stay.

### Guest (2025-11-13T17:53:26.519Z)

Yeah. I mean, that's it right now. I'm just. That lawsuit and all that kind of stuff is stuck in my head. How? Like, how do we avoid that situation, right? Because.

### You (2025-11-13T17:53:38.360Z)

Yeah.

### Guest (2025-11-13T17:53:39.719Z)

If you are rightly saying. I. I mean I've seen how market I think he is hot headed for sure. But, yeah, I think we should probably. Think more and then decide. So no decision today. Think more on it. Because of the potential loss that it brings to us. Right. Okay? Then going back. I'm not going to be on the call today because I have so much budget work to do. I. I think I'm gonna, like, actually, like, go throw up pretty soon. At the amount of analytical work I've got to do that follows this. I guess you guys go through the LLC agreement. I mean, I'm not the. It's. We're all partners, right? So. And I've spent a lot of time in it myself. So, you guys, you can debate it. And Howard. I mean, is that a good use of your time, or what do you. What do you think?

### You (2025-11-13T17:54:44.520Z)

Yeah, I don't. I don't mind. Going through and working some of those out. I mean, it may actually set the stage for what we might want to do. Because I will bring up my objections to the the job description. I will bring up my objections to the salary if you're not working full time. And you know, I don't want. To expect a decision. But I will lay it out that these are. Potential breaking points. And we'll buy some time to give us some thought. And go from there, so I don't think it's a waste of time, but, you know. It would be interesting to see Mark's reaction to. When I say no, you're not going to be sales. I don't know. We'll see.

### Guest (2025-11-13T17:55:38.279Z)

I'm. Guys, I'm just telling you, he. We cannot have someone who will drag their feet.

### You (2025-11-13T17:55:43.960Z)

No.

### Guest (2025-11-13T17:55:44.519Z)

We have. We have to have to have to have someone. And the other thing is, we're giving him 20% of the company for what at this point? Right. Like, if somebody is not done. So far, he has not done anything.

### You (2025-11-13T17:55:57.240Z)

Yeah.

### Guest (2025-11-13T17:55:57.799Z)

Maybe he would have done in future, we don't know. But so far there's no contribution from his side. You agree with that, though, right? Like, I'm not crazy that there's been. No. We can see it, right? It's like we. We can see it. Like, it's not. I'm just making up.

### You (2025-11-13T17:56:09.240Z)

Yeah.

### Guest (2025-11-13T17:56:12.599Z)

Like it's. It's there. Like we are here for close to a year now.

### You (2025-11-13T17:56:17.400Z)

You know, a couple months ago, when I initially brought up my objections to Mark getting a salary and we talked about the commission, I had a conversation with Drew, and Drew agreed. He didn't see number one. Where Mark should be drawing a salary for that. And he also said the same thing. He says. He hasn't done anything to this point. He's waiting until we have a working model before he's willing to have any conversations with anybody. And, you know, at least a couple months ago, Drew was not. He was. He was frustrated with that as well. So, you know, we do have some common ground there.

### Guest (2025-11-13T17:56:58.039Z)

Mark wants us to deliver the perfect product that he can sell immediately, whereas what we need right now is someone who can go in and start to talk with potential. Like people in the hotel industry that have a reason to want to make something like this come to fruition. They're not just pure angel investors, right, that say, oh, I get this, right? And so I really want to be part of the change, you know, and we're going to work with you to get from where you are at now, 75% of the MVP to a finished MVP and then start to get your. Do you call these version launches right? We need an inner like we need someone who will. It's not like we're delivering the perfect product because we still need a lot of customer, real customer feedback, not just what Mark and Drew want to exhaust everything that Mark and Drew and I know about the investing industry. And that's good. But this is the thing. I'm not actually been a lender myself. Mark has not been a lender himself, nor has Drew been a lender himself. Right. So when we're talking about launching in the debt unstructured finance space. We need real customer interviews. With lenders themselves. I may think I know the way a lender looks at this because back in the day when I was at lendlease, we were balance sheet lender and we had MES funds, right? And so I worked a little bit on it. But I'm not Western Alliance Bank. Right. I don't understand their processes. I don't understand, like, what UI they would want. And we need these, this customer feedback. And I think Drew and Mark are just going to keep dragging their, dragging their feet, dragging their feet, hoping to create the perfect product. And I keep saying this. It's on your backs, right? They're basically using you and your time and when. No, I mean, you won't be reimbursed. You won't be retroactively paid for the work that you're doing, and that's perfectly fine with them. And that's. But that's not okay, because we could be using this time to get customer feedback, which helps us advance the product itself. And that customer feedback then could lead to customer engagements where we spend three to six months not only working with the customers on the ui, but on what the pricing strategy should be. Right? And then they get locked into some sort of below market pricing strategy for a period of time. But at least we understand and can start to evaluate what the true pricing strategy should be in the first launch on the debt and structured finance product. But can I just. I get the sense of. Because of some. I mean, all of our personal situations are unique and need to be considered here, so we're not going to make a decision today. We're going to think about it. This could be salvageable. It could not be salvageable. You guys are going to go ahead without me at 5:30. And talk about the llc agreement. I am going to get what everyone asked for in documentation on Driftwood. I sent Howard some of it to you earlier that I had. In the next couple of weeks, I will ask them to send something that says they understand how we're using the 75k. The note. I can't backtrack right now on the 75k safe note. It was just too hard to get done. If you understood how I had to song and dance. And work through a big company. To get that done. Maybe you understand more. Yeah, it's definitely tough to get the money for a project that very first anchor investor. Just the fact that we can say that Driftwood's the anchor investor alone is worth some reputational validation. For us as we talk to other people. Of course. Yeah, we'll. We'll do the meeting at 5:30. And we'll probably. Think I need time to digest all this. I've been out. If there's a chance we lose you on this, I'm not going to risk. If I have to, I'm not risking you. I'd rather. Be in constant war with Mark for the next five years than risk losing you on this. So know that, like, if you feel like that's not a risk you're willing to take, Then I'm going to go down Howard route, which is try to find a role for Mark that's de minimis, but keeps him involved to the extent that he's actually contributing. And I won't risk this company if it means you're not comfortable with that decision. Yeah. Yeah. So we can group together tomorrow? Probably. Let me. I'm. Till now, I was just hoping that we grouped together again, back again, and probably. Think through our dialogue. And we'll find some solution. I met Kruger all day the next two days, and then I'm in Miami all week next week going through 50 budgets with them. So I'm going to be pretty much out until close to Thanksgiving when it falls out and dawn, from a workload perspective, You're good from personal front, right? What? I would check you needed. That's good. Well, I don't know. I mean, do I have a check? It's being delivered today. For a month, right? For one month? Yes, for one month. It's just 12,500. It's not too much. And then for rest we'll figure out you need what you need. There no two ways about it.

### You (2025-11-13T18:03:16.360Z)

Yeah.

### Guest (2025-11-13T18:03:18.199Z)

I mean, you can do anything. If you don't have a house or food to eat or, you know, to take care of fm, there's no point doing anything, right? Why are we doing even InnVestAI if one of the person doesn't have basic things, right? So, I mean, I'm going to ask you guys this, too, is that. I hope you can. Maybe you haven't seen everything, but. I can push this forward, right? There are certain skills I don't have, but I know where to go to get those skills in the industry. And there are things like, I wish instead of fighting about the LLC and instead of fighting about Driftwood, we could have spent the last two weeks talking about this incredible strategic relationship. That is potentially emerged where CBRE hotels are shut down their research group. And Howard and I had a call with the former head of their research group, who's no longer there, about resurrecting a product that they're going to kill, essentially. And that product has 8,000 hotels of data. That is delivered into a benchmark product, where they have built these relationships over 25 years with the operators. And it breaks my heart that we argue and argue and argue about such small things. And we could be talking about benchmark or what to do and how to go after the customers and how to create a partnership. With Mark Woodworth, because that's, to me, so much more valuable. But. And these are things that I work on, too, even though you guys don't see it. Like, when cberen announced the research team was dead, I started to put calls in, like, ok, what does that mean? Who's going? Where are you? Literally going to just graveyard this product, because we could call, like, we could resurrect it with them and call it something like Bench. And within a very short period of time, we could have 8,000 hotels that are in software benchmarking. That could take us years to develop otherwise. But I can't even bring it up with Mark because his head explodes if I do anything like that. Is that a separate product or that will be part of this? We have to talk about kind of all of it, I think. Well, we'd have to talk about. We'd have to literally lay out that this is benchmarker. CBRE just graveyard it. It's 8,000 hotels. It's really very quite interesting how the 8,000 hotels come together because Aimbridge is the single largest third party manager in the United States. They have a thousand hotels that they are feeding monthly information into benchmark right now. What is the financial potential there? If there's some financial potential, we can just spin up completely new companies do that.

### You (2025-11-13T18:06:23.160Z)

Yeah.

### Guest (2025-11-13T18:06:25.719Z)

Yeah. I mean. Yeah. I mean, the thing is, we can't do that alone. We need a gentleman named Mark Woodworth, who was the. He was the one who created that product, like, 25 years ago. And we need another gentleman that's getting laid off, like, just like you could. Just like the whole Radix thing. Right? His name is Robert Mandelbaum. Robert Mandelbaum has the. Personal relationships with every single management company. So if we developed a strategy where Robert Mandelbaum and Diane Fox went in and talked to those management companies, I think we could keep the data flowing and then it would flow into us, right? We would process the PNLs like you guys are processing right now. And we would keep the benchmarking product alive. And that would save us years worth of trying to accumulate enough assets ourselves to have a really good inn software benchmarking product. Yeah.

### You (2025-11-13T18:07:31.480Z)

Awesome media revenue. Almost. I mean, depending on how we structure this, but it's possible.

### Guest (2025-11-13T18:07:36.199Z)

Yeah, I would keep an eye on that. We can start completely new company. Nothing to do with True or Mark, right?

### You (2025-11-13T18:07:44.120Z)

Yeah.

### Guest (2025-11-13T18:07:47.159Z)

And focus on that.

### You (2025-11-13T18:07:48.040Z)

Yep.

### Guest (2025-11-13T18:07:50.439Z)

If you see this, any financial potential. I do see. I see enormous financial potential. And, Howard, you were on a call, right, with them the other day. So I don't know if you want to add anything to. I mean, the conversation. I mean, obviously our first call. Not the first call I've had with them on the idea of an avm, because. I've been talking to them for years about it. But did you think it went. I mean, you're honest to God truth. If you didn't think it went well, or you thought it went well, what are your thoughts?

### You (2025-11-13T18:08:23.160Z)

I thought it went very well. Mark and Bill were clearly. Interested and said numerous times that we're on the right track and that this is something the industry needed. So, you know, they were excited enough to ask for a second meeting first in the beginning of December. So they are. They are very interested.

### Guest (2025-11-13T18:08:46.679Z)

You guys see my. This is my dilemma, right? If I go to Mark and Drew right now on this, they are just gonna. It's like angry bees in a beer. We don't have to make this part of InnVestAI. There can be a separate company altogether.

### You (2025-11-13T18:09:01.400Z)

Y. Eah.

### Guest (2025-11-13T18:09:03.559Z)

Okay. All right. Well, we have the game plan, right? And. Good will come I guess, of the conversation, if nothing else, will advance the LLC to the point where if the three of us needed to pick it up and just sign it, we could. Right, because it'll be far enough along we just might be signing it under a different company name than in Best AI.

### You (2025-11-13T18:09:28.200Z)

I was gonna say, I think. I think the node really kind of hit the nail on the head with that one. That maybe. We would need to get a parent company set up. Just another Ein. Set up. And then, you know, just like when Reddick spot Rediq. Rediq is still Rediq. But you had that little thing at the bottom of the screen. Now part of the Radix family, right? We don't have to put that on the screen, but, you know, we would have one almost like a holding company. Something. That would then be the owner of InnVestAI and the owner of whatever we get. You know, like, if we did get benchmarked, or we could continue with that, even keep the name, depending on how cbr he wants it. And I don't know if you saw my note yet or not.

### Guest (2025-11-13T18:10:26.039Z)

About how.

### You (2025-11-13T18:10:26.600Z)

Yeah, yeah. Berkadia gave a steep discount to Radix.

### Guest (2025-11-13T18:10:27.399Z)

Yeah.

### You (2025-11-13T18:10:33.640Z)

As long as they can continue to keep using rediqiq. And so. Blairm got a good deal on rediqiq. Didn't pay anywhere near full market value in exchange for giving Berkadia continued access. So maybe CBI would be open to something like that.

### Guest (2025-11-13T18:10:54.919Z)

Do you guys want me to just go ahead and. I mean, not that I have the time in the next week, but just to set up another LLC in Delaware? Yeah, I mean, that would definitely be good. But let's hold on that. And also, Howard, let's hold on telling Mark that you won't be part of sales.

### You (2025-11-13T18:11:13.320Z)

Oh, no. Yeah.

### Guest (2025-11-13T18:11:15.559Z)

In today's meeting because let's think through our strategy about this company now, how we'll kind of move forward. Why? Because I want to just, you know, let him be calm for some time till we have everything figured out.

### You (2025-11-13T18:11:31.320Z)

Yeah. Okay. Yeah. We can steer the conversation. I mean, there's an awful lot to talk about. I doubt that we will get through everything anyway.

### Guest (2025-11-13T18:11:43.159Z)

Yeah. And that new llc, right? I mean, yeah, let's, let's think through the name, whether we want to just have a standalone for that benchmarking or a parent setup. So probably that's how we'll come up with the naming. And things, right? I prefer Parent Setup. And if there's a name that better, you know, like, you know. And maybe it's not just a hospitality name, either. I mean, that might be something we need.

### You (2025-11-13T18:12:10.360Z)

No, it just has to be. I mean, it could be the three Amigos. Yeah, it doesn't make any difference. What that's named is nobody will see it. All of our marketing material, I mean, everything that's customer facing will say InnVestAI or bookmarker or totally different names. Whatever we come up with.

### Guest (2025-11-13T18:12:12.039Z)

To. Right. And I really understand Vinod with your point about keeping our calm. But I'll also say you guys haven't seen the worst of how he can be because he's been rude on the calls we've had. But you've never seen him be rude to the extent. That can be, like, jaw dropping. Like, holy crap. Right? And I do think if you saw him in that mode where he really, really started to show his true colors versus just raising his voice as he adds on some of the calls, you guys would be very. I don't know, maybe the trepidation would rise a little bit in the fact that his interpersonal skills are too. Let's think through how to handle it. Right. Which don't want to get into unnecessary things.

### You (2025-11-13T18:13:25.560Z)

Yeah. All right? I just realized what time it is, and I've got this appointment in 15 minutes. I got to get my butt going. All right.

### Guest (2025-11-13T18:13:32.759Z)

All right. Thank you, guys. Thank you very.