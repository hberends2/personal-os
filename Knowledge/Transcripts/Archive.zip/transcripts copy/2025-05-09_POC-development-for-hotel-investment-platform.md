# POC development for hotel investment platform

**Date:** 2025-05-09 00:00:00 UTC
**Meeting ID:** 13a8880e-26e7-4d24-8bad-0357191cec4a
**Synced:** 2026-02-05 14:46:48

---

# Transcript for: POC development for hotel investment platform

### You (2025-05-09T19:04:26.893Z)

Hey. How are you doing?

### Guest (2025-05-09T19:04:28.249Z)

Yeah. Howard.

### You (2025-05-09T19:04:30.383Z)

Good. How about you? Good. Hold on. Let me bring this back up.

### Guest (2025-05-09T19:04:34.869Z)

Good. Good. How about you? Yeah. Yeah.

### You (2025-05-09T19:04:36.883Z)

There we go.

### Guest (2025-05-09T19:04:45.499Z)

Have feeling more layoffs

### You (2025-05-09T19:04:47.873Z)

Project that I

### Guest (2025-05-09T19:04:49.089Z)

I saw round post.

### You (2025-05-09T19:04:49.253Z)

I don't know if they're layoffs or if people are just leaving.

### Guest (2025-05-09T19:04:52.319Z)

Probably tell it to more people.

### You (2025-05-09T19:04:53.353Z)

Because I wouldn't think so.

### Guest (2025-05-09T19:04:59.409Z)

No. No. Nobody will leave without job. Right?

### You (2025-05-09T19:04:59.953Z)

But there's a a a couple of people that I've seen in the Kosovo office that have left. Okay.

### Guest (2025-05-09T19:05:09.379Z)

Mhmm.

### You (2025-05-09T19:05:10.253Z)

Not developers. Did you ever meet to Tringa?

### Guest (2025-05-09T19:05:15.059Z)

Okay. Uh-huh.

### You (2025-05-09T19:05:17.693Z)

Yeah. She she worked for Michelle, I mean. Customer service team. That's right. Okay. Yeah.

### Guest (2025-05-09T19:05:25.289Z)

Okay.

### You (2025-05-09T19:05:25.893Z)

But they back before we were laid off, hired 27 people to read

### Guest (2025-05-09T19:05:32.969Z)

Uh-huh.

### You (2025-05-09T19:05:34.183Z)

replace the, Brocadia team, and she was leading that. So I was really surprised that she left. And then

### Guest (2025-05-09T19:05:41.979Z)

Okay.

### You (2025-05-09T19:05:44.433Z)

Maragona left. Okay. Couple other ones. So, yeah, I I pinged Raul. I haven't heard back from him yet. I was gonna

### Guest (2025-05-09T19:05:52.719Z)

Okay.

### You (2025-05-09T19:05:56.573Z)

see what's up. But yeah, I saw that yesterday. I was really surprised. Yeah. Once again, I'm trying to return

### Guest (2025-05-09T19:06:07.349Z)

Yeah. Yeah. So once you get

### You (2025-05-09T19:06:07.933Z)

Okay. I just wanted to give you a quick

### Guest (2025-05-09T19:06:10.609Z)

I'm trying to up this thing I was working on. I just wanted to give you

### You (2025-05-09T19:06:13.663Z)

to where I am One second.

### Guest (2025-05-09T19:06:16.779Z)

a quick demo to show where I am Once again, yes. This is strings. I'm at a I've

### You (2025-05-09T19:06:39.303Z)

Let's

### Guest (2025-05-09T19:06:41.169Z)

And, yeah, can go to the other one. Let's see.

### You (2025-05-09T19:06:50.163Z)

Okay. So I will put the MVP. Right? With this support we need. For this one.

### Guest (2025-05-09T19:06:56.449Z)

Okay. So I'm in for the MVP, right, we discuss what we need for

### You (2025-05-09T19:06:59.713Z)

For the POC. I don't know what all

### Guest (2025-05-09T19:07:03.659Z)

this one. For the POC,

### You (2025-05-09T19:07:05.023Z)

should we have.

### Guest (2025-05-09T19:07:08.299Z)

I don't know what all should we

### You (2025-05-09T19:07:14.493Z)

So want to go down, but I'm just getting started and stuff. Yeah. Are are you sharing your screen?

### Guest (2025-05-09T19:07:18.689Z)

One second. Yeah. This is coming up. So this is the

### You (2025-05-09T19:07:22.873Z)

I'm not Yeah.

### Guest (2025-05-09T19:07:24.029Z)

lot to do there, but I'm just getting started with something.

### You (2025-05-09T19:07:24.323Z)

Yeah. This is and we have to work on

### Guest (2025-05-09T19:07:30.279Z)

Yeah. One moment. Yeah. This is

### You (2025-05-09T19:07:30.653Z)

the do you call the

### Guest (2025-05-09T19:07:35.359Z)

And we have to work on the the

### You (2025-05-09T19:07:36.383Z)

laying down the funnel. So let's get it. I mean, this is

### Guest (2025-05-09T19:07:40.999Z)

what you call, the UI part.

### You (2025-05-09T19:07:41.603Z)

basic. First payment. Mhmm.

### Guest (2025-05-09T19:07:44.349Z)

It's laying down on this one.

### You (2025-05-09T19:07:44.893Z)

And just giving the overall look of the

### Guest (2025-05-09T19:07:47.449Z)

So let's see. I mean, this is

### You (2025-05-09T19:07:49.123Z)

thing, but that's fine. So I'll show you from here.

### Guest (2025-05-09T19:07:51.159Z)

basic first page.

### You (2025-05-09T19:07:53.263Z)

So you have a

### Guest (2025-05-09T19:07:53.639Z)

And just giving the overall look of the

### You (2025-05-09T19:07:54.243Z)

see. This is this is real. Okay? And this is coming from the real data.

### Guest (2025-05-09T19:07:58.579Z)

thing, but that's fine. I'll show you from here.

### You (2025-05-09T19:08:00.423Z)

Okay. Investments returns.

### Guest (2025-05-09T19:08:02.119Z)

So here. Right? PC. And this is

### You (2025-05-09T19:08:04.283Z)

Time frame.

### Guest (2025-05-09T19:08:05.259Z)

by this is real. Okay? This is coming from the real data where

### You (2025-05-09T19:08:07.303Z)

Okay. I need to modify this, but then this is the

### Guest (2025-05-09T19:08:10.139Z)

investments returns

### You (2025-05-09T19:08:11.813Z)

things that come from the database threading this is still my

### Guest (2025-05-09T19:08:13.899Z)

time frame. Okay. So I need to modify

### You (2025-05-09T19:08:15.603Z)

local Okay. And then if I go in here,

### Guest (2025-05-09T19:08:18.449Z)

but, yeah, this is the deal. And these deals are coming from the data

### You (2025-05-09T19:08:19.783Z)

it I'm trying to modify it. Yeah. It needs to have different columns. Yeah.

### Guest (2025-05-09T19:08:23.069Z)

directly. This is still my

### You (2025-05-09T19:08:23.623Z)

Okay.

### Guest (2025-05-09T19:08:25.239Z)

local. And then if I go here, I I need to modify it. If

### You (2025-05-09T19:08:29.483Z)

So this was.

### Guest (2025-05-09T19:08:31.169Z)

needs to have different columns. Okay.

### You (2025-05-09T19:08:34.083Z)

Oh, so at least something. This is very

### Guest (2025-05-09T19:08:39.189Z)

So this was being yesterday.

### You (2025-05-09T19:08:40.893Z)

How did this back to the deal of yesterday's great deal? But this

### Guest (2025-05-09T19:08:41.629Z)

Let's see. Oh, okay. So at least something

### You (2025-05-09T19:08:45.473Z)

basically a deal, this type page that we have right

### Guest (2025-05-09T19:08:48.129Z)

this is great deal. I did this back to the deal. Okay. So there's great deal.

### You (2025-05-09T19:08:50.853Z)

Yes. We need to do more here. And then if I

### Guest (2025-05-09T19:08:54.419Z)

But there's basically a deal list type of page that we have. Right?

### You (2025-05-09T19:08:56.193Z)

go back, one button. Please disconnect.

### Guest (2025-05-09T19:09:00.549Z)

I still need to

### You (2025-05-09T19:09:01.273Z)

Sure.

### Guest (2025-05-09T19:09:01.999Z)

do more here. And then if I go back there's one button.

### You (2025-05-09T19:09:08.233Z)

If you see it,

### Guest (2025-05-09T19:09:09.279Z)

See, see this gray deal button here?

### You (2025-05-09T19:09:11.523Z)

Mhmm. So

### Guest (2025-05-09T19:09:11.749Z)

To this create deal button. I need to add more, but

### You (2025-05-09T19:09:18.103Z)

So let's see.

### Guest (2025-05-09T19:09:18.129Z)

you see if I type anything here. Right?

### You (2025-05-09T19:09:19.473Z)

Country Like,

### Guest (2025-05-09T19:09:21.979Z)

So let's see.

### You (2025-05-09T19:09:22.153Z)

these are the kind of portals that are coming from our database directly. Yeah.

### Guest (2025-05-09T19:09:27.689Z)

So let's see.

### You (2025-05-09T19:09:29.043Z)

Not tell me there.

### Guest (2025-05-09T19:09:30.029Z)

Country. Like, these are the

### You (2025-05-09T19:09:34.003Z)

Basically, with the

### Guest (2025-05-09T19:09:34.019Z)

kind of hotels that are coming from our database directly.

### You (2025-05-09T19:09:36.493Z)

Yeah. That they wanna provide.

### Guest (2025-05-09T19:09:37.469Z)

So this one not don't mean there.

### You (2025-05-09T19:09:38.203Z)

It. Yeah. Alright. Cool. And if I choose something here, it's

### Guest (2025-05-09T19:09:41.379Z)

Can't put hotels of Fairfield. This is the basically, the

### You (2025-05-09T19:09:44.843Z)

see.

### Guest (2025-05-09T19:09:45.209Z)

data that Drew had provided.

### You (2025-05-09T19:09:48.903Z)

30.

### Guest (2025-05-09T19:09:49.789Z)

And then if I choose something here, say

### You (2025-05-09T19:09:57.003Z)

Number of

### Guest (2025-05-09T19:09:57.459Z)

Fair Field 13.

### You (2025-05-09T19:09:58.553Z)

keys and all. That. That's really missing here.

### Guest (2025-05-09T19:10:00.729Z)

Kind of

### You (2025-05-09T19:10:01.163Z)

K. And this is

### Guest (2025-05-09T19:10:01.969Z)

just puts all the

### You (2025-05-09T19:10:03.693Z)

part of here.

### Guest (2025-05-09T19:10:04.099Z)

address here. I still need number of

### You (2025-05-09T19:10:04.323Z)

This for the people, see that I just

### Guest (2025-05-09T19:10:07.599Z)

keys and all that, and that really is missing here.

### You (2025-05-09T19:10:08.193Z)

connect and start one.

### Guest (2025-05-09T19:10:10.999Z)

And this is

### You (2025-05-09T19:10:11.193Z)

And then once Mhmm. Move to left.

### Guest (2025-05-09T19:10:12.769Z)

create deal button here. This for the POC, I I just

### You (2025-05-09T19:10:14.993Z)

You get getting at the end.

### Guest (2025-05-09T19:10:17.989Z)

created a sort one.

### You (2025-05-09T19:10:19.253Z)

And if I go

### Guest (2025-05-09T19:10:21.149Z)

And then once

### You (2025-05-09T19:10:21.643Z)

that page,

### Guest (2025-05-09T19:10:22.689Z)

we do that,

### You (2025-05-09T19:10:23.983Z)

So we

### Guest (2025-05-09T19:10:24.229Z)

so basically,

### You (2025-05-09T19:10:24.663Z)

one more thing here.

### Guest (2025-05-09T19:10:25.899Z)

the deals get created

### You (2025-05-09T19:10:26.033Z)

Yeah. Nice. Yeah.

### Guest (2025-05-09T19:10:28.189Z)

And if I go back to that deal page, so we have one more deal here now. Yeah. And then let's see if pilot is working at think it is trying that out. So, yeah, that's

### You (2025-05-09T19:10:45.603Z)

Doing a demo, this is expected.

### Guest (2025-05-09T19:10:46.369Z)

then let's see.

### You (2025-05-09T19:10:49.643Z)

This stuff always happens during a demo.

### Guest (2025-05-09T19:10:50.959Z)

Yeah. There are things

### You (2025-05-09T19:10:52.583Z)

Yeah.

### Guest (2025-05-09T19:10:54.279Z)

still in progress. Yeah. Yeah.

### You (2025-05-09T19:10:58.683Z)

Okay. Alright. Sorry.

### Guest (2025-05-09T19:11:02.209Z)

Yeah.

### You (2025-05-09T19:11:02.803Z)

To do that.

### Guest (2025-05-09T19:11:05.019Z)

Let's see. Let's see. Okay. Alright. So, yeah, I mean,

### You (2025-05-09T19:11:08.163Z)

Fuel. Feels

### Guest (2025-05-09T19:11:10.549Z)

lot of

### You (2025-05-09T19:11:11.133Z)

So

### Guest (2025-05-09T19:11:11.169Z)

this is throwing error. But, I mean, that's

### You (2025-05-09T19:11:13.553Z)

I don't need to do. We

### Guest (2025-05-09T19:11:17.029Z)

where I'm with few

### You (2025-05-09T19:11:17.813Z)

in this

### Guest (2025-05-09T19:11:19.119Z)

few POC things. Right? So I do need to do more on, but

### You (2025-05-09T19:11:25.713Z)

Yeah. So on the create a deal, I'm also working on

### Guest (2025-05-09T19:11:26.369Z)

create deal, deal this space, view deal, then, you know, I'm kind of

### You (2025-05-09T19:11:30.233Z)

the

### Guest (2025-05-09T19:11:31.099Z)

trying to add then add it, and then probably I'll go to that model and all that.

### You (2025-05-09T19:11:31.363Z)

order of the modals and All steps. Yep. I'll have that by the I wanna have confirmation on our Monday call. That everybody's in agreement with that.

### Guest (2025-05-09T19:11:43.589Z)

Steps. Yeah.

### You (2025-05-09T19:11:45.393Z)

And we'll go from there. And then I also need to get a list of all the property types

### Guest (2025-05-09T19:11:49.269Z)

Yeah.

### You (2025-05-09T19:11:50.613Z)

Do you have that? All the different property types. Yeah. All the different hotel types. There's you know, because there's we don't see everything.

### Guest (2025-05-09T19:12:02.649Z)

Property type. Yeah. Yeah. Yeah. I think we have it once again. Let me see in the database. So the schema, let me input shared.

### You (2025-05-09T19:12:19.433Z)

Yeah.

### Guest (2025-05-09T19:12:19.949Z)

So this is our database. These are our tables. And I think hotel type. You see this hotel type?

### You (2025-05-09T19:12:27.753Z)

Okay, so that's that's it. There's only five types?

### Guest (2025-05-09T19:12:30.749Z)

And data Okay. So we have full service, left service.

### You (2025-05-09T19:12:34.953Z)

Okay. Alright. Thanks. Thanks. Alright. I'm just gonna send out an email to get a list

### Guest (2025-05-09T19:12:36.669Z)

Convention. Yeah. I can send it this.

### You (2025-05-09T19:12:41.303Z)

it looks like you've got it. So let's,

### Guest (2025-05-09T19:12:42.339Z)

That's the data we have right now.

### You (2025-05-09T19:12:43.733Z)

let's make a note

### Guest (2025-05-09T19:12:45.849Z)

Maybe there are more types, but

### You (2025-05-09T19:12:45.863Z)

for on our call Monday to do the same thing to to to confirm

### Guest (2025-05-09T19:12:47.519Z)

that's the of data we have.

### You (2025-05-09T19:12:50.353Z)

that. So once we have the order of the modals and then

### Guest (2025-05-09T19:12:52.919Z)

Yeah.

### You (2025-05-09T19:12:55.423Z)

this will be the drop down list. There are couple other ones that have drop downs, but I think I have all of the data in the Excel model. To populate those. So

### Guest (2025-05-09T19:13:07.449Z)

Yeah.

### You (2025-05-09T19:13:08.773Z)

yeah, we should be good to go.

### Guest (2025-05-09T19:13:09.019Z)

Mhmm.

### You (2025-05-09T19:13:11.523Z)

Yeah.

### Guest (2025-05-09T19:13:19.039Z)

Gotcha. Yeah. And this is the extracted data. Right? This is all the data that Drew had sent.

### You (2025-05-09T19:13:27.403Z)

So just just

### Guest (2025-05-09T19:13:31.089Z)

And let's see.

### You (2025-05-09T19:13:32.123Z)

what else we have.

### Guest (2025-05-09T19:13:34.019Z)

This is just

### You (2025-05-09T19:13:36.953Z)

We Let's

### Guest (2025-05-09T19:13:38.819Z)

these are just numbers. This only more sense, but what else we have? We have brands. Let's see. We'll take that. Yeah. So this is these are all the brands he sent in this parent brand. Account class.

### You (2025-05-09T19:13:58.173Z)

Okay. Yeah.

### Guest (2025-05-09T19:14:04.849Z)

So so tonight yeah. Yeah. Basically, that in group.

### You (2025-05-09T19:14:14.323Z)

Yeah.

### Guest (2025-05-09T19:14:15.489Z)

This group.

### You (2025-05-09T19:14:16.833Z)

So this is this is what I have now. But

### Guest (2025-05-09T19:14:24.769Z)

Yeah. So, I mean, this is

### You (2025-05-09T19:14:26.863Z)

I haven't worked on that letter

### Guest (2025-05-09T19:14:29.229Z)

this is where I'm right now, but making some progress.

### You (2025-05-09T19:14:29.913Z)

that I sent to you. But but that's another thing that I'm gonna try to get ready for Monday. For our call. Yeah. So

### Guest (2025-05-09T19:14:41.189Z)

Yeah. Yeah. Yeah.

### You (2025-05-09T19:14:41.263Z)

I don't know if we need to have I think the there were the of the three recommendations, there is one that we just simply have a letter

### Guest (2025-05-09T19:14:48.769Z)

Yep.

### You (2025-05-09T19:14:54.673Z)

that basically says that we would hold DIP rights until all of the paperwork is done for invest. And then we can transfer something like that. That's what Howard I don't know. I I talked to Diane last week.

### Guest (2025-05-09T19:15:14.409Z)

Yeah. That's what I wanted to,

### You (2025-05-09T19:15:17.123Z)

And

### Guest (2025-05-09T19:15:17.789Z)

as well. And what what is our plan? When is it

### You (2025-05-09T19:15:19.593Z)

she basically said the same thing about financing that she's always

### Guest (2025-05-09T19:15:20.969Z)

planning to register the company?

### You (2025-05-09T19:15:23.253Z)

that she's said every time.

### Guest (2025-05-09T19:15:23.369Z)

Yeah.

### You (2025-05-09T19:15:24.833Z)

But didn't I I just think it's why would be that's not registry? Well, we don't. We we don't. It it it's not expensive to to just

### Guest (2025-05-09T19:15:35.699Z)

But registering is why do we need the financing for registering?

### You (2025-05-09T19:15:35.913Z)

get the name. Just don't know how much she wants,

### Guest (2025-05-09T19:15:39.589Z)

It will be an LLC. Right?

### You (2025-05-09T19:15:39.953Z)

to do in terms of

### Guest (2025-05-09T19:15:41.259Z)

Yeah.

### You (2025-05-09T19:15:42.273Z)

footing the bill for now?

### Guest (2025-05-09T19:15:46.959Z)

Yeah.

### You (2025-05-09T19:15:47.013Z)

But to to actually compile the paperwork and and and file you know, I I she's probably gonna have to get some advice, whether it's an LLC or a corporation. I mean, there's different ways to go about it. So Yeah. I don't know. I was just

### Guest (2025-05-09T19:16:07.069Z)

Perfect.

### You (2025-05-09T19:16:07.833Z)

like let me touch base with her again. If I don't get

### Guest (2025-05-09T19:16:12.199Z)

Yes.

### You (2025-05-09T19:16:13.143Z)

with her before the call on Monday, I'll bring it up on the call. Yeah. That's that's fine. You know, because I I don't feel

### Guest (2025-05-09T19:16:20.039Z)

Yeah.

### You (2025-05-09T19:16:25.583Z)

don't I don't I don't feel like there's

### Guest (2025-05-09T19:16:27.729Z)

Yeah. That

### You (2025-05-09T19:16:28.083Z)

any risk

### Guest (2025-05-09T19:16:28.889Z)

that's fine.

### You (2025-05-09T19:16:29.863Z)

You know, I don't I don't think she's the type of person who's going to But Yeah. Yeah. I I I can't keep mean, I'm I'm still actively looking. You know, I'm not gonna stop looking for a job, but, you know, there's

### Guest (2025-05-09T19:16:42.009Z)

Yeah. Yeah. No. No. No. I don't. Definitely.

### You (2025-05-09T19:16:46.133Z)

there's a point that I wanna have

### Guest (2025-05-09T19:16:46.749Z)

Yeah. Yeah.

### You (2025-05-09T19:16:48.213Z)

some assurance that this is really gonna happen.

### Guest (2025-05-09T19:16:52.819Z)

Yeah.

### You (2025-05-09T19:16:52.853Z)

And and right now, it's just like we're just four friends working on a your back of the napkin idea. It's you know, I mean, you've been putting in many hours. So

### Guest (2025-05-09T19:17:02.329Z)

I'm gonna what? Yeah.

### You (2025-05-09T19:17:04.673Z)

So, I mean,

### Guest (2025-05-09T19:17:05.029Z)

Right. Right. Right.

### You (2025-05-09T19:17:05.963Z)

we gotta at least find out how far they are. So

### Guest (2025-05-09T19:17:10.429Z)

Yeah.

### You (2025-05-09T19:17:10.783Z)

okay. Yeah. But get some some sort of to that. Vehicle. Yeah. Yeah.

### Guest (2025-05-09T19:17:19.599Z)

Yeah. I mean, if you could get some some sort of

### You (2025-05-09T19:17:20.183Z)

I mean, there she said that we would we would get compensated for all the work that we're doing now.

### Guest (2025-05-09T19:17:25.219Z)

money to run the payrolls. Right?

### You (2025-05-09T19:17:27.713Z)

That she's added that into the budget

### Guest (2025-05-09T19:17:28.249Z)

And that have been great.

### You (2025-05-09T19:17:30.293Z)

but when? You know? Yeah. Yeah. I agree. We next January here. So yeah. We'll we'll It's okay. Okay. Yeah.

### Guest (2025-05-09T19:17:43.919Z)

When? Yeah. Do we have to pay the bills? Yeah. So this company yeah. Yeah. I mean, the company I've been working with, it's been, what,

### You (2025-05-09T19:17:55.283Z)

Oh. Yeah.

### Guest (2025-05-09T19:17:58.649Z)

more than a month now. I have not got paid because they have not got paid

### You (2025-05-09T19:18:02.353Z)

The screen.

### Guest (2025-05-09T19:18:04.339Z)

from the other company.

### You (2025-05-09T19:18:04.753Z)

Yeah. That

### Guest (2025-05-09T19:18:06.459Z)

And I had call with these guys.

### You (2025-05-09T19:18:07.263Z)

two. Half a day.

### Guest (2025-05-09T19:18:09.189Z)

Yeah, in the morning. Yeah. Like, like, I'm spending my savings, like, you know,

### You (2025-05-09T19:18:14.193Z)

Yeah.

### Guest (2025-05-09T19:18:15.679Z)

driving here, paying houses. I'm paying more to get on my house, and then I'm paying rent on where I'm living. And, you know, it's basically adding a

### You (2025-05-09T19:18:24.423Z)

Man, I hate hate to hear that. I hope you can

### Guest (2025-05-09T19:18:26.689Z)

expenses, but I'm not getting paid.

### You (2025-05-09T19:18:27.703Z)

work it out.

### Guest (2025-05-09T19:18:29.899Z)

Tell me what's your plan. So you're like, yeah, haven't got

### You (2025-05-09T19:18:30.133Z)

Yeah. So Yeah.

### Guest (2025-05-09T19:18:33.309Z)

paid, and that's why we control your payroll.

### You (2025-05-09T19:18:34.733Z)

So, yeah, I've talked to

### Guest (2025-05-09T19:18:35.429Z)

Yeah.

### You (2025-05-09T19:18:36.633Z)

company. I got company.

### Guest (2025-05-09T19:18:38.819Z)

Yeah, man. Surviving so far. So, yeah, I talked to the company, real company. Like, why haven't you paid them? And they're like, oh, they submitted their invoice late.

### You (2025-05-09T19:18:52.243Z)

Yeah. Yeah. Hope so.

### Guest (2025-05-09T19:18:54.369Z)

Why did you submit it? No. No. No. Wait. Submit it on time and this and that. So, basically,

### You (2025-05-09T19:18:55.283Z)

Alright. Cool. Anything else?

### Guest (2025-05-09T19:18:58.799Z)

I don't know what's going on, but, hopefully, I'll get paid probably by the next week. Yeah. Yeah. I mean, I wanted to understand, like, what

### You (2025-05-09T19:19:08.613Z)

The

### Guest (2025-05-09T19:19:11.829Z)

what also do you make for POC? Definitely that deal creation flow. But that's more of

### You (2025-05-09T19:19:14.923Z)

called with the existing data and the existing Yep. Flow. So we just select

### Guest (2025-05-09T19:19:18.509Z)

the manual flow

### You (2025-05-09T19:19:19.803Z)

the property from the existing list.

### Guest (2025-05-09T19:19:21.799Z)

whether we wanna go that route. For POC, probably we are just

### You (2025-05-09T19:19:22.393Z)

And Yeah. By whatever data we have. Yeah. And we have to think

### Guest (2025-05-09T19:19:25.759Z)

good with the existing data and the existing

### You (2025-05-09T19:19:26.433Z)

based on that. We we do, but

### Guest (2025-05-09T19:19:28.989Z)

flow. So we just select the property from the existing list.

### You (2025-05-09T19:19:29.263Z)

basically, the workflow that I'm working on is everything having to do with

### Guest (2025-05-09T19:19:33.449Z)

Right? Whatever data we have, we create the deal based on that.

### You (2025-05-09T19:19:34.883Z)

inputs that the user would do. So a lot of those inputs would be used in calculating the data. So we do have to take the data that Drew has, but then we have to use that for the valuation. So

### Guest (2025-05-09T19:19:48.469Z)

Yeah.

### You (2025-05-09T19:19:50.743Z)

So So, yeah. I think we need to get all of those models. And if it'll help, I can I can use one of the tools and I can create

### Guest (2025-05-09T19:19:57.749Z)

Yeah.

### You (2025-05-09T19:19:59.433Z)

the modals and just give you the code and then I mean, it might look a little different than what you've got, but I mean, it's just a simple mortal? Mean, Probably take a couple hours to finish it up, if that'll help you. Yeah. That's that's correct. Thing is that one kept the data on. We have. That we have inside. Yeah. Yeah. So we we would take all those inputs and then

### Guest (2025-05-09T19:20:26.169Z)

Yeah. I mean, that that's that's a good ad. The only thing is

### You (2025-05-09T19:20:30.443Z)

know, some of those inputs, like the the financing and what is my interest

### Guest (2025-05-09T19:20:30.479Z)

that model will get data based on what we have in the database. Right?

### You (2025-05-09T19:20:34.603Z)

rate, what is my my hold period, things like that,

### Guest (2025-05-09T19:20:38.329Z)

Yeah.

### You (2025-05-09T19:20:39.023Z)

those will be used in some of the calculations. So the next thing we'll need

### Guest (2025-05-09T19:20:41.329Z)

Inputs. Okay.

### You (2025-05-09T19:20:43.483Z)

to do is go through that Excel model, where I did all the named ranges. And then decide which of those we need for an MVP just to kinda show that I can change this, and this is what it looks like. I mean,

### Guest (2025-05-09T19:20:59.049Z)

Mhmm.

### You (2025-05-09T19:21:01.753Z)

mean Yeah.

### Guest (2025-05-09T19:21:10.049Z)

MVP, like, MVP is later. Like, before MVP, there's POC. Right? And that's what I think Diane was saying that for POC, we really need basic. In the last meeting.

### You (2025-05-09T19:21:21.473Z)

That is required with the model.

### Guest (2025-05-09T19:21:22.899Z)

Then the other thing was for the model. Right?

### You (2025-05-09T19:21:23.203Z)

So that means we have the data for the model. That they have to solve.

### Guest (2025-05-09T19:21:25.989Z)

As far as my understanding goes,

### You (2025-05-09T19:21:27.763Z)

K.

### Guest (2025-05-09T19:21:28.709Z)

we said that we have all the data from Drew that is required for the model. So that means we have the data for the model in the database already.

### You (2025-05-09T19:21:35.723Z)

Would I would say want to do you want. That. Okay. But if we have the data in

### Guest (2025-05-09T19:21:39.739Z)

I mean, can definitely do the user flow if

### You (2025-05-09T19:21:41.763Z)

the data is for the model. Right?

### Guest (2025-05-09T19:21:43.269Z)

you know, We I mean, I would say you continue working on that.

### You (2025-05-09T19:21:46.253Z)

If we put together all the knowledge, then we should Yeah. So

### Guest (2025-05-09T19:21:50.109Z)

But if we have the data in the database for the model, right,

### You (2025-05-09T19:21:54.203Z)

what we'll need to do is take a look at

### Guest (2025-05-09T19:21:55.579Z)

then we should read it. If we put together all the logic then we should be able to generate some model based on the data we have.

### You (2025-05-09T19:22:04.173Z)

the formulas where I did the named ranges and you know, I I went did my best to name a column, but it it's likely not gonna match Drew's. So we'll have to do some temporary reconciliation to change

### Guest (2025-05-09T19:22:17.779Z)

Mhmm.

### You (2025-05-09T19:22:21.643Z)

and and make sure that we got the formula. I mean, we don't have to probably

### Guest (2025-05-09T19:22:25.269Z)

Yeah.

### You (2025-05-09T19:22:25.503Z)

through. We we can just choose which formulas we wanna do.

### Guest (2025-05-09T19:22:26.949Z)

Yeah. Yeah.

### You (2025-05-09T19:22:29.203Z)

And then we can just kinda go through one by one. And and that way, we can we can start getting some of those calculations.

### Guest (2025-05-09T19:22:36.719Z)

Right.

### You (2025-05-09T19:22:37.383Z)

With the POC. Okay. This is the model. Yeah.

### Guest (2025-05-09T19:22:46.249Z)

Yeah. Yeah. Yep. Yep. And then I think that is

### You (2025-05-09T19:22:52.183Z)

Yeah.

### Guest (2025-05-09T19:22:53.769Z)

this is the model where you put the name in convention. Right? Yeah. Cool. Cool. It's See, I'm yet to reach

### You (2025-05-09T19:23:03.883Z)

See how big corporate

### Guest (2025-05-09T19:23:04.869Z)

that part wherein I integrate that model with the application.

### You (2025-05-09T19:23:05.643Z)

both of those together. Right? Yeah. I I just thought that

### Guest (2025-05-09T19:23:10.319Z)

But, yeah, yeah, please continue working on that flow and

### You (2025-05-09T19:23:12.453Z)

you know, she's a I would have

### Guest (2025-05-09T19:23:15.089Z)

we'll see how to incorporate both of those together. Right? But for I just

### You (2025-05-09T19:23:18.613Z)

probably I've been having a

### Guest (2025-05-09T19:23:21.209Z)

thought that POC was more like, you know, she said, oh, or whatever we decided that we need

### You (2025-05-09T19:23:25.523Z)

suppose. See

### Guest (2025-05-09T19:23:26.179Z)

one week or two weeks. So that means we'll probably rely on the shortest path. And then we you know, if

### You (2025-05-09T19:23:33.953Z)

charges. Right? Yeah.

### Guest (2025-05-09T19:23:35.359Z)

we have more time, suppose she needs this POC

### You (2025-05-09T19:23:35.553Z)

So it's just, you know, please. Yeah. I don't know what's going if if she's still working on that side

### Guest (2025-05-09T19:23:38.379Z)

be completed next to say she needs this POC by Wednesday.

### You (2025-05-09T19:23:41.523Z)

project that she's got, you know, because she's not been available much. So

### Guest (2025-05-09T19:23:41.979Z)

And probably we'll just rely on the shortest path. Right?

### You (2025-05-09T19:23:45.683Z)

I I can't imagine that we would wanna have anything by Wednesday.

### Guest (2025-05-09T19:23:46.369Z)

So which is, you know yeah.

### You (2025-05-09T19:23:51.003Z)

Yeah. I mean, you're you're still gonna be working. Right? So Tuesday through Thursday? Yeah. Howard, I'm done.

### Guest (2025-05-09T19:23:58.679Z)

Yeah.

### You (2025-05-09T19:24:01.853Z)

For sure. Alright. I guess I can I can get those morals

### Guest (2025-05-09T19:24:07.669Z)

Yeah. I I would I'm planning to

### You (2025-05-09T19:24:07.783Z)

spun up? I mean, it's it's pretty simple. Yeah.

### Guest (2025-05-09T19:24:10.629Z)

like, spend a lot of time this weekend for sure.

### You (2025-05-09T19:24:11.373Z)

Yep. That was correct. And Okay.

### Guest (2025-05-09T19:24:13.639Z)

Because I'm here. I have nothing to talk.

### You (2025-05-09T19:24:14.193Z)

How to combine both things.

### Guest (2025-05-09T19:24:16.069Z)

So yeah.

### You (2025-05-09T19:24:16.173Z)

Approaches. Yeah.

### Guest (2025-05-09T19:24:18.929Z)

Well, cool. Cool. Yep. Yep. Yep. That will be good. And then we'll figure out how to combine both of these approaches.

### You (2025-05-09T19:24:24.913Z)

So what else would that seem? Yeah. I think

### Guest (2025-05-09T19:24:28.079Z)

Together. Right? And, yeah, I'm here to play more with the UI. We can definitely

### You (2025-05-09T19:24:29.483Z)

the part, right,

### Guest (2025-05-09T19:24:33.049Z)

improve that.

### You (2025-05-09T19:24:33.353Z)

he's trying to step. Company, all that.

### Guest (2025-05-09T19:24:36.529Z)

And what else would I see? Yeah. At the

### You (2025-05-09T19:24:36.993Z)

Yeah.

### Guest (2025-05-09T19:24:40.739Z)

Drew's part. Right? Like, he's trying to sell the

### You (2025-05-09T19:24:46.693Z)

I I

### Guest (2025-05-09T19:24:47.009Z)

and all that.

### You (2025-05-09T19:24:48.703Z)

I would be happy if that's the way it's carried out. Because

### Guest (2025-05-09T19:24:52.429Z)

I don't I don't know what you've your comment on that.

### You (2025-05-09T19:24:56.433Z)

theoretically, you know, we could be chained to this for four or five years before we get to the point where we could sell it. But if we can basically merge with Drew, Yeah. Package it together You know? That way, we would have funding. You know? Whoever buys it would be able to fund it. And typically, in an acquisition,

### Guest (2025-05-09T19:25:20.689Z)

Yeah. Yeah.

### You (2025-05-09T19:25:24.783Z)

part of the acquisition is written into the contract that the founders would stay on. To run the business for a certain amount of time, whether it be two years, five years, whatever. So you know, that's the only thing that I would be concerned about is if somebody bought it and then decided

### Guest (2025-05-09T19:25:43.159Z)

Yeah.

### You (2025-05-09T19:25:46.443Z)

well, we we we've got people. We can run it on our own and then all of a sudden Yeah. Self unemployed. But either way what that Yeah. And then, you know, either way, though, I mean,

### Guest (2025-05-09T19:25:57.469Z)

We need it.

### You (2025-05-09T19:25:58.963Z)

we have a verbal

### Guest (2025-05-09T19:26:01.159Z)

Yeah.

### You (2025-05-09T19:26:02.573Z)

agreement from Diane that it's just gonna be a

### Guest (2025-05-09T19:26:04.449Z)

Similar to what Redex did.

### You (2025-05-09T19:26:06.423Z)

25% split between the four of us. But you know, we need to get something in writing and then either way I mean, right now, we have, like, zero investment You know? That's right. If we get something right,

### Guest (2025-05-09T19:26:17.789Z)

Yeah.

### You (2025-05-09T19:26:20.563Z)

now to to purchase it, that's like a % split between the headless. You know? Split head. Yeah. But, yeah, we'll see we'll see how that plays out. I I

### Guest (2025-05-09T19:26:35.109Z)

Yeah. Go ahead.

### You (2025-05-09T19:26:36.073Z)

I still don't know exactly

### Guest (2025-05-09T19:26:38.009Z)

Give us $1,000,000.

### You (2025-05-09T19:26:39.043Z)

what Drew's relationship is. Remember him when he had us send our resumes for the CTO and everything? So Yeah. He says he's it's it's his company, and he's bootstrapping the CTO. I'm not quite sure where those guys fit in and how that would work. But

### Guest (2025-05-09T19:26:54.809Z)

Yeah.

### You (2025-05-09T19:26:56.353Z)

I don't that that's that's up to him. So

### Guest (2025-05-09T19:27:01.439Z)

He is the CEO.

### You (2025-05-09T19:27:02.443Z)

was something like he has something

### Guest (2025-05-09T19:27:03.319Z)

Yeah. In the last

### You (2025-05-09T19:27:10.533Z)

Yeah. I think he's got financing

### Guest (2025-05-09T19:27:13.409Z)

call, Diana was saying something like he has some like, traditional

### You (2025-05-09T19:27:16.323Z)

from somebody, but they're, yeah, they're not actively participating. It's almost like a loan, I guess.

### Guest (2025-05-09T19:27:17.749Z)

partners, whatnot that you know, modern with the technologies and all that. So

### You (2025-05-09T19:27:21.293Z)

Guess. But some type of you know, VC capital or something. So, yeah, I I I think it'd be it'd be very interesting. Interesting to see how that would all play combined. So, I didn't know I I knew Diane was talking to somebody, and he's been didn't realize they were talking to the same group. So it

### Guest (2025-05-09T19:27:44.419Z)

Okay.

### You (2025-05-09T19:27:46.713Z)

I I don't know. I I Throttle head or something like that. I I took had the note take on. I could go to double check the transcript.

### Guest (2025-05-09T19:27:53.879Z)

Yeah. What are the number of points?

### You (2025-05-09T19:27:58.133Z)

But yeah.

### Guest (2025-05-09T19:27:58.309Z)

Drop what?

### You (2025-05-09T19:27:59.123Z)

Have to see. I'm not I'm not quite sure. I I didn't

### Guest (2025-05-09T19:27:59.179Z)

Prop hedge or something like that. That's what you say.

### You (2025-05-09T19:28:02.113Z)

the name didn't sound at all familiar to me. So they might be in the hospitality space or something. I know. Okay. Okay. So this company will be

### Guest (2025-05-09T19:28:14.429Z)

Okay.

### You (2025-05-09T19:28:15.263Z)

So obviously, established. Yeah. We have this too. Disconnecting the stuff. Yeah. Yes. We are. But well, cool. Any plans for the weekend? No. No. That is just black and sit time. Yeah. So work. Yeah. Alright. Well, cool. Yeah. So anything else or

### Guest (2025-05-09T19:28:17.599Z)

Alright. Alright. Okay. So both of them but his company, hotel b I, is obviously established. Are still scratching the surface. So No. No. I just plan to sit and do some good work.

### You (2025-05-09T19:28:45.643Z)

Yeah. No. We're we're on the same page there. I I, you know, I think the the modals that I put together will look very, very similar to that. Maybe

### Guest (2025-05-09T19:28:49.999Z)

Yeah. That's all I just wanted to point out.

### You (2025-05-09T19:28:53.403Z)

slightly different input.

### Guest (2025-05-09T19:28:53.619Z)

Briefly show you what I've got and, you know, how I'm thinking about it.

### You (2025-05-09T19:28:54.723Z)

Based on kind of what I before, but all I need to do is put together the take the Excel graph where it has the names format, things like that. Group it by what Drew put together in terms of here's model one, model two, model three, and you know, I can put that all in as one requirement, and it could knock out all the mortals at once. So That point. Thought we are. I thought we had just one more and the guy

### Guest (2025-05-09T19:29:33.419Z)

A mod model one, model three, like,

### You (2025-05-09T19:29:33.983Z)

one. Yeah. The way. You me in the

### Guest (2025-05-09T19:29:36.199Z)

I thought we had we had we had three models, but I didn't pay attention to that.

### You (2025-05-09T19:29:40.803Z)

Yeah. No. We've got the one that that that is kind of the main

### Guest (2025-05-09T19:29:43.159Z)

I thought we had just one model, and the last one was

### You (2025-05-09T19:29:45.653Z)

valuation model.

### Guest (2025-05-09T19:29:46.679Z)

way you put the name changes and all.

### You (2025-05-09T19:29:47.253Z)

Okay. But I'm talking about the the user input models. That pop up. Oh, gotcha. Yeah. And I think he came up with 14 different sections altogether. But some of them only have

### Guest (2025-05-09T19:29:58.179Z)

Right.

### You (2025-05-09T19:30:01.843Z)

two or three, so they could be

### Guest (2025-05-09T19:30:03.399Z)

Oh, gotcha.

### You (2025-05-09T19:30:03.463Z)

on the same modal Oh, Oh, Right. So that's what I'm saying. If I can get the designs for those

### Guest (2025-05-09T19:30:17.349Z)

Got you. What you are talking about? Okay. After we had that

### You (2025-05-09T19:30:18.823Z)

and I can send you the code, and then you can just copy it

### Guest (2025-05-09T19:30:21.389Z)

meeting of the flow, then he has input some

### You (2025-05-09T19:30:22.333Z)

paste it into yours, and then you can

### Guest (2025-05-09T19:30:24.499Z)

there, which I didn't follow. Okay.

### You (2025-05-09T19:30:24.943Z)

Yeah. And yeah, go ahead and even if you want.

### Guest (2025-05-09T19:30:26.649Z)

Got it.

### You (2025-05-09T19:30:28.153Z)

Also learning. Say that in the Mhmm. Okay. Okay.

### Guest (2025-05-09T19:30:36.899Z)

Yeah. And yeah. Code and even if you could also include, like,

### You (2025-05-09T19:30:39.303Z)

Yeah. Okay.

### Guest (2025-05-09T19:30:41.669Z)

share the link like you shared last time.

### You (2025-05-09T19:30:42.733Z)

So, typically, these no code

### Guest (2025-05-09T19:30:45.009Z)

That will be helpful too.

### You (2025-05-09T19:30:46.683Z)

tools are using

### Guest (2025-05-09T19:30:48.119Z)

Because this call yeah.

### You (2025-05-09T19:30:49.433Z)

React

### Guest (2025-05-09T19:30:51.369Z)

Yeah. The both would be helpful. Yeah.

### You (2025-05-09T19:30:51.563Z)

as well as either tailwind or shad cn Okay. Next. And then you know k. And then both rested. This. Okay. Alright. Yeah. So sounds like and is that what you're doing with yours?

### Guest (2025-05-09T19:31:07.829Z)

Is good and reactivate next

### You (2025-05-09T19:31:10.183Z)

Basically? That's what happened right now. That's that's what I figured.

### Guest (2025-05-09T19:31:11.989Z)

and then Node. Js

### You (2025-05-09T19:31:14.053Z)

Yeah.

### Guest (2025-05-09T19:31:14.599Z)

and then postgres database.

### You (2025-05-09T19:31:15.103Z)

Perfect. Time.

### Guest (2025-05-09T19:31:22.999Z)

Yeah. That's what I have to write down. Yeah. And

### You (2025-05-09T19:31:26.053Z)

Right.

### Guest (2025-05-09T19:31:26.269Z)

yeah, so three of the I

### You (2025-05-09T19:31:26.563Z)

Okay. Cool. I just

### Guest (2025-05-09T19:31:28.219Z)

have is without TypeScript right now for the POC version because if we use TypeScript then the lot of validation and all that required.

### You (2025-05-09T19:31:37.193Z)

So Well, yeah, they they they want something

### Guest (2025-05-09T19:31:40.429Z)

But, I mean, I just got some impression from the last meeting that

### You (2025-05-09T19:31:41.373Z)

like, yesterday, I'm sure, to go out and show I'm like, I wanna get paid yesterday too.

### Guest (2025-05-09T19:31:44.829Z)

probably Dan and other people are expecting some things to know.

### You (2025-05-09T19:31:49.293Z)

It's like, yeah. That that's that's really kinda what I wanna

### Guest (2025-05-09T19:31:49.339Z)

So

### You (2025-05-09T19:31:53.963Z)

sure that you know, we protect ourselves with all the work that we've done so far. If they go out and show somebody a demo and yeah, I just wanna make sure that that's why I actually feel better than

### Guest (2025-05-09T19:32:02.069Z)

That's

### You (2025-05-09T19:32:05.443Z)

hosted on your laptop and that it's not already out in the cloud. And

### Guest (2025-05-09T19:32:09.919Z)

Yeah.

### You (2025-05-09T19:32:10.173Z)

so, anyway, you know, you've got total control over it. So Yeah.

### Guest (2025-05-09T19:32:17.809Z)

Yeah. Alright. Alright.

### You (2025-05-09T19:32:24.263Z)

Yeah. Well, you know that they say expect the best, but prepare for the worst. So

### Guest (2025-05-09T19:32:26.279Z)

Yep. Yep. Yeah. I mean, yeah, if you on

### You (2025-05-09T19:32:29.063Z)

The best.

### Guest (2025-05-09T19:32:29.429Z)

mean, if we want more control, yeah, I can probably host it.

### You (2025-05-09T19:32:29.843Z)

The best drug. I will. I will

### Guest (2025-05-09T19:32:33.559Z)

Somewhere just one hour. Server if required.

### You (2025-05-09T19:32:40.553Z)

Yeah. I like I said, I I really am not

### Guest (2025-05-09T19:32:40.619Z)

That's true. That's true. Yep. I'm in

### You (2025-05-09T19:32:44.083Z)

really worried about it.

### Guest (2025-05-09T19:32:45.069Z)

I know Dan a little bit, but

### You (2025-05-09T19:32:45.763Z)

I just just that

### Guest (2025-05-09T19:32:47.909Z)

whatever I've seen, think she's

### You (2025-05-09T19:32:48.893Z)

one

### Guest (2025-05-09T19:32:50.559Z)

see, I find that reliable for sure.

### You (2025-05-09T19:32:51.163Z)

know, If clear.

### Guest (2025-05-09T19:32:54.509Z)

Yeah.

### You (2025-05-09T19:32:54.893Z)

It's like yeah. Just The the sweet grandma bank robber. She could never do that.

### Guest (2025-05-09T19:33:01.459Z)

Okay.

### You (2025-05-09T19:33:02.843Z)

So

### Guest (2025-05-09T19:33:04.119Z)

It's all business. Yeah.

### You (2025-05-09T19:33:04.213Z)

alright.

### Guest (2025-05-09T19:33:06.329Z)

You never know. That's true.

### You (2025-05-09T19:33:07.393Z)

Then I can take I can actually I can actually work on that this afternoon. So maybe I can have something to

### Guest (2025-05-09T19:33:14.989Z)

Yeah.

### You (2025-05-09T19:33:15.143Z)

very soon.

### Guest (2025-05-09T19:33:16.969Z)

Alright. Thank you. Thank you,

### You (2025-05-09T19:33:16.973Z)

So Okay. Cool. I'll I'll get going. K. Alright. Bye.

### Guest (2025-05-09T19:33:29.049Z)

Cool. Cool. Cool. Yeah. That sounds great. So if we have that, then probably I'll

### You (2025-05-09T19:33:30.733Z)

Thanks. We'll see you. Thank you. See you. Bye.

### Guest (2025-05-09T19:33:33.659Z)

incorporate that over the weekend. K. K. Thank you. Thank you. See you. Bye.