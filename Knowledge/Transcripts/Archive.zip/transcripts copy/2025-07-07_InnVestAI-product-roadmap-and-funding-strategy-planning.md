# InnVestAI product roadmap and funding strategy planning

**Date:** 2025-07-07 00:00:00 UTC
**Meeting ID:** 11326009-4756-4000-8224-794679f2b193
**Synced:** 2026-02-05 14:46:48

---

# Transcript for: InnVestAI product roadmap and funding strategy planning

### Guest (2025-07-07T14:01:20.209Z)

Happy Monday.

### You (2025-07-07T14:01:22.186Z)

Happy Monday. Hey. Good morning. How are you?

### Guest (2025-07-07T14:01:24.669Z)

I'm good. How are you?

### You (2025-07-07T14:01:25.836Z)

I'm good. How are you? Good. So Go away. Stop. So

### Guest (2025-07-07T14:01:32.899Z)

Picture, but Are you still there?

### You (2025-07-07T14:01:35.746Z)

I thought I'll show it to you this way then. This

### Guest (2025-07-07T14:01:36.849Z)

Sorry. Well, I'll show it to you this way then.

### You (2025-07-07T14:01:38.906Z)

phone leather box. Investing in our way, we can't do it.

### Guest (2025-07-07T14:01:40.649Z)

This faux leather bound invest

### You (2025-07-07T14:01:42.616Z)

Go. Nice. You know? Nice. Yeah. Nice.

### Guest (2025-07-07T14:01:43.669Z)

you can't there you go. You can kinda see it now. Nice.

### You (2025-07-07T14:01:48.336Z)

So I guess that makes it official, doesn't it?

### Guest (2025-07-07T14:01:52.179Z)

Yeah. I'm gonna go through the EIN stuff.

### You (2025-07-07T14:01:52.646Z)

Yeah. I know stuff today and then there's stuff that, for each partner that I've got to

### Guest (2025-07-07T14:01:56.849Z)

Today, and then there's stuff that, for each partner that I've got just

### You (2025-07-07T14:01:57.186Z)

just figure out how to get to you guys or what information to get from you guys. Yeah.

### Guest (2025-07-07T14:02:00.799Z)

figure out how to get to you guys or what information to get from you guys.

### You (2025-07-07T14:02:01.906Z)

Well, cool. Okay. Great. Thank you joining us. Good.

### Guest (2025-07-07T14:02:05.359Z)

Okay. How was your weekend? It was good?

### You (2025-07-07T14:02:06.286Z)

You have had a you have had a busy weekend.

### Guest (2025-07-07T14:02:09.769Z)

Peaceful?

### You (2025-07-07T14:02:14.246Z)

Seeing a lot of emails and attachments. I haven't had a chance to go through all of them yet. Pulled up the most recent one that you sent the budget So Yes. Where do you wanna start? After I

### Guest (2025-07-07T14:02:26.169Z)

Yes. Yes.

### You (2025-07-07T14:02:27.766Z)

This I was just I had some time this weekend

### Guest (2025-07-07T14:02:29.819Z)

Yes. And we can walk through it

### You (2025-07-07T14:02:30.786Z)

so I used whatever time I could have. And then

### Guest (2025-07-07T14:02:31.539Z)

This I was just I had some time this weekend. So

### You (2025-07-07T14:02:34.226Z)

we can go all

### Guest (2025-07-07T14:02:34.949Z)

I use whatever time I could have. And then we can work all, of course, asynchronous

### You (2025-07-07T14:02:35.256Z)

of course asynchronously on this kind of stuff. But I could, like, some let me go back to the things

### Guest (2025-07-07T14:02:39.769Z)

on this kind of stuff. But

### You (2025-07-07T14:02:42.106Z)

that I wanna try to hit at least this week or next week with you because I just

### Guest (2025-07-07T14:02:42.679Z)

I put, like, some let me go back to the things that I'm I wanna try to hit the least

### You (2025-07-07T14:02:46.956Z)

all over the place. I know I can. And so

### Guest (2025-07-07T14:02:47.649Z)

this week or next week with you because I jump all over the

### You (2025-07-07T14:02:50.996Z)

the one that I mentioned, I went through what you said that'd great, Howard. Good. Good.

### Guest (2025-07-07T14:02:51.299Z)

place. I know I can. And so the one the valuation, I went through what you sent the

### You (2025-07-07T14:02:55.726Z)

Keep in mind that the design can and will change

### Guest (2025-07-07T14:02:59.709Z)

very hard.

### You (2025-07-07T14:03:01.266Z)

But I think overall, my what I'm trying to make sure you hear is just the flow. Starting from step one, going through the whole process, making sure that the layout makes sense. Then we can get into you know, the actual aesthetics of it. Which probably won't change much. Know? But a lot of things I wanna get, I wanna get feedback from the

### Guest (2025-07-07T14:03:25.879Z)

Mhmm.

### You (2025-07-07T14:03:26.756Z)

clients. It's like, is it okay to have two rows for these items? Which I think we almost have to because, you know, for example, on the expenses, the top row contains, you know, if I select to budget by POR, you know, then it shows the POR. If I do provide it by percentage of revenue, it'll show the percentage. So I have to have something to gauge know, historical and then go on there, But it's it's little things like that. It's like, does does it does it flow the way that these our users want it to go step by step? Does it make sense? You know, ideally, I wanna have a product that somebody can sign up create a username and a password, go in, and underwrite a deal without any training. You know, I want it to be so intuitive that they can see, oh, yeah. I I I see. I get it, you know, laid out the steps. So see how close we can get to that. But So what is the time Is it to the point yet where, like, Drew and I could go start to test it? Or does it be

### Guest (2025-07-07T14:04:42.159Z)

What is the timing? Is it to the point yet where, like,

### You (2025-07-07T14:04:42.226Z)

what you were telling me about how it has to go to the note the node has to do his thing before the producer can go in and test it.

### Guest (2025-07-07T14:04:45.869Z)

Drew and I could go start to test it, or does it need to be

### You (2025-07-07T14:04:49.226Z)

It's a it's a combination of both.

### Guest (2025-07-07T14:04:50.419Z)

what you were telling me about how it has to go to Vinod, and Vinod has to do his thing before

### You (2025-07-07T14:04:52.426Z)

I mean, you can go in there and plug in numbers today.

### Guest (2025-07-07T14:04:55.389Z)

a user can go in and test it.

### You (2025-07-07T14:04:55.456Z)

Okay. But the problem is we we well, it's not a problem. We just we haven't gotten to the point where

### Guest (2025-07-07T14:05:02.819Z)

Okay.

### You (2025-07-07T14:05:03.096Z)

we can ingest historical data. All of the historical data in there historical data that came from the Excel models. Right? So there's no way of changing the historical data but you can go in and play with the numbers, put in your own different numbers, etcetera, But I've I've been chatting with Vinod. I my subscription to the tool that I'm using I started off at the base level And then last month, I had to double my subscription because I was just burning through the credits, and I already have. I'm I I signed up on the sixteenth and so my my my my credits go from the sixteenth through the sixteenth. I'm totally out, and it's the seventh. Right? So I've got, like, almost ten days where I can do almost nothing. To this rule. And the fact that you know, I've said before that I'm I'm really maxing out what this tool is capable of. It's not an end enterprise level. So in the other operating expenses, we have a fully functional tool where you've got the drop down and says, wanna either by POR percentage of revenue or manual.

### Guest (2025-07-07T14:06:33.609Z)

Mhmm.

### You (2025-07-07T14:06:34.606Z)

Where I can go in there and do that. Somehow, that same drop down box in the undistributed expenses and the non operating expenses got removed. No Okay. How. And so it's like you can't go through the full process. So the tool I that I'm using does give

### Guest (2025-07-07T14:06:56.639Z)

Okay.

### You (2025-07-07T14:06:58.896Z)

like, every day, you get five free tokens. So it's like every morning, I get up and I do a little bit here. And then I got away. Next morning, I get up and do a little bit here, and I just gotta pray that whatever I do doesn't break something else. So I do think matter of having just needs to come out of that tool altogether Yeah. Or that we can upgrade tool. Okay? Well, upgrading the tool, I don't think is going to help. When you upgrade, it's just how many more tokens. So I'd so I can go

### Guest (2025-07-07T14:07:28.749Z)

Is it a matter that it just needs to come out of that tool all or that we need to upgrade the tool? Okay. Okay. Got it.

### You (2025-07-07T14:07:33.236Z)

you know, how how many chats are you allowed to have? It doesn't fix the complex of of the tool. The good thing is I actually have two tools that I use And so I can kinda work simultaneously It doesn't work very well. When I try to work on the same file with both tools. They're just a little bit too different so that one tends to break the other. But I can work on separate things. So I am gonna keep going on some of the other pages that I need to work on. Simultaneously. But I do need the node to get in there and basically take what's already put together and just fill in the blanks. You know, some of those things that need to be fixed. Some minor formatting things, It's not a big deal. So Vinod and I, we we meet every Monday at eleven, but he had to reschedule. So 've got a call with him at five, And I know we have our team call at three, so I think we need to at the point where we need to pin down and find out exactly what he needs in order to pick up and and run with the rest of it. I do know that, you know, we do have to be able to ingest financial data. So that we can get historical data and not just made up numbers. You know, the users are gonna wanna see it. From beginning to end. And if we can't upload their historical data, we can't do anything. So that is probably gonna have to go through with Drew. So now I need to start meeting with Drew. On a regular basis and find out what he can or cannot do for us with that. You know? So, like Got it. If if we can only work with his existing clients

### Guest (2025-07-07T14:09:44.129Z)

Got it.

### You (2025-07-07T14:09:45.766Z)

I don't know how that's gonna work. I don't know if any of the people you're talking to are also HBIS clients, you know, your CBRE contacts Arcadia, I doubt that they are. So we do need to have So much this. In place. This is I I think of it in two different things. One is is

### Guest (2025-07-07T14:10:09.269Z)

So on this,

### You (2025-07-07T14:10:09.866Z)

what I'm just calling to start with capital, one of management companies they use

### Guest (2025-07-07T14:10:13.569Z)

this is I I think of it as two different things.

### You (2025-07-07T14:10:14.966Z)

as Davidson Hotels. Yeah. And Davidson are very close friends

### Guest (2025-07-07T14:10:17.709Z)

One is

### You (2025-07-07T14:10:18.586Z)

of mine. So on Friday afternoon, I'm talking to them k. To see

### Guest (2025-07-07T14:10:19.449Z)

one of Drew's clients is Starwood Capital.

### You (2025-07-07T14:10:22.166Z)

they would

### Guest (2025-07-07T14:10:22.529Z)

One of the management companies they use is Davidson Hotels.

### You (2025-07-07T14:10:22.566Z)

willing to test. Automatically sending data that's not truth data. Right? Like, it could even be

### Guest (2025-07-07T14:10:26.089Z)

And Davidson are very close friends of mine. So on Friday afternoon, I'm talking to them.

### You (2025-07-07T14:10:29.116Z)

totally made up data, doesn't you know, it doesn't matter to us. We just wanna see

### Guest (2025-07-07T14:10:30.939Z)

To see if they would be willing to test

### You (2025-07-07T14:10:32.716Z)

and go from a manager directly to Drew direct

### Guest (2025-07-07T14:10:34.359Z)

automatically sending data that's not Drew's data. Right?

### You (2025-07-07T14:10:36.096Z)

into InnVestAI. Or maybe I should say from

### Guest (2025-07-07T14:10:37.469Z)

Like, it could even be made totally made up data. It doesn't not doesn't matter to us. We just wanna

### You (2025-07-07T14:10:39.416Z)

eventually from a manager to InvestAI and then it's Drew because he can

### Guest (2025-07-07T14:10:41.719Z)

see if it can go from a manager directly to

### You (2025-07-07T14:10:44.356Z)

you know, we we thought we talked about the last time we talked. But if I can just get

### Guest (2025-07-07T14:10:44.739Z)

Drew directly into InnVestAI. Or maybe I should say from

### You (2025-07-07T14:10:48.246Z)

one management company to work with us and kind of, like, test

### Guest (2025-07-07T14:10:49.139Z)

eventually, from a manager to InvestAI and then into Drew because you you kind of

### You (2025-07-07T14:10:51.446Z)

it that, auto transfer of data.

### Guest (2025-07-07T14:10:53.719Z)

re you know, we we thought we talked about the last time we talked. But

### You (2025-07-07T14:10:54.856Z)

I think what we can show people

### Guest (2025-07-07T14:10:56.919Z)

if I can just get one management company to work with us and kind of, like,

### You (2025-07-07T14:10:57.296Z)

the future could look like. Right? Right. But

### Guest (2025-07-07T14:11:00.719Z)

testing that auto transfer of data.

### You (2025-07-07T14:11:02.526Z)

the, you know, for real

### Guest (2025-07-07T14:11:04.429Z)

I think what we could show people is what the future could look like. Right?

### You (2025-07-07T14:11:04.856Z)

like, kind of, like, clients or if we were able to get a consulting agreement, right, that turns

### Guest (2025-07-07T14:11:09.249Z)

With the auto transfer.

### You (2025-07-07T14:11:10.836Z)

equity. I think we're gonna

### Guest (2025-07-07T14:11:11.719Z)

But then in the interim for any real, like,

### You (2025-07-07T14:11:12.616Z)

be more online, but you guys have with Red IQ.

### Guest (2025-07-07T14:11:15.229Z)

pilot

### You (2025-07-07T14:11:15.656Z)

Which is a place where someone can drop the files. Yeah.

### Guest (2025-07-07T14:11:16.289Z)

clients or if we were able to get a consulting agreement, right, that turns into

### You (2025-07-07T14:11:19.216Z)

And pull them up, and then everyone else in goes into that. It's like like that almost I think we almost have to run

### Guest (2025-07-07T14:11:20.869Z)

equity, I think we're gonna need more along the lines what you guys had with Red IQ.

### You (2025-07-07T14:11:24.336Z)

both concurrently Mhmm. Until we

### Guest (2025-07-07T14:11:25.329Z)

Which is a place where someone can drop the files

### You (2025-07-07T14:11:26.306Z)

get to the point where enough we could change the industry

### Guest (2025-07-07T14:11:28.979Z)

and we pull them up and it maps and goes into the like like, that almost I think we almost

### You (2025-07-07T14:11:30.246Z)

so that it's being digitally transferred, but then we have

### Guest (2025-07-07T14:11:33.559Z)

have to run both concurrently until we get to the point where enough

### You (2025-07-07T14:11:34.486Z)

interim solution. Does that does that make sense? Where until we get there.

### Guest (2025-07-07T14:11:37.959Z)

we can change the industry so that

### You (2025-07-07T14:11:38.556Z)

Well, you know, here here's the thing too.

### Guest (2025-07-07T14:11:41.119Z)

it's being digitally transferred, but that we have an interim solution. Does that does that make

### You (2025-07-07T14:11:41.556Z)

Is when you say digitally transferred, I'm interpreting that as

### Guest (2025-07-07T14:11:46.089Z)

sense where until we get there?

### You (2025-07-07T14:11:47.396Z)

not having a human in the loop. For getting that historical data. And and and that's basically what we had at Red IQ. And it was only only if a file failed to be processed for some reason would a human have to get in? We had a team in India that you know, if a file was uploaded to be processed, and something changed. Know, especially with an Excel, a lot of times people will take an Excel file that they get from the broker or the seller and they'll do their own calculations. And they'll start putting in formulas. And then they upload it, and it won't work because they changed the file. Those are the only situations. The the the good thing is that in this industry, those financial statements are way more standardized than what we get. RedIQ. So getting around those issues is much easier. So I fully intend for the MVP

### Guest (2025-07-07T14:12:53.139Z)

Mhmm.

### You (2025-07-07T14:12:55.016Z)

to have a process in place where they can drag and drop a file, and then in a minute or two, they see all that historical data on the screen. I do not wanna get into you know, one of those situations. I'm the I don't know if you heard, but there was a blow up recently the AI industry where there was a company that was touting their new AI tools, and it turned out to be as a sweatshop in The Philippines where it was people who were actually typing the response to these yeah. So it's like Just that. Yeah. Like that. Yeah. Yeah. Yeah. You can't you can't you can't get away with something like that. So, you know, I do think that there may be

### Guest (2025-07-07T14:13:43.139Z)

To the chats and things like that. Yeah.

### You (2025-07-07T14:13:44.796Z)

situations where there will be something uploaded I mean, we had people uploading just the wrong file. They they couldn't you know, instead of uploading a financial statement, it could have been, you know, photos of the comp of the property or whatever. But you're never gonna get around that. But you can always

### Guest (2025-07-07T14:14:01.369Z)

Mhmm.

### You (2025-07-07T14:14:03.576Z)

easily flag those. So one of the things that we can do and this is what I've talked about before, that our POC will be a demo. We don't need them to get on there. So we can go and demo this afternoon. Right? We've got enough. I feel comfortable with what we have that I can show the walks

### Guest (2025-07-07T14:14:25.179Z)

Mhmm.

### You (2025-07-07T14:14:25.716Z)

through, and people can either nod their head yes or no. And and, you know, at least get a feel in order for them to actually start working in the model, we have to have the MVP version, which will include we have to process documents, whether you know, hopefully, that means they drag and drop into InnVest. And then we send that document through Drew's processing and get that data back. And Okay. You know, that could that could take ten seconds, twenty seconds. Yeah. I mean, it's not like you're gonna have to wait an hour.

### Guest (2025-07-07T14:15:01.059Z)

Mhmm.

### You (2025-07-07T14:15:02.806Z)

You know, if it's fully automated. And then that has to populate the MVP so that they can go in there and start plugging in their numbers. Mhmm. So that's that's where we need to be, and we cannot get to the MVP using the notes laptop.

### Guest (2025-07-07T14:15:21.639Z)

Mhmm.

### You (2025-07-07T14:15:21.956Z)

And, you know, that's basically where everything resides. We have to have a database subscription. We have to have external servers and all of this to be set up. And so that's what that's what the node's working on now. A budget for that. Right? Working on a budget for it. Yeah. Initially, it's not gonna be very expensive. You know, because we're not

### Guest (2025-07-07T14:15:46.459Z)

A budget for that. Right?

### You (2025-07-07T14:15:46.586Z)

the data that we have can fit on a spreadsheet. Right? It's not like we have, you know, a

### Guest (2025-07-07T14:15:50.709Z)

Yes.

### You (2025-07-07T14:15:52.696Z)

massive database that we have to host somewhere. What's really expensive in your mind? Does

### Guest (2025-07-07T14:15:59.429Z)

Mhmm.

### You (2025-07-07T14:16:00.776Z)

different things to different people. Yeah. No. No. No. They actually I mean,

### Guest (2025-07-07T14:16:05.149Z)

What's not expensive in your mind?

### You (2025-07-07T14:16:05.616Z)

if you go with, like, Azure, Microsoft's tool, or even

### Guest (2025-07-07T14:16:09.999Z)

Just not expensive means different things to different people. So I'm curious what

### You (2025-07-07T14:16:11.776Z)

Google. There are actually free levels of of those where you can kind of test out Some of those actually are tied into using some of their tools. So if the node wants to go with Google or go with Azure, it might require using some of their tools, and then you get a free version of their database. You're not gonna get every feature, and you're not gonna get a huge storage, but it might be enough to get us off the ground. If we want to continue to use Azure or Google you know, then we would have to start subscribing to levels. So when I was talking to Vinod, he was I I could tell he's nervous about a number because I I think he feels like he's committing to this is the exact number. And and there are thing you know, we don't know what we don't know yet in Yeah. Right. So I said, let let's give a range. Let's give a what's the minimum that we can use to get started in the next

### Guest (2025-07-07T14:17:19.699Z)

Yep.

### You (2025-07-07T14:17:20.156Z)

three to six months? And then six to nine months when we start

### Guest (2025-07-07T14:17:22.959Z)

Mhmm.

### You (2025-07-07T14:17:24.826Z)

releasing additional features and we need more power. And then, what is the maximum you can see this going to? So hopefully, we'll get a range. It's it's gonna be a big range. It's not gonna be tight. At least it'll give us some idea. Of what we're gonna need for the MVP. Low level. So Because I can have I it was good. Very good that we have different opinions. That's why diversity is positive within So Mark is a big opinion. That we

### Guest (2025-07-07T14:17:56.049Z)

Because I think I I I

### You (2025-07-07T14:17:56.476Z)

really can't go out to to angel investors until we have the

### Guest (2025-07-07T14:17:58.609Z)

mark and then it's good. It's very good that we have different opinions. That's

### You (2025-07-07T14:18:01.206Z)

true working

### Guest (2025-07-07T14:18:01.989Z)

why diversity of thought is a good thing. So mark is of the opinion

### You (2025-07-07T14:18:02.256Z)

MVP. I want the opinion that we can't go out

### Guest (2025-07-07T14:18:06.269Z)

that we really can't go out

### You (2025-07-07T14:18:06.336Z)

to investors with

### Guest (2025-07-07T14:18:08.299Z)

to the to angel investors until we have a

### You (2025-07-07T14:18:08.366Z)

the the proof. Concept. But since we're very different. So

### Guest (2025-07-07T14:18:11.499Z)

true working MVP. I am of the opinion that we can go out

### You (2025-07-07T14:18:14.056Z)

run and run and run and run and about many

### Guest (2025-07-07T14:18:16.469Z)

to AngelVestAI with the

### You (2025-07-07T14:18:18.336Z)

is perhaps

### Guest (2025-07-07T14:18:20.089Z)

the proof of concept, but this is where we differ. So we go back.

### You (2025-07-07T14:18:20.096Z)

given relationships in the hotel industry. We could go to

### Guest (2025-07-07T14:18:24.369Z)

Around, around, around, around, and round about it. And where we end up

### You (2025-07-07T14:18:24.836Z)

10 or so people and do a house that hat.

### Guest (2025-07-07T14:18:28.649Z)

is perhaps

### You (2025-07-07T14:18:28.746Z)

Like, could you contribute 25 k? Could you, you know, like,

### Guest (2025-07-07T14:18:30.419Z)

given the relationships in the hotel industry, we could go to

### You (2025-07-07T14:18:32.176Z)

help us get through this initial

### Guest (2025-07-07T14:18:35.209Z)

10 or so people and do a pass the hat

### You (2025-07-07T14:18:35.496Z)

three month period. Where we go from POC to MVP. Yeah. That's what we talked about on Friday.

### Guest (2025-07-07T14:18:38.949Z)

Like, could you contribute 25 k? Could you you know, like, to help us

### You (2025-07-07T14:18:41.566Z)

The other idea that I have is could we find

### Guest (2025-07-07T14:18:43.439Z)

get through this initial three month period where we go from POC

### You (2025-07-07T14:18:45.906Z)

a consulting project that

### Guest (2025-07-07T14:18:48.229Z)

MVP.

### You (2025-07-07T14:18:48.676Z)

is so similar to what we're doing.

### Guest (2025-07-07T14:18:49.699Z)

That's what we talked about on Friday.

### You (2025-07-07T14:18:50.806Z)

Like, go to hunter hotels who's a big

### Guest (2025-07-07T14:18:51.959Z)

The other idea that I had

### You (2025-07-07T14:18:53.186Z)

tier Right? And

### Guest (2025-07-07T14:18:54.309Z)

is could we find a consulting project that is

### You (2025-07-07T14:18:55.526Z)

say, look, Look. Look. Look. Look. Look. Look. Label this for you. You'll be our first investor. We paid us a

### Guest (2025-07-07T14:18:59.249Z)

so similar to what we're doing, like, to Hunter Hotels who's a mid

### You (2025-07-07T14:19:01.956Z)

consulting project. We'll help you clean up your files, anything.

### Guest (2025-07-07T14:19:03.579Z)

tier broker. Right? And say,

### You (2025-07-07T14:19:05.366Z)

And then at the end of whatever period, six months a year,

### Guest (2025-07-07T14:19:06.509Z)

look. We'll, like, we'll white label this for you. You'll be our first We pay us a consulting project. We'll help you clean up your files, anything.

### You (2025-07-07T14:19:08.586Z)

what you spend on consulting converts into an equity contribution and you become an owner. And we could do one or two of those that may help us get off the ground as well.

### Guest (2025-07-07T14:19:15.669Z)

And then at the end of whatever period, six months a year, what you spent on consulting converts into an equity contribution and you become

### You (2025-07-07T14:19:19.336Z)

Yeah. Right? And so that's where we're landing, but he Mark is very he's like, no. We cannot go to. He's like,

### Guest (2025-07-07T14:19:23.559Z)

an owner. And if we could do one or two of those, that might help us

### You (2025-07-07T14:19:26.146Z)

I belong to an angel investor group, and I took this to my peer group.

### Guest (2025-07-07T14:19:27.839Z)

get off the ground as well. Right? And so that's where we're landing, but he Mark is

### You (2025-07-07T14:19:31.056Z)

They would not fund it. So

### Guest (2025-07-07T14:19:33.199Z)

very he's like, no. We can't go to Angel. He's like,

### You (2025-07-07T14:19:33.256Z)

and I and I talked to an angel investor back in January who I believe

### Guest (2025-07-07T14:19:36.489Z)

I belong to an angel investor group. And if I took this to my peer group,

### You (2025-07-07T14:19:38.226Z)

would want this under a proof of concept. But I don't know how to get past that impact.

### Guest (2025-07-07T14:19:41.189Z)

they would not fund it. So and I've

### You (2025-07-07T14:19:42.806Z)

Impasse with him. Right? Because we we we he's he's absolutely right,

### Guest (2025-07-07T14:19:44.379Z)

I talked to an angel investor back in January who I believe

### You (2025-07-07T14:19:46.606Z)

Right? And I mess it up. Going too early.

### Guest (2025-07-07T14:19:48.639Z)

would fund this under a proof of concept. But I don't know how to get past that impasse with him.

### You (2025-07-07T14:19:49.676Z)

Or I could be running and we fall apart because we take too long. Right? So I don't know how to navigate that. No.

### Guest (2025-07-07T14:19:53.549Z)

Right? Because we we he he could be absolutely right. Right? And I mess it up going too early, or I could be right and we fall apart because we take too long. Right?

### You (2025-07-07T14:20:00.766Z)

There are one of the things that I've I've I've seen is that

### Guest (2025-07-07T14:20:04.109Z)

So I don't know how to navigate that.

### You (2025-07-07T14:20:08.796Z)

no angel investor is the same. No VC is the same. They all have specific niches and requirements, what they are willing to invest in and what they're not. So you're both right. K? So Mark's group has a specific set of rules that have to be met before they'll consider funding something. But that doesn't apply to every angel investor. You know? Like I said, my brother-in-law and his friend, they get in very early They would you know, they're the type of person who would write a check today based on the current concept. There's a difference between a proof of concept on a PowerPoint and there's also then a proof of concept where you can actually see it working.

### Guest (2025-07-07T14:20:51.209Z)

Mhmm.

### You (2025-07-07T14:20:53.896Z)

You know, we are the latter. We can we can log in, and we can put numbers in what I've developed. You can see the numbers change and calculate. So that it's, you know, it's not some theoretical product out there. So I I agree with you. That's what I do. And I believe it's far enough, especially when you point to other multifamily that have made that leap.

### Guest (2025-07-07T14:21:18.159Z)

That's what I

### You (2025-07-07T14:21:18.326Z)

Right? It's it's it exists. It's so

### Guest (2025-07-07T14:21:21.329Z)

believe too. I mean, I I believe it's far enough, especially when you point to other

### You (2025-07-07T14:21:21.896Z)

how do you tell them? How do you know what what you're doing by what rules?

### Guest (2025-07-07T14:21:25.639Z)

multifamily AVMs that have made that leap. Right? It's

### You (2025-07-07T14:21:27.476Z)

Just Or you just have to know Just gotta ask.

### Guest (2025-07-07T14:21:29.439Z)

it's it exists. It's so

### You (2025-07-07T14:21:29.716Z)

Just gotta ask. Yeah. Yeah.

### Guest (2025-07-07T14:21:32.049Z)

how do you tell, though? How do you know what

### You (2025-07-07T14:21:33.096Z)

Yeah. So I wanna say, well, Mark, let's call

### Guest (2025-07-07T14:21:34.759Z)

what angel investor goes by what rules?

### You (2025-07-07T14:21:35.986Z)

Alex, whoever had his last name. He's with a company that used to be called Revolution, and they

### Guest (2025-07-07T14:21:38.179Z)

You just have to know you just ask. Yeah.

### You (2025-07-07T14:21:40.646Z)

invested in Mint House. And I think he would agree

### Guest (2025-07-07T14:21:41.549Z)

Yeah. Because that was my point. Said, well, Mark, let's

### You (2025-07-07T14:21:44.456Z)

Mark said, no. We're not calling anyone until, you know, like,

### Guest (2025-07-07T14:21:46.009Z)

call Alex who I forgot his last name. He's with a company that used

### You (2025-07-07T14:21:48.036Z)

I just we're I'm gonna try and figure that out.

### Guest (2025-07-07T14:21:49.539Z)

to be called Revolution, and they invested in Mint House.

### You (2025-07-07T14:21:51.126Z)

Which then let me down the road, though.

### Guest (2025-07-07T14:21:52.769Z)

And I think he would agree, but Mark said, no way. We're not

### You (2025-07-07T14:21:53.046Z)

Okay. Could I figure out a consulting assignment with, like, a

### Guest (2025-07-07T14:21:56.539Z)

calling anyone until, you know, like so I just I'm trying to figure that out.

### You (2025-07-07T14:21:56.906Z)

brokerage group or something like that that would give us a chance to work with someone and build this and get our launch that way.

### Guest (2025-07-07T14:22:01.279Z)

Which then led me down the road of, okay. Could I figure out a consulting assignment with, like, a brokerage group or something like that

### You (2025-07-07T14:22:04.916Z)

The other thing that has me a therapy service as

### Guest (2025-07-07T14:22:09.119Z)

that would give us a chance to work with someone and build this and

### You (2025-07-07T14:22:11.806Z)

and this morning at the time of think about it.

### Guest (2025-07-07T14:22:14.059Z)

get our launch that way.

### You (2025-07-07T14:22:14.456Z)

Do believe I know who are

### Guest (2025-07-07T14:22:15.549Z)

The other thing that has me

### You (2025-07-07T14:22:16.406Z)

most direct competitor, I now. Mhmm. A woman

### Guest (2025-07-07T14:22:19.029Z)

very nervous as between Friday and

### You (2025-07-07T14:22:20.006Z)

named Michelle Russo. She has a company called

### Guest (2025-07-07T14:22:23.039Z)

morning, I've had time to think about it. I do believe I know who are

### You (2025-07-07T14:22:23.236Z)

she has a consulting company called Hotel Havoc.

### Guest (2025-07-07T14:22:26.879Z)

most direct competitor is now.

### You (2025-07-07T14:22:27.326Z)

Now she has a tax arm. Called sickle pain.

### Guest (2025-07-07T14:22:30.169Z)

Woman named Michelle Russo. She has a company called she has a

### You (2025-07-07T14:22:31.386Z)

They have chief technology officer They're product. That is

### Guest (2025-07-07T14:22:35.139Z)

consulting company called Hotel Ave. Now she has a tech

### You (2025-07-07T14:22:35.336Z)

asked management. For asset quickly

### Guest (2025-07-07T14:22:39.719Z)

arm called Single Pain. They have a chief technology officer.

### You (2025-07-07T14:22:39.766Z)

moving into the debt space. And into, like, the CapEx space. And she knows

### Guest (2025-07-07T14:22:44.669Z)

They're building a product that is asset management

### You (2025-07-07T14:22:46.146Z)

want it. Industry.

### Guest (2025-07-07T14:22:48.299Z)

oriented, but quickly moving into the debt space.

### You (2025-07-07T14:22:48.396Z)

What he's like it is.

### Guest (2025-07-07T14:22:52.429Z)

And into, like, the CapEx space.

### You (2025-07-07T14:22:52.516Z)

People really dislike her. A lot of people people love her.

### Guest (2025-07-07T14:22:55.109Z)

And she knows everyone in the industry.

### You (2025-07-07T14:22:55.556Z)

She does know a lot of people And so to our

### Guest (2025-07-07T14:22:58.879Z)

Whether she's liked or not liked is

### You (2025-07-07T14:22:58.986Z)

point, it like we try

### Guest (2025-07-07T14:23:02.199Z)

up in the air. A lot of people really dislike her. A lot of people like her. But she does know a lot of people. And so to Mark's point,

### You (2025-07-07T14:23:07.976Z)

too. So so

### Guest (2025-07-07T14:23:10.569Z)

information like, we need to be tried

### You (2025-07-07T14:23:11.446Z)

at this my my fingernails a bit.

### Guest (2025-07-07T14:23:13.589Z)

gather information about her, but I'm guessing she might be gathering

### You (2025-07-07T14:23:13.756Z)

So I did last.

### Guest (2025-07-07T14:23:16.669Z)

information about us right now too. So

### You (2025-07-07T14:23:18.356Z)

A way. Makes She's coming up

### Guest (2025-07-07T14:23:21.489Z)

so, anyway, that just has me biting my fingernails a bit

### You (2025-07-07T14:23:22.536Z)

down to deals. But

### Guest (2025-07-07T14:23:24.719Z)

more than it did last week because

### You (2025-07-07T14:23:25.756Z)

the project will compete with each other

### Guest (2025-07-07T14:23:27.769Z)

I we're coming at it a different way, if that makes sense. She's coming up

### You (2025-07-07T14:23:28.396Z)

And had a converse four or five months ago.

### Guest (2025-07-07T14:23:31.539Z)

through asset management, and we're coming down through deals.

### You (2025-07-07T14:23:33.486Z)

Therapy. Capital. Their

### Guest (2025-07-07T14:23:35.009Z)

But in the end, I think the products will compete with each other

### You (2025-07-07T14:23:35.346Z)

BCHER. Of traffic.

### Guest (2025-07-07T14:23:39.599Z)

I had a conversation four or five months ago with

### You (2025-07-07T14:23:40.576Z)

Product. Like this. But the woman that I spoke to

### Guest (2025-07-07T14:23:43.829Z)

their venture capital. They're a VC firm in the hotel

### You (2025-07-07T14:23:43.886Z)

friend. Of one my dad. Were talking, she said,

### Guest (2025-07-07T14:23:47.929Z)

space. They do a lot of travel tech investing. They would love a product

### You (2025-07-07T14:23:49.396Z)

would come eventually. She's like, but they're quick.

### Guest (2025-07-07T14:23:51.999Z)

like this, but the woman that I spoke to is a is a friend of one of my mentors.

### You (2025-07-07T14:23:52.956Z)

And then could be cause like, else is in the space? But now I understand

### Guest (2025-07-07T14:23:56.939Z)

And when we were talking, she said, oh, she's like, I knew this would come eventually. She's like,

### You (2025-07-07T14:23:57.096Z)

it. Connection Michelle, to KFL.

### Guest (2025-07-07T14:24:01.909Z)

but there could be two of you. Right? And that just made me pause like, well, who else is in the space?

### You (2025-07-07T14:24:02.056Z)

KFL's clients. KFL the people at KSO are

### Guest (2025-07-07T14:24:06.879Z)

But now I understand the connection is

### You (2025-07-07T14:24:08.886Z)

people from there.

### Guest (2025-07-07T14:24:09.679Z)

Michelle has gotten to KSL.

### You (2025-07-07T14:24:10.056Z)

And Fair Blood. Because for people.

### Guest (2025-07-07T14:24:13.149Z)

And KSL is one of her clients.

### You (2025-07-07T14:24:13.456Z)

Who work to. And so I

### Guest (2025-07-07T14:24:15.949Z)

KSL the people from KSL are very, very close with

### You (2025-07-07T14:24:16.016Z)

I'm starting to feel like after closing to us that I would been open. Does this make sense? Because

### Guest (2025-07-07T14:24:20.599Z)

the people from Fair Venture Fund because many of the

### You (2025-07-07T14:24:21.146Z)

Yeah. She's already in KFL, then she may have already sold

### Guest (2025-07-07T14:24:24.129Z)

Thayer Venture Fund people worked at KSL. And so I

### You (2025-07-07T14:24:26.036Z)

KFL. On this idea and sold

### Guest (2025-07-07T14:24:28.019Z)

I'm starting to feel like apps are closing to us

### You (2025-07-07T14:24:28.716Z)

you know. Not sure about it. So I guess

### Guest (2025-07-07T14:24:31.039Z)

that I thought would have been open. Does this make sense? Because if

### You (2025-07-07T14:24:31.926Z)

saying it's because I feel like

### Guest (2025-07-07T14:24:34.509Z)

she's already in with KSL,

### You (2025-07-07T14:24:35.106Z)

gonna I mean maybe it's four more for me.

### Guest (2025-07-07T14:24:36.779Z)

then she may have already sold KSL on this idea and sold

### You (2025-07-07T14:24:37.576Z)

Pick, like, surpass us in a heartbeat because she actually has

### Guest (2025-07-07T14:24:41.539Z)

you know, their venture on it. So I guess I'm just saying it this because I feel

### You (2025-07-07T14:24:43.276Z)

people. Right? And and and working on it. The what they I checked their website

### Guest (2025-07-07T14:24:46.509Z)

I feel like I mean, it's it's mean, maybe it's more to Mark, but we need to pick, like, you know,

### You (2025-07-07T14:24:48.786Z)

a couple months ago. I checked back over the weekend, I was really shocked at how far they had made it as far as Catharine and debt stuff. So

### Guest (2025-07-07T14:24:51.959Z)

like, she could zoom past us in a heartbeat because she actually has people. Right? And and and they're working on it. And the what they

### You (2025-07-07T14:24:58.456Z)

Okay. So Don't lose sleep over it.

### Guest (2025-07-07T14:25:00.659Z)

I checked their website a couple months ago, and when I checked back over the weekend,

### You (2025-07-07T14:25:02.806Z)

There are I mean, it it there it it doesn't matter

### Guest (2025-07-07T14:25:04.459Z)

I was really shocked at how far they had made it as far as CapEx and

### You (2025-07-07T14:25:07.106Z)

what you do. There will always be a competitor.

### Guest (2025-07-07T14:25:08.949Z)

and debt stuff. So

### You (2025-07-07T14:25:10.546Z)

Either they come in now or they come in later.

### Guest (2025-07-07T14:25:10.779Z)

so k.

### You (2025-07-07T14:25:15.096Z)

Or you might be the competitor that comes in after somebody else. I mean and and even being first to market, does not necessarily mean you're gonna last. I mean, if you take a look at you know, Apple, Apple didn't invent the PC. They didn't invent smartphones. They didn't invent anything. But they they come in later, but they do it right, and they do the marketing. So it's it's not about being first. It's about being the best. And one thing that I see that we have that they don't we are actually looking to take this to be cradle to grave. You know? She's looking at cap ex, one slice of the pie of the whole life cycle of the energy or debt service. Right? We are looking at managing the process from the minute they an investor becomes aware that a property is for sale, all the way to the point where they sell that property. Right? So we're looking at clients who will be with us for I don't know how what's the average length of time they own in the hotel? Five years, seven years? Whatever that is. Yeah. Whatever it is. Right?

### Guest (2025-07-07T14:26:31.999Z)

Mhmm.

### You (2025-07-07T14:26:34.706Z)

And even so so we're looking at the acquisition process from a broker standpoint.

### Guest (2025-07-07T14:26:41.819Z)

Five years. Yeah. Five to seven years. Yeah. Mhmm.

### You (2025-07-07T14:26:42.736Z)

From the investor, from the lender, all of that Okay. All the way up there. So we're gonna have the data from day one to the day it closes. And, hopefully, then when it closes, it closes with somebody who's a InnVestAI and they just kinda and so it kinda

### Guest (2025-07-07T14:26:57.139Z)

Mhmm.

### You (2025-07-07T14:26:57.996Z)

on and on and on. Somebody's gonna come in. Right? Or it it doesn't make any difference. So, you know, that's that's why I kinda tagged you in that LinkedIn thing. I don't know if you saw that yesterday. I

### Guest (2025-07-07T14:27:09.319Z)

Mhmm.

### You (2025-07-07T14:27:12.066Z)

did. You. Yeah. I'd like it. Yeah. Well, that's that's the thing is

### Guest (2025-07-07T14:27:14.439Z)

Mhmm.

### You (2025-07-07T14:27:18.856Z)

I I've always kind of felt that the biggest problem with a lot of startups is people start talking too early.

### Guest (2025-07-07T14:27:24.329Z)

I did. Thank you. I liked it this morning.

### You (2025-07-07T14:27:25.336Z)

And and get the word out. Now it doesn't necessarily have to be stealth, you know, where we we all sign an NDA, and we promise not to talk about it. Know, I don't think that's gonna work in a situation like this but I really do think, you know, we have to keep our cards close to our chest. Only talk to people that we really trust Don't worry about other people out there doing it. They're they're gonna do it.

### Guest (2025-07-07T14:27:52.869Z)

Mhmm.

### You (2025-07-07T14:27:52.936Z)

You know? And don't oversell the AI part. This is something that I've been very sensitive to when I Right. When we've got AI in our name and everything else. I know. But we will get there.

### Guest (2025-07-07T14:28:05.149Z)

Mhmm.

### You (2025-07-07T14:28:05.946Z)

Know, we're gonna start, you know, with babysit. Let's start with the core. How do we underwrite a hotel investment?

### Guest (2025-07-07T14:28:11.319Z)

Right.

### You (2025-07-07T14:28:13.016Z)

And that's where we're starting with our valuation model.

### Guest (2025-07-07T14:28:13.209Z)

I know.

### You (2025-07-07T14:28:17.026Z)

Then how do we incorporate AI into that more and more and more? And, you know, that's circle goes from here. Starts expanding, and eventually you got there. And when I say eventually, I'm not talking ten years down the road. I'm talking No. I I you know, eighteen months down the road. Right? Yeah. Eighteen months. Yes. Yeah. And you know where I'm going be out here? But AI. Name. It's lease AI. Is a winner of the big part of

### Guest (2025-07-07T14:28:42.429Z)

You know what? I know. I know.

### You (2025-07-07T14:28:42.776Z)

Right? And they're like just mean, they're

### Guest (2025-07-07T14:28:45.819Z)

Yeah. Eighteen months. Yes.

### You (2025-07-07T14:28:47.606Z)

about what they're doing on their property

### Guest (2025-07-07T14:28:48.519Z)

And you know where I got the idea to put AI in the name? It's AlisaAI.

### You (2025-07-07T14:28:49.266Z)

side of all type family.

### Guest (2025-07-07T14:28:53.489Z)

Which is a winner of the mid market. Right? And they're, like, just

### You (2025-07-07T14:28:53.516Z)

I was trying to think of names, and I was trying to think of like

### Guest (2025-07-07T14:28:57.529Z)

I mean, they're left and right getting accolades about

### You (2025-07-07T14:28:57.616Z)

around it and that. It just made me think all I said, hey. I'm

### Guest (2025-07-07T14:29:00.819Z)

what they're doing on the property side of multifamily. But they are definitely a group that I follow. And when I was trying to think of names,

### You (2025-07-07T14:29:07.426Z)

So No. I I don't I don't object to that at all. I think it's

### Guest (2025-07-07T14:29:08.239Z)

I was trying to think of, like, words around InnVest, it just made me think, oh, if I

### You (2025-07-07T14:29:11.686Z)

idea.

### Guest (2025-07-07T14:29:13.359Z)

just add AI to the name like they did, would the would the domain name be available?

### You (2025-07-07T14:29:13.646Z)

As long as we can go to somebody and say, you know, AI will underwrite your deal.

### Guest (2025-07-07T14:29:18.329Z)

And and behold, it was available. So

### You (2025-07-07T14:29:20.046Z)

You can just go back and watch the numbers pop up.

### Guest (2025-07-07T14:29:22.489Z)

mhmm.

### You (2025-07-07T14:29:23.726Z)

Which

### Guest (2025-07-07T14:29:25.119Z)

Just not to oversell it.

### You (2025-07-07T14:29:26.346Z)

at some point, we will get very close to that where we'll have enough data and they just need to go in and fine tune.

### Guest (2025-07-07T14:29:31.969Z)

Right. Right.

### You (2025-07-07T14:29:35.906Z)

But, yeah, in fact, you know, this morning when I was chatting with Vinod, know, the one of the first things we can do, and this can be very early, is having a chat interface and you could basically get in there and and underwrite your model and say, where can I adjust this? Or how can I make this model give me x? ROI. So you don't have to keep going. You're manually hunting and pet. We feed it. Like, we know, like,

### Guest (2025-07-07T14:30:12.399Z)

Mhmm.

### You (2025-07-07T14:30:14.356Z)

Right? That have to biggest levers.

### Guest (2025-07-07T14:30:18.319Z)

That's a really good idea because we could we could already

### You (2025-07-07T14:30:19.656Z)

For twenty some years. Yep. And

### Guest (2025-07-07T14:30:21.519Z)

feed it. Like, we know, like, adjust ADR by increments of

### You (2025-07-07T14:30:22.256Z)

and it's pretty amazing how and I to learn. On itself. Right?

### Guest (2025-07-07T14:30:25.589Z)

10¢ until you get to this. Right? Like, we know the things that

### You (2025-07-07T14:30:26.886Z)

Yeah. Yeah. Yeah. And you could also then create a deal summary

### Guest (2025-07-07T14:30:30.079Z)

have the biggest levers because we've done it for twenty some years.

### You (2025-07-07T14:30:33.526Z)

for an investment committee or something. So

### Guest (2025-07-07T14:30:34.239Z)

And and it's pretty amazing how AI just learns on itself. Right? It's

### You (2025-07-07T14:30:36.696Z)

have the AI go through this is where it really shines. It would be something that they could go through and

### Guest (2025-07-07T14:30:40.469Z)

yeah.

### You (2025-07-07T14:30:43.736Z)

actually create a deal summary You know, we could say, okay. Create this section. This section, this section. You know, I do that all the time with some of my product management documents. And so it can go through the model, get the details it needs, and underwrite an investment committee. Overview. Right? So that's that's the low hanging fruit We can get that out really quickly. But it's where we have to go outside the third party data or public data that's available out there, you know, what I really would love to get is to the point where we can get the average cap rate know, the RevPAR, you know, these certain metrics for the most recent deal in whatever city or whatever neighborhood that this resides in, and then use that data that's where we can get to the point where we can do 80% of the work. Of writing. And then the user gets in there, and they just tweak their assumptions. You know, one thing we will never be able to do is CapEx. You know, we don't know

### Guest (2025-07-07T14:31:47.409Z)

Mhmm.

### You (2025-07-07T14:31:49.846Z)

how the carpet looks in there. Right.

### Guest (2025-07-07T14:31:52.399Z)

Mhmm.

### You (2025-07-07T14:31:54.196Z)

But even speak up process. Yeah. Yeah. And what

### Guest (2025-07-07T14:32:01.869Z)

Mhmm.

### You (2025-07-07T14:32:02.116Z)

I guess, I just this

### Guest (2025-07-07T14:32:03.089Z)

Right.

### You (2025-07-07T14:32:04.986Z)

do it. High

### Guest (2025-07-07T14:32:06.109Z)

We can create

### You (2025-07-07T14:32:07.136Z)

I still do it. And you have, like, four or five different ways

### Guest (2025-07-07T14:32:10.329Z)

tools that, like, speed that process up.

### You (2025-07-07T14:32:10.366Z)

to do it. They'll all spend money on it. Right? Yeah. But, yeah,

### Guest (2025-07-07T14:32:13.409Z)

And because what I guess I just have this vision, like, Marriott will do it. Hilton will do it. Hyatt will do it. And then IHT will do it. And you'll have, like,

### You (2025-07-07T14:32:13.476Z)

could come in and try to help them create solutions and centralize that, if that makes sense. Right? Their spend. Try to facilitate between the

### Guest (2025-07-07T14:32:22.179Z)

four or five different ways of doing they'll all spend money on it. Right?

### You (2025-07-07T14:32:22.816Z)

brand and then the investor and all of the people that touch it.

### Guest (2025-07-07T14:32:25.799Z)

But yet if we could come in and try to help them create solutions and centralize that,

### You (2025-07-07T14:32:27.106Z)

In between. I think we really can create a product that

### Guest (2025-07-07T14:32:30.769Z)

if if that makes sense. Right? Reduce their spend,

### You (2025-07-07T14:32:31.226Z)

helps with CapEx. Is that is that Oh, yeah. No. Absolutely. Absolutely.

### Guest (2025-07-07T14:32:33.789Z)

and try to facilitate it between the brand and then the investor and all of the people that touch it in between.

### You (2025-07-07T14:32:36.816Z)

And and, you know, let let's face it. There's nothing stopping

### Guest (2025-07-07T14:32:41.209Z)

I think we really could create a product that

### You (2025-07-07T14:32:41.856Z)

the Hiltons and the Marriotts and the Hyatts of the world

### Guest (2025-07-07T14:32:44.079Z)

helps with CapEx, if that if that makes sense.

### You (2025-07-07T14:32:45.066Z)

building their own investment model.

### Guest (2025-07-07T14:32:47.129Z)

Yeah.

### You (2025-07-07T14:32:48.386Z)

They could create an AVM. What they're not gonna get is all of that aggregated data coming from other sources. They're still gonna have to either subscribe and pay big bucks to CoStar or these other ones.

### Guest (2025-07-07T14:32:57.619Z)

Mhmm.

### You (2025-07-07T14:33:04.656Z)

Whereas we are looking to create an all in one environment.

### Guest (2025-07-07T14:33:08.789Z)

Mhmm.

### You (2025-07-07T14:33:10.726Z)

Where

### Guest (2025-07-07T14:33:11.389Z)

Mhmm.

### You (2025-07-07T14:33:11.516Z)

they don't have to have all these separate subscriptions. We're gonna have that data and then bring it into their model. We'll have a marketplace where they can talk to everybody. Right? So that that's what we're trying to do is eliminate all of that fragmented data and process and bring it into one house. And that's what's gonna separate us from anybody else. You know, you you sent out the link to single pane. I've got it open on on my Okay. Main. You know, I've I've I've taken a look at it and Look at it. Yeah. Yeah. I mean, you're always gonna have niche players or doing certain Yeah. Things. Right? I

### Guest (2025-07-07T14:33:50.449Z)

Okay.

### You (2025-07-07T14:33:50.626Z)

know. I don't know her for year, and so that's why I have so much truncation

### Guest (2025-07-07T14:33:53.749Z)

Look at it.

### You (2025-07-07T14:33:54.946Z)

know how, like,

### Guest (2025-07-07T14:33:56.749Z)

Yeah.

### You (2025-07-07T14:33:57.116Z)

just I mean, I just know what she's like, and so I know that. That's what I think the thing that just worries

### Guest (2025-07-07T14:34:01.429Z)

I know the one I worked for her

### You (2025-07-07T14:34:02.946Z)

me the most. Yeah. But but what I do because

### Guest (2025-07-07T14:34:04.779Z)

for a year, and so that's why I have so much trepidation.

### You (2025-07-07T14:34:05.396Z)

truly we're taking a different approach to it.

### Guest (2025-07-07T14:34:08.729Z)

I know how, like,

### You (2025-07-07T14:34:08.836Z)

An approach that's proven

### Guest (2025-07-07T14:34:10.489Z)

just I mean, I just know what she's like and so I'll do that.

### You (2025-07-07T14:34:11.036Z)

successful. More monetized.

### Guest (2025-07-07T14:34:13.929Z)

That's what I I think the thing that just worries me the most.

### You (2025-07-07T14:34:15.036Z)

Right?

### Guest (2025-07-07T14:34:17.339Z)

But but I do truly believe we're taking a different

### You (2025-07-07T14:34:19.556Z)

In.

### Guest (2025-07-07T14:34:20.249Z)

approach to it, an approach that's proven to be successfully more monetizable in the broader commercial real estate

### You (2025-07-07T14:34:24.956Z)

Thinking like, for Pete. Yeah. Right. Because I just saw

### Guest (2025-07-07T14:34:27.759Z)

space. Right? And that's what I took away from CBRE, and that's

### You (2025-07-07T14:34:28.906Z)

what open. Like,

### Guest (2025-07-07T14:34:32.159Z)

I walked into CBRE thinking like Michelle Russo,

### You (2025-07-07T14:34:32.426Z)

an open ecosystem. It's how play with others. Right? You know, how we're

### Guest (2025-07-07T14:34:35.509Z)

And two years later, I walked out of CBRE thinking like,

### You (2025-07-07T14:34:36.896Z)

able to collaborate that data.

### Guest (2025-07-07T14:34:39.249Z)

Arcadia. Right? Because I just saw what it

### You (2025-07-07T14:34:39.796Z)

Things like that. So

### Guest (2025-07-07T14:34:42.929Z)

what of an open, like, is an open ecosystem, and it's how well you play with others. Right? And it's how well you're able to

### You (2025-07-07T14:34:49.016Z)

like, I'm like, for

### Guest (2025-07-07T14:34:50.879Z)

collaborate on data and things like that. So

### You (2025-07-07T14:34:51.026Z)

our our for six months. Is to try to integrate with

### Guest (2025-07-07T14:34:54.879Z)

one of the things I sent you this weekend that is, like,

### You (2025-07-07T14:34:55.316Z)

any title closing. Process. Mhmm. And there is

### Guest (2025-07-07T14:34:59.189Z)

on, like, tippy top of my

### You (2025-07-07T14:34:59.196Z)

really good complexity search that through.

### Guest (2025-07-07T14:35:02.329Z)

like, cool like, for our our first six months,

### You (2025-07-07T14:35:02.336Z)

All the platforms that type of companies are using to commercial

### Guest (2025-07-07T14:35:06.219Z)

is to try to integrate with the title closing process.

### You (2025-07-07T14:35:07.916Z)

companies. Too. Sure. A commercial problem that they're using

### Guest (2025-07-07T14:35:11.009Z)

And there is a really good perplexity search that walked

### You (2025-07-07T14:35:11.256Z)

to digitize their closing statements.

### Guest (2025-07-07T14:35:15.079Z)

through all the

### You (2025-07-07T14:35:15.416Z)

And course, the of how the

### Guest (2025-07-07T14:35:16.909Z)

platforms that title companies are using to commercial companies.

### You (2025-07-07T14:35:17.136Z)

closing documents on to our plan. Helps too because the

### Guest (2025-07-07T14:35:21.669Z)

Too. A commercial property types are using to digitize their

### You (2025-07-07T14:35:22.226Z)

statement is included in those closing binders. Mhmm. So if we can split that with that,

### Guest (2025-07-07T14:35:26.549Z)

closing statements. And, of course, the idea of getting all the closing documents

### You (2025-07-07T14:35:28.056Z)

that will I can puts us in such a good position as to start

### Guest (2025-07-07T14:35:31.399Z)

onto our platform helps too because the HUD statement is

### You (2025-07-07T14:35:32.236Z)

from the very beginning. With the end. Intention of quickly getting cap

### Guest (2025-07-07T14:35:36.189Z)

included in those closing binders. So if we can

### You (2025-07-07T14:35:36.836Z)

you know, cap rate pressure on deals because

### Guest (2025-07-07T14:35:40.139Z)

I mean, that that alone, I think, puts us in such

### You (2025-07-07T14:35:40.226Z)

it's so long that we don't want has good or bad information on a deal

### Guest (2025-07-07T14:35:43.519Z)

a good position is to start from the very

### You (2025-07-07T14:35:45.286Z)

So

### Guest (2025-07-07T14:35:46.539Z)

beginning with the intention of quickly getting

### You (2025-07-07T14:35:46.676Z)

particular, because I know I sent you a lot of stock, is really worth the

### Guest (2025-07-07T14:35:49.609Z)

cap, you know, cap rate information on deals?

### You (2025-07-07T14:35:50.696Z)

And just by market stay

### Guest (2025-07-07T14:35:52.379Z)

Because it's the one thing no one has

### You (2025-07-07T14:35:54.036Z)

someone from

### Guest (2025-07-07T14:35:55.429Z)

good or accurate cap rate information on deals.

### You (2025-07-07T14:35:56.586Z)

a commercial title company reached out to me and I'm talking to him tomorrow.

### Guest (2025-07-07T14:35:58.869Z)

So that in particular, because I know I sent you a lot of stuff, is really worth a read.

### You (2025-07-07T14:36:00.826Z)

Right. So I'm gonna pick the brain about what their using and how they view the digitization of their space.

### Guest (2025-07-07T14:36:03.839Z)

And then just by happenstance, someone from

### You (2025-07-07T14:36:07.736Z)

So that's one thing. Particular

### Guest (2025-07-07T14:36:09.829Z)

commercial title company reached out to me, and I'm talking to him tomorrow.

### You (2025-07-07T14:36:10.666Z)

when I found the perplexity.

### Guest (2025-07-07T14:36:14.199Z)

So I'm gonna pick his brain about what they're using and how

### You (2025-07-07T14:36:14.886Z)

Pro. Yeah. It's so much better. Yeah. As I've

### Guest (2025-07-07T14:36:17.249Z)

they view the digitization of their space.

### You (2025-07-07T14:36:18.486Z)

to the $20 subscription, I saw there's now

### Guest (2025-07-07T14:36:20.269Z)

So that's just one thing that in particular when I when I found the

### You (2025-07-07T14:36:20.946Z)

a 200 dollars. Subscription.

### Guest (2025-07-07T14:36:25.239Z)

when

### You (2025-07-07T14:36:25.766Z)

Subscription.

### Guest (2025-07-07T14:36:25.769Z)

I I did upgrade to perplex Perplexity Pro, it's so much better.

### You (2025-07-07T14:36:28.356Z)

It's much better. So it's that

### Guest (2025-07-07T14:36:30.499Z)

As I was upgrading to the $20 subscription, I saw there's now a $200 subscription

### You (2025-07-07T14:36:30.696Z)

particular is really good. Yeah. Yeah. I I use perplexity a lot, and I also have to probe. And I got a

### Guest (2025-07-07T14:36:35.469Z)

Right? The price is, like, per month.

### You (2025-07-07T14:36:40.286Z)

a year free for a newsletter

### Guest (2025-07-07T14:36:40.399Z)

But it's much better. So that's that one in

### You (2025-07-07T14:36:43.786Z)

subscription that I have. So I I didn't pay for it, but I do know that

### Guest (2025-07-07T14:36:44.229Z)

is really good to read.

### You (2025-07-07T14:36:47.586Z)

I probably will start when when that expires because, like, I I do really like it. But, yeah, it's it's it's good information. So, yeah, I I saw quite a few different attachments to that one, so I'm just gonna have to set aside some time to through them. It's skip coffee.

### Guest (2025-07-07T14:37:13.459Z)

Yeah. Yeah.

### You (2025-07-07T14:37:15.616Z)

So hard.

### Guest (2025-07-07T14:37:17.919Z)

It's a fun thing if you in the evening, if you wanna, like, have a drink, wine, or something in

### You (2025-07-07T14:37:20.306Z)

And we talked the

### Guest (2025-07-07T14:37:22.199Z)

sit on your porch and just, like, scan through what the future will look like. So

### You (2025-07-07T14:37:26.926Z)

family.

### Guest (2025-07-07T14:37:27.169Z)

So it it is really interesting, though. So

### You (2025-07-07T14:37:27.566Z)

We talked about the LLC. LLC.

### Guest (2025-07-07T14:37:30.339Z)

alright. So we talked about the budget. We talked about the timing.

### You (2025-07-07T14:37:32.086Z)

We talked about the consulting We talked about

### Guest (2025-07-07T14:37:34.349Z)

We talked about the MVP and the POC.

### You (2025-07-07T14:37:35.286Z)

sickle

### Guest (2025-07-07T14:37:37.669Z)

We talked about the friends and family.

### You (2025-07-07T14:37:38.576Z)

pitch book. On the pitch. Book.

### Guest (2025-07-07T14:37:41.419Z)

We talked about the LLC.

### You (2025-07-07T14:37:44.256Z)

So But

### Guest (2025-07-07T14:37:45.379Z)

We talked about the consulting agreements. We talked about single pane.

### You (2025-07-07T14:37:45.526Z)

No. I use I used like you were talking about. Like, pieces of a product

### Guest (2025-07-07T14:37:50.079Z)

Oh, I okay. The pitch book.

### You (2025-07-07T14:37:51.596Z)

book. I

### Guest (2025-07-07T14:37:52.629Z)

On the pitch book, it is very ugly.

### You (2025-07-07T14:37:52.766Z)

Propex Flow, and I Perplexity Pro, and I went through

### Guest (2025-07-07T14:37:55.769Z)

Very, very ugly. But I used I did use per

### You (2025-07-07T14:37:59.566Z)

slide for each thing.

### Guest (2025-07-07T14:38:01.159Z)

like, you were talking about, like, the pieces of a product

### You (2025-07-07T14:38:01.176Z)

And then I went back and I said, use language to write this.

### Guest (2025-07-07T14:38:04.899Z)

book. I use Perplexity Flow, and I

### You (2025-07-07T14:38:05.246Z)

And it's instantaneously change the tone of the language

### Guest (2025-07-07T14:38:08.089Z)

Perplexity Pro, and I went through, and I did it once, and I asked it to write a

### You (2025-07-07T14:38:08.976Z)

make it much more easy. And light hearted to, like, get through.

### Guest (2025-07-07T14:38:12.819Z)

slide for each thing. And then I went back, and I said, clever language

### You (2025-07-07T14:38:12.896Z)

Yeah. So that was purpose on my part. Yeah. Like, I was trying to not break for

### Guest (2025-07-07T14:38:17.249Z)

to write this, and it instantaneously changed

### You (2025-07-07T14:38:18.706Z)

but something that just have a little bit

### Guest (2025-07-07T14:38:20.269Z)

the tone of the language and made it much more

### You (2025-07-07T14:38:20.986Z)

ease. For read a little more about

### Guest (2025-07-07T14:38:23.499Z)

easy and lighthearted to, like, get through. So that was on purpose on my part. Right? It's like I was trying to not write a boring

### You (2025-07-07T14:38:27.666Z)

design.

### Guest (2025-07-07T14:38:31.219Z)

pitch book, but something that just

### You (2025-07-07T14:38:31.566Z)

Like that. So it's ugly

### Guest (2025-07-07T14:38:33.349Z)

had a little bit easier of a read, a little more

### You (2025-07-07T14:38:34.766Z)

but this week, I'll try to work on using

### Guest (2025-07-07T14:38:36.969Z)

conversational tone.

### You (2025-07-07T14:38:37.246Z)

beautiful eye something along those lines.

### Guest (2025-07-07T14:38:38.899Z)

I am a terrible designer, though. Like, I

### You (2025-07-07T14:38:39.556Z)

To prove the look. And

### Guest (2025-07-07T14:38:43.119Z)

hate PowerPoint. I hate anything like that. So it's ugly.

### You (2025-07-07T14:38:44.786Z)

pricing.

### Guest (2025-07-07T14:38:48.089Z)

But this week, I'll try to work on using beautiful AI or along those lines to improve the look of it. And then

### You (2025-07-07T14:38:55.346Z)

Concept

### Guest (2025-07-07T14:38:55.709Z)

I didn't include a page on the pricing

### You (2025-07-07T14:38:55.876Z)

of for in the proof of concept that shows

### Guest (2025-07-07T14:38:58.799Z)

That's something we're gonna need to work on.

### You (2025-07-07T14:38:58.886Z)

the common attraction. Right. Right? What's

### Guest (2025-07-07T14:39:01.309Z)

And then I also you had a really good idea with

### You (2025-07-07T14:39:01.646Z)

in that play. Yeah. So then people can see see that work.

### Guest (2025-07-07T14:39:04.839Z)

maybe we should put a document together that shows the proof of concept

### You (2025-07-07T14:39:04.976Z)

Thinking about it. Just a proof of concept.

### Guest (2025-07-07T14:39:09.619Z)

or maybe it's in the proof of concept, but shows the coming attractions.

### You (2025-07-07T14:39:10.666Z)

So So

### Guest (2025-07-07T14:39:13.889Z)

Right? Like, what's next on the playbook so that people can

### You (2025-07-07T14:39:14.826Z)

static deck or something like that that we share?

### Guest (2025-07-07T14:39:17.539Z)

see that we're thinking ahead and that this is just the proof of concept.

### You (2025-07-07T14:39:17.656Z)

Both. I already have some pages in the POC.

### Guest (2025-07-07T14:39:21.839Z)

So on the latter, should that be

### You (2025-07-07T14:39:24.166Z)

That are

### Guest (2025-07-07T14:39:24.459Z)

in the actual POC, or should it be some sort of static

### You (2025-07-07T14:39:25.456Z)

more future related. But

### Guest (2025-07-07T14:39:28.619Z)

deck or something like that that we share?

### You (2025-07-07T14:39:29.016Z)

every investor is gonna wanna watch see our road map. And

### Guest (2025-07-07T14:39:34.609Z)

Okay.

### You (2025-07-07T14:39:34.966Z)

not just the near term. We're gonna have to go out, like, a year And and so we'll have to kinda, like I I I've got the document open right now, your five year strategic road map, and that's basically what we're gonna have to add is something like that. That shows each item. That that we have on the road map. And then along with that, then we would probably wanna have a couple of pages that might have some mock ups. Or more explanation. So I'm, you know, I'm looking at that right now, and, you know, you've got each each line item and then a Gantt chart showing length. But it doesn't describe what those items are. We're gonna have to give you a little bit more detail. And some of them, we might be able to group together so we don't show a whole bunch of different things. You know, we could talk about, you know, here's the AI related things.

### Guest (2025-07-07T14:40:27.259Z)

Right.

### You (2025-07-07T14:40:27.786Z)

Here's the market things. One thing that I'm working on that I

### Guest (2025-07-07T14:40:30.449Z)

Okay.

### You (2025-07-07T14:40:31.976Z)

absolutely need to have you, Drew, and Mark go through is what's called the personas. Which is actually a breakdown of who uses this tool. And what it it in in the product management world, rather than referring to actual clients, you create a persona. Give them a name. You talk about their background. Why are we it's it's, like, really getting in what does the average broker who might use this? Yeah. So I need everybody to go through that and comment, you know, whether they agree or disagree. And so that's where we would really get into

### Guest (2025-07-07T14:41:19.589Z)

Joe is a hotel broker. Right? And, like, something like this. Right? He's yeah. Yep.

### You (2025-07-07T14:41:24.366Z)

prioritizing as well. And and I I still feel like there might be a little bit of difference between what what I feel we should be focusing on and what Mark feels and what other people I I know that we were talking about the title company and and and other companies. I I don't know that they would be at least for my knowledge, I don't have them at the top of the list.

### Guest (2025-07-07T14:41:53.469Z)

Mhmm.

### You (2025-07-07T14:41:56.166Z)

You know? I I'm I'm thinking, you know, we gotta go for the brokers first and investors. Okay. Yeah. But you do understand part of the closing process. Like, get back. Adoption. Yeah. In our system so we can got the purchase price like that.

### Guest (2025-07-07T14:42:14.849Z)

Oh, I agree. I I agree. I no. I I agree.

### You (2025-07-07T14:42:15.766Z)

Like, because then we have real

### Guest (2025-07-07T14:42:18.469Z)

But you you understand, like, as just part of the closing process, like,

### You (2025-07-07T14:42:18.576Z)

cap rate. For each. And so that's like why I'm so focused on that. Yes. So

### Guest (2025-07-07T14:42:22.149Z)

getting that gosh dang hugs HUD statement into our system. So we've got the

### You (2025-07-07T14:42:23.206Z)

Yeah. So I'm I'm I'm diff so I differentiate be between

### Guest (2025-07-07T14:42:27.119Z)

purchase price. Like, that is, like,

### You (2025-07-07T14:42:27.806Z)

the tools that we have

### Guest (2025-07-07T14:42:29.949Z)

then we have

### You (2025-07-07T14:42:30.916Z)

and the target users. So, yeah, you know, all of the things that we would want

### Guest (2025-07-07T14:42:31.299Z)

real cap rate information. And so that's, like, why I'm so focused on that piece of it.

### You (2025-07-07T14:42:35.406Z)

for a lender and for an appraiser and for a title company. We wanna have those documents or we wanna have that data But I don't know that I would go out there and try to sell our platform to them. Because we're saw her. Type with title

### Guest (2025-07-07T14:42:53.629Z)

Mhmm.

### You (2025-07-07T14:42:55.866Z)

ultra Yeah. With

### Guest (2025-07-07T14:43:04.769Z)

Oh, we would never sell our platform to a title company. It's more that the owner would be using this digital title company with

### You (2025-07-07T14:43:10.486Z)

bringing it back into command central. Okay. Does that make

### Guest (2025-07-07T14:43:13.929Z)

the attorney, right, and all of that. And we would have almost like a we now call it

### You (2025-07-07T14:43:14.006Z)

It does. That helps. So Right. That's where we wanna start taking a look at this Gantt chart and

### Guest (2025-07-07T14:43:18.899Z)

agents versus almost an API, right, where we're going out and grabbing that work

### You (2025-07-07T14:43:21.966Z)

you know, kind of breaking it into groups and and

### Guest (2025-07-07T14:43:23.239Z)

flow and bringing it back into command central. Does that make sense? Like,

### You (2025-07-07T14:43:24.846Z)

who would be the the primary users of these, and that'll help form our

### Guest (2025-07-07T14:43:28.739Z)

right.

### You (2025-07-07T14:43:31.186Z)

actual road map. So and then I've also sent out that email. With a link where, you know, any AI related idea, I wanna add those thoughts into that Trello board And then I've we've got the the Jira worksheet. Since we're using Jira for development, This is a really cool tool where we would then probably monthly? I think, is all we need to do We go through every single idea that's been submitted. And we give it there are three scores. One of them is, you know, how is this going to help the overall business? The second one is confidence. You know? When we say, you know, this is the great feature, we'll rate it five out of five. You know, every client's gonna want this. How confident are we of that? Right? Alright. 100% sure that everybody's gonna want this or, yeah, maybe not. You So then you give it a confidence score, and then Vinod has to give it an effort score. How easy is it to develop? So

### Guest (2025-07-07T14:44:58.269Z)

Right.

### You (2025-07-07T14:44:59.236Z)

know, ultimately, you want something that's got five stars for market impact. A 100% confidence and one star for development. Right? Something we can get That's gonna be your highest scoring thing. And then so but it takes a combination. Of everything and and creates a score, and that helps us to prioritize. Of of what should we do You know, you may have some really, really cool idea

### Guest (2025-07-07T14:45:24.559Z)

Right.

### You (2025-07-07T14:45:28.126Z)

But if it's gonna Alright. It might not. Be something that wants to Yeah. To be too expensive. Yeah. Or the node may not be able to do it without having you know, more people a larger

### Guest (2025-07-07T14:45:40.979Z)

But it might not be something that once

### You (2025-07-07T14:45:42.256Z)

staff. Yeah. We just may not

### Guest (2025-07-07T14:45:44.539Z)

to people wanna use or could be too expensive to build initially. Right?

### You (2025-07-07T14:45:44.676Z)

this. So those are the things that we really need to start looking at. And those will be the things that are beyond the MVP. Yeah. So, you know, looking at your road map here, the five year road map, that's

### Guest (2025-07-07T14:45:55.109Z)

Mhmm.

### You (2025-07-07T14:45:57.896Z)

what we wanna take a look at, number one. Make sure that everything that you've got on there is in that Jira board. And then number two, we have a chance to go through and and

### Guest (2025-07-07T14:46:05.139Z)

Mhmm.

### You (2025-07-07T14:46:06.636Z)

and rank them. I mean, so the order of Yeah. Could could easily change. Yeah. But that was just something I put together this morning. But is been I think. What I know it has to Mark

### Guest (2025-07-07T14:46:23.139Z)

Yes.

### You (2025-07-07T14:46:23.546Z)

the bucket thing.

### Guest (2025-07-07T14:46:23.999Z)

Yes. And that was just something I put together this morning.

### You (2025-07-07T14:46:24.316Z)

An hour ago by raising capital. Yeah. And then he really wants a Gantt chart. Too. And so

### Guest (2025-07-07T14:46:29.269Z)

But Mark has been this is the other I think what I'm gonna get past with Mark is the MVP POC thing, the past the bucket

### You (2025-07-07T14:46:29.606Z)

I feel like I gotta give him like, those three know, I've gotta start to get this. Of those same that I over overcoming. His objection.

### Guest (2025-07-07T14:46:37.229Z)

and how we're gonna go about raising capital. And then he really wants a Gantt chart.

### You (2025-07-07T14:46:37.586Z)

To move forward it. He can be a

### Guest (2025-07-07T14:46:41.839Z)

Too. And so I feel like I've gotta give him, like, those three I've gotta start to give him some of those things so that I'm overcoming his objective

### You (2025-07-07T14:46:42.566Z)

of the capital market. For we get to them. Part. Right? That to

### Guest (2025-07-07T14:46:50.489Z)

to move forward with things. Because he's gonna be a tremendous advocate

### You (2025-07-07T14:46:52.446Z)

her. Speaks

### Guest (2025-07-07T14:46:55.039Z)

and face of the capital markets for us when we get to that part. Right?

### You (2025-07-07T14:46:55.996Z)

language and it's a Gabriel guy. Right? So that is secret sauce of ours.

### Guest (2025-07-07T14:46:59.919Z)

That is just gonna click in, and that's something that Michelle doesn't have. That's something, like,

### You (2025-07-07T14:47:01.956Z)

It's gonna hard to come along.

### Guest (2025-07-07T14:47:04.709Z)

she doesn't have a broker on her team that

### You (2025-07-07T14:47:06.456Z)

Yeah. It's definitely get there. So

### Guest (2025-07-07T14:47:07.879Z)

that speaks the broker language and is the hey, bro guy. Right? So

### You (2025-07-07T14:47:10.456Z)

like, can we do that?

### Guest (2025-07-07T14:47:12.359Z)

that is a secret sauce of ours.

### You (2025-07-07T14:47:12.516Z)

Gantt chart? Or twenty four months and then five in trial.

### Guest (2025-07-07T14:47:14.979Z)

It's just getting Mark to come along and not have it be a year from now.

### You (2025-07-07T14:47:16.846Z)

Something like that. Is that something you're making work on this week? Sure. Yeah. Is it

### Guest (2025-07-07T14:47:19.949Z)

That we get there.

### You (2025-07-07T14:47:20.926Z)

we can do that. Okay. Let me

### Guest (2025-07-07T14:47:21.299Z)

So so how do we do a Gantt chart? Like, we redo that Gantt chart for twenty four months and then five years?

### You (2025-07-07T14:47:25.876Z)

let me take a few minutes in this afternoon's call. Because I think I need to remind everybody of

### Guest (2025-07-07T14:47:29.359Z)

In Trello or something like that? Is that something you and I could work on this week?

### You (2025-07-07T14:47:32.166Z)

where this information is being stored.

### Guest (2025-07-07T14:47:33.649Z)

Or is it okay.

### You (2025-07-07T14:47:35.426Z)

And then reiterate that we need to have everybody chip in and provide their recommendations. And then we can also schedule a call sometime over the next few days know, that we can go through as a group. It has to be done as a group. That's that's one of drawbacks for as far as scoring. You know, I might think something's a three Everybody else might rate it a five. Right? So always negotiation.

### Guest (2025-07-07T14:48:05.269Z)

Mhmm.

### You (2025-07-07T14:48:07.116Z)

That takes place during this process.

### Guest (2025-07-07T14:48:10.109Z)

Mhmm.

### You (2025-07-07T14:48:10.716Z)

And and then once we have that, I think then we can really start to get going.

### Guest (2025-07-07T14:48:16.639Z)

Mhmm.

### You (2025-07-07T14:48:18.396Z)

And the ideas that are on there are really getting into the weeds. Like, this is a specific feature we have to have but we don't we don't wanna get into the weeds. So we can separate well, here are the AI features and here are the underwriting features. Here are the reporting features. Here's the We we need to group it then, and then that's what I think we need put on a a Gantt chart. So the way I see it is we would have a Gantt chart that would be very broad.

### Guest (2025-07-07T14:48:49.569Z)

Mhmm.

### You (2025-07-07T14:48:51.636Z)

You know, here are the categories. But then as part of the documentation, we can we can then break it down. K. So here are the AI items and then break it down into give a little bit more detail on that. And then so on and so forth. You know, the the thing is people do not spend a lot of time on these. So it's important to make the most important things jump out right away. And not make it so they have to read every single word because they won't. Very few will. Correct. Right. At least at first. So if you can get them interested they want more information, that's when we can really start breaking down

### Guest (2025-07-07T14:49:39.649Z)

Mhmm.

### You (2025-07-07T14:49:44.406Z)

more details. But Which I

### Guest (2025-07-07T14:49:47.149Z)

Right.

### You (2025-07-07T14:49:48.156Z)

actually a really great segue than the last thing I had. Which is I would a, like, a night second video. It's kind of like deal panel. Technology has to be there. I would suggest that

### Guest (2025-07-07T14:50:00.799Z)

Which is actually a really great segue to the last thing I had, which is

### You (2025-07-07T14:50:02.586Z)

Voice over.

### Guest (2025-07-07T14:50:04.359Z)

I would love it if we could figure out how to put together, like,

### You (2025-07-07T14:50:04.426Z)

Right? I mean There's tons of AI tools that have come out lately.

### Guest (2025-07-07T14:50:07.649Z)

a ninety second video kind of, like, deal path

### You (2025-07-07T14:50:10.116Z)

You can use tools like Eleven Labs and

### Guest (2025-07-07T14:50:10.849Z)

that the technology has to be there, right, to just go out,

### You (2025-07-07T14:50:13.406Z)

others that will actually

### Guest (2025-07-07T14:50:14.259Z)

find some stock image and voice over and

### You (2025-07-07T14:50:15.236Z)

replicate your voice.

### Guest (2025-07-07T14:50:17.429Z)

right? I mean,

### You (2025-07-07T14:50:17.546Z)

So, you know, if if Diane gets on there, all you have to do is read, like, a thirty second thing that they got on there and then you know, you can then just type on a script. And it'll read it back. In your voice. And then in terms animations and things like that, I mean, it's it is getting to the point where some of these tools and and Google has some that are actually free. And they are amazingly detailed. You can make it look like a cartoon, or you can make it look like an actual person who's something. So you just So So you said they won't free. I

### Guest (2025-07-07T14:51:06.959Z)

Mhmm.

### You (2025-07-07T14:51:11.216Z)

deal. Q one.

### Guest (2025-07-07T14:51:14.869Z)

And I just think it would be helpful for because people, like you said, they won't read, but I

### You (2025-07-07T14:51:15.296Z)

Quickly what the product was. So

### Guest (2025-07-07T14:51:19.449Z)

flip on those ninety second deal path

### You (2025-07-07T14:51:19.586Z)

Well, that's the like, the number one marketing tool that in the world right now is TikTok.

### Guest (2025-07-07T14:51:22.469Z)

like things, and I I looked at the red IQ ones. Right? So

### You (2025-07-07T14:51:24.016Z)

The because people want to see short videos of it.

### Guest (2025-07-07T14:51:26.899Z)

it really helped to understand quickly what the product was and

### You (2025-07-07T14:51:28.316Z)

And I, up until about six months ago, always thought TikTok was just a

### Guest (2025-07-07T14:51:31.479Z)

I would love for us to do that in our market.

### You (2025-07-07T14:51:33.226Z)

social. Media for kids to get on, make silly videos, and have fun.

### Guest (2025-07-07T14:51:34.459Z)

Mhmm.

### You (2025-07-07T14:51:38.196Z)

I didn't realize how many businesses are using it.

### Guest (2025-07-07T14:51:38.869Z)

Videos.

### You (2025-07-07T14:51:42.566Z)

And the amount of Yeah. That they're getting from a thirty or ninety second TikTok video and I never would have thought about that. So

### Guest (2025-07-07T14:51:54.539Z)

Restaurants.

### You (2025-07-07T14:51:56.696Z)

it doesn't have to be on TikTok, but that's

### Guest (2025-07-07T14:51:58.939Z)

Galore are using it. Yeah.

### You (2025-07-07T14:51:59.896Z)

that's an option. I don't know how many hotel investors are on TikTok. Apparently Yeah. Yep. Yeah. Try to have it Yeah. They're unprofitable. They're very

### Guest (2025-07-07T14:52:17.629Z)

No no hotel type. But but can I tell you something, though, that I think could actually be an interesting

### You (2025-07-07T14:52:19.186Z)

They're at the beach. Worst.

### Guest (2025-07-07T14:52:22.799Z)

like, future thing for us?

### You (2025-07-07T14:52:24.006Z)

But

### Guest (2025-07-07T14:52:25.219Z)

High end hotels often have restaurants.

### You (2025-07-07T14:52:27.466Z)

customer

### Guest (2025-07-07T14:52:29.489Z)

They're very unprofitable. They're very diff

### You (2025-07-07T14:52:29.686Z)

they eat and not care about the Right? So the

### Guest (2025-07-07T14:52:32.539Z)

f and b restaurants in a hotel are the worst thing. They usually lose money.

### You (2025-07-07T14:52:32.596Z)

videos of the rest of the in their hotels very important. On.

### Guest (2025-07-07T14:52:37.609Z)

But hotel investors don't understand that the

### You (2025-07-07T14:52:38.076Z)

What's on TikTok So like for us to be able to

### Guest (2025-07-07T14:52:40.929Z)

customer making the decision on where they eat is on TikTok.

### You (2025-07-07T14:52:40.976Z)

go kind of stuff in and say, oh, look. This is what tells her Sales. These Are Tickets Is The Tick Topic On There. Yeah. That Would Be Interesting, Something That No One Else Has Really Thought Of To Do. Could It's A Small Thing. It's A Super Small Thing. But It's It's Crazy How Yeah. Even Even, Like, When I Was At Portland,

### Guest (2025-07-07T14:52:44.759Z)

Right? So those videos of the restaurants in their hotels it's very important for them to be monitoring what's on TikTok. So, like, for us to be able to go and bring that kind of stuff in and say, oh, look. This hotel is for sale. These are the tick this the TikTok. On their restaurants. Right? That would be interesting. Something that no one else

### You (2025-07-07T14:53:01.406Z)

and they they were doing multi family.

### Guest (2025-07-07T14:53:04.989Z)

has really thought of to do and could I mean, it's a small thing.

### You (2025-07-07T14:53:05.036Z)

That's And family

### Guest (2025-07-07T14:53:08.669Z)

It's a super small thing, but it's it's crazy how

### You (2025-07-07T14:53:08.836Z)

the CEO.

### Guest (2025-07-07T14:53:12.559Z)

even even, like, when I was at Portman,

### You (2025-07-07T14:53:13.016Z)

Like,

### Guest (2025-07-07T14:53:15.039Z)

and they they were very big in the multifamily investment,

### You (2025-07-07T14:53:15.266Z)

for him.

### Guest (2025-07-07T14:53:19.449Z)

And Ambrish Banswala, who was the CEO, would walk in

### You (2025-07-07T14:53:23.316Z)

Not

### Guest (2025-07-07T14:53:24.179Z)

the only thing he wanted to know about was, like, the billboard advertising.

### You (2025-07-07T14:53:26.246Z)

to source.

### Guest (2025-07-07T14:53:28.369Z)

For the apartment building off of I 75. Right?

### You (2025-07-07T14:53:30.136Z)

Like a opportunity

### Guest (2025-07-07T14:53:33.339Z)

And he it was so off, right, because

### You (2025-07-07T14:53:33.476Z)

social channel.

### Guest (2025-07-07T14:53:36.419Z)

that's not where the renter is going today to source living opportunities, like apartment complexes. You need to get into the social channels

### You (2025-07-07T14:53:45.756Z)

Yeah.

### Guest (2025-07-07T14:53:48.179Z)

because that's where this is happening. And it and it really blew my mind

### You (2025-07-07T14:53:48.226Z)

Too. Like, I felt people stupid

### Guest (2025-07-07T14:53:51.799Z)

how little they knew

### You (2025-07-07T14:53:52.686Z)

dollars.

### Guest (2025-07-07T14:53:53.619Z)

about the actual social selling and and, like, the commercial

### You (2025-07-07T14:53:53.766Z)

On that. Apartment. So, you know,

### Guest (2025-07-07T14:53:58.139Z)

selling piece of multifamily. It scared me too. Like,

### You (2025-07-07T14:54:00.356Z)

Yeah. Well, in terms of the videos, I I really like the idea

### Guest (2025-07-07T14:54:02.359Z)

these are people who are making you know, $50,000,000 decisions on apartments, and they don't

### You (2025-07-07T14:54:05.486Z)

We can put it on our web page. Link you know, post something on there. I I just

### Guest (2025-07-07T14:54:09.159Z)

truly get how these decision you know, the buying decisions are being made right now.

### You (2025-07-07T14:54:13.326Z)

we we need to decide how much we're willing to show. At at first, kinda going back to the conversation about, you know Right. Keeping things close to the chest. You know, we could do teaser videos. There are so many tools out there right now. That you know, the the only problem is when you do the

### Guest (2025-07-07T14:54:31.769Z)

Right.

### You (2025-07-07T14:54:34.316Z)

animated videos using the tools out there, I think the most you can get is, like, eight seconds. Of of But Okay. You can create multiple and then edit them together. Okay. You can create a file. You know, it's just that's not an area that I'm involved with.

### Guest (2025-07-07T14:54:56.039Z)

Oh, really?

### You (2025-07-07T14:54:56.086Z)

My son does. He's got his degrees.

### Guest (2025-07-07T14:54:58.919Z)

Okay.

### You (2025-07-07T14:54:59.306Z)

Actually,

### Guest (2025-07-07T14:55:00.209Z)

Okay.

### You (2025-07-07T14:55:00.366Z)

digital media person. So, you know, we could always have something and then have him splice it together Other alternatives are just like the videos that I record, you can actually record a video like that and then have an AI go in there and do the voice over. So as I go through it, I'm like, know, it'll clean all that. It'll take whatever text you've done and just make it better. You can choose a voice. It could be anybody else. That's an option as well. But then the question is, you know, like,

### Guest (2025-07-07T14:55:38.969Z)

Right.

### You (2025-07-07T14:55:39.956Z)

do we wanna show the actual tool, or is there just something that we can show Right. You know, like, here's here's the state of the industry today, and that's just, you know, have a screen flash full of Excel spreadsheets. Right. And this is where we want to go.

### Guest (2025-07-07T14:55:58.089Z)

Right.

### You (2025-07-07T14:55:58.536Z)

And then leave it at that, you know, something like that, like an initial teaser. You know? And And everyone

### Guest (2025-07-07T14:56:05.009Z)

Right.

### You (2025-07-07T14:56:05.536Z)

a teaser on our website, but then there's something a little bit more focused for potential consulting client or investors. Right? That is like but still sixty seconds. Gets the message or

### Guest (2025-07-07T14:56:16.929Z)

And that's great. And, like, maybe there's, like, just a teaser on our website

### You (2025-07-07T14:56:17.096Z)

girl. At least if I'm interested enough to pick up the the pitch back and

### Guest (2025-07-07T14:56:20.249Z)

but then there's something a little bit more focused for potential

### You (2025-07-07T14:56:21.966Z)

and read it or take the consulting projects.

### Guest (2025-07-07T14:56:23.869Z)

consulting clients or investors. Right? That is like but still in sixty seconds gets the message across and at least at least gets them interested enough

### You (2025-07-07T14:56:24.166Z)

Seriously. So I also have a copy of that research that was done. It it's it's been, like, fifteen years maybe. It was, like,

### Guest (2025-07-07T14:56:33.209Z)

to pick up the the pitch deck and and read it or take the consulting project

### You (2025-07-07T14:56:34.536Z)

maybe early aughts, 2010, but it

### Guest (2025-07-07T14:56:37.489Z)

seriously. So

### You (2025-07-07T14:56:38.036Z)

was University of Hawaii, and it was something that was really eye opening about errors in Excel. And the percentage of Excel models that have errors. Is extremely high, but people don't know it. And, you know, that's something we could also put in there for the initial teaser, you know, x percentage of spreadsheets have errors and, you know, they hadn't make it show, you know, this was based they don't have footnotes on it. You know? This and Yeah. I mean, there was a really famous case about ten years ago where one of the Wall Street companies had over it was over a million dollars that they lost because of a bad formula in in an Excel spreadsheet.

### Guest (2025-07-07T14:57:23.399Z)

Yeah.

### You (2025-07-07T14:57:30.826Z)

And that's been well documented. We can take things like that. Yeah. You know, not we're not just gonna make up facts. Yeah. Put that on there and just you know, I I kinda I'm kinda visioning it like a fun Yeah. All these errors and then coming down to, like, here's

### Guest (2025-07-07T14:57:44.599Z)

Yeah.

### You (2025-07-07T14:57:47.116Z)

can give you your single source of truth.

### Guest (2025-07-07T14:57:48.999Z)

Yeah.

### You (2025-07-07T14:57:49.366Z)

You know, without errors, without everything else as the initial teaser.

### Guest (2025-07-07T14:57:53.349Z)

Yeah.

### You (2025-07-07T14:57:56.276Z)

2020. That show a core real estate spread. Spend. Twenty five. Percent of their time doing. Than reorganizing information.

### Guest (2025-07-07T14:58:06.339Z)

HiLabs did a study back in 2020 that showed

### You (2025-07-07T14:58:06.656Z)

Yeah. Reorganizing

### Guest (2025-07-07T14:58:11.309Z)

commercial real estate investments per firms spend 25% of their time doing nothing other than reorganizing information.

### You (2025-07-07T14:58:15.616Z)

They've got 25% of your

### Guest (2025-07-07T14:58:20.259Z)

Than manipulating information. It's crazy. And if that's commercial real estate,

### You (2025-07-07T14:58:23.176Z)

And that's true. That's

### Guest (2025-07-07T14:58:24.989Z)

hotels, you I mean, we're harder, so it's gotta be up there. And that's a big number.

### You (2025-07-07T14:58:25.596Z)

So I'm I'm not a marker, but I'm kinda thinking now that

### Guest (2025-07-07T14:58:29.659Z)

25% of your time is doing nothing

### You (2025-07-07T14:58:30.476Z)

know, we've got an opportunity to take all these different things. So we could do the spreadsheet angle. We could do, you know,

### Guest (2025-07-07T14:58:32.679Z)

but manipulating data so that you can do your job.

### You (2025-07-07T14:58:35.446Z)

the information gathering angle.

### Guest (2025-07-07T14:58:36.799Z)

And that's true. That's honest to god what happens.

### You (2025-07-07T14:58:39.016Z)

You know? The AI will go out and get that information for you. We'll go to all these different sites The aggregated data value is like, why are you paying thousands and thousands of dollars to all these different things when you can have it all here in one place. Mhmm. Those are the types of things that I think would be really cool to have on our website. And then right below it, you know, sign up for being a beta for more information. Yeah.

### Guest (2025-07-07T14:59:06.069Z)

Mhmm.

### You (2025-07-07T14:59:16.126Z)

So Alright.

### Guest (2025-07-07T14:59:18.609Z)

Yeah. Yeah. I love what Vinod did. Are you interested

### You (2025-07-07T14:59:19.016Z)

So what's this good? Down. This is Okay.

### Guest (2025-07-07T14:59:22.889Z)

or was, like, you know and you know and then put your, you know,

### You (2025-07-07T14:59:24.006Z)

Fair. Okay. So sounds good. I will

### Guest (2025-07-07T14:59:25.909Z)

coming attraction. I thought that was great. He did a really good job with the coming soon page.

### You (2025-07-07T14:59:29.406Z)

I'll take a look at some of those. I and some of the better ones, I've actually bookmarked.

### Guest (2025-07-07T14:59:31.309Z)

Alright, Howard. So was this good for, like, a good hour admin? Right? This

### You (2025-07-07T14:59:33.296Z)

So I can probably send some links to some of those

### Guest (2025-07-07T14:59:35.649Z)

was productive.

### You (2025-07-07T14:59:36.516Z)

AI

### Guest (2025-07-07T14:59:36.779Z)

Okay.

### You (2025-07-07T14:59:37.716Z)

video marketing type things. We so we can at least start thinking about that. And then let me just take a few minutes today. I don't wanna take the whole call and start getting into the weeds and taking suggestions. I just wanna remind everybody of where the Trello board is, the process, then then start scheduling. Maybe in a week or two, we can just have our first review of all the things that are in there. I mean, I probably between Vito and I, I think we probably got about 15 things in the list already. To kinda go through. Okay. So, yeah, we can we can we can start doing that, and then that'll help with getting your road map. Getting the road map. Right. Which

### Guest (2025-07-07T15:00:28.469Z)

Mhmm.

### You (2025-07-07T15:00:29.106Z)

I get that. More like, feels starts to feel

### Guest (2025-07-07T15:00:32.759Z)

Okay.

### You (2025-07-07T15:00:32.776Z)

confidence. Yeah. Because part of it part maybe is that he is

### Guest (2025-07-07T15:00:38.579Z)

Getting the road map.

### You (2025-07-07T15:00:39.146Z)

to get his own health

### Guest (2025-07-07T15:00:41.719Z)

Right, which we need, but I need to give that to Mark so that he feels

### You (2025-07-07T15:00:43.106Z)

that he could his name out there, we will talk to people

### Guest (2025-07-07T15:00:45.309Z)

starts to feel some confidence. Because part of what I'm gathering

### You (2025-07-07T15:00:46.716Z)

Yeah. So I because I'm

### Guest (2025-07-07T15:00:49.439Z)

from Mark maybe is that he is still trying to get his

### You (2025-07-07T15:00:49.856Z)

like talking about this for a year, with people, but I do get gather things.

### Guest (2025-07-07T15:00:53.419Z)

own sense of confidence that this is real. Right?

### You (2025-07-07T15:00:53.926Z)

He's definitely be part of the stuff. Just what he's trying

### Guest (2025-07-07T15:00:56.739Z)

Before he puts his name out there and will talk to people about it.

### You (2025-07-07T15:00:57.836Z)

emulate. Mhmm. Yeah. So No. And and that's perfectly understandable.

### Guest (2025-07-07T15:01:00.829Z)

So I'm different because I've been, like, talking about this for years with people, but I do get

### You (2025-07-07T15:01:02.666Z)

So I guess my my concern

### Guest (2025-07-07T15:01:06.589Z)

that he's that might be part of the

### You (2025-07-07T15:01:06.926Z)

is going back to the very beginning of the conversation where he thinks

### Guest (2025-07-07T15:01:09.359Z)

the what he's trying to mentally get his arms around.

### You (2025-07-07T15:01:10.546Z)

we have to have a fully functioning MVP before we can get a

### Guest (2025-07-07T15:01:13.089Z)

Yep. So

### You (2025-07-07T15:01:14.706Z)

anybody writing a check. Know you and I are on the same page, so I don't know how we address that with Mark. Or I think I I finally got it. I mean, Friday.

### Guest (2025-07-07T15:01:36.009Z)

Pass the hat. I think that

### You (2025-07-07T15:01:37.956Z)

Bad. So it's like, and

### Guest (2025-07-07T15:01:40.169Z)

I think I I finally got I mean, we went round and round for, like, a half hour on Friday,

### You (2025-07-07T15:01:40.776Z)

thought that we can also go, like, through trying to find them. Of, like, 50 people

### Guest (2025-07-07T15:01:45.109Z)

and finally, I just turned around and asked him,

### You (2025-07-07T15:01:46.076Z)

are wealthy enough industry.

### Guest (2025-07-07T15:01:47.929Z)

this is our problem, Mark. So how do we solve it? And he said, pass the hat.

### You (2025-07-07T15:01:48.096Z)

That could correct you know, a tenant in a $50,000 check or something

### Guest (2025-07-07T15:01:51.999Z)

So it's like,

### You (2025-07-07T15:01:52.226Z)

like that.

### Guest (2025-07-07T15:01:53.739Z)

and that's I spent the weekend also going through trying to find a list of, like,

### You (2025-07-07T15:01:53.986Z)

Have an interest in being on the ground for this. About consulting projects.

### Guest (2025-07-07T15:01:57.569Z)

50 people that are wealthy enough in this industry that

### You (2025-07-07T15:01:58.696Z)

That could turn into an equity investment. So Well, during today's call, then we I think we also need to make

### Guest (2025-07-07T15:02:02.089Z)

could write a, you know, a 10 or $50,000 check or something like that.

### You (2025-07-07T15:02:05.406Z)

it known that we will never get to an MVP unless we have at least

### Guest (2025-07-07T15:02:06.609Z)

And might have an interest in being on the ground for this.

### You (2025-07-07T15:02:09.446Z)

some funding. And I'm not talking Right.

### Guest (2025-07-07T15:02:10.139Z)

And thinking about consulting projects that could turn into an equity investment

### You (2025-07-07T15:02:11.806Z)

Million. I'm talking about maybe 10,000 or, you know,

### Guest (2025-07-07T15:02:14.719Z)

So

### You (2025-07-07T15:02:15.236Z)

whatever. No. No. $2.50. No. Like, Two people.

### Guest (2025-07-07T15:02:24.249Z)

Right.

### You (2025-07-07T15:02:25.336Z)

Yeah. It's the Yeah. Yeah. Yeah. Just to to just get

### Guest (2025-07-07T15:02:28.769Z)

Oh, that's less than I thought. I was I was kinda thinking $2.50, but

### You (2025-07-07T15:02:29.666Z)

a database. Set up, with Vinod so that we can get other people able to log in and try the tool.

### Guest (2025-07-07T15:02:33.019Z)

but, I mean, if it's 10,000, that's probably two two people to write a small check. Yeah.

### You (2025-07-07T15:02:40.106Z)

Because, you know, I I don't know if if everybody understands what Vinod was saying. It's on his machine. But so it's actually his physical laptop that has all this

### Guest (2025-07-07T15:02:48.569Z)

Mhmm.

### You (2025-07-07T15:02:51.096Z)

Oh my gosh. You and I can't log in to his laptop to to test. So we have to have a an external database and that's what we need the initial money for. So

### Guest (2025-07-07T15:03:00.289Z)

Mhmm.

### You (2025-07-07T15:03:02.246Z)

Vinod can get us that money

### Guest (2025-07-07T15:03:03.029Z)

I under yeah.

### You (2025-07-07T15:03:05.386Z)

or get at least a high estimate

### Guest (2025-07-07T15:03:05.479Z)

Right.

### You (2025-07-07T15:03:07.456Z)

of what it would be just to get it started, and that's all we're looking for. We're not looking for full you know, two point Yeah. In or even, you know, a $100. We could be way less. Just to get the MVP up. Yeah. Yes. So Okay. Alright. This is great. Time.

### Guest (2025-07-07T15:03:24.679Z)

Yes.

### You (2025-07-07T15:03:27.496Z)

Alright. See you then. Alright.

### Guest (2025-07-07T15:03:27.829Z)

Yeah.

### You (2025-07-07T15:03:29.736Z)

Bye.

### Guest (2025-07-07T15:03:31.069Z)

Yes. Yes. Okay. This was great time time to get together, Howard. Thank you. And we will talk at 03:00. Alright. Bye.