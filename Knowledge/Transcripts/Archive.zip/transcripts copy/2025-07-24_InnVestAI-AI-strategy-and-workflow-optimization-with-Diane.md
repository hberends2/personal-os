# InnVestAI AI strategy and workflow optimization with Diane

**Date:** 2025-07-24 00:00:00 UTC
**Meeting ID:** 1daa863c-cdf5-4976-9af7-3c1c32fed460
**Synced:** 2026-02-05 14:46:48

---

# Transcript for: InnVestAI AI strategy and workflow optimization with Diane

### Guest (2025-07-24T21:31:33.789Z)

Baby.

### You (2025-07-24T21:31:54.667Z)

Good afternoon.

### Guest (2025-07-24T21:31:58.929Z)

Hello? Hey, guys.

### You (2025-07-24T21:32:03.537Z)

Hey.

### Guest (2025-07-24T21:32:05.079Z)

Hey.

### You (2025-07-24T21:32:08.657Z)

Mark, how's it going today? I'm stuck. Thanks.

### Guest (2025-07-24T21:32:09.499Z)

Mark, how's golfing today? It was good. Thanks.

### You (2025-07-24T21:32:13.627Z)

It's good. We have Elaine.

### Guest (2025-07-24T21:32:15.179Z)

It was good? Were you up early?

### You (2025-07-24T21:32:17.137Z)

Yeah. Not too bad.

### Guest (2025-07-24T21:32:17.619Z)

Yeah. It wasn't too bad.

### You (2025-07-24T21:32:18.347Z)

But

### Guest (2025-07-24T21:32:19.979Z)

But,

### You (2025-07-24T21:32:19.997Z)

I don't know, they don't have any kind of technology event at the London Conference in Phoenix.

### Guest (2025-07-24T21:32:21.699Z)

don't you know, they don't have any kind of, technology event at the lodging conference in Phoenix.

### You (2025-07-24T21:32:26.097Z)

No.

### Guest (2025-07-24T21:32:26.359Z)

So they

### You (2025-07-24T21:32:26.707Z)

So it wasn't really

### Guest (2025-07-24T21:32:27.719Z)

No. So he wasn't really

### You (2025-07-24T21:32:30.317Z)

That helped us speed on

### Guest (2025-07-24T21:32:31.859Z)

That helpful. Up to speed on

### You (2025-07-24T21:32:33.047Z)

the trends You know, if you have the trade show in Florida, right,

### Guest (2025-07-24T21:32:34.049Z)

the trends You know, see a big trade show for, though. Right?

### You (2025-07-24T21:32:37.327Z)

Did you mention that? Yeah.

### Guest (2025-07-24T21:32:38.909Z)

Did he mention that?

### You (2025-07-24T21:32:39.597Z)

Yeah. But they don't have you know, like, house has a specific

### Guest (2025-07-24T21:32:40.449Z)

Yeah. Yeah. But they don't have you know, like, Alice has a specific

### You (2025-07-24T21:32:43.387Z)

technology competition.

### Guest (2025-07-24T21:32:45.249Z)

technology competition. Yeah.

### You (2025-07-24T21:32:45.427Z)

Yeah.

### Guest (2025-07-24T21:32:47.069Z)

Yeah.

### You (2025-07-24T21:32:48.477Z)

Well, I sent you something

### Guest (2025-07-24T21:32:50.499Z)

Mark, I sent you something

### You (2025-07-24T21:32:51.637Z)

If you're your

### Guest (2025-07-24T21:32:53.489Z)

if you're in New York, the Cretech conference is a really

### You (2025-07-24T21:32:55.127Z)

is

### Guest (2025-07-24T21:32:58.399Z)

great well, I only know that I've never been, but I've watched the streaming from it.

### You (2025-07-24T21:32:59.407Z)

the streaming from it. But if that you're in work, it'll be I mean, you'd love it.

### Guest (2025-07-24T21:33:03.079Z)

If that week you're in New York, it would be

### You (2025-07-24T21:33:05.907Z)

Sure. And it's way more affordable than

### Guest (2025-07-24T21:33:06.309Z)

I mean, you'd love it. I'm sure. And it's way more

### You (2025-07-24T21:33:08.247Z)

the whole time conference. It's only, like, $800.

### Guest (2025-07-24T21:33:09.329Z)

affordable than any of the hotel conferences. It's only, like, $800.

### You (2025-07-24T21:33:12.687Z)

Yeah. That's what a couple of years ago.

### Guest (2025-07-24T21:33:13.919Z)

Yeah. Yeah. I went to it a couple years ago,

### You (2025-07-24T21:33:15.257Z)

Did you? Yeah. It's not I don't think they really have much in the hotel space, but it's a

### Guest (2025-07-24T21:33:17.279Z)

Did you? Yeah. It's my I don't think that they really have much in the hotel space, but I guess,

### You (2025-07-24T21:33:21.457Z)

something interesting to to check it out.

### Guest (2025-07-24T21:33:23.109Z)

it'd still be interesting to

### You (2025-07-24T21:33:23.597Z)

Two, but it's not the hotel space, but it's for us to look at what other

### Guest (2025-07-24T21:33:24.819Z)

to check it out. Too. But it's not the hotel space, but it's for us to look at what other

### You (2025-07-24T21:33:28.077Z)

commercial sectors are doing. We're on the other side. Are they ahead of office

### Guest (2025-07-24T21:33:30.019Z)

commercial sectors are doing. Right? And say, alright. Are they ahead of us?

### You (2025-07-24T21:33:32.387Z)

What can we learn from them? Because I think they're ahead of us by the decade almost.

### Guest (2025-07-24T21:33:34.359Z)

What can we learn from them? Because I think they're ahead of us by, like, a decade almost. So Yeah.

### You (2025-07-24T21:33:38.657Z)

So Yeah. Yeah.

### Guest (2025-07-24T21:33:42.519Z)

We'll definitely check it out. Yeah.

### You (2025-07-24T21:33:44.197Z)

And Howard is back in a sweatshirt.

### Guest (2025-07-24T21:33:44.769Z)

And, Howard, you're back in a sweatshirt.

### You (2025-07-24T21:33:47.487Z)

Yeah. That button down shirt just kinda I'm down in my main office today, which is in the basement. And it's just freezing down here. It's freezing in the basement. That's the worst place to work. To probably I worked in a basement, and it was like,

### Guest (2025-07-24T21:34:02.269Z)

It's freezing. In a basement. That's the worst place to work. Through COVID, I worked in a basement, and it was, like, just

### You (2025-07-24T21:34:06.747Z)

just the stress of COVID basement, and it was just, like,

### Guest (2025-07-24T21:34:09.129Z)

the stress of COVID and being in a basement. It was just like,

### You (2025-07-24T21:34:11.597Z)

Yeah.

### Guest (2025-07-24T21:34:13.639Z)

Really makes you go crazy.

### You (2025-07-24T21:34:14.137Z)

It it it it's it's a walkout basement. It's not not like, but

### Guest (2025-07-24T21:34:15.279Z)

It did. Okay.

### You (2025-07-24T21:34:18.297Z)

right behind me is the mechanical room. And when the air conditioner is going to cool off the house, it's like probably 10 degrees cooler down here than it is elsewhere. Yeah. Alright.

### Guest (2025-07-24T21:34:32.069Z)

Yeah.

### You (2025-07-24T21:34:32.607Z)

I

### Guest (2025-07-24T21:34:33.669Z)

Alright. So I this might be a short call, but let's start with

### You (2025-07-24T21:34:34.337Z)

call, but it's straight way because, know,

### Guest (2025-07-24T21:34:37.979Z)

because drum roll, the node

### You (2025-07-24T21:34:38.877Z)

you like over the last couple of days or

### Guest (2025-07-24T21:34:41.079Z)

you like

### You (2025-07-24T21:34:41.817Z)

team has been

### Guest (2025-07-24T21:34:42.189Z)

over the last couple of days, your team has been really hitting it hard.

### You (2025-07-24T21:34:42.747Z)

really getting a Yeah. Yep.

### Guest (2025-07-24T21:34:45.989Z)

Yep. Yep. We have been busy setting up the infrastructure, deploying the code, setting up the pipelines.

### You (2025-07-24T21:34:51.627Z)

And now kind of doing

### Guest (2025-07-24T21:34:53.969Z)

And now kind of doing the application development part.

### You (2025-07-24T21:34:53.987Z)

the application until we part. So I think that's

### Guest (2025-07-24T21:34:58.479Z)

So I think we are close to wrapping up the SSO login.

### You (2025-07-24T21:34:59.647Z)

the SSO login. So once that is done with

### Guest (2025-07-24T21:35:04.339Z)

So once that is done with

### You (2025-07-24T21:35:05.367Z)

kind of tool container, it is

### Guest (2025-07-24T21:35:07.389Z)

kinda move to on the inner pages. That's good. And is it going well working

### You (2025-07-24T21:35:11.507Z)

across time zones with your colleagues

### Guest (2025-07-24T21:35:12.979Z)

across time zones with your colleagues?

### You (2025-07-24T21:35:16.197Z)

Yeah. Those

### Guest (2025-07-24T21:35:16.929Z)

Offshore? Yeah. Yeah. They was kind of working very late.

### You (2025-07-24T21:35:20.817Z)

So, yeah, it's it's going well. It's quite well.

### Guest (2025-07-24T21:35:22.879Z)

Yeah, it's it's going well.

### You (2025-07-24T21:35:24.117Z)

Yeah. So they're working late afternoon, evening?

### Guest (2025-07-24T21:35:24.839Z)

It's going well. Yeah.

### You (2025-07-24T21:35:27.527Z)

Shifts over there? Yeah. I have to practice at four.

### Guest (2025-07-24T21:35:31.229Z)

Yeah. I got a message, like, 4PM. Last message I got was 4PM just

### You (2025-07-24T21:35:32.277Z)

PM. And the last minute, were supposed to in just

### Guest (2025-07-24T21:35:38.239Z)

one and a half hours back. So yeah.

### You (2025-07-24T21:35:38.777Z)

So yeah. Alright. Because I know that we used to try to schedule all the meetings before eleven. 11:30 in the morning. That's about the same there, Ned. Yes. I never had any

### Guest (2025-07-24T21:35:52.009Z)

Yes. So 11:30 EST here would be their

### You (2025-07-24T21:35:53.317Z)

be in there. About eight. 09:00. Yeah.

### Guest (2025-07-24T21:35:57.389Z)

09:00.

### You (2025-07-24T21:35:57.437Z)

Yeah. Where's the

### Guest (2025-07-24T21:35:58.409Z)

Yeah. Where are they where are they based? Exactly?

### You (2025-07-24T21:36:02.667Z)

So

### Guest (2025-07-24T21:36:03.039Z)

So around daily area, the capital area. Yeah. Yeah. Banola, is there anything else we can do to help

### You (2025-07-24T21:36:13.197Z)

process or

### Guest (2025-07-24T21:36:13.469Z)

them feel, like, more part of the process or

### You (2025-07-24T21:36:15.247Z)

to more excited

### Guest (2025-07-24T21:36:16.549Z)

to make them

### You (2025-07-24T21:36:17.547Z)

about the opportunity.

### Guest (2025-07-24T21:36:18.639Z)

more excited about the opportunity.

### You (2025-07-24T21:36:19.187Z)

You know, probably we could do a couple of things.

### Guest (2025-07-24T21:36:21.279Z)

Yeah. Probably, we could do a couple of things. But

### You (2025-07-24T21:36:23.137Z)

For it. And

### Guest (2025-07-24T21:36:26.399Z)

those are not mandatory as well. If we could get them email or on Teams, that'll be great. And I think Drew is already working on account. Setup, and then we'll get paid whenever this account is up.

### You (2025-07-24T21:36:37.727Z)

talking with the office.

### Guest (2025-07-24T21:36:42.669Z)

So for now, I think that should be sufficient. And once in a half, MVP is

### You (2025-07-24T21:36:46.957Z)

Think about something else.

### Guest (2025-07-24T21:36:48.139Z)

completed on time. We can

### You (2025-07-24T21:36:48.587Z)

Okay.

### Guest (2025-07-24T21:36:49.769Z)

think about something else. Okay.

### You (2025-07-24T21:36:54.397Z)

Start the bank.

### Guest (2025-07-24T21:36:54.879Z)

Yeah. And I I did, start the bank

### You (2025-07-24T21:36:55.307Z)

The bank is reviewing our documents right now.

### Guest (2025-07-24T21:36:58.189Z)

The bank is reviewing our documents right now, so

### You (2025-07-24T21:36:58.347Z)

In the next couple of days, hopefully, before

### Guest (2025-07-24T21:37:01.249Z)

see you in the next couple of days. Hopefully, before end of week.

### You (2025-07-24T21:37:04.177Z)

my account and

### Guest (2025-07-24T21:37:05.109Z)

Bank will be set up, and I can link

### You (2025-07-24T21:37:06.297Z)

figure out. The best way.

### Guest (2025-07-24T21:37:07.259Z)

my account and

### You (2025-07-24T21:37:08.137Z)

Do it. March monthly account or let me write check

### Guest (2025-07-24T21:37:09.239Z)

figure out the best way, you know, either Mark can link his account or write or write a check.

### You (2025-07-24T21:37:12.197Z)

Okay.

### Guest (2025-07-24T21:37:13.779Z)

Okay. Drew, is there anything I can do to help you the EIN forms? No. I don't think so. I mean Okay. I mean, the account was you know, just took a few minutes. It just needed the EIN, and now that that's available, I was able to finish the process. So it's just under review.

### You (2025-07-24T21:37:28.657Z)

Okay. And how is the the day?

### Guest (2025-07-24T21:37:31.599Z)

Okay. And Howard's been busy. He's been working

### You (2025-07-24T21:37:33.827Z)

Been working on it.

### Guest (2025-07-24T21:37:37.649Z)

on the how how would you describe it? Because I'm not gonna

### You (2025-07-24T21:37:37.727Z)

Describing because I'm not gonna describe it very But I was

### Guest (2025-07-24T21:37:42.019Z)

describe it very well.

### You (2025-07-24T21:37:42.067Z)

should have started first.

### Guest (2025-07-24T21:37:43.109Z)

But what you should have started with first, but we went out of our

### You (2025-07-24T21:37:43.327Z)

But Oh. The pipeline? Oh, yeah. The documentation. Yes.

### Guest (2025-07-24T21:37:49.649Z)

Documentation. Documentation.

### You (2025-07-24T21:37:51.767Z)

Okay. Sorry about that. No. It's it's going really well. So Vinod, I've gotten all of these sections down through the pro form a. So at this point, there's only a couple more sections left that I need to document. Which would be I don't have it in front of me. Let me click on that.

### Guest (2025-07-24T21:38:14.719Z)

That's amazing.

### You (2025-07-24T21:38:15.727Z)

So yeah. The investment summary, not gonna do anything on the reports.

### Guest (2025-07-24T21:38:18.959Z)

That's amazing. That is kind of That

### You (2025-07-24T21:38:22.957Z)

Yet. We we still need to develop those. And then the document upload. Or document storage. So That's great. Thank you. Yeah.

### Guest (2025-07-24T21:38:38.179Z)

That's great. Thank you.

### You (2025-07-24T21:38:38.467Z)

So the

### Guest (2025-07-24T21:38:40.129Z)

You send me that? I don't normally I probably wouldn't normally read it because I'm sure it's very it's more technical, but

### You (2025-07-24T21:38:48.497Z)

technical, but

### Guest (2025-07-24T21:38:50.219Z)

or maybe or maybe we should meet I realize now that you're doing that, if there are if there's anything that we would wanna, like, incorporate like, changes to the POC or, you know, additions to or whatever, you know, we should do sooner rather than later. There were a couple of things They don't actually need to be in the POC, but I wanted to make sure you were aware of them. So that they get into the MVP. How what's the best way to do that? Should I document what they are? It's just it's just a few probably a few things

### You (2025-07-24T21:39:23.607Z)

Like,

### Guest (2025-07-24T21:39:26.999Z)

like, that I could into an email bullet points, or we could talk about I'll start putting an email bullet points

### You (2025-07-24T21:39:33.977Z)

Yeah. We we still need to schedule that meeting where I've got the whole

### Guest (2025-07-24T21:39:35.509Z)

and then you can review and ask me questions. And

### You (2025-07-24T21:39:38.557Z)

list of items. So have you tried to access confluence or actually, you probably don't. Access yet. So okay.

### Guest (2025-07-24T21:39:48.419Z)

Yep.

### You (2025-07-24T21:39:50.047Z)

So I I I have the

### Guest (2025-07-24T21:39:51.799Z)

So I I I have a

### You (2025-07-24T21:39:52.517Z)

the thing that you Yeah. Yeah.

### Guest (2025-07-24T21:39:55.269Z)

whatever the thing was when we put in our ideas bucket. So let me let me do that.

### You (2025-07-24T21:39:59.107Z)

And then yes. So that's where we definitely need to get in there and start to prioritize items there. So

### Guest (2025-07-24T21:40:12.979Z)

I have a few of those too, so I'll put them in Trello. It's like it it's only

### You (2025-07-24T21:40:14.627Z)

but it's it's very,

### Guest (2025-07-24T21:40:16.859Z)

I mean, three items, but it's

### You (2025-07-24T21:40:16.947Z)

small. But I'll

### Guest (2025-07-24T21:40:19.749Z)

it's very, very small. But I'll include them in Trello for you guys, and I'll and maybe I'll shoot you just an email what what they are as well. And then, Howard, you I mean, you had a really good suggestion this past week that we floated on the team site, which is

### You (2025-07-24T21:40:35.127Z)

for the third engineering yet, but we

### Guest (2025-07-24T21:40:37.739Z)

might not be ready for the third engineer yet,

### You (2025-07-24T21:40:38.017Z)

should consider sourcing But someone

### Guest (2025-07-24T21:40:41.039Z)

maybe we should consider sourcing. I mean, I don't know how we're gonna do this because I'm sure this is in high demand, but

### You (2025-07-24T21:40:44.947Z)

with AI

### Guest (2025-07-24T21:40:48.019Z)

someone with

### You (2025-07-24T21:40:48.397Z)

You can't I'll explain

### Guest (2025-07-24T21:40:49.339Z)

AI

### You (2025-07-24T21:40:49.817Z)

experience. I'm that's the

### Guest (2025-07-24T21:40:51.459Z)

You can't even can you call experience? I don't even that's not a thing yet.

### You (2025-07-24T21:40:51.547Z)

thing yet. Right? But we're only at orientation, experience. Plenty plenty of them out there. Yeah. It's it's been around for years.

### Guest (2025-07-24T21:40:55.979Z)

Right? I mean but with an AI orientation okay. AI experience.

### You (2025-07-24T21:40:59.197Z)

Okay. Alright.

### Guest (2025-07-24T21:41:00.059Z)

Okay. Alright.

### You (2025-07-24T21:41:01.847Z)

To help fill that gap, technically. Right?

### Guest (2025-07-24T21:41:04.679Z)

To help fill that gap, technically. Right?

### You (2025-07-24T21:41:04.697Z)

From on the technical side. And then we can start feeding our ideas in. Right? And then

### Guest (2025-07-24T21:41:08.389Z)

On on the technical side. And then we can start feeding our ideas in, right,

### You (2025-07-24T21:41:10.147Z)

then identify the person that they can help to

### Guest (2025-07-24T21:41:13.179Z)

And then that once we identify that person, they can help to figure out

### You (2025-07-24T21:41:13.187Z)

figure out. How to do some of that. Yep.

### Guest (2025-07-24T21:41:17.839Z)

how to do some of that.

### You (2025-07-24T21:41:18.047Z)

Yep. Yeah.

### Guest (2025-07-24T21:41:19.799Z)

Yep. Cool. I mean, as far as AI agent, agent thing goes and right. Right? That's what we are considering. If we could set up clear use case for that,

### You (2025-07-24T21:41:33.137Z)

Set

### Guest (2025-07-24T21:41:36.129Z)

the upgrade. Then we can figure out You mean, like, the basic because we went over those four or five early, you know, early on use cases for AI. No. And hardly use cases for AI is good. We are kind of

### You (2025-07-24T21:41:52.247Z)

speak same time with you. Yeah. It's in the workflow and then so it is

### Guest (2025-07-24T21:41:55.089Z)

specifically saying that we'll use AI as intake workflow and then a racks. So if this

### You (2025-07-24T21:41:58.367Z)

like you know, we know where that it's exactly you know,

### Guest (2025-07-24T21:42:02.229Z)

like, you know, we know where

### You (2025-07-24T21:42:03.377Z)

Yeah. And The note, I did I did meet with David that

### Guest (2025-07-24T21:42:04.389Z)

that fits exactly then, you know, end up.

### You (2025-07-24T21:42:08.207Z)

the guy that I was working with on the financial AI extraction. He's the one that I've also mentioned that he

### Guest (2025-07-24T21:42:15.469Z)

Yeah.

### You (2025-07-24T21:42:19.567Z)

has a tool where he just takes a screenshot of an OM. And or of a section, like the the units, things like that, and it automatically processes. He he told me how it's being done, and it's kind of what I suspected. And it's actually quite easy. So I think what I'm gonna do is we need to take a look at not necessarily using the screenshot because we can do the same thing if we have an OM in a PDF format and we upload it to an LLM, can just tell it what we wanted to extract. So we could say, you know, take the broker's summary and shrink it down, you know, or or summarize it. Look for x or whatever we want in there, like the financial statement, the broker's financial statement that he have in there. And we can we can really probably pull a lot of stuff out of that that could then automatically populate the model. So we had a we had a good call today, with one of Diane's contacts, and she was spitting on a lot of pretty good ideas on the AI side. Most of them we've already talked about, but she had she had some suggestions. So

### Guest (2025-07-24T21:43:40.079Z)

I think the one thing that

### You (2025-07-24T21:43:42.057Z)

The one thing considered

### Guest (2025-07-24T21:43:45.289Z)

the one thing maybe we haven't completely considered, and it

### You (2025-07-24T21:43:46.277Z)

considered

### Guest (2025-07-24T21:43:50.079Z)

should be in our pitch deck. It won't be in our proof of concept or MVP.

### You (2025-07-24T21:43:52.177Z)

unstructured data. Right? Like, how

### Guest (2025-07-24T21:43:54.779Z)

But is the unstructured data.

### You (2025-07-24T21:43:55.407Z)

roll out? Getting ahead of the

### Guest (2025-07-24T21:43:57.679Z)

Right? Like, how you go about

### You (2025-07-24T21:43:57.947Z)

unstructured data and

### Guest (2025-07-24T21:44:00.479Z)

getting ahead of the unstructured data and

### You (2025-07-24T21:44:02.617Z)

to

### Guest (2025-07-24T21:44:04.039Z)

she talked a lot about voice

### You (2025-07-24T21:44:04.397Z)

how how can I say this? But on the left, you're pissed. Voice. Yeah.

### Guest (2025-07-24T21:44:07.289Z)

to Howard. What how would I say this? But it's almost like text Voice to yeah. Voice Yeah.

### You (2025-07-24T21:44:14.127Z)

Common. Yeah, interesting things.

### Guest (2025-07-24T21:44:14.939Z)

These are maybe the what do you call common AI features these days.

### You (2025-07-24T21:44:17.227Z)

I did not want it last

### Guest (2025-07-24T21:44:20.209Z)

As far as I remember our last conversation, we decided that we'll

### You (2025-07-24T21:44:24.247Z)

Yeah.

### Guest (2025-07-24T21:44:24.539Z)

kind of keep self host the entire model within our environment

### You (2025-07-24T21:44:25.137Z)

And and and that's how we work kind of

### Guest (2025-07-24T21:44:28.309Z)

And

### You (2025-07-24T21:44:29.647Z)

supposed to go.

### Guest (2025-07-24T21:44:30.269Z)

that's how we were kind of supposed to go.

### You (2025-07-24T21:44:30.507Z)

Yeah. Yeah. I understand. Yeah. We we we agree with that because we have gotta just get

### Guest (2025-07-24T21:44:34.599Z)

So I just have that. We agree we agree with that because we have gotta just

### You (2025-07-24T21:44:34.967Z)

something out. But at the same time, I mean, her feedback was a little bit

### Guest (2025-07-24T21:44:38.229Z)

get something out. Right? But then at the same time, I think her feedback was a little bit more from, like, a

### You (2025-07-24T21:44:43.067Z)

creeping about all the time. It's, like, from a fundraising perspective. Right? That

### Guest (2025-07-24T21:44:44.719Z)

well, I'm gonna circle back to something Mark preaches about all the time. It's, like, from a fundraising perspective. Right? That

### You (2025-07-24T21:44:47.677Z)

maybe we don't have it exactly in our proof of concept slash NLP version one, but kind of on our minds.

### Guest (2025-07-24T21:44:51.579Z)

maybe we don't have it exactly in our proof of concept slash

### You (2025-07-24T21:44:56.137Z)

In our roadmap on how we start to take unstructured data

### Guest (2025-07-24T21:44:56.459Z)

MDP version one, but that it's on our minds and in our road map.

### You (2025-07-24T21:45:00.767Z)

and

### Guest (2025-07-24T21:45:01.189Z)

On how we start to take unstructured data

### You (2025-07-24T21:45:01.647Z)

really just go out and find what all the things out and and

### Guest (2025-07-24T21:45:04.739Z)

and really just go out and find, like, all the data that we can

### You (2025-07-24T21:45:06.107Z)

how to explain this, but kind of like scatter the web and find anything that we can find and

### Guest (2025-07-24T21:45:10.059Z)

Howard, help me explain this, but kind of, like,

### You (2025-07-24T21:45:13.727Z)

pull it into our platform, and then

### Guest (2025-07-24T21:45:13.959Z)

scour the web and find any data that we can find and

### You (2025-07-24T21:45:17.227Z)

be thinking about use cases for how to voice that

### Guest (2025-07-24T21:45:17.729Z)

pull it in to our platform, and then also be thinking about use

### You (2025-07-24T21:45:20.667Z)

AI can translate through

### Guest (2025-07-24T21:45:22.519Z)

cases for how voice activated

### You (2025-07-24T21:45:24.957Z)

improve workflows. Would that be fair to

### Guest (2025-07-24T21:45:25.629Z)

AI can translate through and improve work

### You (2025-07-24T21:45:27.957Z)

Yeah. But I think she's all well, she's mentioning that

### Guest (2025-07-24T21:45:31.019Z)

that be fair to say? No.

### You (2025-07-24T21:45:32.897Z)

she brought that up in the context that that's what a lot of the people who are going for funding are bringing to the table But then she also mentioned that that those are the purely technical plays out there where we are more of a process and a tool oriented. There really isn't a whole lot of use case for voice in what we're doing. I mean, you you you you can use Apple's built in voice to text and and talk. That's that's all all you're doing is translating your voice to a text. I I don't anticipate somebody's gonna be sitting in front of their computer and having a conversation about the deal. Maybe But can I just, like, fact? Forward. Like, changing those for

### Guest (2025-07-24T21:46:29.099Z)

But can I just, like, fast forward, like, two years for or I mean, maybe eighteen months? And this is coming from my own disposition

### You (2025-07-24T21:46:35.137Z)

sell a hotel. Mhmm. And

### Guest (2025-07-24T21:46:37.059Z)

experience. Right? When you're getting ready to sell a hotel,

### You (2025-07-24T21:46:37.187Z)

and that is so

### Guest (2025-07-24T21:46:40.919Z)

and that is,

### You (2025-07-24T21:46:40.947Z)

broker goes out, to work hotel with

### Guest (2025-07-24T21:46:43.089Z)

so when a broker goes out

### You (2025-07-24T21:46:44.767Z)

people that are signed the copy and are starting to look.

### Guest (2025-07-24T21:46:46.309Z)

tour a hotel with people that have signed a confi and are starting to look. Right?

### You (2025-07-24T21:46:50.607Z)

Do the tours with the prospective buyers. It's very time

### Guest (2025-07-24T21:46:52.389Z)

The GM and the DOSM do the tours with the prospective buyers.

### You (2025-07-24T21:46:54.597Z)

consuming. It's very stressful. It's very stressful on the team because they have the existing

### Guest (2025-07-24T21:46:57.659Z)

It's very time consuming. It's very stressful. It's very stressful on the team because

### You (2025-07-24T21:47:02.047Z)

somehow grandfather

### Guest (2025-07-24T21:47:02.569Z)

they, the executive level,

### You (2025-07-24T21:47:03.467Z)

because they're a

### Guest (2025-07-24T21:47:04.769Z)

they are somehow grandfathered in because they're a

### You (2025-07-24T21:47:05.817Z)

brandish property. I like, was Carlton or something. But if they already

### Guest (2025-07-24T21:47:10.029Z)

a brand managed property, I e, like, they're a Ritz Carlton or something.

### You (2025-07-24T21:47:11.467Z)

party company, they're looking at their jobs through this.

### Guest (2025-07-24T21:47:14.069Z)

But if they are a third party managed company, they're likely to lose their jobs through this. So it is a really stressful

### You (2025-07-24T21:47:17.397Z)

Process. Yeah. That see it future where you almost sit down and someone

### Guest (2025-07-24T21:47:21.349Z)

process. And I could see a future where

### You (2025-07-24T21:47:23.497Z)

them, and

### Guest (2025-07-24T21:47:24.549Z)

you almost sit down and someone

### You (2025-07-24T21:47:25.987Z)

conversation

### Guest (2025-07-24T21:47:26.709Z)

interviews them.

### You (2025-07-24T21:47:27.567Z)

gets translated to text

### Guest (2025-07-24T21:47:28.509Z)

And that

### You (2025-07-24T21:47:29.057Z)

and goes

### Guest (2025-07-24T21:47:29.729Z)

conversation gets translated to text

### You (2025-07-24T21:47:29.747Z)

picks up, like, the documentation behind it. And

### Guest (2025-07-24T21:47:33.049Z)

and goes in and picks up, like, the documentation behind it,

### You (2025-07-24T21:47:34.997Z)

for potential buyers. Mhmm. Does that make sense? Like, that's the

### Guest (2025-07-24T21:47:36.939Z)

spits it out on the other end for potential

### You (2025-07-24T21:47:39.757Z)

that's the

### Guest (2025-07-24T21:47:40.419Z)

buyers. Does that make sense? Like, that's the use that's the that is maybe one of the bigger bigger use cases

### You (2025-07-24T21:47:41.937Z)

favorite. Cases that I see. Yeah.

### Guest (2025-07-24T21:47:46.739Z)

that I see.

### You (2025-07-24T21:47:46.827Z)

Notetaker, that's all they're doing.

### Guest (2025-07-24T21:47:48.049Z)

Yeah. I mean, that if you see these tools like

### You (2025-07-24T21:47:49.067Z)

That kind of Yeah.

### Guest (2025-07-24T21:47:51.049Z)

notetaker, that's all they are doing. They're kind of converting our voice into Dell. So yeah, this is

### You (2025-07-24T21:47:58.937Z)

But

### Guest (2025-07-24T21:47:59.239Z)

pretty much possible for sure. I'm going to speak with you. My friend Chelsea at there. She's a young, young VP, very young VP. And

### You (2025-07-24T21:48:08.507Z)

very one of her professors. So he connected us and

### Guest (2025-07-24T21:48:13.239Z)

Barry Bloom, who I used to work for, was one of her professors, so he connected us.

### You (2025-07-24T21:48:15.937Z)

giving us, like, like, her thoughts at a very

### Guest (2025-07-24T21:48:17.909Z)

And Well, that was the

### You (2025-07-24T21:48:18.957Z)

she's very

### Guest (2025-07-24T21:48:19.279Z)

Yeah. She's just giving us, like,

### You (2025-07-24T21:48:19.577Z)

junior person, so she's, like,

### Guest (2025-07-24T21:48:21.229Z)

like, her thoughts at a very she's a very junior person, so she's not even bringing this up.

### You (2025-07-24T21:48:21.357Z)

us up. Internally.

### Guest (2025-07-24T21:48:26.019Z)

Internally. But

### You (2025-07-24T21:48:26.287Z)

Really good feedback for us.

### Guest (2025-07-24T21:48:27.999Z)

she had right, Howard? I I think she had a lot of really good feedback

### You (2025-07-24T21:48:30.017Z)

The whole

### Guest (2025-07-24T21:48:31.559Z)

for us. What were her other AI suggestions?

### You (2025-07-24T21:48:32.627Z)

month data. She was really big.

### Guest (2025-07-24T21:48:35.179Z)

The whole unstructured data. She was really, really big. Well,

### You (2025-07-24T21:48:35.867Z)

First, she said, I think it as our totally the right track. Of creating

### Guest (2025-07-24T21:48:40.149Z)

first, she said, I think you guys are on totally the right track of creating

### You (2025-07-24T21:48:41.987Z)

workflow that is that exactly the workflow we have in hospitality.

### Guest (2025-07-24T21:48:45.819Z)

a workflow that is almost exactly like the work

### You (2025-07-24T21:48:47.187Z)

So, Mark, you talked about this. Right? Like, the workflow can't be

### Guest (2025-07-24T21:48:49.949Z)

we have in hospitality. So, Mark, you've talked about this.

### You (2025-07-24T21:48:51.107Z)

for to people. Gotta be honest with

### Guest (2025-07-24T21:48:53.209Z)

Right? Like, that the workflow can't be

### You (2025-07-24T21:48:54.477Z)

do it. Excel. Just in the cloud based

### Guest (2025-07-24T21:48:55.769Z)

foreign to people. It's gotta be almost what they do in Excel, just

### You (2025-07-24T21:48:57.387Z)

platform. So she gave she did. The latest for the ad.

### Guest (2025-07-24T21:49:00.739Z)

in a cloud based platform. So she gave huge accolades for that.

### You (2025-07-24T21:49:01.017Z)

Then she said, I think think I go out and with your god.

### Guest (2025-07-24T21:49:05.409Z)

Then she said, I think you guys should go out and totally look at

### You (2025-07-24T21:49:06.787Z)

All these cases where could look at. Unstructured data and screen

### Guest (2025-07-24T21:49:09.849Z)

all of the use cases where you could look at

### You (2025-07-24T21:49:11.857Z)

anything you can from the web to make that

### Guest (2025-07-24T21:49:13.859Z)

unstructured data and scraping anything you can from the web

### You (2025-07-24T21:49:15.077Z)

easier. And that's talked about, like, even things like if you're touring a property, you say, oh,

### Guest (2025-07-24T21:49:18.439Z)

to make that easier. And then she talked about, like, even things

### You (2025-07-24T21:49:21.237Z)

that there's a water leak.

### Guest (2025-07-24T21:49:22.359Z)

like if you're touring a property, right, and you say, oh, that there's a

### You (2025-07-24T21:49:23.507Z)

Here and I see it. To be able to somehow pull all

### Guest (2025-07-24T21:49:26.699Z)

water leak.

### You (2025-07-24T21:49:27.657Z)

that into

### Guest (2025-07-24T21:49:28.019Z)

Here, and I see it to be able to somehow, like,

### You (2025-07-24T21:49:28.877Z)

the workflow. Stream.

### Guest (2025-07-24T21:49:31.039Z)

pull all of that into the workflow stream. So so when you say on on on what was the term unorganized? Unstructured. Like, if someone is giving

### You (2025-07-24T21:49:36.717Z)

A podcast and talking about the Chicago market, then someone's doing it underwriting.

### Guest (2025-07-24T21:49:41.359Z)

a podcast and talking about the Chicago market and then someone is doing an underwriting for

### You (2025-07-24T21:49:41.457Z)

For Chicago hotel. Be able to scrape the

### Guest (2025-07-24T21:49:46.239Z)

Chicago hotel Yeah. Would we be able to scrape the pod the podcast? Talking about. Yeah. John Gray said that Chicago is gonna have a 20% increase next year because there's a decrease in supply.

### You (2025-07-24T21:49:50.657Z)

decreased in supply. That would go into the Yeah. Exactly. That would be a great great thing. So so that's basically that

### Guest (2025-07-24T21:49:56.679Z)

That would go into the Yeah. Exactly. That would be a great a great thing.

### You (2025-07-24T21:49:58.877Z)

research that I set up that I did through Genspark. That's that's basically what it's doing. It's sending all these agents out, and it's looking all over the place for this data it brings it back and creates a report. That we can do pretty simply. The idea that Diane was talking about as well that I thought was really good was while they are doing the physical inspection, they could be videotaping or taking pictures. And so if there's a stage her example is if it's sees a stain in the carpet, it can notate that or record that, you know, this this carpeting has to be replaced. You know, it's things like that. Physical inspections. And I know a company in the multifamily space that's that's doing that. And there's a few other ones that are example, drone based. They'll fly it over the roof. Right? And you can see if it's the if the roofs are damaged, if there's any repairs that need to be made without actually physically having to walk on the roof. To to do that. So I mean, nothing we could do

### Guest (2025-07-24T21:51:03.749Z)

Yeah.

### You (2025-07-24T21:51:04.017Z)

just thinking out loud for a minute. So was that, like, a

### Guest (2025-07-24T21:51:06.339Z)

I mean, another thing we could do, just thinking out loud for a minute,

### You (2025-07-24T21:51:07.387Z)

a video tour of the hotel. Yeah. Right? So so many times, you know,

### Guest (2025-07-24T21:51:10.749Z)

almost have, like, a

### You (2025-07-24T21:51:11.827Z)

broker books have, like, a few stock

### Guest (2025-07-24T21:51:12.029Z)

a video tour of the hotel.

### You (2025-07-24T21:51:13.627Z)

pictures. Mhmm. But there was a way to, like,

### Guest (2025-07-24T21:51:14.279Z)

Mhmm. Right? So so many times, you know,

### You (2025-07-24T21:51:15.877Z)

film

### Guest (2025-07-24T21:51:16.419Z)

broker books have, like, a few stock pictures

### You (2025-07-24T21:51:16.447Z)

the entire hotel tour.

### Guest (2025-07-24T21:51:18.819Z)

Mhmm. But if there was a way to, like, film Yeah. The entire hotel tour,

### You (2025-07-24T21:51:19.667Z)

Excuse me. I had that film that that video. Of the entire property on the site so that

### Guest (2025-07-24T21:51:24.389Z)

excuse me, and have that film, that that video

### You (2025-07-24T21:51:25.177Z)

you know, we can't from GM and DOS. Right? Exactly.

### Guest (2025-07-24T21:51:27.049Z)

of the entire property on the site so that you know, people save you. From the GM, the DOS. Right? They could see each room type, see the view from the rooms, see the ballroom not in in the photograph, but in a real live video. So, yeah, there's lots of interesting things. Right? That would be a a huge way But, I mean, that might be as we get more into the work flow streams of the investors and the brokers.

### You (2025-07-24T21:51:31.927Z)

Seeing the woman good live video. More. Sooner to work. For downstream of the investors and the broker. Yeah. But yeah. So it was really helpful to have your opportunity. Feet. On structure.

### Guest (2025-07-24T21:51:54.999Z)

But, yeah, so it was really helpful to talk to her about. But she big theme on unstructured

### You (2025-07-24T21:51:55.767Z)

On, like, how you go to have all the unstructured data opportunity

### Guest (2025-07-24T21:51:59.939Z)

data on, like, how do you go tackle the unstructured data opportunity? And I think we've we've thought we've kinda have that included in our right, two or a couple of the AI features we were talking about, right, being able to use an AI agent to pull market data summarize it,

### You (2025-07-24T21:52:18.317Z)

Right. Yep.

### Guest (2025-07-24T21:52:19.389Z)

you know, within the within the app,

### You (2025-07-24T21:52:20.817Z)

Right.

### Guest (2025-07-24T21:52:22.559Z)

Right? Mhmm. That's, like, step one of that.

### You (2025-07-24T21:52:24.367Z)

Well She she did make it clear that the most important thing is

### Guest (2025-07-24T21:52:25.879Z)

Right? And then then you can go you can expand, you know, lot beyond that.

### You (2025-07-24T21:52:29.177Z)

to have some signed clients on board. And then you can work on the AI said, you don't even have to have the AI in the product right now. But if it's on your road map and you can show this is coming. And, of course, I think we do have to have some

### Guest (2025-07-24T21:52:43.129Z)

Mhmm.

### You (2025-07-24T21:52:45.197Z)

workable AI in there, so it's not just smoke and mirrors or vaporware. We we need to show that we can do that. And then she's Yeah.

### Guest (2025-07-24T21:52:55.619Z)

Listen. Let's not forget our name is InnVestAI.

### You (2025-07-24T21:52:56.387Z)

Yeah. Well, I I was referring to before we get

### Guest (2025-07-24T21:52:59.659Z)

Mhmm.

### You (2025-07-24T21:53:01.107Z)

before we even go on to, like, a second round. You know? She she recommended very first thing we need to do is get some angel investing. To to get us through to that POC. But she she said if you want to go for, you know, a series a or something like

### Guest (2025-07-24T21:53:16.599Z)

Yep.

### You (2025-07-24T21:53:16.757Z)

that, you know, you don't have to have it all the AI baked in. You can show some that you've got in there already. In a road map of what you have planned and she's at least for her organization, she said that's that's all they need to to start considering a product. Keen on the idea of partnerships. Right? Yes. Like, yes.

### Guest (2025-07-24T21:53:38.299Z)

And Howard,

### You (2025-07-24T21:53:40.637Z)

And it's

### Guest (2025-07-24T21:53:41.319Z)

she was also very keen on the idea of partnerships. Right? Like, yes.

### You (2025-07-24T21:53:41.437Z)

so much that I guess, group is probably talked to her which is

### Guest (2025-07-24T21:53:45.989Z)

And so she said, I guess this group is probably

### You (2025-07-24T21:53:46.177Z)

for British. Is that is

### Guest (2025-07-24T21:53:50.059Z)

talked to her, which is

### You (2025-07-24T21:53:50.067Z)

helping

### Guest (2025-07-24T21:53:51.399Z)

Bridge. Bridge is a group that is helping place. I don't know what the right word is, but small loans.

### You (2025-07-24T21:53:58.347Z)

other brands embrace them.

### Guest (2025-07-24T21:54:01.529Z)

And Hilton, Choice, other brands have really embraced them probably on the

### You (2025-07-24T21:54:01.627Z)

Franchise. Side. Of it. But she creating part with groups that are to

### Guest (2025-07-24T21:54:06.729Z)

side of it with the select service product. She was very keen on the idea of create partnerships with groups that are doing something a little different than you're doing so you can combine your,

### You (2025-07-24T21:54:18.827Z)

plan plan.

### Guest (2025-07-24T21:54:20.869Z)

your business plans or your workflows And and how how do I describe this better? But just show how, like, a combined partnership helps

### You (2025-07-24T21:54:25.697Z)

Yeah.

### Guest (2025-07-24T21:54:30.149Z)

accelerate the the the, I don't know, the business processes or

### You (2025-07-24T21:54:33.917Z)

Yeah. I I think if I could summarize what she was really

### Guest (2025-07-24T21:54:38.039Z)

something like that.

### You (2025-07-24T21:54:38.407Z)

focused on is speed. And automation. Right? Those those two big themes that she kinda was that was bringing up at

### Guest (2025-07-24T21:54:48.229Z)

Mhmm.

### You (2025-07-24T21:54:49.287Z)

And so, yeah, I think if we could focus on both of those.

### Guest (2025-07-24T21:55:03.849Z)

But, Mark Bridge is a, the senior leadership team is New York based and browse around and look at You might know them through connections of yours, but if not, it might be

### You (2025-07-24T21:55:15.467Z)

To chat with. The senior team.

### Guest (2025-07-24T21:55:16.679Z)

like, a good breakfast when you're in New York City or something like that to

### You (2025-07-24T21:55:17.477Z)

Yeah.

### Guest (2025-07-24T21:55:20.749Z)

chat with the senior team?

### You (2025-07-24T21:55:22.027Z)

Okay. Thank you.

### Guest (2025-07-24T21:55:22.959Z)

Yeah. No. I'll definitely do that. And I'll be in New York next week, so I'll try to reach out.

### You (2025-07-24T21:55:23.607Z)

Sure. Alright. So I just

### Guest (2025-07-24T21:55:27.379Z)

Okay. Thank you. Sure.

### You (2025-07-24T21:55:29.457Z)

want a short one. Right? Before Alright. Alright. So much on Tuesday.

### Guest (2025-07-24T21:55:33.839Z)

Alright. So this one's the short one. Right? We're probably inside of a half hour because we talked so much on Tuesday. But I know. What what are you work what's gonna be kind of the next steps?

### You (2025-07-24T21:55:48.537Z)

And

### Guest (2025-07-24T21:55:49.019Z)

Next step. Is

### You (2025-07-24T21:55:50.437Z)

I'm

### Guest (2025-07-24T21:55:51.859Z)

like, you know, completing the login part.

### You (2025-07-24T21:55:51.997Z)

thinking of focusing on of

### Guest (2025-07-24T21:55:55.579Z)

And then I'm

### You (2025-07-24T21:55:56.987Z)

So

### Guest (2025-07-24T21:55:58.059Z)

thinking of focusing on the data extraction from PNL.

### You (2025-07-24T21:55:58.557Z)

know, told you I'm more towards doing some

### Guest (2025-07-24T21:56:03.409Z)

So whether, you know,

### You (2025-07-24T21:56:03.557Z)

AI. Code. I was kind of playing with

### Guest (2025-07-24T21:56:05.119Z)

to you

### You (2025-07-24T21:56:06.127Z)

Carl, probably Javier.

### Guest (2025-07-24T21:56:06.629Z)

I'm leaning more towards using some AI tool

### You (2025-07-24T21:56:07.827Z)

I'm probably might have smaller tool. This guy

### Guest (2025-07-24T21:56:10.439Z)

I was kind of playing with

### You (2025-07-24T21:56:10.587Z)

other idea was talking about some other tools to read.

### Guest (2025-07-24T21:56:12.159Z)

Carl, Polly, earlier.

### You (2025-07-24T21:56:13.587Z)

We're talking about that. That's right.

### Guest (2025-07-24T21:56:13.699Z)

I probably might have some other tool. This guy, the other engineer was talking about some other

### You (2025-07-24T21:56:15.157Z)

Okay. So

### Guest (2025-07-24T21:56:18.639Z)

tools, so we we'll look into that as well.

### You (2025-07-24T21:56:19.777Z)

is ready.

### Guest (2025-07-24T21:56:21.459Z)

Okay. So yeah. I mean, as as soon as the data model is

### You (2025-07-24T21:56:24.777Z)

Okay. Cool. Yeah.

### Guest (2025-07-24T21:56:26.399Z)

ready for you, I'll walk it through, explain, create document, and share. Okay. Cool. Yeah. If you want me to if you start to I mean, if you need any help validating, like, what the AI is pulling from the P and L,

### You (2025-07-24T21:56:38.537Z)

Different order.

### Guest (2025-07-24T21:56:39.419Z)

Right? I think I gave you, like,

### You (2025-07-24T21:56:39.457Z)

Yeah. I'm pretty good.

### Guest (2025-07-24T21:56:41.189Z)

twenty or thirty.

### You (2025-07-24T21:56:41.917Z)

Yeah. Yeah.

### Guest (2025-07-24T21:56:43.549Z)

You know, different operators. Yeah. Which is a pretty good cross section. Yep. Yeah. But let me know if you need any help. You know, validating or or

### You (2025-07-24T21:56:52.707Z)

And

### Guest (2025-07-24T21:56:54.889Z)

guiding the AI folks in there.

### You (2025-07-24T21:56:56.557Z)

demo on Tuesday morning,

### Guest (2025-07-24T21:56:57.309Z)

Sounds good. Sounds good.

### You (2025-07-24T21:56:58.187Z)

So we'll send for that at 10:00 eastern.

### Guest (2025-07-24T21:56:58.759Z)

Alright. So so we're not we're not gonna be speaking before this

### You (2025-07-24T21:57:00.697Z)

Okay. Mhmm. Yep. Yeah. Howard, this

### Guest (2025-07-24T21:57:02.499Z)

demo on Tuesday morning. So we all set for that at 10:00 eastern?

### You (2025-07-24T21:57:03.487Z)

chain up. He can do a fast He can do a swallow. We'll just take Ellen.

### Guest (2025-07-24T21:57:06.759Z)

Mhmm. Yeah. Howard is a champ.

### You (2025-07-24T21:57:09.377Z)

Hope we'll figure out, like, Ellen's

### Guest (2025-07-24T21:57:10.119Z)

He he can do it fast. He can do it slow.

### You (2025-07-24T21:57:11.737Z)

interest. Right? If she wants to dig deep or she wants to stay high level,

### Guest (2025-07-24T21:57:13.139Z)

We'll just take Ellen's we'll we'll figure out, like, Ellen's interest, right, if she wants to dig deep or she wants

### You (2025-07-24T21:57:15.587Z)

But market really impressed Howard does an awesome job on the Dallas. Yeah.

### Guest (2025-07-24T21:57:20.049Z)

to stay high level, But Mark, you're gonna be really impressed. Howard does an awesome job on the demos.

### You (2025-07-24T21:57:22.577Z)

Yeah. I

### Guest (2025-07-24T21:57:25.909Z)

Alright. I This is with full No doubt.

### You (2025-07-24T21:57:26.467Z)

many times.

### Guest (2025-07-24T21:57:28.599Z)

Yeah. Fulcrum. Fulcrum. Fulcrum. Okay. I I've talked many times with Fulcrum

### You (2025-07-24T21:57:30.387Z)

Many And one point,

### Guest (2025-07-24T21:57:34.569Z)

and Steve Angel did

### You (2025-07-24T21:57:34.837Z)

and he

### Guest (2025-07-24T21:57:36.619Z)

At one point, he you know, I gave him a proposal for our services.

### You (2025-07-24T21:57:40.387Z)

because he

### Guest (2025-07-24T21:57:41.089Z)

And he just

### You (2025-07-24T21:57:43.797Z)

you know, analyst to just

### Guest (2025-07-24T21:57:44.339Z)

didn't feel it was cost effective.

### You (2025-07-24T21:57:45.137Z)

you know, crunch on these numbers and

### Guest (2025-07-24T21:57:46.599Z)

Because he's like he's like, I have a pool of

### You (2025-07-24T21:57:46.647Z)

all these reports. You know, like, at

### Guest (2025-07-24T21:57:49.889Z)

you know, analysts that just, you know, crunch all these numbers and run all these reports and

### You (2025-07-24T21:57:50.117Z)

whatever the cost is, it's just specific. Kind of

### Guest (2025-07-24T21:57:54.199Z)

he's like, that that whatever the cost is, it was just easier to stick to doing what he was doing.

### You (2025-07-24T21:57:59.147Z)

Yeah.

### Guest (2025-07-24T21:58:00.589Z)

It ended up not not working out. But yeah, we I'll be curious to see how this goes. I did not meet with this woman. I met with Steve Angel himself and then Mike I think, again, a Mike or Michael.

### You (2025-07-24T21:58:10.617Z)

Yeah. I think so. Yeah. I think those things pretty well.

### Guest (2025-07-24T21:58:12.739Z)

Is there head of asset management?

### You (2025-07-24T21:58:15.037Z)

But I think that if you fail in

### Guest (2025-07-24T21:58:15.079Z)

Is there head of yeah. Yeah. I think so.

### You (2025-07-24T21:58:16.787Z)

you know, really like

### Guest (2025-07-24T21:58:17.899Z)

Yeah. And I I know Steve pretty well.

### You (2025-07-24T21:58:18.267Z)

this as think she will. You know, maybe

### Guest (2025-07-24T21:58:20.649Z)

But I I think that if if Ellen you know, really likes this as

### You (2025-07-24T21:58:22.357Z)

we get support, from her, maybe that'll help us with that. With state Yeah.

### Guest (2025-07-24T21:58:26.299Z)

think she will, you know, and maybe if we get support

### You (2025-07-24T21:58:27.067Z)

Yeah. Yeah. I think and the epidemic that does suffer from

### Guest (2025-07-24T21:58:29.319Z)

from her, maybe that'll help us with with Steve. Yeah. Yeah. Yeah. Yeah. I think I mean, asset management does

### You (2025-07-24T21:58:35.687Z)

you can't

### Guest (2025-07-24T21:58:36.749Z)

suffer from the this whole thing. It's just, like, people just throw analysts at the problem.

### You (2025-07-24T21:58:37.367Z)

You know? I wish more. Part of it for that. And

### Guest (2025-07-24T21:58:42.459Z)

You can't really do that as, you know, acquisition is much has a much more

### You (2025-07-24T21:58:44.837Z)

find some

### Guest (2025-07-24T21:58:45.949Z)

art and finesse and analysis to it.

### You (2025-07-24T21:58:49.667Z)

Should we have, like,

### Guest (2025-07-24T21:58:49.679Z)

In the underwriting part. So so I it's it's it's very possible. It could be a completely different conversation.

### You (2025-07-24T21:58:54.097Z)

associated reporting because that's

### Guest (2025-07-24T21:58:56.229Z)

Should be Yeah. I think we should try to focus on, you know, the efficiency.

### You (2025-07-24T21:58:56.317Z)

big part. Of what these assets Either cancel or trying

### Guest (2025-07-24T21:59:00.179Z)

Associated with monthly reporting because that's a big part of what these asset managers do.

### You (2025-07-24T21:59:03.687Z)

a more efficient way.

### Guest (2025-07-24T21:59:04.489Z)

You know, they're constantly trying to go through the data and reanalyze it on a regular basis

### You (2025-07-24T21:59:05.127Z)

Do that. Make their lives a lot easier.

### Guest (2025-07-24T21:59:08.979Z)

and just having a more efficient way to do that. You know, could make their lives a lot easier. Well, that is what I really part of a big it's a big part of our pitch is, like, we can take all of your your reporting, and it can be condensed. You know, you you won't have to do anything. Right? You click a button and the reports are generated. And I think Steve was one of the use one of the kind of use case the the cases where he came back and was like, it know, it's not as much of a pain for him as it is maybe for some others because they have a process in place that seems to work for them.

### You (2025-07-24T21:59:42.437Z)

So and and so it's but I I think that's why we need go in the capital markets route.

### Guest (2025-07-24T21:59:42.489Z)

You know, arguably, I think how noble felt. Too. It's like Yeah. People crunching data, and so and

### You (2025-07-24T21:59:47.277Z)

Could really differentiate us because, Drew, as you said, the capital markets

### Guest (2025-07-24T21:59:49.589Z)

so it's but I I think that's why maybe going the capital markets route

### You (2025-07-24T21:59:51.607Z)

all flows are just different. Right? And

### Guest (2025-07-24T21:59:53.359Z)

could really differentiate us because

### You (2025-07-24T21:59:54.717Z)

Yeah. Deals fuel our industry. Like, he

### Guest (2025-07-24T21:59:56.109Z)

as you said, the capital markets workflows are just different. Right? And

### You (2025-07-24T21:59:57.327Z)

do deals you don't do

### Guest (2025-07-24T22:00:01.079Z)

deals fuel our industry. Like, you do deals and you win, or you don't deal you don't do deals and you lose. Right? So Well, but I also get think

### You (2025-07-24T22:00:09.277Z)

Yeah.

### Guest (2025-07-24T22:00:09.829Z)

I think also moving away from the monthly you know, monthly reporting, we can talk about, but I think being able to say that this can you know, that you could use this to say, you know, update an updated valuation of your whole portfolio, right, without having to go manually do that. Right? It just it's gonna sort of, like, all the data would flow in there, and it'll give you valuations Or as you're doing new deals, right, like the the it'll it'll pull the data as new data becomes available in the deal room. Right? So it it I think we can take the same, you know, efficiency speed, accuracy, etcetera, but but talk about

### You (2025-07-24T22:00:45.807Z)

You know, so, if

### Guest (2025-07-24T22:00:46.129Z)

the underwriting acquisitions process.

### You (2025-07-24T22:00:47.177Z)

we could gas in that

### Guest (2025-07-24T22:00:48.359Z)

But you would think that you would think that if we told someone like Steve that with this technology,

### You (2025-07-24T22:00:48.747Z)

12 with us instead of 10, because of automation. You think that would resonate

### Guest (2025-07-24T22:00:52.609Z)

know, someone like Ellen Brown could asset manage 12 hotels instead of 10,

### You (2025-07-24T22:00:53.797Z)

with them. I'm so surprised that he see that.

### Guest (2025-07-24T22:00:56.889Z)

because of automation,

### You (2025-07-24T22:00:57.987Z)

Like, at the end of the day, you know,

### Guest (2025-07-24T22:00:58.699Z)

you think that would resonate with him?

### You (2025-07-24T22:00:59.357Z)

he's trying to run a profitable business, and

### Guest (2025-07-24T22:01:00.609Z)

I'm I'm surprised that

### You (2025-07-24T22:01:02.067Z)

convince him that this makes

### Guest (2025-07-24T22:01:02.519Z)

he didn't see that. Right? Because at end of the day, know,

### You (2025-07-24T22:01:03.467Z)

his, you know, someone like Ellen more more efficient.

### Guest (2025-07-24T22:01:06.049Z)

he's trying to run a profitable business. And if if we can convince him that this makes

### You (2025-07-24T22:01:06.547Z)

That's right. You know, I will do that. Pitch it the right way.

### Guest (2025-07-24T22:01:10.029Z)

his you know, someone like Alan more more efficient,

### You (2025-07-24T22:01:11.067Z)

I don't know. I'm just thinking about it. The best approach. I I think

### Guest (2025-07-24T22:01:12.999Z)

That's right. You know, I might not have

### You (2025-07-24T22:01:15.107Z)

But I have been told if I try to

### Guest (2025-07-24T22:01:16.109Z)

pitched it the right way. I know. I'm just thinking it out loud in terms of the best approach. I I don't know. I I think

### You (2025-07-24T22:01:18.537Z)

focus on

### Guest (2025-07-24T22:01:21.899Z)

what I have been told and what I tried to do is focus and then we you guys talked about this too. Focus on the pain points

### You (2025-07-24T22:01:27.107Z)

and about

### Guest (2025-07-24T22:01:28.229Z)

and tell a story about the benefits and the value, not features and functions.

### You (2025-07-24T22:01:35.357Z)

I

### Guest (2025-07-24T22:01:36.049Z)

And I've tended to do the latter, which I think has worked against me. So, I think that point you made. Right? Like, can can you ask each of your asset managers ask asset manage, you know, two or three more properties? I mean, that

### You (2025-07-24T22:01:48.877Z)

I would think so.

### Guest (2025-07-24T22:01:49.299Z)

know, that's working your underwriting. You can your analyst underwrite. Or three more properties at a time? I mean, that that that is very valuable.

### You (2025-07-24T22:01:53.037Z)

Problems do we solve, like, Evelyn have some houses?

### Guest (2025-07-24T22:01:55.519Z)

I would think so. Again, I'm just thinking about mean, Diane, how many properties do you think someone like Ellen asset manages?

### You (2025-07-24T22:02:01.647Z)

Mhmm.

### Guest (2025-07-24T22:02:01.709Z)

Seven is my guess.

### You (2025-07-24T22:02:02.347Z)

I guess thinking of that.

### Guest (2025-07-24T22:02:04.239Z)

Yeah. Right. She can go average. Right. Yep. So if you can go from seven to 10,

### You (2025-07-24T22:02:04.977Z)

Game changer for me. Especially with the

### Guest (2025-07-24T22:02:08.159Z)

Mhmm. Again, just thinking out loud, I mean, I would think that that would be a game changer

### You (2025-07-24T22:02:09.357Z)

I'm looking massive peak impression. Right? It's almost like half of their revenue

### Guest (2025-07-24T22:02:12.169Z)

for Especially with the fee compression because they're facing this massive I mean, it's a massive

### You (2025-07-24T22:02:12.967Z)

has disappeared. Over seven years, and this is same. Matter. Appraisal.

### Guest (2025-07-24T22:02:16.869Z)

fee compression. Right? It's almost like half of their revenue has disappeared over the

### You (2025-07-24T22:02:17.457Z)

Right. Right. But I I yeah.

### Guest (2025-07-24T22:02:20.849Z)

seven years, and this is the same in appraisal.

### You (2025-07-24T22:02:22.267Z)

I mean, we're thinking about it. We're gonna be doing one of these calls before

### Guest (2025-07-24T22:02:23.919Z)

Right.

### You (2025-07-24T22:02:24.847Z)

see you know, sort of start to see what

### Guest (2025-07-24T22:02:25.039Z)

Right. But Is that a Yeah. Mean, we should think about mean,

### You (2025-07-24T22:02:27.847Z)

But you know, that's impressive.

### Guest (2025-07-24T22:02:30.039Z)

as we do more of these calls, we'll, you know, sort of start to see what

### You (2025-07-24T22:02:32.407Z)

Is probably different than printing

### Guest (2025-07-24T22:02:33.089Z)

resonates with people. Mhmm. But,

### You (2025-07-24T22:02:34.327Z)

we have seen. Right? We see this you know,

### Guest (2025-07-24T22:02:35.809Z)

you know, in the the presentation that we give Ellen,

### You (2025-07-24T22:02:36.487Z)

at the end the day, know, every dollar is safe. You know, goes to some

### Guest (2025-07-24T22:02:39.099Z)

probably different than the presentation we give Steve. Right? Because Steve is

### You (2025-07-24T22:02:40.087Z)

pocket. You know, we're eligible just you know,

### Guest (2025-07-24T22:02:42.339Z)

you know, at the end of the day, you know, every dollar that he saves, you know, goes disproportionately in his pocket.

### You (2025-07-24T22:02:42.797Z)

the last thing she wants is another hotel room, but you know, saying so much. So I I think we have to sort of have

### Guest (2025-07-24T22:02:47.159Z)

You know, where Ellen is just, you know,

### You (2025-07-24T22:02:48.887Z)

different presentations based on

### Guest (2025-07-24T22:02:49.429Z)

the last thing she wants is another hotel in her plate. Right? It just makes her life

### You (2025-07-24T22:02:50.377Z)

the level of person that we're speaking with. But

### Guest (2025-07-24T22:02:53.259Z)

so I I think we have to sort of have a different presentations based on

### You (2025-07-24T22:02:53.657Z)

Yeah. You know, I think it's just, you know, she can make her money.

### Guest (2025-07-24T22:02:56.939Z)

the level of the person that we're speaking with.

### You (2025-07-24T22:02:57.597Z)

More efficient. You know? She can

### Guest (2025-07-24T22:02:59.609Z)

But,

### You (2025-07-24T22:03:00.067Z)

know, be smart. Right? Because she

### Guest (2025-07-24T22:03:00.599Z)

Yeah. You know, with Ellen, I think it's just, you know,

### You (2025-07-24T22:03:01.717Z)

better filters.

### Guest (2025-07-24T22:03:03.029Z)

she could make her life more efficient.

### You (2025-07-24T22:03:03.167Z)

Right? She can have access to more. They have more research

### Guest (2025-07-24T22:03:05.199Z)

You know, she can, you know, be smarter, right, because she has better tools at her disposal.

### You (2025-07-24T22:03:06.697Z)

And she would sit on the front end of something that is gonna change clear

### Guest (2025-07-24T22:03:10.059Z)

Right? She can have access to more

### You (2025-07-24T22:03:11.377Z)

trajectories. I mean,

### Guest (2025-07-24T22:03:12.089Z)

more research.

### You (2025-07-24T22:03:12.477Z)

is what I I think as well. I don't know if you guys saw there was something that went around.

### Guest (2025-07-24T22:03:13.499Z)

And she gets in on the front end of something that is gonna change

### You (2025-07-24T22:03:16.577Z)

Like, what's your career

### Guest (2025-07-24T22:03:17.359Z)

career trajectories. I mean, this is what I I I think as well.

### You (2025-07-24T22:03:18.207Z)

in

### Guest (2025-07-24T22:03:21.249Z)

Don't know if you guys saw there was something that went around, like, what's your career

### You (2025-07-24T22:03:23.817Z)

Ellen, like, if if footfall and undercooked

### Guest (2025-07-24T22:03:25.139Z)

age bracket and how and what does the next phase of AI mean to you?

### You (2025-07-24T22:03:27.017Z)

leadership, right, as she brings this idea to the table,

### Guest (2025-07-24T22:03:29.989Z)

And, like,

### You (2025-07-24T22:03:30.687Z)

it could potentially change

### Guest (2025-07-24T22:03:30.729Z)

Ellen, like, if if Fulcrum and under her leadership

### You (2025-07-24T22:03:32.307Z)

the trajectory of co career and

### Guest (2025-07-24T22:03:34.409Z)

right, if she brings this idea to the table, then it could potentially change this

### You (2025-07-24T22:03:35.307Z)

other people that work in her organization. I mean, that I I kinda see that. Like, do you wanna be a dinosaur in two years, or do you wanna be

### Guest (2025-07-24T22:03:39.379Z)

trajectory of her career and other people that work in her organization. I mean, I

### You (2025-07-24T22:03:43.497Z)

someone at the front end of this even during his own fifties, right, that

### Guest (2025-07-24T22:03:46.509Z)

kinda see that. Like, do you wanna be a dinosaur in two years or do you wanna be someone who is

### You (2025-07-24T22:03:49.687Z)

still saying, okay. I I embrace this and

### Guest (2025-07-24T22:03:51.999Z)

at the front end of this even if your age is in the fifties?

### You (2025-07-24T22:03:53.347Z)

did that make sense? So what was that? So

### Guest (2025-07-24T22:03:55.469Z)

Right? That you're still saying, okay. I I embrace this and does that make sense at all? Or is that Yeah. For sure. Yeah. Yeah. And then and

### You (2025-07-24T22:04:01.297Z)

I don't know, six f. Okay. And she's been in the hotel industry for probably

### Guest (2025-07-24T22:04:03.709Z)

Howard, you should just so you're aware. I mean, Ellen is someone who's

### You (2025-07-24T22:04:06.147Z)

thirty five years.

### Guest (2025-07-24T22:04:06.459Z)

you know, she's probably

### You (2025-07-24T22:04:07.897Z)

And she's smart.

### Guest (2025-07-24T22:04:08.339Z)

I don't know, 60 ish.

### You (2025-07-24T22:04:08.807Z)

Which is nice. So if you you're talking to someone

### Guest (2025-07-24T22:04:10.449Z)

Mhmm. And she's been in the hotel industry for probably thirty five years.

### You (2025-07-24T22:04:11.177Z)

who's very experienced in hotels. So, you know, I think

### Guest (2025-07-24T22:04:14.189Z)

And she's smart, and she's nice. So, I mean, you you deal you're

### You (2025-07-24T22:04:14.257Z)

they you know, as present. Know, you may wanna certainly focus more on

### Guest (2025-07-24T22:04:17.209Z)

talking to someone who's very experienced in hotels. So

### You (2025-07-24T22:04:18.177Z)

you know, not the basics of hotel room, you know that.

### Guest (2025-07-24T22:04:20.329Z)

you know, I I think that

### You (2025-07-24T22:04:21.517Z)

Extremely well, which is more on, you know, how we're gonna make her life

### Guest (2025-07-24T22:04:21.689Z)

know, as you present, you know, you may wanna sort of focus more on, you know, not on the basics of hotels, right, because she's

### You (2025-07-24T22:04:24.537Z)

more efficient. Easier, design that's a you know, how

### Guest (2025-07-24T22:04:27.809Z)

knows that extremely well, but just more on, you know, how we're gonna make her life more efficient

### You (2025-07-24T22:04:28.597Z)

you know, we can make her smarter and and more focused on kind of future. K. And it does

### Guest (2025-07-24T22:04:32.449Z)

easier. And as Diane had said, you know, how

### You (2025-07-24T22:04:33.807Z)

point that will resonate most with her. K. Sounds good.

### Guest (2025-07-24T22:04:35.619Z)

we could make her smarter and and more focused on kind of future. I think those are the points that'll resonate most with her. Yeah. That's fine. For the Just wondering if you have a sample of a monthly report that you were talking about.

### You (2025-07-24T22:04:51.107Z)

Yeah.

### Guest (2025-07-24T22:04:52.949Z)

Well, Diane, I'm sure you might have. Do you Yeah. Yeah. We I'm If you could share, then, you know, that'll be useful whenever, you know, we reach with that point. This is the sort of thing that, like, the estimate. You mean, like, the when we talk about the report that, like, the asset managers are putting together like, as the output to sort of the finished product,

### You (2025-07-24T22:05:14.687Z)

Already.

### Guest (2025-07-24T22:05:16.389Z)

because otherwise, the monthly reports that come from the hotels really just the p and l's. Which I provided already. Right. But but don't they ultimately

### You (2025-07-24T22:05:27.227Z)

Working there.

### Guest (2025-07-24T22:05:27.619Z)

asset managers typically give the ownership or management or whoever they're working with, like, a

### You (2025-07-24T22:05:27.717Z)

A

### Guest (2025-07-24T22:05:32.199Z)

a summary of their The commentary. Yeah. Think that's what I've noticed. Is that what you're That's what I'm saying. Yeah. I mean, we we can create one on our own, but just

### You (2025-07-24T22:05:38.067Z)

And I I

### Guest (2025-07-24T22:05:40.639Z)

wanted to have a look how that looks so that, you know, we could probably create something very similar to that.

### You (2025-07-24T22:05:44.787Z)

Michelle Russo had a

### Guest (2025-07-24T22:05:46.039Z)

And just kinda and just to jump in just as

### You (2025-07-24T22:05:48.087Z)

for page summary

### Guest (2025-07-24T22:05:48.759Z)

a person who's been through two third party asset management organizations,

### You (2025-07-24T22:05:50.017Z)

step. With others. And staff like, opinions about

### Guest (2025-07-24T22:05:52.949Z)

Michelle Russo had a very concise

### You (2025-07-24T22:05:55.597Z)

and risk.

### Guest (2025-07-24T22:05:55.969Z)

four page summaries

### You (2025-07-24T22:05:56.307Z)

So, honestly,

### Guest (2025-07-24T22:05:58.019Z)

stacked with numbers and stacked with, like, opinion

### You (2025-07-24T22:05:59.337Z)

good. See,

### Guest (2025-07-24T22:06:01.849Z)

about group pace and risk. So, honestly, her was very, very good.

### You (2025-07-24T22:06:05.927Z)

and

### Guest (2025-07-24T22:06:08.009Z)

CH Warren CH Warnick had a 20 page deck

### You (2025-07-24T22:06:11.947Z)

part. Endures.

### Guest (2025-07-24T22:06:12.759Z)

that was dense and hard to get through and repetitive. And so there's a big difference between third party asset managers and how they report, if if this is making sense at all. Like,

### You (2025-07-24T22:06:18.857Z)

It. Same way. Yourself. So

### Guest (2025-07-24T22:06:24.959Z)

so they don't all do it the same way. And Michelle probably is at their front end or the the leading edge of that process when it comes to asset management reporting. I don't know. That does probably Do you do you have a copy of her report?

### You (2025-07-24T22:06:41.867Z)

So you know,

### Guest (2025-07-24T22:06:42.899Z)

By chance? I'll go back through my stuff. I don't I don't think I'd do. She was pretty particular about what like, what was

### You (2025-07-24T22:06:50.267Z)

Yeah.

### Guest (2025-07-24T22:06:50.829Z)

know, the documents that we had, but I'll go back through. If not, I can probably from memory, almost give the sections of it. Yeah. I have a few different versions

### You (2025-07-24T22:06:59.867Z)

I was looking through all of the files saved on the team site. I don't

### Guest (2025-07-24T22:07:01.669Z)

our customers use. I can send them.

### You (2025-07-24T22:07:03.887Z)

find the sample OMs. I thought we had uploaded or or did we Right? Okay.

### Guest (2025-07-24T22:07:18.529Z)

I thought I did. I but maybe I uploaded it

### You (2025-07-24T22:07:18.867Z)

Yeah. Because I'm looking through folders. If if

### Guest (2025-07-24T22:07:21.699Z)

too because before teams, we add another site. Right?

### You (2025-07-24T22:07:21.887Z)

that that would be very, very helpful speaking of file uploads if we could get

### Guest (2025-07-24T22:07:25.889Z)

But I can

### You (2025-07-24T22:07:26.387Z)

I I I see a bunch of financial statements that Drew sent set up, but I cannot find the OMs. I'll look. Maybe I'll stick them to my laptop and with the intent of adding on there. But yeah, as many different versions of OEMs that we have, that would be very helpful. As well.

### Guest (2025-07-24T22:07:42.769Z)

yeah.

### You (2025-07-24T22:07:44.037Z)

Okay. And, Drew, I did take a look at that contract that you sent, the sample contract.

### Guest (2025-07-24T22:07:48.139Z)

Okay.

### You (2025-07-24T22:07:49.367Z)

Just one couple little comments that I emailed back. Okay. I I

### Guest (2025-07-24T22:07:52.999Z)

Yes.

### You (2025-07-24T22:07:54.857Z)

found it. Okay. Are there

### Guest (2025-07-24T22:08:01.819Z)

Okay. Yeah. I saw you responded. So Alright, everyone. Very good. Is next week

### You (2025-07-24T22:08:08.317Z)

Yep. Okay. Bye.

### Guest (2025-07-24T22:08:10.559Z)

the same? 05:30, Tuesday, Thursday? Because this feels like a good time. Yep. Yep. Very good. I'll get it on our calendars. Alright. Thanks, guys. Happy weekend. Bye. Thank you, guys. Thank you very much. Bye.