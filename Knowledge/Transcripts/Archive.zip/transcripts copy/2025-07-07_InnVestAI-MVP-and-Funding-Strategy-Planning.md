# InnVestAI MVP and Funding Strategy Planning

**Date:** 2025-07-07 00:00:00 UTC
**Meeting ID:** 14b1ffb3-43b2-4b65-84b3-df6ac75f5b62
**Synced:** 2026-02-05 14:46:48

---

# Transcript for: InnVestAI MVP and Funding Strategy Planning

### Guest (2025-07-07T21:02:53.394Z)

No. Or

### You (2025-07-07T21:02:54.656Z)

Hey. How are doing? How are you?

### Guest (2025-07-07T21:02:54.964Z)

oh, yeah. Good. Good. Yourself?

### You (2025-07-07T21:02:57.356Z)

Good. Good. Yourself? Good. How was your weekend? Good weekend.

### Guest (2025-07-07T21:03:02.424Z)

Weekend was

### You (2025-07-07T21:03:04.236Z)

Was COVID. My mom is here. Oh, nice. Yep.

### Guest (2025-07-07T21:03:04.374Z)

good. My mom is here. Let's see. K one.

### You (2025-07-07T21:03:07.796Z)

Yeah. I see I I see you cleaned up a bit. Yeah.

### Guest (2025-07-07T21:03:12.754Z)

Yep. And so I went to JFK to pick her up on Friday.

### You (2025-07-07T21:03:13.516Z)

I'm Yep. And so I went to ZFK to pick her up on Friday. Oh, you had to go all the way to JFK?

### Guest (2025-07-07T21:03:20.744Z)

Well, she was supposed to come with

### You (2025-07-07T21:03:21.046Z)

Well, it's supposed to come with someone who

### Guest (2025-07-07T21:03:23.974Z)

someone who was coming from CFK.

### You (2025-07-07T21:03:25.216Z)

who's coming to a CRM. Team. And then the flight was changed. Oh, okay.

### Guest (2025-07-07T21:03:27.114Z)

And then their flight was changed. Apparently, the flight overbooked

### You (2025-07-07T21:03:30.536Z)

Apparently, the flight overbooked. And they moved

### Guest (2025-07-07T21:03:32.884Z)

and they moved them to a different flight.

### You (2025-07-07T21:03:33.806Z)

them to a different flight. K. And I'm buying one

### Guest (2025-07-07T21:03:36.064Z)

And my mom is like, oh, I'm gonna come alone.

### You (2025-07-07T21:03:38.246Z)

come alone. And, okay, we'll do something. So

### Guest (2025-07-07T21:03:39.564Z)

Like, okay. I will do something. So

### You (2025-07-07T21:03:42.436Z)

I don't have it here.

### Guest (2025-07-07T21:03:42.554Z)

booked our wheelchair both ways from there as well as here.

### You (2025-07-07T21:03:44.746Z)

Ways. On there. I will let you And there was someone at the airport driving their cars.

### Guest (2025-07-07T21:03:47.224Z)

And there was someone at the airport who kind of helped her.

### You (2025-07-07T21:03:50.116Z)

K. So that worked out fine.

### Guest (2025-07-07T21:03:51.364Z)

So that worked out fine.

### You (2025-07-07T21:03:55.116Z)

Did you take the train or drive? Because I've

### Guest (2025-07-07T21:03:56.354Z)

Right.

### You (2025-07-07T21:03:57.796Z)

isn't it, like, a four hour train ride?

### Guest (2025-07-07T21:03:59.144Z)

Yeah. No. It was all drive. No other.

### You (2025-07-07T21:04:00.806Z)

Yeah. Not in a long drive. No. Train front either.

### Guest (2025-07-07T21:04:02.794Z)

Train from here.

### You (2025-07-07T21:04:03.856Z)

Yeah.

### Guest (2025-07-07T21:04:04.004Z)

So probably there's m drive or something, but that's too costly. So

### You (2025-07-07T21:04:04.556Z)

Probably, there's an or something. But that will cost less. Yeah.

### Guest (2025-07-07T21:04:08.644Z)

but

### You (2025-07-07T21:04:09.176Z)

Yeah.

### Guest (2025-07-07T21:04:09.534Z)

Yeah. Yep. So that's that's great.

### You (2025-07-07T21:04:11.096Z)

That's that's great. Yeah. So what'd you think of today's call?

### Guest (2025-07-07T21:04:17.854Z)

I'm sorry. What I think about today's call?

### You (2025-07-07T21:04:18.226Z)

I'm sorry. What I think of after this call, call? Yeah. Yeah. Call call was good. Just

### Guest (2025-07-07T21:04:22.424Z)

Yeah. Call call was gorgeous.

### You (2025-07-07T21:04:24.886Z)

just tell you.

### Guest (2025-07-07T21:04:25.324Z)

Just that, you know, we should have some

### You (2025-07-07T21:04:26.536Z)

Make sure that's him. Funds are available. Otherwise, we'll end up

### Guest (2025-07-07T21:04:27.854Z)

funds available. Otherwise, we'll end up just using our card everywhere.

### You (2025-07-07T21:04:30.056Z)

using a card everywhere. Yeah. So that's a lot of what Diane and I talked about this morning during our call.

### Guest (2025-07-07T21:04:39.284Z)

Right.

### You (2025-07-07T21:04:40.216Z)

And Right. You know, that that's when that's when I came up with the differentiation between the POC and the MVP. And when I explained it to her, you know, POC is just

### Guest (2025-07-07T21:04:51.024Z)

Goodbye. Yeah.

### You (2025-07-07T21:04:53.026Z)

us. To work internally and do demos.

### Guest (2025-07-07T21:04:56.444Z)

Yeah.

### You (2025-07-07T21:04:57.186Z)

Yeah. We can use it, but in order for you to go on and build the MVP, for external users,

### Guest (2025-07-07T21:05:03.804Z)

Yeah.

### You (2025-07-07T21:05:04.566Z)

we gotta get money. Gotta gotta get some funding somewhere.

### Guest (2025-07-07T21:05:06.994Z)

Right. Right.

### You (2025-07-07T21:05:08.896Z)

Alright. So Apparently, they're not even that much. Right? It's

### Guest (2025-07-07T21:05:08.944Z)

Alright. Apparently, not even that much.

### You (2025-07-07T21:05:12.966Z)

services are not that expensive to unless you're doing something with machine learning.

### Guest (2025-07-07T21:05:13.344Z)

It's cloud services are not that expensive to unless you are doing something with machine learning.

### You (2025-07-07T21:05:17.046Z)

That cost a lot. Sometimes when you are training a model and all.

### Guest (2025-07-07T21:05:18.134Z)

That costs a lot sometimes when you are training a model and all.

### You (2025-07-07T21:05:20.686Z)

Yeah. Although,

### Guest (2025-07-07T21:05:21.874Z)

Although, like, 500, 600, and then probably

### You (2025-07-07T21:05:22.866Z)

100 system then and then probably thought probably 500 more.

### Guest (2025-07-07T21:05:26.304Z)

whatever if we are adding the resource. Probably 500 more.

### You (2025-07-07T21:05:28.696Z)

Yeah. But in the end, we we that. Right? Otherwise,

### Guest (2025-07-07T21:05:29.924Z)

But then even then, we need that. Right? Otherwise,

### You (2025-07-07T21:05:31.806Z)

I don't know.

### Guest (2025-07-07T21:05:33.264Z)

I don't know how to move forward.

### You (2025-07-07T21:05:37.106Z)

Yeah. So what going to NLC filing?

### Guest (2025-07-07T21:05:41.644Z)

What happened to LLC filing? Did you hear any update on that?

### You (2025-07-07T21:05:42.236Z)

Did you hear update on that? On which one?

### Guest (2025-07-07T21:05:44.884Z)

LLC?

### You (2025-07-07T21:05:45.256Z)

I will see She sent an email. Over the weekend.

### Guest (2025-07-07T21:05:51.494Z)

What was it so that in the

### You (2025-07-07T21:05:52.436Z)

What was it? Sorry. I didn't One of them did specify she has all of the in fact, let me see if I can That is fine.

### Guest (2025-07-07T21:06:01.904Z)

No. It's fine. We don't need to spend time on it. That's fine.

### You (2025-07-07T21:06:02.566Z)

Yeah. Well, I wanna make sure you're on I wanna make sure you're on that email.

### Guest (2025-07-07T21:06:05.744Z)

So she's in place.

### You (2025-07-07T21:06:06.926Z)

Yeah. Sure. I'm on that email. I must have not heard.

### Guest (2025-07-07T21:06:07.964Z)

Yeah. I'm sure I'm on that email. I must have not read.

### You (2025-07-07T21:06:10.546Z)

Okay. Yeah. There there's quite a few of them.

### Guest (2025-07-07T21:06:12.764Z)

Yeah.

### You (2025-07-07T21:06:13.496Z)

That she sent out. I just don't know. I don't remember which one I actually talked about

### Guest (2025-07-07T21:06:18.384Z)

There are a lot of emails sent.

### You (2025-07-07T21:06:19.506Z)

Number eight. So Yeah.

### Guest (2025-07-07T21:06:22.524Z)

Private and regional bank, list of marketing, Since, like, she was

### You (2025-07-07T21:06:30.146Z)

Marketing. Speech single page.

### Guest (2025-07-07T21:06:31.624Z)

pitch deck, single pane, working session.

### You (2025-07-07T21:06:33.856Z)

Yeah.

### Guest (2025-07-07T21:06:35.404Z)

Oh, I know that. They are really loud. She sent some no. She sent some email to me and said that's the problem with email. I just

### You (2025-07-07T21:06:43.196Z)

Bottom of email. I just never checked my email. That's why we have

### Guest (2025-07-07T21:06:46.224Z)

never checked my email. That's why we have Teams.

### You (2025-07-07T21:06:46.806Z)

beams. Yeah. Okay. So, anyway anyway, I yeah.

### Guest (2025-07-07T21:06:53.994Z)

Oh, I'll check. Emails more often.

### You (2025-07-07T21:06:59.026Z)

I don't think maybe it was in the Teams chat? No. I think the only one the only Teams chat are the ones that you did. There was I mean,

### Guest (2025-07-07T21:07:09.124Z)

There was some email I

### You (2025-07-07T21:07:10.386Z)

email I saw, if you were saying it will be

### Guest (2025-07-07T21:07:12.594Z)

saw. She was saying it will leave Innode's wife's name on that, something like that. Right?

### You (2025-07-07T21:07:12.666Z)

his wife's name. On there or something like that. Right? Yeah. I think so. Yeah. He had started somewhere.

### Guest (2025-07-07T21:07:17.424Z)

Yeah. Saw it somewhere.

### You (2025-07-07T21:07:18.756Z)

Yeah. From what I remember on there, it's it's kinda like what you and I talked about last week. I think we need to give some of our personal information and have her you know, for us to be added on as officers and stuff like that. So It it fine? But I'll

### Guest (2025-07-07T21:07:37.574Z)

Is the is it file? But how how is it gonna work?

### You (2025-07-07T21:07:38.076Z)

I'll work. Thank you.

### Guest (2025-07-07T21:07:41.554Z)

She it in process or it is already done or what's going on?

### You (2025-07-07T21:07:42.886Z)

No. I don't I don't think so. I don't think she can officially finish it. Oh. Until until we get that information.

### Guest (2025-07-07T21:07:49.894Z)

Oh, okay. Oh, okay. So that's what she asked

### You (2025-07-07T21:07:52.326Z)

Oh, Sorry. That's what he asked. For in the email? Yeah.

### Guest (2025-07-07T21:07:56.934Z)

in the email?

### You (2025-07-07T21:07:59.216Z)

Yeah. Gonna have to go back. I don't think she actually

### Guest (2025-07-07T21:07:59.884Z)

Got it.

### You (2025-07-07T21:08:02.236Z)

asked for us to send her the information. I think she mentioned she was gonna reach out to us or something. So yeah, not not a big deal.

### Guest (2025-07-07T21:08:10.144Z)

Okay.

### You (2025-07-07T21:08:11.456Z)

It's at least she's working on that. And, you know, we also talked about we also have to get

### Guest (2025-07-07T21:08:11.784Z)

Yeah. Yeah. Yeah. Yeah.

### You (2025-07-07T21:08:16.426Z)

a CPA. CPA.

### Guest (2025-07-07T21:08:20.614Z)

CP. Yeah. Okay. Do we need a CP?

### You (2025-07-07T21:08:21.566Z)

For what? Like, the

### Guest (2025-07-07T21:08:23.614Z)

For what? Like, the top. Don't have money.

### You (2025-07-07T21:08:25.106Z)

No. No. Well, we we do have to set up a bank account, stuff like that. We can't just Oh.

### Guest (2025-07-07T21:08:28.854Z)

Oh,

### You (2025-07-07T21:08:31.026Z)

Know, whatever funds we get, we can't just deposit it into our own account. But, also, we have to decide you know, We we know that we're everybody is, like, 20%.

### Guest (2025-07-07T21:08:44.194Z)

Yeah.

### You (2025-07-07T21:08:45.906Z)

But there's different ways of how you dis distribute the money the the funds. So you can

### Guest (2025-07-07T21:08:52.324Z)

Mhmm.

### You (2025-07-07T21:08:53.316Z)

we could have a, like, a a stock option It could be just like an annual distribution. There's there's just different ways that we have to have. I don't know if it has to be part of the LLC filing or if it can be separate. But we do have to have a a written plan for how any profits are distributed. So Okay.

### Guest (2025-07-07T21:09:22.704Z)

Got it. Got it.

### You (2025-07-07T21:09:23.626Z)

Got it. Yeah. I I I know a lot of start ups You know, like, the CEO works. Their their salary is $1. And all of their income comes from

### Guest (2025-07-07T21:09:31.664Z)

Okay.

### You (2025-07-07T21:09:34.576Z)

know, either percentage of the profit or distributions, things like that. So but for that, we do need to have an accountant that that can set everything up

### Guest (2025-07-07T21:09:46.764Z)

Mhmm.

### You (2025-07-07T21:09:47.036Z)

fill in the forms, tax, type of things. So there's, yeah, there's there's still a lot of lot of paperwork that needs to be done yet.

### Guest (2025-07-07T21:09:56.464Z)

Gotcha.

### You (2025-07-07T21:09:57.826Z)

Okay. But I think

### Guest (2025-07-07T21:10:01.224Z)

Got

### You (2025-07-07T21:10:03.676Z)

when she and I talked this morning, she was like, she she she mentioned, well, I put that budget together. I think I it down to $2,800,000 and know, how much you know, when do you think we can start doing this? I'm like, we don't need 2,800,000.0. We just need a couple thousand dollars. To get the database set up and and everything like that.

### Guest (2025-07-07T21:10:24.634Z)

Yeah.

### You (2025-07-07T21:10:26.176Z)

You know? Before we can do the external. So I think she was very worried that we might hit a wall if we don't get funding and and we can't do anything so I think she understands now that we could just get a small know, $1,020,000 dollar seed funding that will at least help us to get go live.

### Guest (2025-07-07T21:10:50.634Z)

Yeah. But I feel that that was good that she was worried a little to do their best to get fundings from somewhere.

### You (2025-07-07T21:10:59.316Z)

Yeah. But I I can

### Guest (2025-07-07T21:11:03.724Z)

Because I I can do. My

### You (2025-07-07T21:11:05.206Z)

find it. I don't provide it. Probably to know. The blind one.

### Guest (2025-07-07T21:11:07.734Z)

out. Pro I probably do know people. I know what I don't know anyone.

### You (2025-07-07T21:11:09.166Z)

Yeah. Thank you for funding and all.

### Guest (2025-07-07T21:11:11.414Z)

I can do funding at all.

### You (2025-07-07T21:11:11.436Z)

No. Well, between you and I, there is a little, little disagreement between Diane and and Mark. Mark doesn't think we should even ask for money. Until we have an MVP and people using the tool

### Guest (2025-07-07T21:11:32.304Z)

Uh-huh.

### You (2025-07-07T21:11:34.046Z)

Apparently, he is part of an angel investing group, and he's a and he told Diane, nobody will give you money if you don't have a a fully functioning product. And our group we would never even look at this. And and I'm like, no. That's that's not true. I mean, angel investors there are angel investors that's they all specialize in a particular type of product or a tip a particular market. And you know, I I I I told her that, you know, if Mark's group doesn't do it, that doesn't mean that there aren't a million other people out there that would. And we and we can't get to the MVP without funding. So that's when that's what how she and I got started talking about it. Is when when Mark made that comment about that. So you know, I'm I'm really kind of aligned with Diane on that, and that's why I was trying on this last call to to let Mark know that trying to explain to him, you know, the difference between the POC and the and we can't do the MVP unless we're live. And I I'm hopeful I'm trying to steer them away from drawing a line in the sand.

### Guest (2025-07-07T21:12:48.614Z)

Yeah.

### You (2025-07-07T21:12:50.866Z)

Yeah. Because I think Diane, the reason she brought him on is because of some of his connections that when we do get an MVP, he might be able to go out there, but he told Diane he was he's not even gonna talk it. Talk about it. With any of his investor friends, until we got this VP. So Yeah.

### Guest (2025-07-07T21:13:14.524Z)

And we can do MVP.

### You (2025-07-07T21:13:17.066Z)

This is what we

### Guest (2025-07-07T21:13:18.274Z)

You know, this

### You (2025-07-07T21:13:19.506Z)

can you know, that's the house.

### Guest (2025-07-07T21:13:19.854Z)

is what we need. We can do MVP in that's why I was

### You (2025-07-07T21:13:21.336Z)

Was trying to be very

### Guest (2025-07-07T21:13:23.324Z)

trying to be very clear that he and everybody is on the

### You (2025-07-07T21:13:24.936Z)

and regards to everything.

### Guest (2025-07-07T21:13:26.434Z)

line in regards to MVP. Otherwise, you know, then they'll say, oh, this is not MVP. And then add more feature, and then we'll kind of

### You (2025-07-07T21:13:31.296Z)

Yeah.

### Guest (2025-07-07T21:13:35.194Z)

just hang in there. Because it is you and me who is gonna put

### You (2025-07-07T21:13:38.516Z)

Right now.

### Guest (2025-07-07T21:13:38.714Z)

lot of hours and everything right now. Right?

### You (2025-07-07T21:13:39.636Z)

And you put some product on for lancing

### Guest (2025-07-07T21:13:44.524Z)

Mean, you could do probably some freelancing or some other work. I could do something. Yeah.

### You (2025-07-07T21:13:48.616Z)

this. If this is

### Guest (2025-07-07T21:13:50.094Z)

Other than this.

### You (2025-07-07T21:13:50.286Z)

not gonna work out. Yeah. No. This is my full time job.

### Guest (2025-07-07T21:13:51.374Z)

If this is not gonna work out. Right?

### You (2025-07-07T21:13:54.266Z)

Yeah.

### Guest (2025-07-07T21:13:54.664Z)

Yeah.

### You (2025-07-07T21:13:56.366Z)

Yeah. That that reminds me. I'm working on some workflow diagrams to try to help Mark and Diane in terms of working on that. Let me do a something as well to try to click to clarify

### Guest (2025-07-07T21:14:16.074Z)

Yeah.

### You (2025-07-07T21:14:16.306Z)

exactly what we need.

### Guest (2025-07-07T21:14:19.734Z)

Alright. And I'm nice friend. Machine learning, AI, whatever goes. They have to clearly say, you know, this is what is gonna sell.

### You (2025-07-07T21:14:26.066Z)

Like

### Guest (2025-07-07T21:14:28.314Z)

Right? We can do thousand things with machine learning AI, but

### You (2025-07-07T21:14:30.316Z)

we we

### Guest (2025-07-07T21:14:32.354Z)

we need very space picking

### You (2025-07-07T21:14:33.166Z)

initiative. Menu.

### Guest (2025-07-07T21:14:34.504Z)

at least initially,

### You (2025-07-07T21:14:35.066Z)

Print this. Six months.

### Guest (2025-07-07T21:14:35.964Z)

then, you know, if we can build this within six months,

### You (2025-07-07T21:14:36.736Z)

Then we have higher chances of getting from customers or investors we focus on the

### Guest (2025-07-07T21:14:39.074Z)

we have higher chances of getting more customers or investors we focus on that because otherwise, the

### You (2025-07-07T21:14:45.006Z)

And even on the AI side, something I mentioned to to Diane is that

### Guest (2025-07-07T21:14:45.894Z)

current things you can do.

### You (2025-07-07T21:14:51.056Z)

we have to get the core product. We have to get the valuation model. Working. Perfectly. It's it's gotta do the calculations correctly.

### Guest (2025-07-07T21:14:57.244Z)

Yeah. Alright.

### You (2025-07-07T21:14:59.386Z)

It has to be easy. So so that's why I said the MVP, really need to focus on the core. And get that done.

### Guest (2025-07-07T21:15:05.704Z)

Right.

### You (2025-07-07T21:15:07.186Z)

We can also put together a PowerPoint or show very high level road map to the client. So, you know, where will we insert AI? But I also told her at the time that and I still think we could potentially have an AI in the MVP where it would just be a simple you know, create a create an investment overview. Which if I were using chat GPT, I would just upload the the the model, show the Outlook, and and say, alright. Create a summary. And for that, you know, we could if we did if we do get some funding, we could create an account in in Claude or chat GPT use the the standard API, and

### Guest (2025-07-07T21:16:00.314Z)

Yeah.

### You (2025-07-07T21:16:00.796Z)

all you'd have is just one little chat.

### Guest (2025-07-07T21:16:03.264Z)

Yeah. Yeah.

### You (2025-07-07T21:16:04.026Z)

Note. Type it in. We can we can definitely

### Guest (2025-07-07T21:16:07.154Z)

Yeah. We can, yeah, we can definitely I mean, we can add we can definitely add very simple features like that. Their own cost was much too.

### You (2025-07-07T21:16:14.866Z)

much too. Yeah. So everyone something like that,

### Guest (2025-07-07T21:16:18.324Z)

So, I mean, if we want to do something like that, then we can definitely do that.

### You (2025-07-07T21:16:19.376Z)

make it that way too. Yeah. Yeah.

### Guest (2025-07-07T21:16:26.924Z)

Yeah. I mean, today, Mark was saying, come up with

### You (2025-07-07T21:16:27.726Z)

Come on then this feature

### Guest (2025-07-07T21:16:31.264Z)

the list of feature. I like that. You you guys tell us what sells at the market.

### You (2025-07-07T21:16:36.506Z)

that can be a direct feature to a small amount sale.

### Guest (2025-07-07T21:16:36.544Z)

We have to make list of features, then that can be any random feature which you want.

### You (2025-07-07T21:16:39.386Z)

Yeah.

### Guest (2025-07-07T21:16:40.704Z)

Won't even sell.

### You (2025-07-07T21:16:47.036Z)

Alright. So I guess the only thing that, I wanted to talk about, and you already put that list up there earlier today, is is the list of items for the budget. So I guess

### Guest (2025-07-07T21:16:59.344Z)

Yeah.

### You (2025-07-07T21:16:59.956Z)

now we've got 11 items up there.

### Guest (2025-07-07T21:17:02.034Z)

Yeah.

### You (2025-07-07T21:17:03.276Z)

I would say are those in the same order? That you think we would I mean, obviously, we need app app hosting, the database, everything else. Right from day one. But

### Guest (2025-07-07T21:17:17.764Z)

Yes.

### You (2025-07-07T21:17:19.486Z)

is there another order of things? You know, what what do we I mean, I'm sure it's not gonna be one at a time. I'm sure we probably do one, two, and three or what you know, whatever we need. Yeah. At once. Did you So let's see.

### Guest (2025-07-07T21:17:32.134Z)

It's

### You (2025-07-07T21:17:33.286Z)

Whatever these things, like, I'll load

### Guest (2025-07-07T21:17:34.324Z)

see, whatever these things, right, load balance or security,

### You (2025-07-07T21:17:35.056Z)

balance and security. These be you. From one.

### Guest (2025-07-07T21:17:41.044Z)

These won't be used from day one.

### You (2025-07-07T21:17:43.716Z)

The project sequence checked mine.

### Guest (2025-07-07T21:17:45.264Z)

Probably, she gets this check mark is

### You (2025-07-07T21:17:45.396Z)

Be. C d security scan

### Guest (2025-07-07T21:17:49.284Z)

the CICD security scanning.

### You (2025-07-07T21:17:50.586Z)

When the part of

### Guest (2025-07-07T21:17:51.944Z)

Where this is part of the

### You (2025-07-07T21:17:52.296Z)

the architecture. So we put it in, kind of use it.

### Guest (2025-07-07T21:17:55.564Z)

architecture. So when you build it,

### You (2025-07-07T21:17:56.876Z)

It just

### Guest (2025-07-07T21:17:57.564Z)

kind of use it

### You (2025-07-07T21:17:57.836Z)

it in one moment. We can also use that later stage.

### Guest (2025-07-07T21:17:59.434Z)

You just build it in one go. We can also use that later stage.

### You (2025-07-07T21:18:01.396Z)

But you can also have these features as something

### Guest (2025-07-07T21:18:03.764Z)

You can also have these features just on the

### You (2025-07-07T21:18:05.096Z)

production pipeline or just on all. Yeah. Yeah.

### Guest (2025-07-07T21:18:06.644Z)

production pipeline, not just on all. Monitoring, logging, you can just disable it

### You (2025-07-07T21:18:13.626Z)

One. Yeah. For for

### Guest (2025-07-07T21:18:15.034Z)

on the development one.

### You (2025-07-07T21:18:15.806Z)

We don't need

### Guest (2025-07-07T21:18:16.454Z)

For for now, we we don't need the staging. We can just have development and

### You (2025-07-07T21:18:18.116Z)

moment then. Production. So, again, we

### Guest (2025-07-07T21:18:21.424Z)

production.

### You (2025-07-07T21:18:21.876Z)

can

### Guest (2025-07-07T21:18:22.124Z)

So, yeah, we can kind of control the cost

### You (2025-07-07T21:18:22.136Z)

can control the cost. From that. To like that.

### Guest (2025-07-07T21:18:25.924Z)

from that.

### You (2025-07-07T21:18:26.246Z)

But and probably it's not even

### Guest (2025-07-07T21:18:27.494Z)

Like that. But

### You (2025-07-07T21:18:28.236Z)

good. Be that. I mean, the

### Guest (2025-07-07T21:18:29.254Z)

and probably it's not even

### You (2025-07-07T21:18:30.056Z)

might be much less than that.

### Guest (2025-07-07T21:18:30.974Z)

gonna be that the rate will be. It might be. Much less than that.

### You (2025-07-07T21:18:33.546Z)

Setting Yeah. Yeah. I'll speak with a piece of things.

### Guest (2025-07-07T21:18:34.884Z)

Initially. And then as the user base or things move, we'll have higher billing.

### You (2025-07-07T21:18:42.166Z)

That.

### Guest (2025-07-07T21:18:43.014Z)

But, yeah, I was not expecting that

### You (2025-07-07T21:18:43.606Z)

Cost. To which is which is good.

### Guest (2025-07-07T21:18:45.454Z)

low costing tool, which is which is good good for us.

### You (2025-07-07T21:18:46.476Z)

Us. And that's the bit of cloud right here on Apple.

### Guest (2025-07-07T21:18:49.224Z)

And that's the benefit of cloud. Right? You don't have to build anything.

### You (2025-07-07T21:18:54.006Z)

Yeah. Yeah.

### Guest (2025-07-07T21:18:55.194Z)

In house.

### You (2025-07-07T21:18:56.686Z)

Cool. Alright. I'm actually taking the list that you sent, and I'm putting the into that spreadsheet. The Investing

### Guest (2025-07-07T21:19:05.694Z)

Yeah.

### You (2025-07-07T21:19:05.956Z)

tools. Alright. So that

### Guest (2025-07-07T21:19:08.604Z)

Alright.

### You (2025-07-07T21:19:08.746Z)

you know, can just go ahead and plug in what you think is a monthly or an annual fee or estimate on something like that, you know, we can

### Guest (2025-07-07T21:19:16.984Z)

Yeah.

### You (2025-07-07T21:19:19.376Z)

talk about it later this week. On our next Yeah. I know. It's just the same number.

### Guest (2025-07-07T21:19:22.724Z)

Yeah. I would expect to

### You (2025-07-07T21:19:25.356Z)

Don't something like that.

### Guest (2025-07-07T21:19:26.134Z)

same number probably annually, 10,000, something like that.

### You (2025-07-07T21:19:26.936Z)

Yeah.

### Guest (2025-07-07T21:19:30.174Z)

Now.

### You (2025-07-07T21:19:30.356Z)

We

### Guest (2025-07-07T21:19:30.774Z)

For now, unless, you know, we go to more machine learning training and all that.

### You (2025-07-07T21:19:34.776Z)

Yeah. And and, you know, that that's a good point. We don't need to have a dollar amount assigned to all 11 of those items.

### Guest (2025-07-07T21:19:41.094Z)

Yeah.

### You (2025-07-07T21:19:42.146Z)

You know, we could just lump it together under one estimate.

### Guest (2025-07-07T21:19:45.904Z)

Yeah.

### You (2025-07-07T21:19:46.196Z)

Okay.

### Guest (2025-07-07T21:19:48.964Z)

Infrastructure, application development, and infrastructure cost.

### You (2025-07-07T21:19:49.106Z)

Infrastructure cost. Yeah. Okay. Yeah. I mean, make a read here.

### Guest (2025-07-07T21:19:53.194Z)

Yeah. And if we can really add one engineer, that'll be great. Because then I can kind of you know, we can speed up. I can and

### You (2025-07-07T21:19:59.326Z)

Kind. Work. It should work to you.

### Guest (2025-07-07T21:20:02.374Z)

hand over a lot of work, initial work to him.

### You (2025-07-07T21:20:03.066Z)

Yeah.

### Guest (2025-07-07T21:20:06.434Z)

Create node. All that. I mean, I don't I don't want to have a training because then it'll take my time.

### You (2025-07-07T21:20:12.446Z)

Yeah.

### Guest (2025-07-07T21:20:15.024Z)

I really want someone who can work but doesn't cost that much.

### You (2025-07-07T21:20:15.256Z)

Cost that much. Right. Right. So so explain to me

### Guest (2025-07-07T21:20:19.124Z)

Right?

### You (2025-07-07T21:20:19.266Z)

Yeah. When we were talking during the team meeting,

### Guest (2025-07-07T21:20:20.724Z)

Yeah.

### You (2025-07-07T21:20:24.716Z)

you made made a comment to Drew that we can't just copy and paste what I've been which which I fully understand. So what would how would we do

### Guest (2025-07-07T21:20:32.824Z)

Yeah.

### You (2025-07-07T21:20:34.496Z)

I mean, I I know you can't copy and paste the code, but I would think that you could use a lot of the code and just clean it up.

### Guest (2025-07-07T21:20:39.834Z)

Yeah.

### You (2025-07-07T21:20:41.946Z)

Or would you want to just use it as a guide and start from scratch? I mean, what are you thinking about that? So this is on GitHub. I would

### Guest (2025-07-07T21:20:50.314Z)

So this is on GitHub. Every

### You (2025-07-07T21:20:50.886Z)

Hold on. We have component. Their call. We'll get up right now. Right?

### Guest (2025-07-07T21:20:53.334Z)

all React component, they all are in GitHub right now. Right?

### You (2025-07-07T21:20:54.296Z)

Yeah. Yeah. So

### Guest (2025-07-07T21:20:56.734Z)

Yeah.

### You (2025-07-07T21:20:57.636Z)

most probably I use

### Guest (2025-07-07T21:20:59.074Z)

So most probably, I would use it as

### You (2025-07-07T21:20:59.396Z)

it. As

### Guest (2025-07-07T21:21:03.924Z)

UX guide or the logical guide.

### You (2025-07-07T21:21:04.976Z)

see

### Guest (2025-07-07T21:21:06.244Z)

And if I need to see logic somewhere,

### You (2025-07-07T21:21:06.586Z)

I'll probably pull it. I'll probably I'll put the

### Guest (2025-07-07T21:21:09.684Z)

I'll probably pull it.

### You (2025-07-07T21:21:10.556Z)

even if

### Guest (2025-07-07T21:21:11.064Z)

Probably, I can pull the logic

### You (2025-07-07T21:21:11.996Z)

don't collect.

### Guest (2025-07-07T21:21:13.334Z)

if it is written clearly in some reusable fashion.

### You (2025-07-07T21:21:16.376Z)

Yeah.

### Guest (2025-07-07T21:21:17.284Z)

I'll probably pick it up.

### You (2025-07-07T21:21:18.286Z)

So something like that. Okay. And it can

### Guest (2025-07-07T21:21:21.004Z)

Something like that. It can always be, you know, like a

### You (2025-07-07T21:21:22.926Z)

but

### Guest (2025-07-07T21:21:26.064Z)

or like a working words in which we can refer to.

### You (2025-07-07T21:21:29.396Z)

Okay.

### Guest (2025-07-07T21:21:29.534Z)

Priority, it is gonna be copy paste.

### You (2025-07-07T21:21:29.806Z)

No. That that makes sense. That makes sense.

### Guest (2025-07-07T21:21:31.974Z)

Yeah.

### You (2025-07-07T21:21:32.606Z)

Because, yes, I mean, the the the formulas are in there. Okay. They're designed designed to calculate on the fly. So

### Guest (2025-07-07T21:21:39.754Z)

Correct.

### You (2025-07-07T21:21:42.096Z)

everything is calculated on the fly.

### Guest (2025-07-07T21:21:44.664Z)

Right.

### You (2025-07-07T21:21:45.626Z)

So so, yeah, I think and then I don't like the looks of it. I don't wanna use the design

### Guest (2025-07-07T21:21:50.944Z)

Yeah.

### You (2025-07-07T21:21:53.616Z)

I think what you've got put together for the web page is way better than what this is. So, so, yeah, I mean, you can get the you can get the database schema.

### Guest (2025-07-07T21:22:02.374Z)

Yeah.

### You (2025-07-07T21:22:03.646Z)

From what's set up, then you can refer refer calculations. Everything else is pretty straightforward.

### Guest (2025-07-07T21:22:08.394Z)

Yeah. Right. Right. I mean, probably the calculations that can be done on the front end itself. Probably can be used as well. Yeah, let let's see how how that goes. But yeah. Definitely, how the application should work, how it

### You (2025-07-07T21:22:31.706Z)

Function.

### Guest (2025-07-07T21:22:32.884Z)

should function. And similar to, you know, fake static Figma, exactly designed, but at least the workflow or the function functioning part.

### You (2025-07-07T21:22:46.156Z)

Yeah. Yeah. Okay. Alright. I I I knew like you said not gonna be copy paste. It's just a no code tool not sophisticated enough, but I was hoping that you're not gonna have to start

### Guest (2025-07-07T21:22:57.694Z)

Yeah.

### You (2025-07-07T21:23:00.836Z)

from scratch and just

### Guest (2025-07-07T21:23:03.624Z)

No. It is not not gonna be completely stressed, but, yeah, it'll it'll be lot definitely lot of help because it's completely like, it's working worse, and we can

### You (2025-07-07T21:23:12.236Z)

take something.

### Guest (2025-07-07T21:23:13.574Z)

definitely

### You (2025-07-07T21:23:14.066Z)

Yeah. And then got

### Guest (2025-07-07T21:23:15.054Z)

take something, and that's

### You (2025-07-07T21:23:15.896Z)

it kind of you know don't have to organize.

### Guest (2025-07-07T21:23:17.684Z)

gonna be kind of you know, we don't have to ask

### You (2025-07-07T21:23:17.906Z)

Every time.

### Guest (2025-07-07T21:23:20.544Z)

every time, you know, how this logic should be this should work, but that should be everything is there. Just go and replicate that same logic.

### You (2025-07-07T21:23:28.196Z)

Yeah. Alright. Cool.

### Guest (2025-07-07T21:23:35.024Z)

So that yeah.

### You (2025-07-07T21:23:35.056Z)

So

### Guest (2025-07-07T21:23:37.654Z)

So, I mean, even I gave those numbers, I don't think we discussed how we're gonna

### You (2025-07-07T21:23:46.666Z)

just

### Guest (2025-07-07T21:23:47.424Z)

raise at least whatever it is. Say 700 a month.

### You (2025-07-07T21:23:50.696Z)

to call 3. Everyone say.

### Guest (2025-07-07T21:23:51.664Z)

So I don't know whether we just want to contrary contribute everyone, say,

### You (2025-07-07T21:23:56.016Z)

Right.

### Guest (2025-07-07T21:23:56.154Z)

dollar, 150. Well, at least for the initial months since you don't have anything right now. And get it started.

### You (2025-07-07T21:24:02.346Z)

Okay.

### Guest (2025-07-07T21:24:04.454Z)

Right. And we'll also have to put a card there

### You (2025-07-07T21:24:04.586Z)

So either we

### Guest (2025-07-07T21:24:07.374Z)

either we want to open our own bank account or have a card which can be

### You (2025-07-07T21:24:08.246Z)

It's gonna be.

### Guest (2025-07-07T21:24:11.574Z)

put on AWS or Azure.

### You (2025-07-07T21:24:12.316Z)

Yeah. Yeah. We're definitely gonna have to talk about that. I I don't know.

### Guest (2025-07-07T21:24:19.944Z)

And we want to have, like, 500 each.

### You (2025-07-07T21:24:20.676Z)

Find. Each. One. Time? Yeah.

### Guest (2025-07-07T21:24:24.624Z)

One time. The credit card made and then, you know, have the credit card auto pay from the account or however, you know, companies work. I know how

### You (2025-07-07T21:24:32.646Z)

Yeah.

### Guest (2025-07-07T21:24:34.534Z)

to do all.

### You (2025-07-07T21:24:34.966Z)

Yeah. We we we need to have that discussion. I think I was hoping you know, why I pushed Diane to get another call is so that we could just go through all this. So I think Thursday's call is when we need to bring it up. We need to Right. Right. I mean, yeah, we need money, but we also

### Guest (2025-07-07T21:24:53.194Z)

Right. Right.

### You (2025-07-07T21:24:54.736Z)

need to figure out how we're we're gonna pay for it. So company credit card, personal credit card reimburse. I mean, I don't know. I have no idea. That's leaving all that up to Diane. So

### Guest (2025-07-07T21:25:10.594Z)

And I think we should also make it clear that after this MVP is

### You (2025-07-07T21:25:15.876Z)

correct. Yeah.

### Guest (2025-07-07T21:25:16.964Z)

done and it's created, we are expecting

### You (2025-07-07T21:25:17.306Z)

Expecting to get some sort of because

### Guest (2025-07-07T21:25:20.824Z)

to get some sort of funding because

### You (2025-07-07T21:25:21.076Z)

we are now. For free all the time. I'm not gonna work for free.

### Guest (2025-07-07T21:25:23.634Z)

you're not gonna work for free all the time. I'm not gonna work for free.

### You (2025-07-07T21:25:24.396Z)

Yeah. For

### Guest (2025-07-07T21:25:27.014Z)

For, say, one year down the line. Right? Say, for three months, can, you know,

### You (2025-07-07T21:25:31.046Z)

it our time or how can that

### Guest (2025-07-07T21:25:33.064Z)

dedicate our time. But after that, it'll be hard for you and me or anyone. Right?

### You (2025-07-07T21:25:35.416Z)

Well, that that's her expectation. She you know, they were talking today about some of the clients that they could work. With. And she's already kind of

### Guest (2025-07-07T21:25:46.284Z)

Yeah.

### You (2025-07-07T21:25:48.266Z)

had an initial conversation with somebody where what they could do is actually hire us as a consultant to build this. And they could then basically, what they would pay us now as a consulting fee

### Guest (2025-07-07T21:26:10.634Z)

Mhmm.

### You (2025-07-07T21:26:11.906Z)

could then be applied to their first year's subscription, right, or whatever we we pay. So that would give us some funds to get going. And develop. Would we would have a client But once you've got one client, it's a lot easier to get more. Right? So we could then go out and say, you know, this is done. It's building. It works. We have x client that's using us, and know, we can go from there. So I would expect that we'll we'll get some not only some additional clients, but also if you've got a paying client, or two or three much, much easier to get additional funding. You know? So Yeah. That will then

### Guest (2025-07-07T21:26:56.534Z)

Yeah. Yeah.

### You (2025-07-07T21:26:58.886Z)

make Mark feel better. You could probably actively start

### Guest (2025-07-07T21:27:03.964Z)

Okay.

### You (2025-07-07T21:27:06.006Z)

bringing in some capital.

### Guest (2025-07-07T21:27:07.594Z)

Sounds good. And the document row is showing, like, that is easy to extract as

### You (2025-07-07T21:27:14.246Z)

That

### Guest (2025-07-07T21:27:15.814Z)

if it is that,

### You (2025-07-07T21:27:17.076Z)

and Yep.

### Guest (2025-07-07T21:27:17.354Z)

you know, it it is just summary page and

### You (2025-07-07T21:27:18.176Z)

If structured like that. I didn't see

### Guest (2025-07-07T21:27:20.714Z)

if it is structured like that, I didn't see any problem with that.

### You (2025-07-07T21:27:20.786Z)

any problem with that. Yeah. We

### Guest (2025-07-07T21:27:25.344Z)

Need to hard code really. You know, line number will be this. The you remember, like, our rental, we had so many problems because we are

### You (2025-07-07T21:27:31.166Z)

with Yeah.

### Guest (2025-07-07T21:27:32.464Z)

we had set our rules. But if it is a

### You (2025-07-07T21:27:34.516Z)

Structured document like that, it just have the exact one.

### Guest (2025-07-07T21:27:37.214Z)

structured document like that and we just have to extract one page, that'll be

### You (2025-07-07T21:27:37.836Z)

Page. Then pretty simple. Yeah. Yeah.

### Guest (2025-07-07T21:27:41.574Z)

pretty simple.

### You (2025-07-07T21:27:42.386Z)

But like I said during the call, that for that would work for the MVP. But I I don't know if if on a summary level I mean, they're

### Guest (2025-07-07T21:27:47.644Z)

Yeah.

### You (2025-07-07T21:27:51.766Z)

the will be clients who want to see their food and beverage. And miscellaneous and all of those things broken down into the details. So, like, if you go into the POC now and you go into the the property details setup, you know, that second page of the model, where you can check what you want to include

### Guest (2025-07-07T21:28:12.754Z)

Okay.

### You (2025-07-07T21:28:13.396Z)

There's three levels on there right now. So so, yeah, we can do level one. Top level summary. Really easy. But when we get down into the lower, I still think it's gonna be easy. But I still think that we do have some sample financial statements, and I started looking at those. And they don't all use identical terms. But they're close enough. You know exactly what they are.

### Guest (2025-07-07T21:28:40.194Z)

Correct.

### You (2025-07-07T21:28:40.956Z)

And so I think if we were gonna be using AI

### Guest (2025-07-07T21:28:42.414Z)

Yeah. Yeah.

### You (2025-07-07T21:28:43.376Z)

we could easily map those and and get it. So, yeah, I don't I'm not I'm not Yeah. It's just a micro

### Guest (2025-07-07T21:28:50.964Z)

Yeah. It's just a matter of time. Right?

### You (2025-07-07T21:28:52.856Z)

Yeah. Complete that

### Guest (2025-07-07T21:28:55.514Z)

Like, we need to complete and maybe three in three months.

### You (2025-07-07T21:28:56.106Z)

three months. But at the same time,

### Guest (2025-07-07T21:29:00.034Z)

At the same time, we have to do the infrastructure, lay down, you know, CICD pipe

### You (2025-07-07T21:29:01.366Z)

see if it five five.

### Guest (2025-07-07T21:29:04.974Z)

database, set up the AWS LWL Azure. So yeah. Wise, it will be telling me.

### You (2025-07-07T21:29:11.186Z)

Yep. Alright. Cool. Have you heard back from Morgan?

### Guest (2025-07-07T21:29:17.904Z)

Nothing.

### You (2025-07-07T21:29:20.106Z)

Oh, man. That sucks. Yeah. Yeah.

### Guest (2025-07-07T21:29:25.794Z)

Yeah. Safe flight. Safe flight is going

### You (2025-07-07T21:29:28.306Z)

Sit like this. This. This. Hopefully

### Guest (2025-07-07T21:29:32.474Z)

so hopefully. Yeah. I've told them I'm hang up. Know I'm not doing a conference.

### You (2025-07-07T21:29:37.696Z)

looking for.

### Guest (2025-07-07T21:29:39.694Z)

Might be looking for

### You (2025-07-07T21:29:39.866Z)

Replacement. But they haven't sent anything yet.

### Guest (2025-07-07T21:29:41.724Z)

my replacement, but

### You (2025-07-07T21:29:42.696Z)

Alright. Well, that's too bad. I

### Guest (2025-07-07T21:29:43.534Z)

they haven't said anything yet.

### You (2025-07-07T21:29:44.666Z)

it sounded very promising when you first talked about it. Yeah. Yeah.

### Guest (2025-07-07T21:29:48.594Z)

Yeah. Yeah.

### You (2025-07-07T21:29:48.906Z)

Yeah. Exactly.

### Guest (2025-07-07T21:29:51.794Z)

I don't know what they are doing. They don't have any process in place.

### You (2025-07-07T21:29:51.856Z)

Any process in place. To add a new one. Like, I

### Guest (2025-07-07T21:29:56.064Z)

To hire anyone.

### You (2025-07-07T21:29:56.126Z)

in IT. Is basically

### Guest (2025-07-07T21:29:57.344Z)

Like, anyone in IT is basically

### You (2025-07-07T21:29:58.276Z)

And then if they are I shouldn't be offered to contract.

### Guest (2025-07-07T21:30:01.094Z)

if they have to hire, it shouldn't be or do contract that makes it

### You (2025-07-07T21:30:02.236Z)

Them. Thing. It more complicated. Complicated So

### Guest (2025-07-07T21:30:05.494Z)

more complication. Complicated?

### You (2025-07-07T21:30:06.926Z)

that's certainly

### Guest (2025-07-07T21:30:08.154Z)

So, yeah, that's why, like, they need this incident test incident test.

### You (2025-07-07T21:30:08.196Z)

they said sorry. Insulin. They don't know how to make the contract.

### Guest (2025-07-07T21:30:12.854Z)

They don't know how to make the contract or anything. So

### You (2025-07-07T21:30:14.786Z)

So

### Guest (2025-07-07T21:30:16.644Z)

so was kind of lucky that time they did the h and b transfer. That is much simpler than doing contract and this and that.

### You (2025-07-07T21:30:25.406Z)

Alright. Well, fingers crossed. Yeah. But yeah. I mean

### Guest (2025-07-07T21:30:31.684Z)

Yep.

### You (2025-07-07T21:30:32.386Z)

you can't go without income. You know, I've got a I've got a plan that I'll probably execute

### Guest (2025-07-07T21:30:36.954Z)

Yeah. This

### You (2025-07-07T21:30:39.156Z)

that'll keep us afloat until we start getting money in. So I'm not I'm not sweating it

### Guest (2025-07-07T21:30:43.934Z)

Yeah.

### You (2025-07-07T21:30:46.226Z)

But yeah.

### Guest (2025-07-07T21:30:47.944Z)

Right. Right.

### You (2025-07-07T21:30:49.026Z)

Yep. Was so that

### Guest (2025-07-07T21:30:51.074Z)

Yeah. In your case, your wife works, so that makes it

### You (2025-07-07T21:30:51.406Z)

we it. Yeah. It it does. Yeah.

### Guest (2025-07-07T21:30:54.694Z)

little. That's a way. My my kid, my wife also doesn't work.

### You (2025-07-07T21:30:58.946Z)

Yeah. So

### Guest (2025-07-07T21:31:01.874Z)

So

### You (2025-07-07T21:31:02.316Z)

yeah. But hopefully, it's safe by

### Guest (2025-07-07T21:31:03.894Z)

tough. But, hopefully, safe file safe light will keep going.

### You (2025-07-07T21:31:04.836Z)

line will keep going. Full time. Being. Yeah.

### Guest (2025-07-07T21:31:09.684Z)

For the time being.

### You (2025-07-07T21:31:09.886Z)

Alright. Well, there anything else you wanted to bring up? Or

### Guest (2025-07-07T21:31:19.454Z)

No. I mean, I'll start thinking about how to

### You (2025-07-07T21:31:19.916Z)

to get started with the structure. But go on.

### Guest (2025-07-07T21:31:22.824Z)

get to start with the structure. But in next call, yeah, if you could I mean, we can both do it, but, yeah, if you can stress more on

### You (2025-07-07T21:31:29.646Z)

Face. Rolling.

### Guest (2025-07-07T21:31:30.904Z)

keeping the funding in place and probably having one more engineer, then that would be

### You (2025-07-07T21:31:35.696Z)

Okay. Yeah. I mean Yes. It's one of those things where, you know, we

### Guest (2025-07-07T21:31:36.354Z)

easier. Yeah.

### You (2025-07-07T21:31:39.496Z)

just gotta keep pounding away and every every phone call bring it up. So they can't forget it and they can't ignore it, which I I don't they aren't. They're not they're they're not.

### Guest (2025-07-07T21:31:51.994Z)

And they are not. They're running with this. Yeah.

### You (2025-07-07T21:31:55.226Z)

Alright. Cool.

### Guest (2025-07-07T21:31:55.484Z)

We have to keep Yeah.

### You (2025-07-07T21:31:57.126Z)

Yeah. Let me go ahead and

### Guest (2025-07-07T21:31:58.194Z)

Cool. Cool. Thank you, Howard.

### You (2025-07-07T21:31:58.806Z)

I'll I'll ping you when I'm done.

### Guest (2025-07-07T21:32:00.204Z)

Okay.

### You (2025-07-07T21:32:01.206Z)

In putting stuff in the spreadsheet. Your

### Guest (2025-07-07T21:32:04.924Z)

Yeah.

### You (2025-07-07T21:32:05.076Z)

your list, but Yeah. Like I said, let's not get down into the weeds for every single item. Let's just whatever Yeah. You need. Too. Okay.

### Guest (2025-07-07T21:32:13.114Z)

Yeah.

### You (2025-07-07T21:32:14.246Z)

Right. Sounds good. Sounds good.

### Guest (2025-07-07T21:32:15.174Z)

Alright. Right. Sounds good. Sounds good.

### You (2025-07-07T21:32:15.816Z)

Let me know if there's anything else I can do.

### Guest (2025-07-07T21:32:18.714Z)

Alright. Thank you.

### You (2025-07-07T21:32:19.016Z)

Sure. Thank you.

### Guest (2025-07-07T21:32:20.044Z)

Sure. We'll know. Thank you.

### You (2025-07-07T21:32:20.416Z)

See you. Bye. See you.

### Guest (2025-07-07T21:32:23.264Z)

Alright. Bye bye. See you.