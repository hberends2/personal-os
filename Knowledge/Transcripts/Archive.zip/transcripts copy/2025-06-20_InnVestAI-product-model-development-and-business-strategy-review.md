# InnVestAI product model development and business strategy review

**Date:** 2025-06-20 00:00:00 UTC
**Meeting ID:** dbe33aa2-7792-4d3b-8d93-bb60e0e583fd
**Synced:** 2026-02-05 14:46:48

---

# Transcript for: InnVestAI product model development and business strategy review

### Guest (2025-06-20T15:00:37.376Z)

Hello. Hello.

### You (2025-06-20T15:00:39.551Z)

Good morning. Hold on a second. I'm not getting any sound.

### Guest (2025-06-20T15:00:39.616Z)

Nice.

### You (2025-06-20T15:00:43.331Z)

Ah, there we go.

### Guest (2025-06-20T15:00:44.236Z)

How are you?

### You (2025-06-20T15:00:44.811Z)

Cool. How are you? Good. How are you doing?

### Guest (2025-06-20T15:00:47.386Z)

Good. Good.

### You (2025-06-20T15:00:48.341Z)

Good. Good. Good.

### Guest (2025-06-20T15:00:50.296Z)

Where are you today?

### You (2025-06-20T15:00:51.561Z)

Whether it's today or What's that?

### Guest (2025-06-20T15:00:54.186Z)

Home or

### You (2025-06-20T15:00:56.261Z)

It's looking

### Guest (2025-06-20T15:00:57.376Z)

which location are you at today?

### You (2025-06-20T15:00:59.011Z)

Alright. Yeah. I'm at I'm at my home office.

### Guest (2025-06-20T15:01:00.656Z)

Nice.

### You (2025-06-20T15:01:03.721Z)

Nice. Right down in the basement.

### Guest (2025-06-20T15:01:05.266Z)

Nice. Okay.

### You (2025-06-20T15:01:07.501Z)

So Okay. Yeah. I've actually got a couple places set up.

### Guest (2025-06-20T15:01:10.326Z)

Mhmm.

### You (2025-06-20T15:01:12.091Z)

So when it's when it's cool outside, I've I've got a

### Guest (2025-06-20T15:01:16.976Z)

Right.

### You (2025-06-20T15:01:17.921Z)

like, a bonus room that's up on the Top Floor. So being on the Top Floor, it stays pretty warm.

### Guest (2025-06-20T15:01:21.916Z)

Right.

### You (2025-06-20T15:01:24.311Z)

And that when it gets warm outside, I come down to the basement where it always stays cold. So

### Guest (2025-06-20T15:01:32.366Z)

Yeah. Basement is best for

### You (2025-06-20T15:01:32.611Z)

Yeah. The basement. Yeah. That's what Yeah. Is staying

### Guest (2025-06-20T15:01:35.906Z)

staying

### You (2025-06-20T15:01:36.791Z)

Yeah. The the the bonus room is

### Guest (2025-06-20T15:01:37.716Z)

for

### You (2025-06-20T15:01:40.321Z)

actually built over the garage, and it doesn't have gonna

### Guest (2025-06-20T15:01:43.726Z)

Okay.

### You (2025-06-20T15:01:45.061Z)

yeah. It it's got some

### Guest (2025-06-20T15:01:45.656Z)

Mhmm.

### You (2025-06-20T15:01:47.431Z)

outlets in there for the furnace and the air conditioner, but just not enough to to keep it cool. So when it gets warm, it gets pretty warm in there, it's hard to bring it down to a decent temperature. So I I I migrate south for the summer.

### Guest (2025-06-20T15:02:03.756Z)

Well,

### You (2025-06-20T15:02:04.751Z)

Well,

### Guest (2025-06-20T15:02:07.446Z)

What?

### You (2025-06-20T15:02:07.651Z)

You've been you've been at home all all week. Right? Yeah.

### Guest (2025-06-20T15:02:07.996Z)

Yeah. I just

### You (2025-06-20T15:02:11.431Z)

Yeah. I told this guy that

### Guest (2025-06-20T15:02:12.936Z)

told this guy that

### You (2025-06-20T15:02:13.731Z)

this week, I will come.

### Guest (2025-06-20T15:02:14.216Z)

this week, won't come. And

### You (2025-06-20T15:02:15.451Z)

Call him from next week, I'm gonna tell him. I'm training another company. So Yeah.

### Guest (2025-06-20T15:02:15.946Z)

probably from next week, I'm gonna tell him I'm training another company. So let's see.

### You (2025-06-20T15:02:19.911Z)

Let's see. Yeah. So so why why can't you just work remote? Do they just not like do they just not allow remote work? Or

### Guest (2025-06-20T15:02:29.516Z)

Yeah. Then I you have to come to office one.

### You (2025-06-20T15:02:30.081Z)

Yeah. Then you have to come to office one. Minimum three days a week.

### Guest (2025-06-20T15:02:33.066Z)

Minimum three days a week.

### You (2025-06-20T15:02:34.401Z)

K.

### Guest (2025-06-20T15:02:34.896Z)

Yeah.

### You (2025-06-20T15:02:35.181Z)

One of those.

### Guest (2025-06-20T15:02:37.046Z)

Yeah. Most of the companies are doing that now. So

### You (2025-06-20T15:02:38.031Z)

Yeah. Most of the companies are doing that now. So It is. Yeah. It's unfortunate that a lot of them are going

### Guest (2025-06-20T15:02:41.696Z)

yeah.

### You (2025-06-20T15:02:44.861Z)

hybrid or full time return.

### Guest (2025-06-20T15:02:46.826Z)

Okay.

### You (2025-06-20T15:02:49.241Z)

Yeah.

### Guest (2025-06-20T15:02:49.256Z)

Morgan property is, like, four days.

### You (2025-06-20T15:02:51.441Z)

Yeah.

### Guest (2025-06-20T15:02:51.956Z)

But it's close by, like, not very

### You (2025-06-20T15:02:53.701Z)

Close by, like, not been forty minutes from my house.

### Guest (2025-06-20T15:02:55.606Z)

but forty minutes from my house.

### You (2025-06-20T15:02:58.761Z)

Which is okay. Yeah. Yeah. That's not bad. Not bad at all.

### Guest (2025-06-20T15:02:59.326Z)

Which is okay. I can Yeah.

### You (2025-06-20T15:03:03.251Z)

So have you have you heard anything from them?

### Guest (2025-06-20T15:03:08.206Z)

I think, yeah. He did speak to my employer. And he passed the contract. I think now they're talking to their attorney or something to

### You (2025-06-20T15:03:19.391Z)

Like, make the panel open.

### Guest (2025-06-20T15:03:19.976Z)

like, make the final offer.

### You (2025-06-20T15:03:21.571Z)

Good. It's probably a complete

### Guest (2025-06-20T15:03:22.766Z)

Supporter could be next week anytime next week. Probably Wednesday.

### You (2025-06-20T15:03:23.841Z)

from next week and time next week. Yeah. Probably next week. Alright. Cool.

### Guest (2025-06-20T15:03:26.816Z)

Tuesday, Wednesday.

### You (2025-06-20T15:03:29.531Z)

So you're gonna try to juggle both as contract? Or

### Guest (2025-06-20T15:03:31.616Z)

No. No. There's both

### You (2025-06-20T15:03:35.691Z)

Yeah.

### Guest (2025-06-20T15:03:36.226Z)

won't work because if I can do good work, just set one and then do InvestAI and that will be

### You (2025-06-20T15:03:45.221Z)

Yeah.

### Guest (2025-06-20T15:03:46.486Z)

more than enough.

### You (2025-06-20T15:03:48.391Z)

Yeah. Definitely. Well, cool.

### Guest (2025-06-20T15:03:49.666Z)

Yeah.

### You (2025-06-20T15:03:54.381Z)

I've been super busy the last couple days.

### Guest (2025-06-20T15:03:54.906Z)

Yeah.

### You (2025-06-20T15:03:57.121Z)

Got a lot done on on the model. So I think I'm fairly well complete with the valuation revenue and expense. Finished a lot of that up yesterday. So if you if you haven't had a chance to log in and test it out, ahead and do so.

### Guest (2025-06-20T15:04:20.776Z)

Hello. Yeah.

### You (2025-06-20T15:04:21.291Z)

Definitely get your feedback on that. You may have noticed I sent out a questionnaire to Drew and Mark and

### Guest (2025-06-20T15:04:31.106Z)

Yeah.

### You (2025-06-20T15:04:32.311Z)

and Diane just to make sure that I'm using the correct calculations. Okay.

### Guest (2025-06-20T15:04:40.506Z)

Okay.

### You (2025-06-20T15:04:40.991Z)

Know, because I do sometimes get I wouldn't say, conflicting answers, but I think Mark and Drew aren't always on the same page.

### Guest (2025-06-20T15:04:50.176Z)

Okay.

### You (2025-06-20T15:04:52.291Z)

And Okay. I don't know whether there's a right answer or whether it's something that the user

### Guest (2025-06-20T15:04:57.996Z)

Mhmm.

### You (2025-06-20T15:04:59.821Z)

user should be able to choose. But one of the things I found out is that like, when they talk about budgeting expenses as a percentage of revenue, particularly on the other operated, food and beverage and all that. Not sure whether it's overall revenue or just the revenue from that department. Right? So if I have food and beverage,

### Guest (2025-06-20T15:05:26.286Z)

Mhmm.

### You (2025-06-20T15:05:30.371Z)

revenue, believe in the Howard setup now is that if you choose to budget by percentage of revenue, then it's taking it as a percentage of just the food and beverage revenue, not the total revenue. But Mark was talking the other day, and I'm just not sure Maybe I misunderstood that. It was like, budgeted off of total revenue. And that's to me, that doesn't make sense. If you're going to have I mean, to to me, those items are, like, a business within a business.

### Guest (2025-06-20T15:06:01.866Z)

Yeah.

### You (2025-06-20T15:06:04.561Z)

So if I'm gonna budget food and beverage, and if I have costs that can be just done based on a percentage of revenue, Revenue goes up, cost goes up. Revenue goes down, costs go down. It would be based on just that group. So once I get

### Guest (2025-06-20T15:06:21.636Z)

Yeah.

### You (2025-06-20T15:06:24.321Z)

responses to that survey, and I and I didn't want to do it on a phone call because I don't want to get hung up on that. I wanted to see each

### Guest (2025-06-20T15:06:29.876Z)

Okay.

### You (2025-06-20T15:06:32.841Z)

individual's responses.

### Guest (2025-06-20T15:06:33.666Z)

Alright.

### You (2025-06-20T15:06:34.881Z)

Then I can go through and make sure that everything is calculating

### Guest (2025-06-20T15:06:37.486Z)

Bye bye.

### You (2025-06-20T15:06:39.521Z)

properly.

### Guest (2025-06-20T15:06:42.476Z)

Bye.

### You (2025-06-20T15:06:42.581Z)

And I did do something yesterday, which I would be interested in your opinion. So yesterday, I added the other nonoperating expenses down at the very bottom. Include them. Right below that, you've got your total expenses, EBITDA,

### Guest (2025-06-20T15:06:58.536Z)

Mhmm.

### You (2025-06-20T15:06:59.881Z)

reserve replacement, and then not net operating income. I formatted the non operating a little bit different. So they just use two rows. You know, top row is is your forecasting. The bottom row is the total.

### Guest (2025-06-20T15:07:10.766Z)

Okay.

### You (2025-06-20T15:07:16.551Z)

But if you look up above what I had done originally, was three rows where I have a header row and then the two rows for the input. I wanna get user feedback. I don't wanna just

### Guest (2025-06-20T15:07:27.916Z)

Mhmm.

### You (2025-06-20T15:07:30.951Z)

one or the other.

### Guest (2025-06-20T15:07:32.616Z)

Right.

### You (2025-06-20T15:07:33.201Z)

You know, this is pretty long. You know? There's a lot of rows to scroll through, and there's gonna be more. So So I'm just wondering if we can just get rid of the header and just kinda use that format that I did yesterday. So that's the only other thing. That I'd need. So formulas, information, then feedback on the formatting.

### Guest (2025-06-20T15:07:53.066Z)

Mhmm. Okay.

### You (2025-06-20T15:07:55.241Z)

Today, I wanna get capital expense. Which actually is gonna be very simple. It's just all all I need to do is create a table. Where they input the capital expense and then input the dollar amount. That usually does not have anything to do with operating revenue expense. Like, you know, if I'm gonna put on a new roof, it has nothing to do with my revenue or expenses. I would get a bid for the roof. So that's gonna be a simple just a manual input. So I'm just gonna create a model for that. So you click on the capital expense, model pops open. You can input what they are. And then probably then whatever you input in the model will just be the next section down in the evaluation. Page. So Yeah. Yeah. I've added you

### Guest (2025-06-20T15:08:53.906Z)

Yeah. Yeah. I'll I'll have a look at that. I'll

### You (2025-06-20T15:08:54.901Z)

Yeah. My feedback on that. Yeah. Yeah.

### Guest (2025-06-20T15:08:56.786Z)

share my feedback on that as

### You (2025-06-20T15:08:59.651Z)

And then the only other thing is

### Guest (2025-06-20T15:09:00.206Z)

well.

### You (2025-06-20T15:09:02.351Z)

during our last call, Mark mentioned that there are six key metrics that should be visible at the top

### Guest (2025-06-20T15:09:11.826Z)

Yeah.

### You (2025-06-20T15:09:11.901Z)

Yeah. At all times. I don't think he really cared for the revenue and the or the expense, but I didn't take the revenue expense away. So there's four tabs now in that summary table. And I actually have seven rows instead of six because he added he asks for total revenue.

### Guest (2025-06-20T15:09:32.286Z)

Yes.

### You (2025-06-20T15:09:34.411Z)

Yes. He mentioned total expense, so I added total expense in. So there's another thing that we can just get feedback on. But so now we've got four different summary tabs at the top. That would remain static there. And, we'll we'll we'll see what kind of feedback we get from the users. But I think it's coming along pretty well. Yeah. It

### Guest (2025-06-20T15:09:57.586Z)

Yeah. It is. Devil.

### You (2025-06-20T15:09:58.591Z)

It's yeah. So the in terms of, like,

### Guest (2025-06-20T15:10:01.476Z)

So the future plan is,

### You (2025-06-20T15:10:02.011Z)

will you

### Guest (2025-06-20T15:10:03.726Z)

we'll use this

### You (2025-06-20T15:10:05.541Z)

alright. I

### Guest (2025-06-20T15:10:07.266Z)

baseline for the formulas as well as, you know, how

### You (2025-06-20T15:10:08.611Z)

as well as how the won't work.

### Guest (2025-06-20T15:10:11.996Z)

the navigation would work.

### You (2025-06-20T15:10:12.451Z)

Yeah. Right? Yeah.

### Guest (2025-06-20T15:10:14.206Z)

Right?

### You (2025-06-20T15:10:15.751Z)

Application.

### Guest (2025-06-20T15:10:16.036Z)

In the application.

### You (2025-06-20T15:10:16.381Z)

Yeah. I I kind of want to get in front of the clients

### Guest (2025-06-20T15:10:20.596Z)

Right.

### You (2025-06-20T15:10:20.721Z)

in baby steps. So Right. Our first meeting could be I mean, just what we have now. I think we would be

### Guest (2025-06-20T15:10:28.956Z)

Yeah.

### You (2025-06-20T15:10:29.251Z)

okay. Okay. I just wanna say, okay. I'm

### Guest (2025-06-20T15:10:31.226Z)

Alright.

### You (2025-06-20T15:10:32.951Z)

Number one, I don't I don't particularly care for the colors. When I put in the prompts, I didn't really request any specific formatting or colors.

### Guest (2025-06-20T15:10:43.606Z)

Yeah.

### You (2025-06-20T15:10:44.161Z)

It that's what it came up with. It's it's pretty bland, you know, I wanna get feedback

### Guest (2025-06-20T15:10:49.396Z)

Yeah. Think that was good.

### You (2025-06-20T15:10:50.591Z)

And that's good. Right? So what that says in different color.

### Guest (2025-06-20T15:10:51.866Z)

It looks good. Right? So forecast has a different color.

### You (2025-06-20T15:10:54.161Z)

Yeah. So that kind of differentiated. So I think

### Guest (2025-06-20T15:10:55.906Z)

So that kind of differentiated. So I think it came out well.

### You (2025-06-20T15:10:57.431Z)

Yes. It came out. Well. Yeah. No. I I it it it's okay. I'm not really consider I'm not concerned about the colors.

### Guest (2025-06-20T15:11:05.186Z)

Right.

### You (2025-06-20T15:11:05.461Z)

Of the aesthetics. And I just want them to go through and say, this make sense? And if, you know, can you click on the on the menu in the sidebar take it where you wanna go, Does it make sense to go through here? The only other thing I wanted to talk to you about is right now, it's I mean, it's real time calculation. Every time you input a digit. It recalculates. Right? Yep.

### Guest (2025-06-20T15:11:28.896Z)

Yeah.

### You (2025-06-20T15:11:29.561Z)

I love that.

### Guest (2025-06-20T15:11:30.766Z)

Yep.

### You (2025-06-20T15:11:31.151Z)

Because that's exactly what I wanna see.

### Guest (2025-06-20T15:11:31.616Z)

Yep. Yeah.

### You (2025-06-20T15:11:34.261Z)

But my question is, on a database load,

### Guest (2025-06-20T15:11:38.486Z)

Mhmm.

### You (2025-06-20T15:11:39.711Z)

at what point do you think I I I know you can't answer this right now. But Yeah. Do you think do you think we would ever reach a point

### Guest (2025-06-20T15:11:46.496Z)

No. No. We can think about you.

### You (2025-06-20T15:11:49.691Z)

where there would be a lag in the calculations the way we've got it set up. So I can give you

### Guest (2025-06-20T15:12:04.336Z)

Server.

### You (2025-06-20T15:12:05.641Z)

things simpler.

### Guest (2025-06-20T15:12:06.066Z)

It would be similar how it is working on the current one.

### You (2025-06-20T15:12:06.671Z)

How it's working on the current one. Because it is doing the calculations on the file.

### Guest (2025-06-20T15:12:10.886Z)

It is doing the calculations on the fly.

### You (2025-06-20T15:12:12.611Z)

We also do do it on the same one.

### Guest (2025-06-20T15:12:14.296Z)

Also do do it on the same way. Right?

### You (2025-06-20T15:12:15.411Z)

On

### Guest (2025-06-20T15:12:17.026Z)

Only the key numbers that

### You (2025-06-20T15:12:17.131Z)

that we have with the same in the database.

### Guest (2025-06-20T15:12:19.416Z)

we have will be saved in the database.

### You (2025-06-20T15:12:20.631Z)

Whatever calculations that would be just on the browser or in the full page itself.

### Guest (2025-06-20T15:12:22.276Z)

Whatever calculations that will be just on the browser or in the code base itself.

### You (2025-06-20T15:12:25.541Z)

Good. So I I see that would be

### Guest (2025-06-20T15:12:28.496Z)

So I I don't see there would be

### You (2025-06-20T15:12:29.441Z)

and I think it's all we can think there. We

### Guest (2025-06-20T15:12:31.516Z)

lag because we won't be getting database for these calculation at all. Right? We are not gonna save are we gonna save these calculation? I don't think we'll save. We'll just save the key numbers that they have input or we have from the historical data. Right?

### You (2025-06-20T15:12:45.121Z)

Yeah. Yeah. I think so. Yeah. Yeah. I just do not wanna get into a first pass situation.

### Guest (2025-06-20T15:12:54.406Z)

Yeah.

### You (2025-06-20T15:12:55.221Z)

Where you know, it gets to a point where it crashes and you know, I I blame that on first pass being built ten years ago, and

### Guest (2025-06-20T15:13:05.376Z)

Right.

### You (2025-06-20T15:13:06.221Z)

not built in a way to anticipate that.

### Guest (2025-06-20T15:13:08.006Z)

Right.

### You (2025-06-20T15:13:09.601Z)

But, you know, I just don't wanna get burned twice by couple years down the road. It'd unusual because they input something, and then it you know, you get the circle or thing crashes because, of of the load. Yeah. If that I just wanna keep that in the back of our mind as we go through this and make sure that we are

### Guest (2025-06-20T15:13:26.806Z)

Yeah. Yeah.

### You (2025-06-20T15:13:31.291Z)

Yeah. Is that

### Guest (2025-06-20T15:13:32.286Z)

Yeah.

### You (2025-06-20T15:13:33.111Z)

Yeah.

### Guest (2025-06-20T15:13:33.876Z)

It should be done Yeah.

### You (2025-06-20T15:13:35.211Z)

Yeah.

### Guest (2025-06-20T15:13:36.166Z)

Much the same it's done on your right now, the only thing is that preserve that state. Right?

### You (2025-06-20T15:13:45.711Z)

Like. What if the user is doing it?

### Guest (2025-06-20T15:13:47.376Z)

What if the user refreshes the window?

### You (2025-06-20T15:13:48.751Z)

Yeah. The only thing we have

### Guest (2025-06-20T15:13:50.386Z)

The only thing we have to save is the numbers they're inputting. Right?

### You (2025-06-20T15:13:50.841Z)

don't numbers they're inputting. Right? Right. So on the fly, have to save just two numbers calculations and just happen on

### Guest (2025-06-20T15:13:55.356Z)

So on the fly, we'll have to save just those numbers. Calculations will just happen

### You (2025-06-20T15:13:59.151Z)

the deposit itself. Yep. Yeah. That that's that's exactly what

### Guest (2025-06-20T15:14:00.326Z)

the project itself.

### You (2025-06-20T15:14:03.491Z)

you just whatever they've input, wanna make sure that that's retained. And get data persistence and go from there. Yep.

### Guest (2025-06-20T15:14:12.236Z)

Yep. As as far as we are able to save their input, then even their

### You (2025-06-20T15:14:12.631Z)

Thought I'd be able to save the

### Guest (2025-06-20T15:14:17.206Z)

refresh, our calculations will be based on those numbers only.

### You (2025-06-20T15:14:19.421Z)

Yeah. Yeah. Now, at some point, we wanna talk about versioning. Right? So if it's calculating on the fly, and they wanna go back,

### Guest (2025-06-20T15:14:28.236Z)

Mhmm.

### You (2025-06-20T15:14:30.611Z)

you know, how do we handle something like that? So should we we're gonna have to figure out, like, is there gonna be a mean, we probably wanna have some type of a save button or version button that says, do you want to create a new version of this? Now chances are they're not gonna just change one input.

### Guest (2025-06-20T15:14:51.476Z)

Mhmm.

### You (2025-06-20T15:14:52.631Z)

And then save it. They're probably gonna wanna go through and do a bunch of different scenarios until they get those metrics to be where they want it. Then they can save it. You know, here's version one. Here's version two. And I I would think that anything that they do after creating a version can always go back to version one. Yeah. Yep. Yeah. I think I

### Guest (2025-06-20T15:15:12.546Z)

Yep. Yep. Yeah. That makes sense.

### You (2025-06-20T15:15:13.151Z)

Yeah. So, like, they have to

### Guest (2025-06-20T15:15:14.996Z)

So we'll basically have to

### You (2025-06-20T15:15:16.261Z)

stay in those numbers separately. I think

### Guest (2025-06-20T15:15:19.386Z)

those version numbers separately whenever the user clicks on that version. We'll fetch that particular version numbers and put it in the on the browser.

### You (2025-06-20T15:15:27.411Z)

Okay. Cool. Yeah.

### Guest (2025-06-20T15:15:29.126Z)

Yeah. I mean, that's definitely a good idea.

### You (2025-06-20T15:15:29.951Z)

Alright.

### Guest (2025-06-20T15:15:31.746Z)

Yeah. And then

### You (2025-06-20T15:15:32.791Z)

Alright.

### Guest (2025-06-20T15:15:35.606Z)

from my end, I'm still kind of putting together that web application and then trying to embed the the application you have. And then the other thing I was looking into that code

### You (2025-06-20T15:15:49.711Z)

So all we want is, like,

### Guest (2025-06-20T15:15:50.336Z)

code editing. So all we want is, like,

### You (2025-06-20T15:15:51.471Z)

coming soon. Right? Yeah. And just one, like,

### Guest (2025-06-20T15:15:53.116Z)

coming soon. Right?

### You (2025-06-20T15:15:54.021Z)

page. Yeah.

### Guest (2025-06-20T15:15:54.466Z)

It's just one landing page. Let's see. I'm looking into that as well.

### You (2025-06-20T15:15:59.511Z)

I guess, you know, we probably wanna finalize the logo if we haven't talked.

### Guest (2025-06-20T15:16:03.646Z)

Yeah.

### You (2025-06-20T15:16:04.231Z)

To me. And just slap that up on the page and

### Guest (2025-06-20T15:16:06.476Z)

Sure.

### You (2025-06-20T15:16:08.331Z)

probably a little bit more than a coming soon without

### Guest (2025-06-20T15:16:11.476Z)

Mhmm.

### You (2025-06-20T15:16:12.871Z)

giving away exactly what we're doing.

### Guest (2025-06-20T15:16:15.276Z)

Mhmm.

### You (2025-06-20T15:16:16.381Z)

You know, maybe just a tagline. Coming soon. The industry is best tool for valuation or automated tool or, I mean, just something like 1 or 2¢.

### Guest (2025-06-20T15:16:30.906Z)

Hey.

### You (2025-06-20T15:16:33.981Z)

We should probably get together and figure out.

### Guest (2025-06-20T15:16:36.166Z)

Show up still.

### You (2025-06-20T15:16:36.311Z)

What. Yeah. Yeah. I just want to know up there on

### Guest (2025-06-20T15:16:40.136Z)

I can put the logo up there on the coming soon page and put some punch line.

### You (2025-06-20T15:16:40.681Z)

the coming from the airport, some funds line. Hey.

### Guest (2025-06-20T15:16:45.486Z)

We can, you know,

### You (2025-06-20T15:16:46.341Z)

Then

### Guest (2025-06-20T15:16:48.146Z)

figure out what our punch line we want to put and and before, you know, we start putting that somewhere on LinkedIn or other

### You (2025-06-20T15:16:53.641Z)

Yeah. Yeah. But I think sources. Yeah. Cool.

### Guest (2025-06-20T15:16:55.536Z)

marketing sources. Yeah.

### You (2025-06-20T15:16:59.081Z)

Yeah.

### Guest (2025-06-20T15:17:02.626Z)

I haven't made any progress on the autonomy front too, but I'll do that soon.

### You (2025-06-20T15:17:05.851Z)

Alright. Yeah. Hopefully, we can get that straightened out.

### Guest (2025-06-20T15:17:07.526Z)

Yeah.

### You (2025-06-20T15:17:10.601Z)

I did also spend some time earlier this week on pricing. Using some deep research tools to go through. And, I mean, it

### Guest (2025-06-20T15:17:18.956Z)

Yeah.

### You (2025-06-20T15:17:22.371Z)

was it really came up with some very good ideas. Including actual dollar amounts in comparison to

### Guest (2025-06-20T15:17:27.146Z)

Okay.

### You (2025-06-20T15:17:30.041Z)

other similar tools out there. Surprisingly, it comes out to be

### Guest (2025-06-20T15:17:33.976Z)

Cool.

### You (2025-06-20T15:17:35.541Z)

pretty comparable to Red IQ. So yeah. So the question is we we wanna start talking about what layers. You know, what's our core product? The the minimum they can do. And then as we build out some of these other ancillary tools, you know, how much do we think we can get for like, if a a comparable star report, if we were to be able to get all that data or some of the other things that we could possibly do. But to get our foot in the door and to get going, I thought the the pricing that it recommended is

### Guest (2025-06-20T15:17:38.846Z)

Ah, okay.

### You (2025-06-20T15:18:17.321Z)

reasonable. And decent enough for us to make money. Mean, it would be something because I'm a I'm a little concerned about funding

### Guest (2025-06-20T15:18:31.366Z)

Mhmm. Yeah.

### You (2025-06-20T15:18:33.981Z)

Yeah. And and I've had some side conversations with Diane and she's learning the same thing, you know, because she kept on talking about getting VC funding.

### Guest (2025-06-20T15:18:44.156Z)

Mhmm.

### You (2025-06-20T15:18:44.391Z)

And in the research that we both have been doing, we're finding

### Guest (2025-06-20T15:18:50.416Z)

Yeah.

### You (2025-06-20T15:18:51.351Z)

that's a lot VC take a huge percent like, 890%

### Guest (2025-06-20T15:18:59.266Z)

They're doing. That's crazy.

### You (2025-06-20T15:19:01.431Z)

Yeah. Yeah. And

### Guest (2025-06-20T15:19:03.386Z)

Yeah.

### You (2025-06-20T15:19:03.611Z)

they have the most of them will retain the ability to hire and fire So it's you know, if we go with the VC funding, we give away

### Guest (2025-06-20T15:19:15.676Z)

Yeah.

### You (2025-06-20T15:19:18.481Z)

80% of the company. And if they don't like you, then

### Guest (2025-06-20T15:19:21.916Z)

Mhmm.

### You (2025-06-20T15:19:22.131Z)

they can let you go and and decide. Not wanna get in that. And it's Yeah. If if we have to bootstrap, if we have to start

### Guest (2025-06-20T15:19:28.786Z)

Yeah.

### You (2025-06-20T15:19:31.291Z)

you know, just selling and getting some revenue and just it up, and we may have to do that. And

### Guest (2025-06-20T15:19:37.756Z)

Yeah.

### You (2025-06-20T15:19:38.401Z)

will take time. But Yeah. That

### Guest (2025-06-20T15:19:41.586Z)

Yeah. That would be the best thing we

### You (2025-06-20T15:19:42.521Z)

for me. Probably need. To find

### Guest (2025-06-20T15:19:44.826Z)

need to find some angel investor.

### You (2025-06-20T15:19:45.061Z)

some agenda

### Guest (2025-06-20T15:19:48.366Z)

And I was hoping that could be Mark. But don't know if he's interested.

### You (2025-06-20T15:19:51.511Z)

Yeah. But, yeah, I can Angela, I mean,

### Guest (2025-06-20T15:19:57.806Z)

But, yeah, I think Angela and Vester will

### You (2025-06-20T15:19:58.731Z)

definitely, I think because I don't think we can speak to anyone can

### Guest (2025-06-20T15:20:00.666Z)

definitely need because I don't think we can really, you, me, or anyone can take a lot of hours on this without getting paid for long ride.

### You (2025-06-20T15:20:09.351Z)

Yeah. Yeah. But I'm still I've been very selective as to the resumes I send out, but, man, I'm getting no response. I just saw a LinkedIn post

### Guest (2025-06-20T15:20:19.336Z)

Yeah.

### You (2025-06-20T15:20:21.631Z)

today from one of my coworkers at RealPage. He was a little higher in the organization than I was, but he worked in a completely different product. So he wasn't really a teammate. He was there, but he's been out for over a year. And

### Guest (2025-06-20T15:20:38.306Z)

Mhmm.

### You (2025-06-20T15:20:39.291Z)

not getting things. It's like, I am just, like,

### Guest (2025-06-20T15:20:41.456Z)

Yeah.

### You (2025-06-20T15:20:41.721Z)

I gotta figure out. You know? I I know that I I I kinda know that I'm

### Guest (2025-06-20T15:20:48.156Z)

Yes.

### You (2025-06-20T15:20:49.991Z)

not gonna get another product management job. And so you know, could I just consult or what am I gonna do in the meantime? And so but, I mean, we if we do sell to cottage,

### Guest (2025-06-20T15:21:00.856Z)

Yeah.

### You (2025-06-20T15:21:03.811Z)

we could survive on my wife's income.

### Guest (2025-06-20T15:21:06.416Z)

Okay.

### You (2025-06-20T15:21:07.851Z)

And we'll see what happens. There. But, yeah, I'm I don't wanna bootstrap. I would love to get some type of funding You know, maybe maybe we get an angel investor who will come in just to help us get

### Guest (2025-06-20T15:21:17.786Z)

Yeah.

### You (2025-06-20T15:21:20.661Z)

started. But

### Guest (2025-06-20T15:21:22.676Z)

Yeah.

### You (2025-06-20T15:21:23.401Z)

Yeah. I don't wanna go with a venture capitalist Yeah. It would just be

### Guest (2025-06-20T15:21:28.276Z)

Yeah. Neither me. I I don't like venture capitalists too.

### You (2025-06-20T15:21:30.661Z)

giving away.

### Guest (2025-06-20T15:21:31.796Z)

Yeah.

### You (2025-06-20T15:21:31.991Z)

Yeah. Yeah. Yeah. Sense. Yeah. Yeah.

### Guest (2025-06-20T15:21:34.376Z)

Yeah. They're, sharks, stainless take most of the thing.

### You (2025-06-20T15:21:39.131Z)

Thing is so

### Guest (2025-06-20T15:21:39.866Z)

The other thing is so yeah, I mean, sooner we get see, getting the customer is the best thing if we can sell out our product.

### You (2025-06-20T15:21:48.071Z)

that. The best.

### Guest (2025-06-20T15:21:50.116Z)

That would be

### You (2025-06-20T15:21:50.731Z)

Well

### Guest (2025-06-20T15:21:51.016Z)

the best way out.

### You (2025-06-20T15:21:52.811Z)

that's where it's

### Guest (2025-06-20T15:21:53.546Z)

And that's why I just wanted to, you know,

### You (2025-06-20T15:21:53.881Z)

what it would you know get started. Much time.

### Guest (2025-06-20T15:21:56.956Z)

get started with the website and start marketing. I don't know if

### You (2025-06-20T15:21:57.571Z)

Start marketing. I don't know. It is work on that way. Her.

### Guest (2025-06-20T15:22:01.826Z)

is gonna work out that way or Diane or Mark could use their network to sell this product.

### You (2025-06-20T15:22:06.211Z)

Yeah. Yeah. Well, Diane did mention that. I think she mentioned it team that of her contacts that Cushman and Wakefield or no. CBRE.

### Guest (2025-06-20T15:22:15.636Z)

Yeah.

### You (2025-06-20T15:22:16.261Z)

Has already committed to have the some of their analysts help evaluate So at least we've got some people there. And I think I think Berecadia's will will help too Berecadia helps one team in and they all know Diane. And that's how that's how I met Diane.

### Guest (2025-06-20T15:22:37.556Z)

Yeah.

### You (2025-06-20T15:22:38.671Z)

Awesome. So

### Guest (2025-06-20T15:22:40.436Z)

Awesome.

### You (2025-06-20T15:22:40.991Z)

yeah, I think that would be good. And I'm also thinking about reaching out to Bryce see what type of help we might get from the be engaged program. I don't know if Bercadia actually invests. Like, they could be a seed investor or angel investor. Or if they just bring these different startups in just to kinda give them a foot in the door. I don't know. But I I wanna reach out to Bryce as soon as we've got something to show. So so Berends is either gonna be a client or perhaps, you know, if we got them to be engaged and they wanna be investors, that'd be cool. Okay. So

### Guest (2025-06-20T15:23:32.896Z)

Okay.

### You (2025-06-20T15:23:33.081Z)

Yeah.

### Guest (2025-06-20T15:23:35.426Z)

Yeah. That and then the other thing we spoke about last time, if we could get some junior engineer who could help

### You (2025-06-20T15:23:40.531Z)

Yeah.

### Guest (2025-06-20T15:23:43.356Z)

expedite it, that that would be great.

### You (2025-06-20T15:23:44.711Z)

Yeah. We do need to get help in that area. So

### Guest (2025-06-20T15:23:53.576Z)

I don't know how you want to I mean, right now,

### You (2025-06-20T15:23:56.521Z)

I don't think someone else

### Guest (2025-06-20T15:23:58.106Z)

I'm I don't

### You (2025-06-20T15:23:58.511Z)

for for the evening. Someone who I'm really

### Guest (2025-06-20T15:23:59.056Z)

think someone helping us for free. We need someone who can really work. We'll at least

### You (2025-06-20T15:24:01.621Z)

Well,

### Guest (2025-06-20T15:24:05.666Z)

need something to pay. Right?

### You (2025-06-20T15:24:05.671Z)

Something to figure. Right?

### Guest (2025-06-20T15:24:09.036Z)

Gonna be just like you and me doing.

### You (2025-06-20T15:24:09.151Z)

Doing. Yeah. So I I can

### Guest (2025-06-20T15:24:14.226Z)

Yeah. I mean, I can definitely

### You (2025-06-20T15:24:15.721Z)

someone. India. For sure.

### Guest (2025-06-20T15:24:17.236Z)

find someone in India for sure. Can help us out, but we'll and that will kind of be very cost effective too. Let's say, probably

### You (2025-06-20T15:24:25.571Z)

Group of 500 or something.

### Guest (2025-06-20T15:24:26.356Z)

say, close to 500 or something.

### You (2025-06-20T15:24:27.221Z)

Per month. Which

### Guest (2025-06-20T15:24:29.266Z)

Per month.

### You (2025-06-20T15:24:29.281Z)

which would be if I burn

### Guest (2025-06-20T15:24:30.706Z)

Which which would be great. But I don't know if you wanna do that now or later.

### You (2025-06-20T15:24:38.481Z)

Well, I don't have $500 a month to spend on this.

### Guest (2025-06-20T15:24:42.546Z)

Yeah.

### You (2025-06-20T15:24:43.261Z)

So, yeah, we gotta get some type of we have to get some type of funding. You know, that. So yeah. I mean, even if it's just

### Guest (2025-06-20T15:24:51.346Z)

Today. Yeah.

### You (2025-06-20T15:24:55.091Z)

something you you hear about people getting, you know, 2,000,000 seed round. You know, it's laboring great. I but man, you know, I think even if we could get you know, half a million and do something like that I I could live with that. Right? Right? I mean, we don't have you know, a huge loan on day one to get something like that started. So so, yeah, I think that that is something that we I I know you and I talked about it, but we didn't have it chance to talk about it in our last meeting. So, yeah, let's make sure You know, like, the last couple meetings, it's been me giving a demo

### Guest (2025-06-20T15:25:37.446Z)

Yes.

### You (2025-06-20T15:25:37.621Z)

Yeah. And it's like, that's that's why I'm sending out these videos so we don't have to take our entire time. To to go through a walk through

### Guest (2025-06-20T15:25:45.146Z)

Yeah.

### You (2025-06-20T15:25:46.851Z)

talk about other business on Monday. So

### Guest (2025-06-20T15:25:46.926Z)

Okay.

### You (2025-06-20T15:25:50.831Z)

I'll I'll bring that up with Diane and just kinda give her a heads up. That we really need to spend time on subjects.

### Guest (2025-06-20T15:25:58.166Z)

Okay.

### You (2025-06-20T15:25:58.541Z)

Again, something

### Guest (2025-06-20T15:26:00.186Z)

Yeah. And I hope Mark, Diane, and Drew understand the tool you are creating right now. That's more of a

### You (2025-06-20T15:26:03.041Z)

to understand the

### Guest (2025-06-20T15:26:08.906Z)

prototype. That has to convert it into a real application. They're not

### You (2025-06-20T15:26:10.931Z)

Then I will then Okay? Confused.

### Guest (2025-06-20T15:26:13.536Z)

I hope they're not getting confused

### You (2025-06-20T15:26:15.521Z)

You know thinking that this is that we get an Excel

### Guest (2025-06-20T15:26:16.176Z)

by you know, thinking that this is the application itself. Because last time, Mark was, like, can we

### You (2025-06-20T15:26:22.731Z)

k.

### Guest (2025-06-20T15:26:25.946Z)

what was he saying? Can we copyright or can we patent the UI itself? I I don't think that's something like that is possible.

### You (2025-06-20T15:26:34.091Z)

Yeah. I I kind of ignore a lot of things when he brings his head up because we we

### Guest (2025-06-20T15:26:39.676Z)

Wait.

### You (2025-06-20T15:26:41.331Z)

we've had that conversation before about the difference between a patent and a copyright. And what you can and cannot copyright and patent. I he he's nervous getting involved with something that somebody else could copy, which I've I get it. I I understand.

### Guest (2025-06-20T15:27:01.176Z)

Yeah.

### You (2025-06-20T15:27:01.241Z)

You know? But if you take a look at what I'm doing, it's no different than 10,000 other models out there. You know? There's only there's only certain ways you can calculate revenue and expense. Right? Right. And and that's what we're doing. It's gotta be the

### Guest (2025-06-20T15:27:16.706Z)

Yeah.

### You (2025-06-20T15:27:17.661Z)

other. Items. And the date. And I he just Yes. He he just keeps bringing up patents and copyrights.

### Guest (2025-06-20T15:27:21.496Z)

Alright. Yeah. Yep.

### You (2025-06-20T15:27:24.941Z)

Yeah. Yeah. I

### Guest (2025-06-20T15:27:27.346Z)

I think differentiator in our case is

### You (2025-06-20T15:27:28.571Z)

from probably the network. Mean,

### Guest (2025-06-20T15:27:30.486Z)

the network Diane and these guys bring in. Right? That'll help us

### You (2025-06-20T15:27:31.421Z)

bring it. Right? That

### Guest (2025-06-20T15:27:35.456Z)

the product or market the product. That's probably gonna be the differentiator. And the

### You (2025-06-20T15:27:43.051Z)

Yeah.

### Guest (2025-06-20T15:27:43.096Z)

and the niche, you know, that

### You (2025-06-20T15:27:45.071Z)

Too.

### Guest (2025-06-20T15:27:45.136Z)

the absence of this tool

### You (2025-06-20T15:27:45.381Z)

Kind of we could to put this up in the market?

### Guest (2025-06-20T15:27:47.946Z)

if we could put this

### You (2025-06-20T15:27:48.741Z)

Quickly.

### Guest (2025-06-20T15:27:49.556Z)

up in the market. Quickly. Right?

### You (2025-06-20T15:27:52.761Z)

That's

### Guest (2025-06-20T15:27:53.906Z)

That's what is gonna be the differentiator.

### You (2025-06-20T15:27:55.761Z)

Yep. Yep. Getting I mean Canceling the money.

### Guest (2025-06-20T15:28:01.336Z)

Capturing the market quickly. Right?

### You (2025-06-20T15:28:01.881Z)

Quickly. Right? Yeah. I mean, first to market. All the you know, it's gives you, at least a little bit of a moat.

### Guest (2025-06-20T15:28:08.956Z)

Yeah.

### You (2025-06-20T15:28:11.151Z)

Yeah. You know, Because you can at least build up a large client base before anybody else gets involved.

### Guest (2025-06-20T15:28:19.186Z)

Okay.

### You (2025-06-20T15:28:19.571Z)

Okay. And that in and of itself, you know, you wanna if it's if it's not easy for somebody to move from us to another product, I mean, that's definitely an advantage. So Yeah.

### Guest (2025-06-20T15:28:31.606Z)

Yeah. Yeah.

### You (2025-06-20T15:28:33.351Z)

Good.

### Guest (2025-06-20T15:28:37.946Z)

Defend this guy. Somebody want to say hi?

### You (2025-06-20T15:28:41.781Z)

Morning. Oh, Love those pajamas. Yeah.

### Guest (2025-06-20T15:28:49.806Z)

Yeah. He's he's two years and one month now.

### You (2025-06-20T15:28:54.571Z)

Speaking.

### Guest (2025-06-20T15:28:55.116Z)

And he hasn't started speaking. And this time, his doctor was also showing concerns

### You (2025-06-20T15:28:58.401Z)

Concern.

### Guest (2025-06-20T15:29:01.406Z)

and now we have concern too.

### You (2025-06-20T15:29:04.061Z)

Bye.

### Guest (2025-06-20T15:29:04.106Z)

I hope we

### You (2025-06-20T15:29:05.361Z)

I Cool.

### Guest (2025-06-20T15:29:05.616Z)

does start soon.

### You (2025-06-20T15:29:07.581Z)

That's a it's a fun age.

### Guest (2025-06-20T15:29:10.286Z)

Yes.

### You (2025-06-20T15:29:11.311Z)

Yeah. Of course.

### Guest (2025-06-20T15:29:11.376Z)

That's definitely funny.

### You (2025-06-20T15:29:13.601Z)

Course. They talk about the terrible twos, but I think my kids hit the terrible twos when they were about one.

### Guest (2025-06-20T15:29:20.216Z)

Uh-huh. Right.

### You (2025-06-20T15:29:21.561Z)

Thought so. Wasn't too bad, but yeah, it's it's a good age. I love it when they're you know, kind of getting to that toddler age and

### Guest (2025-06-20T15:29:30.866Z)

Yes.

### You (2025-06-20T15:29:30.951Z)

It Yeah.

### Guest (2025-06-20T15:29:33.326Z)

Yes.

### You (2025-06-20T15:29:33.551Z)

Enjoy it while it does. Thanks.

### Guest (2025-06-20T15:29:34.156Z)

Do

### You (2025-06-20T15:29:35.811Z)

Yeah.

### Guest (2025-06-20T15:29:37.256Z)

Yeah. Do we have a meeting today? Or

### You (2025-06-20T15:29:39.461Z)

No. I think our next

### Guest (2025-06-20T15:29:40.196Z)

is it on Monday?

### You (2025-06-20T15:29:41.261Z)

yeah. Diane sent out earlier today. On Monday. Yes. So

### Guest (2025-06-20T15:29:46.826Z)

Okay. Monday. Okay. It's Monday.

### You (2025-06-20T15:29:48.591Z)

I don't think there's anything else going on today. I think this is it.

### Guest (2025-06-20T15:29:49.316Z)

Well, good.

### You (2025-06-20T15:29:53.351Z)

I Yep.

### Guest (2025-06-20T15:29:56.506Z)

I hope I'll I'll have few things done by Monday. I and go to the page and probably some other items.

### You (2025-06-20T15:30:00.191Z)

So Yeah. Alright. Well, cool. Of course. Yeah.

### Guest (2025-06-20T15:30:04.556Z)

Well, I mean yeah. If you think about any punch line or something, let me know. Otherwise, I'll put something there for

### You (2025-06-20T15:30:08.571Z)

Put something. There for sure. Okay. Yeah. I'll

### Guest (2025-06-20T15:30:12.686Z)

sure, and then we can always modify it.

### You (2025-06-20T15:30:14.861Z)

I'll see if I can come up with something that's fairly catchy, but not giving away too much. Yeah.

### Guest (2025-06-20T15:30:23.226Z)

Yeah. Yeah. And as far as logo goes, right, the new logo I had created, I am sure I put that in the

### You (2025-06-20T15:30:26.751Z)

Then Okay.

### Guest (2025-06-20T15:30:31.666Z)

folder. But if you don't find it, let me know. I'll pass it to you again. I mean, do the comparison. Let me know what you like. If like the old one, we'll stick to the old one.

### You (2025-06-20T15:30:38.881Z)

Yeah. Okay. Alright. Cool. Now we can take out

### Guest (2025-06-20T15:30:42.356Z)

We can think about something else as well.

### You (2025-06-20T15:30:47.001Z)

I'm not a designer.

### Guest (2025-06-20T15:30:47.326Z)

If you have something else in mind, we can do that.

### You (2025-06-20T15:30:48.441Z)

I just I know what I like. I know what I don't like, but I don't know. You know, don't ask me to put one together. So Yeah. I Bye bye. Bye. Aditya.

### Guest (2025-06-20T15:30:59.856Z)

I started my career with graphic designing.

### You (2025-06-20T15:31:00.241Z)

Yeah.

### Guest (2025-06-20T15:31:02.676Z)

I did. Yeah.

### You (2025-06-20T15:31:03.121Z)

Then

### Guest (2025-06-20T15:31:05.266Z)

Then lot of I I don't know whether you knew the software Adobe Photoshop, Photoshop, Adobe's Photoshop, they're gone. Tool. And there's another one called. Don't know which company was that.

### You (2025-06-20T15:31:18.511Z)

Right.

### Guest (2025-06-20T15:31:19.776Z)

And then there was Illustrator So I did work on those.

### You (2025-06-20T15:31:20.141Z)

So I think what we'll do. Cool. Tools once. Yeah. And then Right there.

### Guest (2025-06-20T15:31:25.416Z)

Tools once. And then into UI front end, and then it kinda moved on with different direction.

### You (2025-06-20T15:31:28.761Z)

Yeah. Yeah. I I took a couple of entry level courses for Figma. And that's about it. Never really other than, you know, just kinda messing around. So well, cool. That'll definitely it's definitely coming in handy.

### Guest (2025-06-20T15:31:44.106Z)

Okay.

### You (2025-06-20T15:31:44.681Z)

Yeah. Because I don't have that creative juice in me. So Yeah.

### Guest (2025-06-20T15:31:48.356Z)

No.

### You (2025-06-20T15:31:49.441Z)

Yeah.

### Guest (2025-06-20T15:31:49.876Z)

Yeah.

### You (2025-06-20T15:31:49.971Z)

Alright. Not yeah. I'm not

### Guest (2025-06-20T15:31:52.986Z)

I am now jack of all trade and master in none.

### You (2025-06-20T15:31:58.071Z)

I've seen, you're you're pretty close to that master level and what I've what I've been watching.

### Guest (2025-06-20T15:31:59.446Z)

Doing everything.

### You (2025-06-20T15:32:02.591Z)

I appreciate it. So alright. Well, is there anything else?

### Guest (2025-06-20T15:32:12.376Z)

Nothing else. Thank you, Howard. I'll I'll keep you posted on that thing if I together. Otherwise, I'll post you on the progress.

### You (2025-06-20T15:32:18.361Z)

Cool. Cool. I'll do the same. I I I do have some things to work on over the weekend. So hopefully by Monday, we'll have a much more fleshed out proof of concept. And we can start having Diane and Mark reach out and schedule some calls. Sounds good. Sounds good. Thank you. Have a great weekend. Yep.

### Guest (2025-06-20T15:32:43.506Z)

Sounds great. Sounds great. Thank you.

### You (2025-06-20T15:32:44.331Z)

Bye bye. Okay. See you.

### Guest (2025-06-20T15:32:46.036Z)

You too. Bye bye.