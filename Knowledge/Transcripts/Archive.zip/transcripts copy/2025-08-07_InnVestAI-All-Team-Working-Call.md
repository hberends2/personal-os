# InnVestAI All Team Working Call

**Date:** 2025-08-07 00:00:00 UTC
**Meeting ID:** 69a68f6f-c95b-42a9-8cc4-e96ed1417268
**Synced:** 2026-02-05 14:46:48

---

# Transcript for: InnVestAI All Team Working Call

### Guest (2025-08-07T21:30:46.600Z)

Hello? Hello? Most punctual is Diane's notetaker. And this guy who is always here. At this time. Hello.

### You (2025-08-07T21:31:00.041Z)

Hey there. Run away. Run away. How's it going?

### Guest (2025-08-07T21:31:09.400Z)

Good. How about you?

### You (2025-08-07T21:31:10.121Z)

Good.

### Guest (2025-08-07T21:31:17.080Z)

Mark. Which part of which part? We live in West. I'm sorry. Where do you live? Are you around? Restaurant. I'm in new york. Oh, you're in new york. Yes. For a few days. Are you always hard in New York? New York for five months. It goes south for the winter. Okay? With the birds. I didn't know you were in New York. I can meet you anytime, then. Yeah, I'm in new york. Actually might come to New York this weekend. Oh, yeah. We're in new york. I am coming tomorrow to New Jersey for a friend's housewarming. And then we might come around there, probably in the city. Okay? Yeah. I live in the beach in new york. But I'm going to be in New Jersey this weekend for a wedding. Okay? That'll be a new jersey, too. Yeah. I'm in south brunswick. How would I email coming through regarding some changes. I think that should be doable.

### You (2025-08-07T21:33:50.521Z)

Yeah.

### Guest (2025-08-07T21:33:52.440Z)

My twists and then there's some field in the deal creation. I believe.

### You (2025-08-07T21:34:02.121Z)

In one of our previous calls, we talked about having that save a new version. Button. Available. So that's all it is. But we're going to have to discuss. How we're going to manage that. So I place the button inside bar. I don't know. That way it's available, whatever page you're on. When you click it. It opens the property details modal and then goes to the box that's on that first page of the modal that says version name. So then they would name a version. We have to add a save button. To that modal. Otherwise it's going to take you next to the food and beverage. Than to document upload. We don't want to have all that. But what I was thinking is we don't want to save it in the deal list as a different deal. Right. We don't want to have three different deals. Of the same property in the same user because they give it three different names. Different versions. So what I was thinking is in the pipeline. Where we would just have to add another column. In the pipeline. Where it would capture all the different versions. So when they go to open the deal, They'll be prompted to select a version. Right, so they'll have all their previous history in there. But until they actually save it. As a version and give it a name. There's only going to be one deal. Every time they click it and open it. Does that make sense?

### Guest (2025-08-07T21:35:55.880Z)

So we have determining it's a duplicate base. Based on address or what? Like, how do we determine that these two, three are the same deals? Based on that address or the historical documents.

### You (2025-08-07T21:36:12.601Z)

It'll still have the same deal id. It's sustained. So if I'm working on. Aoi hotel. And I create that deal in my abm. So on my pipeline, I've got one row for Howie Hotel. Then I open up that avm and I make some changes. To it. But so I want to save it as a new version. So I click the button. Save it. Go through that. And there's still just one Howie Hotel. It's always going to have the same id, right? But in the drop down version, Box. Then when I go to open it. If I have more than one version, we're going to have to create a rule that says if more than one version exists, I would have to go to that drop down list. And choose which version I want to open, right? So you can create 10 versions of the same deal. We don't want to have a deal.

### Guest (2025-08-07T21:37:19.320Z)

In redIQ, I think, just for dog. We had something called as of date. Right. But that was mostly for. The documents, rent roll or operating statement that we would load different reports based on the user selection of adoptive right. So suppose I'm a user. I create different. Like, I upload different documents. And different, you know, times. And then. When I'm generating operating statement. Let's say then there's this as of day, wherein you could select that then your report eventually change. But there are just for the reporting purpose, not the entire day.

### You (2025-08-07T21:38:07.081Z)

Yeah. I don't know if that ever got used or not. Dude.

### Guest (2025-08-07T21:38:23.000Z)

Yeah, different versions of the team. Let's. Let me open it.

### You (2025-08-07T21:38:26.281Z)

Yeah. Okay?

### Guest (2025-08-07T21:38:28.280Z)

Little bit more.

### You (2025-08-07T21:38:31.081Z)

Is Drew going to join or not?

### Guest (2025-08-07T21:38:34.280Z)

Each of sends an email saying it's running premium is late.

### You (2025-08-07T21:38:34.761Z)

Oh, I didn't see that. Don't. In my inbox. Or email it.

### Guest (2025-08-07T21:38:39.960Z)

I won't die.

### You (2025-08-07T21:38:42.761Z)

Vinod. I'm also going through Heap and Pendo right now. They do have free versions that have some might be enough that we can just get started with it. But both of them are going to require you to add some code. Into the data so that it can access, but I don't know. On one hand, we're used to Pendo. On the other hand, Heath has some pretty neat. Some additional things that Pendo doesn't have, and I'm just wondering. If we should get together, kind of go through the website and make a decision on which one we should pursue.

### Guest (2025-08-07T21:39:34.520Z)

Every single day. Also about Pendo. I think they are closing down or something. Their company was not doing that great.

### You (2025-08-07T21:39:40.201Z)

Oh, really? I haven't heard that.

### Guest (2025-08-07T21:39:43.960Z)

Yeah. I read somewhere. I'm not very sure what I read, but it was probably downsizing or closing some level. It was not a positive.

### You (2025-08-07T21:39:52.361Z)

Okay? All right. And mark. I know. I just want to confirm you got the email. With the valuation. Model. Formulas. Right. That I asked if you can just confirm them. This morning, late this morning or early afternoon?

### Guest (2025-08-07T21:40:14.520Z)

Oh, when was that sent out? I don't remember seeing that. Let me see you send it to my intrinsic.

### You (2025-08-07T21:40:23.641Z)

Yeah.

### Guest (2025-08-07T21:40:27.480Z)

Late morning. It's been one of those days.

### You (2025-08-07T21:40:35.801Z)

Well, let me double check the email and make sure.

### Guest (2025-08-07T21:40:36.120Z)

I hope I have that. Maybe sends it to.

### You (2025-08-07T21:40:43.401Z)

I only have one email for you that I use. If I'm sending it to one. If I should be using a different one. Let's see. So.

### Guest (2025-08-07T21:41:04.440Z)

I don't see an email from you. All right. Everybody.

### You (2025-08-07T21:41:12.281Z)

No worries.

### Guest (2025-08-07T21:41:13.400Z)

No problem.

### You (2025-08-07T21:41:13.561Z)

Yeah. It was sent at 12 8. My bad. You're right. It went with the market. InnVestAI Com. All right. Let me forward it to the right email. Sorry.

### Guest (2025-08-07T21:41:29.000Z)

Okay?

### You (2025-08-07T21:41:29.401Z)

I didn't catch that one.

### Guest (2025-08-07T21:41:31.880Z)

Thank you. No problem.

### You (2025-08-07T21:41:34.201Z)

So you use is the intrinsic hotel capital, the one you use most often, okay?

### Guest (2025-08-07T21:41:40.440Z)

Yes.

### You (2025-08-07T21:41:41.321Z)

Okay? All right. I just. Just sent it, so.

### Guest (2025-08-07T21:41:46.200Z)

Thank you.

### You (2025-08-07T21:41:54.361Z)

Okay?

### Guest (2025-08-07T21:41:57.960Z)

Guys. Did I miss anything?

### You (2025-08-07T21:41:59.561Z)

Small talk mostly.

### Guest (2025-08-07T21:42:00.120Z)

Or were you? We're just warming up.

### You (2025-08-07T21:42:08.441Z)

Talking to Vinod a little bit about the email that I just sent out about the two editions to the poc. And how we're going to handle when they do multiple versions. Because we don't want to have. Multiple versions of the deal in our database. Right? So if I'm an investor and I create three different versions for three different scenarios, I don't want to say. I have three deals. In our database. Right. It's going to throw off the numbers. We have one deal. But it has multiple versions. If I create a deal. I'm looking to buy hotel Howie. In my database. I create a scenario. And then tomorrow. I open it up and I create another scenario. I save it as a different version. I still only have one hotel, Howie in our database. And that's for reporting purposes. I don't want to inflate the number of deals. That we have. So what I was suggesting is that anytime they change the version, we save it. In our database. But when I go in my pipeline or my deal list and I want to work on hotel hobby again, I'm going to click on Hotel Howie. And then, because I have more than one version, I would be prompted to say, which version do you want to open? And then I can just choose the version. Open it. Keep going. That way I could have two. I could have 20, I don't think it would matter. But when we start reporting, how many active deals do we have? Where are the deals going? That would cause a problem if we had an actually, if we get that new version of Brand New Deal id.

### Guest (2025-08-07T21:44:14.200Z)

I think there's probably the need for a separate object or attribute. Something that separates property, a location. From a deal. Right. I think is what you're saying. Right. There could be an unlimited number of deals.

### You (2025-08-07T21:44:34.361Z)

Right.

### Guest (2025-08-07T21:44:34.600Z)

Related to a location.

### You (2025-08-07T21:44:35.961Z)

Yeah. Because all of us could be writing, wanting to buy. Oh, it's Al Howie, right?

### Guest (2025-08-07T21:44:37.560Z)

Yeah, okay. Yeah. And the common. The shared data that applies to all deals would be the data we're loading in from the operators. Related to financials actuals. Right. Forecast budgets, et cetera. And then the data that is specific to each deal is going to be the input, more or less.

### You (2025-08-07T21:45:11.801Z)

Yeah. So when I set up that. Add a new deal. The deal. Properties modal. I added the box. They're called Senses ID because that's what you had mentioned. Would be kind of like the STR ID or something. Where we know that hotel, Howie is the same hotel. How are you located at one two three Main street, right? That's the only one. That Hotel Howie will have, like, one unique id. But when you go and add Hotel Howie into your deal list for underwriting purposes, You will be assigned a unique id. Right. So you've got the hotel Howie census id and then you'll have the hotel how we account property id Assign. Yeah. Deal. Right. Assigned to you. Right. Yeah.

### Guest (2025-08-07T21:46:15.720Z)

It might. Be. Useful. On that input. Property details. Modal to separate out a deal name versus a property name. I hope that. And I was something about this before and I didn't bring it up. But one of the companies that I've done business with, they always come up with some esoteric name for each deal. Right. I can't remember what it was. But they have project for project. I don't know, whatever. Project Upside Down. Because we like to keep things secret so they want to be able to talk about Project Upside down without anybody knowing what it is.

### You (2025-08-07T21:46:56.361Z)

Yeah. That's a really good point. Because that's very common in multifamily.

### Guest (2025-08-07T21:47:05.000Z)

Which hotel they're talking.

### You (2025-08-07T21:47:09.081Z)

So I might be underwriting. There's a lot of companies out there that are branding. So they always have a name like the Pillars at whatever town. The pillars. They'll use their name. Or their naming convention to underwrite a different multifamily deal. And, yeah, we had that issue. Where we were. Basically just using the street address to make sure if it was the same deal.

### Guest (2025-08-07T21:47:47.320Z)

Howard what I thought from that conversation. Is there can be multiple users. They sell or buy or lender or more types of user writing the same deal, writing different deals for the same property.

### You (2025-08-07T21:48:04.201Z)

Yeah.

### Guest (2025-08-07T21:48:06.120Z)

Right. The property is same. But different user writing different deals. So basically, how do we handle that? So property will basically have a unique id, right? So property is same. So everything everyone is doing aligns with the same property, right? Yeah. And then. Data. Whatever user is seeing on their dashboard or on their reports is based on what they upload, right?

### You (2025-08-07T21:48:43.801Z)

Yes.

### Guest (2025-08-07T21:48:46.360Z)

Well, yeah. There's going to be a comment. Yeah. Common data set that the data we get, like the actual, the historicals that we get from the operators. Regardless of where it comes from, I guess. It's possible. Think about it. If we set up, somebody sets up a new property. Like a new deal. And they start loading data from a broker. Or a seller if we have five different users. Five different companies. Looking at the same deal. They're going to all upload the same data. It might be from the same broker's data room, right? They might all download it. And upload it to us. We wouldn't necessarily already have that data uploaded. By someone, say if we have that data coming in from some standard property management system. Would it be feasible to share that data across the users? Can we preload the data? As soon as user kinds of select that property, we say we already have this data.

### You (2025-08-07T21:50:10.761Z)

Yeah.

### Guest (2025-08-07T21:50:11.000Z)

Here. Is the data preloaded for you.

### You (2025-08-07T21:50:12.281Z)

I think Mark would probably have a comment on that.

### Guest (2025-08-07T21:50:13.800Z)

So that's what we do. Yeah. That's what we do. But as I'm thinking about that, that would probably violate the confidence. That everybody has to sign when they start looking at a new deal.

### You (2025-08-07T21:50:24.041Z)

Yeah. Now, here's one way we could address that. And this is down the road when we create the marketplace. In that. Case. Well, actually, we don't even have to wait. We would do what's called deal sharing. Right. So in that case, a broker could create a deal. You'd invest and upload all the documentations, everything they need. And then they can share it. With individual investors. That way we could have the checkbox about your confidentiality agreements and everything else. And that way we could ensure that everybody is getting the same information. But a lot of times,

### Guest (2025-08-07T21:51:13.640Z)

Yeah. This goes back to sort of. This is more of a business operational. Comment, right? But the best way to get data into the system and to get scale. It's like getting the broke rs. If we got all the brokers. To, even if they weren't customers, right? That if they were loaning in the data. Because they're sort of the first line of. There's. There's the fewest of them. And everything goes through them. So if they are loading in documents. Pnls and all that. The funnel at which we can capture the most information with the fewest users. The most bang for our buck, essentially, right? There's one company that all the brokers use to organize their data rooms. I wonder if that would be a good partner to have. Yeah. What company is it? I got to find the name of a company. But virtually all the brokers use this. Yeah. Total bis. Right? If we have data from Hotel Bis, could we share that across all our YouTube? I mean. Yes, but the use at the point at which data is coming to Hotel Bis, like our hotels, were sort of the opposite. InnVestAI right. Our hotels and our customers, they're not buying and selling. Stuff that they own. They're the investor. Like their asset managing. They're renovating, so it's not like there's a bunch of people looking at it. Right. We have hundreds and hundreds of hotels, but very few users. This is sort of the other way around. You have InnVestAI might have five hotels. And 50 users. Looking at the same five hotels. Right. From an acquisition acquisitions perspective. So if somebody is feeding data and if our Sunstone customers, if they are using InnVestAI, it's not to do a transaction. It's to do an internal analysis. An internal underwriting analysis.

### You (2025-08-07T21:53:43.881Z)

Yeah.

### Guest (2025-08-07T21:53:44.440Z)

That use case would be uncommon.

### You (2025-08-07T21:53:44.921Z)

Okay?

### Guest (2025-08-07T21:53:45.720Z)

Basically. Okay? Gotcha. But I do think that. The point about getting the brokers right. If they load the data. To the system for us. Then they do it once. Or they are going to put data on a data room and 10 or 20 or 50 potential buyers are going to download it. And then upload it. Each individually. Right. So. There is a benefit to just being like, look, shit down the road. We could even pay the brokers to do it, you know what I mean? Pay the brokers to do it for us. Right. To put the data in our system.

### You (2025-08-07T21:54:30.681Z)

Yeah.

### Guest (2025-08-07T21:54:31.400Z)

That would be okay.

### You (2025-08-07T21:54:31.561Z)

Well, Drew, to your original point. Go ahead, vinod.

### Guest (2025-08-07T21:54:35.400Z)

So everybody. Is everybody is using their own data. We are not sharing. I am just thinking, like, what version are we talking about? So suppose me and you are creating a deal for the same property. We are uploading our own pnls. Our own documents. And so we'll have our dashboard or reports based on the documents that we are uploading, and we'll have our own dedicated deal based on our user group.

### You (2025-08-07T21:55:14.041Z)

Yeah. So initially, it's going to be just like Red iq. The user creates a deal. The user uploads the data that they get from the broker. Right. And to Drew's point, what I was explaining earlier would be it would have to be a broker client who has access to InnVestAI and could upload that he could create the deal.

### Guest (2025-08-07T21:55:27.720Z)

Yeah.

### You (2025-08-07T21:55:40.361Z)

Name it whatever. Upload the financials, and then he could push a button to share it. A mortal pops up and you put in the email address of whoever it is you want to share it with. But they would be. They also have to be InnVestAI users. Right. So it's just sharing it from one to the other. But I do see a use case where we could do something that would be just kind of like the deal room. That Mark was just identifying that we could do the same thing, just have brokers upload it. And then make it available to everybody. I mean, it would be a very beneficial to them. It's another way of marketing the property and getting in front of investors. Yeah.

### Guest (2025-08-07T21:56:29.960Z)

Yeah. So this idea of look at my screen. Hrec investment advisors. Hostile areas. They're selling this property. I get tons and tons and tons of these. I'm sure mark gets 10 times as many as I do. But there's a confidentiality agreement. Everybody's got to sign it. And once you sign it. And they give you access to a data room and you download the data. It's going to have pnl statements. Balance sheets. Str reports. Lots of other stuff. Right. And you do your analysis. Right. So this email probably went out. Know 100 people maybe or more, I have no idea. It could be 1000 people for all I know. And any number of them could be signing this confidentiality agreement.

### You (2025-08-07T21:57:16.921Z)

Right.

### Guest (2025-08-07T21:57:20.520Z)

And downloading the data. And then doing their underwriting. And ultimately, we want all of them.

### You (2025-08-07T21:57:26.281Z)

Yeah.

### Guest (2025-08-07T21:57:27.000Z)

To use us.

### You (2025-08-07T21:57:27.161Z)

I mean, all they would have to do is send that same email to us. We can automate it so that when we get one, we could have a dedicated email inbox. They send it to. We could upload the. We could just make this same thing available just like you're looking at now. We wouldn't have the data, but we could make that data. Available to our users.

### Guest (2025-08-07T21:57:46.440Z)

Yeah.

### You (2025-08-07T21:57:49.961Z)

They would just click on that confidentiality agreement.

### Guest (2025-08-07T21:57:56.600Z)

Yeah. We can definitely have sharing functionality like this. I wanted to go back to the discussion we were having earlier. So suppose, say, five InnVestAI users use PNLs from here. So they would basically create five different deals to analyze that property, right?

### You (2025-08-07T21:58:15.401Z)

Yeah.

### Guest (2025-08-07T21:58:18.520Z)

So nobody is sharing. I mean, even though it is same pnl. We are kind of duplicating the data for them because we are not sharing the data, right?

### You (2025-08-07T21:58:27.081Z)

Right.

### Guest (2025-08-07T21:58:31.000Z)

Yeah. Or at least there has to be the appearance that we are not sharing the data.

### You (2025-08-07T21:58:33.001Z)

Yeah.

### Guest (2025-08-07T21:58:36.120Z)

I don't know if that matters. From a technology perspective. Because if we want to use the data. If we were trying to look at all the 2024 performance of all the hotels in the system. We wouldn't want to look at duplicates of hotels based on the number of times they've been loaded, right? So there does need to be some mechanism to filter to create uniqueness at the location, the physical location level separate from the deal level. But maybe that doesn't need to be the data itself.

### You (2025-08-07T21:59:17.721Z)

That goes back to our conversation about the unique id, right? So hotel how his ideas? 1, 2, 3, 4, 5. But Drew and Vinod and Mark, their investors, all three of them want to underwrite it. So there will also be a unique ID for each of you. So that when you go into the database, You're only going to see your data assigned to your account, right? So you're going to have Hotel Howie. We're going to know that all three of you have in your database because it's the same 1, 2, 3, 4, 5, right? But mark might be 2, 3, 4, 5, 6. Drew 3.567 the node 4.5e, right? So you each have your own unique id. And then for us, When we are reporting on aggregated data, we would be looking for the Data assigned to 1, 2, 3, 4, 5, the STR or the Census ID or whatever. So yeah. It doesn't matter if we have one upload or 1000 uploads. Because we don't want to say A thousand hotel howeys for sale. It's just one hotel, Howie. Right.

### Guest (2025-08-07T22:00:35.800Z)

And we'll have one, because we'll have that unique property ID assigned to that hotel, right? And that everything kind of aligns with that.

### You (2025-08-07T22:00:42.121Z)

And that's the thing we never had in redIQ. Even though Berkadia had a database. They were doing exactly that. They were getting a database of every multifamily property in the country. Assigning it a unique id. But redIQ didn't do that. We wait to select the users, create their deals.

### Guest (2025-08-07T22:01:01.000Z)

Yeah.

### You (2025-08-07T22:01:01.001Z)

And that was it. It was something that was not thought of at the time that they created right IQ in the database.

### Guest (2025-08-07T22:01:15.960Z)

I mean, we could go and get a data list of what we go to sdr. You can buy that list. All the hotels they have expensive. But eventually that is something we probably would want to do.

### You (2025-08-07T22:01:28.521Z)

Yeah.

### Guest (2025-08-07T22:01:29.000Z)

They'll buy a list of all the hotels they have and buy it once a year. And populate our database. Just so that anytime anybody starts typing in any hotel, we at least have hotel list and the basic information can automatically calculate.

### You (2025-08-07T22:01:40.841Z)

Yeah.

### Guest (2025-08-07T22:01:45.720Z)

So that's probably cost prohibitive right now. Yeah. So RCM is the company that was referring to a lot of brokers. Basically, when they have a deal they want to market, RCM will organize all the contacts. We'll send out the confidentiality agreements to all the brokers. And we'll then build the data room for the broker. So I don't know if RCM is someone that we want to try to create one of these partnerships with, but that may be an efficient way to do this. I just clicked on the hrec. I clicked on the confidentiality agreement. And it pulled up platform and it reveres cre. Com. Is that the same thing as rcm? I don't know. Hrec is sort of. A lot of select service stuff. They're not doing the bigger full service stuff. Generally speaking. Are kind of the bigger. Yeah. But there's company. I see them all the time. The Berkadia I have one from brcadia. Rcm. They market themselves as the global marketplace for buying and selling commercial real estate.

### You (2025-08-07T22:03:38.361Z)

Yeah. I was able to find that website. I got it pulled up right now. Yeah.

### Guest (2025-08-07T22:03:45.080Z)

Yes. It's rcm1.com or cm1. Yeah. So, yeah, I'm not saying that they do it all. But they're a major player. If we could link up with them. I mean, they've got tons of data. Yeah. I wonder if how we would do that. I feel like. Mark, this is something we'll have to talk about as you start to think about our test case users, those initial companies we're going to go to. Obviously we want a diverse set of test case. We want Love and operator. A public company, a private company. But a broker I feel like is going to be like if the brokers are putting all the data for all their deals. Before they. Distribute the marketing emails. Know, they could basically do our advertising for us. I wonder if. I wonder if there's value to the brokers of knowing how all of the potential buyers are underwriting the properties they're selling right now. The brokers have no idea. How the buyers are underwriting because it's all in Excel. There's no connection. But if the broker was an InnVestAI client and they sent out an email and said, the underwriting data, all the data's in here. Do your underwriting and Invest AI if it's part of the confidentiality agreement. That all that underwriting done in InnVestAI then becomes accessible to the broker. They could get a sense of how that. Yeah.

### You (2025-08-07T22:05:50.761Z)

Yeah.

### Guest (2025-08-07T22:05:50.920Z)

Although I don't think that the buyers would want the broker to know how their underwriting it. Right. Because that's kind of their proprietary. Yeah.

### You (2025-08-07T22:05:53.561Z)

Well, we could do a summary. Here's a range of cap rates. Here's the range of this, but not identify it by user.

### Guest (2025-08-07T22:05:57.720Z)

That's fair. They're not going to want that.

### You (2025-08-07T22:06:01.481Z)

It could be one, it could be 100.

### Guest (2025-08-07T22:06:06.840Z)

I think that needs to be some kind of wall up between.

### You (2025-08-07T22:06:13.961Z)

Right.

### Guest (2025-08-07T22:06:15.080Z)

If I'm underwriting a deal, I certainly don't want other people to see my math. Or I don't want the broker to see it. Right. Because I could. But if we could find value. We could present value, something valuable to the brokers. Well, if we tell the brokers that our tool will make buyers more efficient, And we'll get them more buyers. Right. I mean, that should be enough. In theory.

### You (2025-08-07T22:06:40.681Z)

Yeah.

### Guest (2025-08-07T22:06:45.480Z)

I feel from a business perspective. From a business operations perspective. It's a compelling through line to get scale quickly. Versus any other potential customer type. Know, trying to hit up every investor. Every operator, right? There's just an endless number of those. And there's very few brokers. And they distribute a lot of information. Gather and distribute a lot of. No, it's a very good thought. But again, usually when the broker goes to market, they want a confidentiality agreement signed by every buyer. And if they're just giving us the data. Then they lose that confidentiality. They lose the control. Well, they should still, the same way that there's the confidentiality agreements that are signed. I was clicking on this link. And it takes me to a portal. Where I can read the compi and sign it. They could still do that. That's really rcm sole business, right? Like they're distributing the compiz. They're keeping track of who signed the copy. And then they give access to the data room once the copy is signed. So they're making a whole business out of that. All we want is. But we could take over the business. Right. I don't know how. Yeah, I mean, ultimately, we want to get here. If the broker is using rcm. I would imagine if the broker said 2 rcm work with InnVestAI to. Do what they. I imagine they would do it. There's probably weird to think about this more. It's probably a conversation that Mark, Diane and I later date.

### You (2025-08-07T22:08:35.081Z)

Yeah. And this kind of goes back to what I was thinking with costar is that if we partner with somebody, It's going to cost us, right? In a few years. We may have enough data so that we can start charging for it. But at the very beginning, We don't provide much value. To these companies. With a small client base and everything else. But. Their business model is easily replicated. So in other words, I'm just assuming, but let's just say with RCM. They may have a form that has to be filled out online, or maybe you just drag and drop your listing into their upload. I mean, we could probably replicate a lot of what they're doing. I know a lot of brokers are going to push back and say, well, why would I want to do it twice? Right. But then we say, well, that's where we start getting into. You've got direct access to our investors.

### Guest (2025-08-07T22:09:32.920Z)

Yeah.

### You (2025-08-07T22:09:41.881Z)

So, yeah, I think we would have to think about that. How we can do that.

### Guest (2025-08-07T22:09:48.520Z)

Well. Yeah.

### You (2025-08-07T22:09:52.041Z)

Right. Yeah. I was just looking at all the different ones.

### Guest (2025-08-07T22:09:53.400Z)

All those platforms. Are not hotel specific, right? But the brokers are also not hotel specific for the most part. I mean, some of them do more exalt than others. But for the most part, almost all of them do more than just hotels.

### You (2025-08-07T22:10:06.121Z)

Yeah.

### Guest (2025-08-07T22:10:12.200Z)

Except for maybe, like, hrec might be one of the few that really just does hotels. And so they might be an interesting target initially, right, to say, like, look, rather than using Revere or whatever it is that's popped up. Let us do that because we cater specifically to hotels, and all you do is hotels. The only negative with HREC is again that most of their hotels are kind of select service. Gearing up for more of a full service or we have more capabilities. That's fair. What are. Hodges. Hodges. Pretty good. He's still jones lang. They do. More than just hotels. Right, but they have hotel divisions. So they have their own separate. Maybe there's divisions would be big enough that they could use a dedicated. Data that they would be willing to use something like us. Instead of revere or rcm or whatever. I'm guessing our students. Not until it's specific. Right. It's all asset classes. No. I think what RCM has now is that they have a database. Of presumably thousands of buyers. They're handling all of the distribution contacts. Right. So once you sign a CA with rcm, they follow up with you. On a regular basis. It's all automated. So unless we have access to all the buyers, It's going to be hard for us to push our CM out of the way. Yeah. Let's think about this. More of it.

### You (2025-08-07T22:11:58.361Z)

So. That's a good point. Yeah. I was going to say. I've got the rcm marketplace.

### Guest (2025-08-07T22:12:04.440Z)

Is there anything from a. Is there anything else you want to talk about? From a product perspective.

### You (2025-08-07T22:12:08.201Z)

Set up there. And Mark, you could kind of triggered an idea. In that. Maybe we take an angle. To go for the rcm buyers. We could partner with our CM and we could say, well, if you want to have this available to your buyers, Where they can take this data. And use our tool to underwrite it. That might be an angle. To get in there as well.

### Guest (2025-08-07T22:12:46.600Z)

Yeah. Because, I mean, you know, I said that email the other day, that article about that brokerage firm. But as part of our process, we could start creating auctions with banks. Right. So if someone is looking to buy a deal, we could have banks upload loan quotes.

### You (2025-08-07T22:13:01.481Z)

Yeah.

### Guest (2025-08-07T22:13:05.480Z)

Into the system and start getting additional fees. As a way to share those fees with the brokerage firms or with rcm. So as a financial inducement.

### You (2025-08-07T22:13:13.401Z)

Okay?

### Guest (2025-08-07T22:13:14.840Z)

Right. Ultimately, sharing of fees seems to get people most motivated.

### You (2025-08-07T22:13:17.561Z)

Yeah. I think I'm all set. So, Drew, I mentioned to Mark if, when you have a chance to review, Is it that I sent yesterday? And Vinod and Drew, you guys, if you can also take a look at that. Account and user. Setup.

### Guest (2025-08-07T22:13:45.560Z)

Yeah. I did also start looking at the calculation. Send me. Unfortunately, I was just trying to wrestle with this Microsoft authenticator. It's not letting me into that file.

### You (2025-08-07T22:13:54.041Z)

Because I gave you access using.

### Guest (2025-08-07T22:13:54.120Z)

That was the problem that we had a couple weeks ago when I tried to download Best AI.

### You (2025-08-07T22:14:00.761Z)

I know that when I had to because I had to click a box about being an outside R.

### Guest (2025-08-07T22:14:14.280Z)

It's asking me to enter an email address. When I enter my email address, then it puts me through this authenticated process again. Maybe it needs to be added to the Azure client list. I think we had just somebody that is similar issue with me.

### You (2025-08-07T22:14:24.601Z)

Yeah, I was going to say, because you got to set up the same.

### Guest (2025-08-07T22:14:27.480Z)

And a while ago.

### You (2025-08-07T22:14:28.441Z)

I'm wondering why.

### Guest (2025-08-07T22:14:34.680Z)

Well, I guess the same prompt that I have to put in my email address, but when I type it in and I hit ok, it opened up the file.

### You (2025-08-07T22:14:39.001Z)

Okay?

### Guest (2025-08-07T22:14:40.840Z)

For me. Yeah. I haven't had such luck. I've been trying to wrestle with this for the last. Just check he's in the azure. If he's in the azure.

### You (2025-08-07T22:14:49.881Z)

Yeah. Okay?

### Guest (2025-08-07T22:14:52.200Z)

I could try.

### You (2025-08-07T22:14:52.441Z)

But yeah. Mark. In the meantime, I can just send you a hard copy of it.

### Guest (2025-08-07T22:14:53.320Z)

User list that might be part of it.

### You (2025-08-07T22:15:01.801Z)

Okay?

### Guest (2025-08-07T22:15:02.120Z)

Okay? Thank you. Oh, I think it actually just. I just was able to do it. Do you want me to look at this whole thing?

### You (2025-08-07T22:15:12.521Z)

Yeah. There's an awful lot of detail in there.

### Guest (2025-08-07T22:15:14.360Z)

I'll look at this.

### You (2025-08-07T22:15:15.481Z)

I think rather than looking at every single bullet point, if you can just kind of confirm, number one, just kind of read the formula.

### Guest (2025-08-07T22:15:16.600Z)

All right.

### You (2025-08-07T22:15:25.081Z)

That's out there. And make sure that it's accurate. And number two makes. Just want to make sure I didn't miss anything. Right. Or something that we may want to add in the future version. But I do need for our developers to make sure that they have access to the formulas and they can go ahead and create them. Yeah. Okay? All right.

### Guest (2025-08-07T22:15:51.160Z)

Now take a look. Yeah, I started to add comments. To that earlier today.

### You (2025-08-07T22:15:55.401Z)

Very good. Guys. Talk to you later.

### Guest (2025-08-07T22:15:58.920Z)

All right.

### You (2025-08-07T22:15:59.881Z)

All right. See you.

### Guest (2025-08-07T22:16:06.360Z)

Thanks, everyone. Bye. Bye.