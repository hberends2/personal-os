# LLC funding and partner compensation review with Diane

**Date:** 2025-11-13 00:00:00 UTC
**Meeting ID:** be99d5d8-9bda-466e-8ec3-e9a760e74e43
**Synced:** 2026-02-05 14:54:33

---

# Transcript for: LLC funding and partner compensation review with Diane

### Guest (2025-11-13T15:18:52.318Z)

Sorry I took a pitch at that. I don't know. I'm not making a commitment. I don't even know that we can do it at the end of the day. I hope I was clear about it, but Jim Alderman could replace Mark in a heartbeat and probably be better at it and maybe not take 20% of the company and doing it.

### You (2025-11-13T15:18:52.719Z)

What did.

### Guest (2025-11-13T15:19:12.638Z)

So forgive my boldness on that.

### You (2025-11-13T15:19:16.559Z)

No problem. So let's get caught up on somebody's emails and everything that's been going around. As I mentioned. Out. An email. About? What Vinod had suggested some items. As well as what Drew had in his email. To. Execute the llc. Right away so that you could get your money. And then go back and circle back. Mark. Would have nothing. Of that. Absolutely refuse. He's not going to sell you at all. See, until. It's. Done. So then we started. Talking about? Other alternatives, of which we may have a couple. But there are some questions. That. All of us. We're in agreement that we need to get straigh. Tened out. In order. To continue. To move forward. And. Those are some of the questions that Drew had. On there. Larc sent me an email. With because when he said, I'm not going to do this, there are points that we have to finish before that. I said, ok, what specifically? And he sent back an email with nine items. We've already. Talked about all nine at some point. But most of those still are not resolved. But we did agree that most of them could wait. That they're not items that have to be addressed. Before. Executing the llc. And there are also items that probably will change during lifetime of the LLC anyway, so might as well go ahead. And take care of that. So the questions I'm going to come down before anybody is willing to move forward. Are some of those that Drew had in the question. It's like, ok. What are the commitments? To driftwood. And the reason why that's being brought up is. In reviewing the sixth note. There is nothing in the safe note, along with your consulting agreement about monthly installments. So we need to find out. The innermost wasn't quite clear because you said something about November and December. 12,500 each. But that's only 25,000 in the 75,000 said. OK, well, then January, they're going to send us 50 grand. I mean, how is this going to work? So we need to be meaning clarification on that. And then we weren't clear on when you specified 8,500 for you, 2,000 for you. Whether that was just a one time payment or if that was going to be monthly. If it's a one time payment of 8,500 to you. And. I already told them I don't need that 2,000. I just want to be reimbursed. So 900 for me. If the $8,500 is anticipated to be a monthly, your contract is six months. That's 51,000 over 75. So in reality. That's almost like saying drifter is investing 24,000. That's. All we've got to work with. So if we can clarify those in this afternoon's meeting, Or if you. Want to send out an email with clarification. That's fine. And. Then I think once we understand. What money? We've got to work with. Do we only have $24,000 or do we have the full 75,000 minus 3, inverse of 8,500? That's. Going to have a lot to go because Vanola was talking about setting up the situation in India where we can provide benefits. And in January, that's going to go from one, I think. 200 wants to. A bit. More. For. Personnel. At least that's what we have budgeted. But it's not just developers. In India, we talk about AI people. Bringing it so we can talk about that. But. That's really, I think. The two items. That we've all. Agreed we were aligned, that we do have to have that information available. When we look at my notes here, see if I'm overlooking anything.

### Guest (2025-11-13T15:24:18.078Z)

And you don't remember or we don't have nodes because I swear we talked about the 8500 and the 2000.

### You (2025-11-13T15:24:26.239Z)

I remember, and I mentioned that in the call, but there again, we didn't know if you were accepting $8,500 a month. Or $8,500 in November.

### Guest (2025-11-13T15:24:38.878Z)

What is the ramification of what is the outcome of each one of those? Like, Jay, help me understand if it's 85k at one time or if it's 85,000amonth, which is what I thought we had agreed to, and I thought that was in Drew's budget. Can you help me understand what happens if it's one or the other?

### You (2025-11-13T15:25:05.119Z)

We did have. A long conversation in a couple months ago about. One founders can start drawing a salary. And. From my recollection, we were. All aligned that. Early investors, safe note investors and angel investors when they give you money. It's for development. It doesn't really cover that. That really? In the startup, you can't really start paying yourself until you have revenue. Coming in. And the revenue should. Be covering. It. So.

### Guest (2025-11-13T15:25:43.438Z)

And if Driftwood is okay with paying me the 8,500 per month because they're the safe node investor, does that change it? Is it that what you guys are saying is that collectively you're all making that decision because Driftwood. I've been pretty clear with Driftwood that this is a win win situation for both of us. I know you guys can't see what I can see into the company, but there will come a time. I promise you that that clarification were that illumination will be clear. But it's budget season. Right? And it's end of year, and so for me to get Carlos's time, really, until January is not. I have. I have some very quick conversations with him. Right? But he knows very well, like this was the win win solution, right? That I'm not taking all this money. It's going, you know, I'm taking the 8,500 per month, which is virtually nothing when it's all said and done on an annualized basis, right? It's not enough. For me to survive. I can't quit Kroger by doing this. That we needed to be able to pay out some money to you. We needed to be able to supplement software engineering. That's where the funds would go. He knows that. So I guess I'm just trying to, you know. We need another 3, 5, 8 safe note investors. And that may be completely different. Right? Maybe I draw nothing of that money because that's exactly what the case is. But help me understand. Like if it's 8,500 per month. What's the reaction when I've already floated this with driftwood and they're fine with it, so they're not gonna object to it. Or if it's 8500 for a one time payment. Is it really Mark and Drew pushing that they want? Their loans repaid before anything goes out the door for other people.

### You (2025-11-13T15:27:52.159Z)

In the sense of something here. Like I said, all four of us are concerned about that because it's the difference between having. 67,000 for working capital, 24,000 for working capital. $51,000 in coin, two hour salary. That only leaves 24,000. Four. Our day and day operating the things that we need. To own the business. Which means we're going to have to read another Watcher.

### Guest (2025-11-13T15:28:26.558Z)

That's the point I've been making over and over and over again. I mean, I don't know how many more times I can make that point and have it and I don't know how many more times I can make the point that at this point, I just need some collaboration. I realize it's. Not fair. Right? And I will make it up to people, but I have a mortgage to pay. I have kids to feed, and I'm not Mark Gordon right now. So I'm disappointed that you all feel that way, because I did feel like there was some sensitivity to the fact that I just needed a way to survive. Initially, I'd come up with a win win solution. You guys can't see some of the things I can see and were six weeks out from me being able to make some of those introductions and show you guys what a CIA. I mean, they're not just an angel investor like they are. Going to help. They're a lender.

### You (2025-11-13T15:28:26.639Z)

Really fast. Well.

### Guest (2025-11-13T15:29:28.958Z)

Carlos and I talked last night, he's like, our credit platform is doing incredibly well. It's the one part of our organization right now that we're nailing. So they could be a customer. Right. Like, we could sit down and do user interviews with that and come January. But, like, there's a lot of good that comes from this. It's not just, but. But if you. I mean, this is what you guys are saying. You're all for not all right with me taking eight. Eight. Okay.

### You (2025-11-13T15:29:57.519Z)

No. Just need clarification and documentation. I remember we've had conversations when we were talking about the rest. Towards where you said on the call that you were going to be working for free in exchange for 75,000. The consulting agree. Ment. States that it's $75,000. It doesn't say anything about Howard saying to be situated. So we feel kind of went from one point where every single one of us thought we were getting $75,000. For development and working on the business. With your email came out. We're very clear whether that was a one time or whatever.

### Guest (2025-11-13T15:30:58.318Z)

But let me just come back one more second. You really don't remember having. Because maybe I just need to go comb through the recordings. I felt like Drew put up a schedule and it said, Diane 8500. It said @ the time I was proposing you get the balance of it. And that's what was in Drew's schedule, so I feel like I have been as transparent about that as I possibly can be about the need about that was what was intended. I am a cost as well. Right? Like, I'm like, you don't get a call with Jim Alderman without me trying to do that. Right? You don't. Get me reaching out and trying to figure out how to resurrect benchmark. Like that takes me doing that, right? And so I like. I am adding that. You're adding value, but no, it's adding value. I'm adding value. I just need team players that. Can have a heart honestly at this point. And I know we need other safe note investors. I've been very clear about that with everyone and my disappointment and Mark that he has not done that. But we're having. I guess we're just having internal disputes about how much we're gonna try to bootstrap, which was never my intention to bootstrap the entire business, because I don't. Even if we are working with some of these customers, I'm not sure we're really. Gonna get revenue out of them. For three or six months, right? And we need 1,500 to get the node on board. 12 months allocated, two hymns. So he feels safe walking away from his job. That we have that money sitting right somehow coming in. You need money to survive. And I'm gonna push because you cannot work for free where we cannot build this on your back for free. And my frustration that Mark has done nothing and Drew has done work, but he just keeps bringing up that he can't continue the level of commitment that he's had going forward. So I'll answer the question. The intention is $8,500 per month goes to me. I am doing two days of asset management work for that. This is not a typical angel third, you know, I mean they are a customer investor advisor agreement that the relationship will help us beyond just the 75k and. That's the answer to that question, so I. But. Okay?

### You (2025-11-13T15:33:45.039Z)

Myself and new to a certain extent. I think we all agreement that we do that. But going back to the salary that was all started, Caden.

### Guest (2025-11-13T15:34:00.238Z)

It wasn't predicated on revenue, though.

### You (2025-11-13T15:34:00.639Z)

The journey.

### Guest (2025-11-13T15:34:04.318Z)

Drew had no revenue in his budget.

### You (2025-11-13T15:34:07.999Z)

And I don't think the salary started until later when we go back and take a look.

### Guest (2025-11-13T15:34:10.478Z)

No, they started. Go back. Look at it. It is in there. It's totally in there. Okay.

### You (2025-11-13T15:34:15.039Z)

Ok? All right. We need to connect the doc. We need to have documentation. Because there's a lot of concern about, well, what happens. If getting other things. To pay you guys could potentially be a regular factor for future fundraising. Innocence Not Document. Ed. If you got a video card, just go back and say look, I need to just do bent them or something to say I need to have something in learning from you trading. That take a lot of money? To be paid per lunch or salary. Break it down.

### Guest (2025-11-13T15:35:03.038Z)

And you want nothing from that. You will. I mean, so how do I handle the difference between the 8,500 and the 12,500? The 4,000? What is it? Because I feel like I've already told him. It goes to payroll, it goes to me, it goes to you, it goes to software engineers. I don't know how. Much simpler it can be than that.

### You (2025-11-13T15:35:21.439Z)

That's fine, whether I think it or not.

### Guest (2025-11-13T15:35:23.198Z)

But.

### You (2025-11-13T15:35:25.679Z)

That's between our team. They don't need to know whether I get paid the 2000 or. Whether I take my 2000 brother allocated towards this. I don't think that's going to be an issue. Then to say, I know that there can't be any pushback by marketing guru. If you haven't been writing from Driftwood saying this is how we are expecting you to. Borrow money. There's nothing they can do about it. That's fine.

### Guest (2025-11-13T15:35:58.158Z)

In an email format. And it just. I mean, because I'm not gonna get. I mean, working with their legal department. They're a big company. They're running a million miles a minute, right? So I just felt so happy to get the safe note. And it's incredibly disappointing to me that I bring what I think is great news to the table and it's met by everyone with such negativity. But you think if I get an email from Driftwood saying that we understand this is how you're using the 7. The 75K is. It's going to be 12,000 per month, used for payroll. Diane gets 8,500 of it, and the balance is used at your discretion on how you want to allocate between labor. It's labor. It's labor costs that were. Yeah, okay. I won't get that immediately because he's running like a madman, Right? Like I get 15 minutes of his time last night. At whatever it was or the night before, like at 7:00, so.

### You (2025-11-13T15:37:07.279Z)

Right.

### Guest (2025-11-13T15:37:07.838Z)

This feels like a redundant, ridiculous step to me. But if this is something you all feel strongly on, it feels like if. It feels like a mountain building a mountain out of a molehill, but.

### You (2025-11-13T15:37:21.999Z)

I'm kind of in between, yes. I fully support you 100% getting paid. I'm not pushing back on that. But I do feel that, yeah, maybe this is something that the specific terms should have been shared with everybody on the call that we should have known. And.

### Guest (2025-11-13T15:37:43.278Z)

This is where I debated. They were. I guess I just have to go back and look through all the AI recordings because we did discuss this on a call and I'm so disappointed that people don't remember it, but.

### You (2025-11-13T15:37:43.599Z)

Then. We call it. That's kind of what concerns me. None of us could recall. And I've got recordings as well. I mean, we could go back through that.

### Guest (2025-11-13T15:38:05.438Z)

Then please go back through your recordings and look at that, because I do believe, like, if you were to go back and when Drew flashed up that budget, He had no revenue. He had 8,500 for me. He had admiring Quest 4,000 for you, which took the $12,500. And that's what I had originally intended, suggested, proposed. And sadly, I don't know that Drew's been saving all those budgets. Share drive. And he only flashes them. So I don't have an email copy of it and what he saved onto the shared drive outdated. He's flashed ones that are more time relevant. Than.

### You (2025-11-13T15:38:55.759Z)

Finance. Site has been updated regularly. I'm probably pulling up now. It's just taking a minute.

### Guest (2025-11-13T15:39:08.878Z)

Mark Drew initially said they would fur their Then we got into the whole question of what salary be if they're not working full time. But I was. Okay, with the intent that if they're working full time and they can have a way to support themselves, they should get a full time salary. But it would be deferred until we have the funds and interest rate that was fair would be applied to that so that it was they were getting some sort of economic compensation for not taking it immediately.

### You (2025-11-13T15:39:45.999Z)

So we do what? The sellers are starting January. Show a negative cash balance. Of98644. And that is after the $15,000 that VaporWomen. And then he's got the $75,000 Storm Drift in this month. Now there are lines of we talk about yesterday. That. Are expensive that are also out of pocket except for and everything else. That doesn't necessarily have to be paid right away. But yeah. That's what we're coming where we're going salary. Up until January. That was the assumption. We've got some yellow highlighting above for the monthly wave. Somewhere in January, thinking that. Whether for us to pay these salaries. Or have to have another $100,000.

### Guest (2025-11-13T15:40:53.118Z)

But it includes Drew and Marx. Right. And it also.

### You (2025-11-13T15:40:53.359Z)

Or. More. Yeah.

### Guest (2025-11-13T15:41:00.318Z)

Yes. And Mark and Drew, I have said until recently, until they just got so angry about this whole driftwood thing that they would defer their salaries because they could survive financially in the interim.

### You (2025-11-13T15:41:15.199Z)

And then that does.

### Guest (2025-11-13T15:41:15.358Z)

And I was the one who could not survive financially in the interim. So if you remove their salaries right, then the math should start to work out more and.

### You (2025-11-13T15:41:18.719Z)

Right. It would be close to why it is because it's got the 12,000. It doesn't have the deferred elsewhere. No. Okay? That's something we need to add in here for salary deferments.

### Guest (2025-11-13T15:41:47.918Z)

It's in your recordings. I swear to God, if you go back and look at your recordings, I am confident you will hear Drew say he was willing to defer salary in this.

### You (2025-11-13T15:41:58.879Z)

That's under in question. That's not part of it. Thinking confusion over. The. Payment. That's why we assume the 8500 with a one time won't send payment to get someone. There because improve. Misleading. We talked about how we were doing this, basically. I remember specifically in order to get the $75,000.

### Guest (2025-11-13T15:42:30.078Z)

To get the 75k which then would help me. And I'm not taking the full 12,500, right? Which is really nothing at the end of the day too. Like I am only taking a portion of that. That is enough for me to pay my mortgage and feed my kids. That is it like that. Is all. And I am so broken hearted that this team cannot have some sympathy in that regard for me. That hurts me to the core of my being that my. But I will do it and I'm not going to get it by today. I'm not going to get an email from Driftwood saying this is the case. But that is the answer. It's 8,500 per month.

### You (2025-11-13T15:42:37.359Z)

No.

### Guest (2025-11-13T15:43:15.758Z)

For the next six months dedicated to me. And I have had conversations with them informally that if I do a good job for them, right, and I help them, then there could be another 75k at the end of this. It would be a continuous relationship. Which would then take my needs off the table. Right. Which would essentially, they would almost be covering my needs. And then we do need more safe note investors. And that has not been done to the level, has not been discussed. We have not agreed to it. We don't have a plan. And we are literally just if you want to talk about a disagreement around this small little mountain and molehill we have a much bigger disagreement on. We have not gone after any other investors. And that was never my intention. Never my intention. So.

### You (2025-11-13T15:44:11.039Z)

I agree 100% with everything the same about that. So take a look at down below where you got $8,500 a month to you. In multiple December. So that cash shortfall that I mentioned does account for that. We just need to extend that forward. To april. As part of.

### Guest (2025-11-13T15:44:40.238Z)

Then if you go back up, look at. And then look at January, it shows 8,500.

### You (2025-11-13T15:44:40.959Z)

This. If we want to keep it on the same line that we're added to keep it separate from here. Come up and get from this $8,500 profit a month. Would. Be a regular rebuttage of the. Salary.

### Guest (2025-11-13T15:45:05.198Z)

Got it.

### You (2025-11-13T15:45:05.599Z)

But we have to have something in here about. Deferment. Very well. Ok? Here's my recommendation. Tick. Et in way. Alps.

### Guest (2025-11-13T15:45:21.438Z)

I'm listening. Sorry I had to step away.

### You (2025-11-13T15:45:26.719Z)

Why everybody know? That you didn't have an agreeable, structured. But we are looking for you. It wasn't. Folks like to do a stage note in the agreement. And you're going to get something in line from Drift. Wood. Best option will be the international document.

### Guest (2025-11-13T15:45:48.718Z)

Now and become an actual document from them.

### You (2025-11-13T15:45:53.519Z)

Ary suffice, because again, I'm concerned about. Auditing or how this is going to affect the future.

### Guest (2025-11-13T15:45:58.158Z)

They don't have. Please. They're not going to audit us. This is like such a. Like the win win solution here that I have managed to come up with between them and us is. Gets. Is so getting overlooked here. But let me.

### You (2025-11-13T15:46:17.519Z)

Looked. Nobody wanting to add, but isn't it? They just have a couple of issues that. First off. Out and detailed in the same word itself should have been if there's anything other than for the government. Fund for salaries and things like that that should have been online.

### Guest (2025-11-13T15:46:45.118Z)

But Drew gave me that safe note, right? That was the safe note he told me to send to Driftwood.

### You (2025-11-13T15:46:45.679Z)

In there. Salary portion.

### Guest (2025-11-13T15:46:56.318Z)

Yes, ever. Everybody. Well, you know, we're just going round and round about it, and it's unhealth. Ok?

### You (2025-11-13T15:47:02.799Z)

Four people are saying the same thing. But this wasn't a meeting that. Nobody said that Virtual bills are $75,000. $51,000. Whether it's going to be. Salary. Nobody ever said that in the meeting at any time. And to open up something on Saturday. You intended to bring it up, and you just didn't have time to get around. I don't know. But what in that respect is one. Right. That doesn't mean it's going to hit you. And I know that most of the billboard in order for this to not really have a serious effect on trucks. And documentation from Griftwood. So again, if they were drafting document and bend them. To death. We could print an email and attach it to the document. It's ok. Well, we have to have something from saying yes of this investment. Anticipating request that this amount was fabric. There is no.

### Guest (2025-11-13T15:48:24.798Z)

So I'm going to stop arguing this because it just makes it worse. And I will get that. It will not come in an agreement. It will come in an email, and it's not going to come by tonight. And honestly, we're gonna I mean, like, they're in budget, so, I mean, I would anticipate that this comes in December at some point, once I can, like, get that into everyone's hands and we're not and so, so. But you have my commitment. I will get something from them in an email to you in the next four weeks that indicates that they're OK with this. Therefore, everyone I hope will get comfortable that that's not an audit risk.

### You (2025-11-13T15:49:09.999Z)

Need to think, though, is one this is legitimate concern. That anybody had is that the LLC specifically? Any fundraising has to be approved. By super majority. And that's where larcu I. Don't got myself get excited about these types of things. Because I move here in very beneficial for the company. They're not doing anything. You are. But. Technically, that document works fine if you've been brought up. With. The team. We wouldn't have had to have four out of five agreement. That wasn't done. I bet that whole thing was bypassed. So if we can achieve them, that will never freedom. And you've got this documentation from Griffin? And that becomes a non issue. And I will fight tooth and nail to make sure that. We agree with everybody else.

### Guest (2025-11-13T15:50:21.438Z)

Ok?

### You (2025-11-13T15:50:29.519Z)

So hopefully. That's become. Modern with a bridge lesson. Ok? We're not going to do anything. Got it? We can have and we'll go from there.

### Guest (2025-11-13T15:50:48.478Z)

Can you read what I'm just about to send you? It's called. I just emailed it to you. Yeah, let me email it again.

### You (2025-11-13T15:51:06.479Z)

Ok? I still have trouble with my laptop and demo as much as I can. Ok? I don't. Have any time for. My email to refresh. To get. All that in.

### Guest (2025-11-13T15:51:32.318Z)

Let me copy it into a team's message. It's in an email that I sent to you and Drew on 11 13.

### You (2025-11-13T15:51:43.359Z)

Looks like the last thing now I have is a forward. Thank you. But I. Don't. Ok? Ok?

### Guest (2025-11-13T15:51:55.678Z)

Of the email to you in teams.

### You (2025-11-13T15:51:57.679Z)

Ok? Times hundred for the first six months or something, I think. Ok? Yeah. For example, email. Just show your signature. But now I see it there. Ok. This is great. What? Do we reply there and just confirm this is what it is?

### Guest (2025-11-13T15:52:29.118Z)

But I sent it to Drew 2. This was to both of you, right? And I don't send. Like, we're not recording this. I don't. Because Mark is impossible to work with. And so I just. It's too important to me, right? Like, I'm in an existential financial crisis right now. And I feel like I wrote it here. Yep, I'm aligned on the 85 for the first six months. The 75k driftwood investment will come almost close. Close to covering Howard and I for six months. At the amount in the budget, I think it's just one case short a month, if we can. Work through Sherburn's 50k offer, which I'm humiliated on how we handle that. But that really sits with me at the end of the day because he's my friend. But I'm humiliated at the way Mark handled that whole thing because we could probably have him in right now and he would be working us for free on legal. That would cover the rest and leave room to pay some other costs. Just not all of them in their entirety. One note on their draw. I can't stay that long, stay that low forever. Maybe it stays that low for another few months post March, but it needs to gradually move up to 150k a range once we get additional precede investors and then 180k at Series A. And I feel like I have over and over said we need to secure 150k in almost set it aside so that the node feels comfortable walking away from his job. Because listen to me, I care about people, right? He has a family. And if he's going to go convince his wife that he's going to walk away from the income that supports their family, we need to be able to show them. OK, look. Here's 150k that we've raised and this gets allocated to you, right? Like this is your money, we're setting it aside and then. Why I keep going back down? We need the top down approach. Like how? Like. Ok, these are the costs we need. I could sometimes I could give a crap. About Drew's monthly budget because it's just like, we need to bring. We need to pay you. We need to pave an ode. We need to pay me something. Howard and Drew are not working full time on this. Right. I need a quick Kroger so that I'm not working 40 hours a. Week there. And then if I could work two weeks, two days for driftwood and five days for InnVestAI then I'm officially full time for InnVestAI right? Drew does not want to be full time for InnVestAI He hasn't even taken our email at this point and I never see Mark putting in the effort on that. We need money for Carrie, we need money for AI. I'm starting to bring up that we need money for Mike Skiba because he'd be a chief contracted chief financial officer and be hypercritical to solving our cap. Acts like strategy because he comes from Taylor Bird and he comes from Rabbit, so, like you. And Howard, he's got a multifamily background, but.

### You (2025-11-13T15:55:14.399Z)

Yeah.

### Guest (2025-11-13T15:55:38.958Z)

It's just to his dad's a hotel project manager. He's too good to let potentially go. We need maybe some money to bring and I've not brought this up with Mark and Drew because they just want to circle around and complain about driftwood versus focusing on anything in the future. But will Webster. We figure out a way to bring Will Webster on to work with Mark Woodworth and Robert Mandelbaum, and we have a shot at resurrecting Benchmarker. Right. So, like, these are the things we should be talking about as a team, and we get caught in these mountain molehill things, and I'M so that's it but does all Let me see if I can go find the same where I have been writing from Driftwood where I've explained how we're going to allocate funds and send it to you and if not, in the next four weeks I'll get something to you.

### You (2025-11-13T15:56:36.399Z)

All right. Let's try to make sure. Some stuff could be festering for a while.

### Guest (2025-11-13T15:56:45.918Z)

It's going to be festering for a while. I don't know how to make those people move faster when this is like a small thing for them, right? They have to figure they're doing a search for a head of operations right now. That's a big thing for them. 75k is in a safe node is something that is so small. Ok. All right.

### You (2025-11-13T15:57:03.999Z)

Understood? All right. So the way I see this today, I know that you and the load and myself are. Definitely aligned. And totally agree with everything that you just said. I think through market. On the other operative end. To end cross. We will follow the llc. Make sure we get a super majority for every fun little jack that comes in. But we're still convinced of it. Going to have a pretty serious battle when it comes to the salary. And. The amount of pay. And. Mark brought up. The job descriptions. I think in principle, if he was right, yeah, we do need to nail down job descriptions. But. Still equating. How much salary he goes to. The value he. Breaks and we call one day. I mentioned that. Do that. We all. Have equal equity because we all bring this to the table. But I think you would actually drop. At this point. When we stuck on. My counterpoint. And I put this in that. Data plane. Ok? Indy $500. A month. I. 'm damn near 40 hours. Every week. On. This. Let. Ting me be 500. You do? I put. In 10 to 15 hours. For 8,500, which means. Your value will go before times more than my value. Don't forget any amount of money for 1/4 to pay. And he kept saying she. Simple fact on the salary. Nobody has brought up a commission with Mark. And I did see it in. Mark's job description is. To our dollars and responsible for the world market. And that's where I said, I will push back. And unless you move. To work full time. I wouldn't do think that someone needs to start thinking about plan B. What's going to happen. If just have a Mexican standoff. On the other. And we cannot. Resolve those issues. What are we going to do? So keep that in mind. Let's. All I can tell you can't come up with an answer today.

### Guest (2025-11-13T16:00:19.438Z)

But what do we. I mean.

### You (2025-11-13T16:00:20.879Z)

But.

### Guest (2025-11-13T16:00:22.478Z)

Like, if I could have. If I could get to the end of the year, like, I'm just. I'm just talking out loud, right? I would want. And I'm sorry, I'm going to say this. I want Mark out. Like, he. He's not adding value. He's making the situation worse. I can't work with him. He does not like me and I do not respect him at this point. I respect you. I respect Benode, I respect Drew. Mark hasn't given me one tangible piece of business development or fundraising strategy.

### You (2025-11-13T16:00:41.439Z)

Yeah.

### Guest (2025-11-13T16:00:59.518Z)

Plan, right? Nothing. He always is a vasin about it when he sends something. I am so disappointed in the results. Right. He spent all this time working on the pitch deck. I get the pitch back deck. Back from right. And it looks pretty, but it leaves out 40% of what should be in a pitch deck. We have no pitch deck. We have. No. I have asked over and over again for some sort of infographic. One page that we could put in front of someone, right, and just say, this is what we are. This is what we're doing. Right? He said, absolutely. If I recall, it was like, Carrie. Like we're not approving Carrie at this point, and so let me just. So I would want the four of us to enter into an LLC agreement. If Drew's not comfortable doing that, then we take our risk. I mean, he's been incredibly valuable. I want him in this. But he is becoming. He's getting too caught up in Mark's dramatics and theatrics. And things like that. And I will say that why I want to Drew part of the team was because of his data experience. He thinks what he adds to the value is his. The fact that he's running a company right? I don't see the same value that he bring the key things he brings to the table in that regard. He's a one man shop. He has created basically a dashboarding product that has so much competition. Like I just, like we're not coming to agreement, right. He keeps giving me business advice and I'M like, okay. Not that I know this, but we need to go to someone like Jessica for business advice, right? We need to go to someone other than Mark and Drew for business advice right now. So. I'm sorry, I'm rambling. Let me just get to it. End of the year marks out. Drew can decide if he wants to stay or not. My intention is always been that this be a very fair and equitable arrangement between us. We may need to rethink the whole equal partners. Not because that I don't want that to be the case, but if it's going to hurt our fundraising, then maybe there needs to be some. Not massive, but just some sort of small adjustments around it that can get ahead of any future negative commentary from investors about the equal ownership percentage, so I don't know the answer to that. Maybe that's not the case. Is it not my like, I'm glad to have us all equal partners. But. But that might not be how we need to do this. If I have to, I will find someone who can replace Drew. And you can already see that I'm trying to figure out how to replace Mark in some capacity. I'm happy dragging the LLC agreement out if you and Vinod know that it's intentional and that this is a marriage. Right. Once we sign this agreement, it's like we're getting married. And I don't want to get divorced from Mark. I'd rather just break up with Mark before. While we're still in the dating phase, because once we sign that LLC agreement with him, I don't actually know how we get him out of this.

### You (2025-11-13T16:04:34.559Z)

Right.

### Guest (2025-11-13T16:04:35.758Z)

And I'm sorry. I tried. I tried all the way up through, I don't know, last Thursday, and then this past week, I broke on it that it's not working.

### You (2025-11-13T16:04:47.759Z)

Now. I think I broke out of before. You didn't look at conversations where I basically have said the same thing. So I don't know. How. We could even continue conversations on the existing llc. With Mark participating. If the goal is to. Not have him involved. Biding him within your. I think. I don't see any other way other than doing.

### Guest (2025-11-13T16:05:24.478Z)

Can we kick the can and just say, like, hey, look, this is budget season. It's Thanksgiving. We all knew this was going to be crunch time. We can't really have this conversation until early December, so put it on hold. Mark is not going to make any introduction calls to us with this. Outstanding. And ok, so. We? I knew that was a risk anyway. I didn't. I mean.

### You (2025-11-13T16:05:24.879Z)

It immediately.

### Guest (2025-11-13T16:05:49.118Z)

Like, I didn't think you'd make those calls and get the. Get those demos set up and in December, and then hopefully, we have a plan in December on how we replace him. Drew accepts it. He doesn't accept it. I mean, our risk to me is that they go create a competitive company. Could they do that? Like.

### You (2025-11-13T16:06:11.999Z)

I'm not worried about that. They don't have. The ability to. Do what the Bill and I have done. In any. Worth the time.

### Guest (2025-11-13T16:06:19.358Z)

That's what I think, too. And I. And I don't think Mark actually understands what we're doing either. Truly. Like so. And Drew a bit. But when Drew says. When Drew doesn't understand that word or we are a real estate proptech. Fintech company specializing in hospitality, I get a little concerned. Like you don't understand what. Business we're in either. So can.

### You (2025-11-13T16:06:44.959Z)

I'm missing. She hasn't been able to do some trouble. It's not going to be a brace. Run through this. You've got the connection here. Successful in adding conversations and getting commitments for money. And we've got other people that we've been seeking to. So let me put it this way. Nobody. Will. Be having about. Delay. Ing the llc, how it can be. I'm OK with it. I know that. You're nia. Vel work it out. Berenable is variations building up all the time. So I think you would need to have a very candid conversation with the world, or for three of us. I wouldn't mind sitting on that. And bringing him into. Update him on the situation. He was a big market. Providing any value. But he would be concerned about Drew. But in order for the node to be comfortable, And not. Continue. To push back on calls. I think we'd have to have that conversation with him before we do anything. And. Then. Reply to safety and get. A meeting on the calendar because.

### Guest (2025-11-13T16:08:02.958Z)

Yeah. Definitely.

### You (2025-11-13T16:08:06.319Z)

She's the only person I think that. I've met. Through. You that I'm due to this. Multiple times. And that's why that very first call we had with her, that's why so I just be good to have either on the team or at least in an environment role. And she's done so many startups. In proptech.

### Guest (2025-11-13T16:08:29.438Z)

That's Jessica. That's just Stacy is Western alliance bank, and so she is an interview. She's more like a customer interview to get a sense of what she would want in a ui. Plus, she was an appraiser. And I think this is really important because what Stacy tells me the bank won't lend unless they have an appraisal that pencils out. And so there is a relationship that exists between lending and appraisal that we need to think through. But yes, Jessica.

### You (2025-11-13T16:08:31.679Z)

Ok? All right. I've had him confused because I didn't have that thread that's going on for a long time. So I thought, ok, let's choose the one that we talked about then. Ok. So Jessica.

### Guest (2025-11-13T16:09:02.318Z)

We want.

### You (2025-11-13T16:09:09.599Z)

Then.

### Guest (2025-11-13T16:09:10.798Z)

To call it Jessica, that makes a lot more sense, okay?

### You (2025-11-13T16:09:13.199Z)

Maybe we just have to ask if a whole vice. And see what we can do.

### Guest (2025-11-13T16:09:19.438Z)

That makes perfect sense to me. And I can do that, yes.

### You (2025-11-13T16:09:20.799Z)

Yeah. They talk about texting and another one. I mean, Larkin's not going to go quietly. Period. So the question is, how much trouble? Could be caused, or do we need to have some type of legal action? Obviously, we don't want to find llc, so nobody can fall back on that. But like I said, my concerns is, do we have verbal agreement? If there.

### Guest (2025-11-13T16:09:45.998Z)

Verbal.

### You (2025-11-13T16:09:49.919Z)

Have a case. Of. Her boarding. Which. I'm sure. That there's probably one simple step back in January, February. Time frame where I'm assuming you may have had that, may not. If not.

### Guest (2025-11-13T16:10:09.758Z)

No, there are. Yeah.

### You (2025-11-13T16:10:11.119Z)

Good.

### Guest (2025-11-13T16:10:12.238Z)

But people change their mind all the time. Like, good Lord, I've gotten, like, fired from things, you know, and kicked out and, like. But I hear your point. I want to understand, and I don't know a way to validate that.

### You (2025-11-13T16:10:27.119Z)

Well, the only thing I'm thinking, worst case scenario. At this point, all we have is E. In for index AI. We don't talk to llc. And for. Basically just say, ok, we're not moving forward within best AI. In FBI is dead. Then we need to start all over again within fai. And maybe change someone or add something to the end of the fight, it's a different entity altogether. With the new ein. I think that might just be word the cut off. Point.

### Guest (2025-11-13T16:11:25.758Z)

Okay?

### You (2025-11-13T16:11:26.319Z)

Never did anything on here. I'll do that with the llc. And because of that, like I said, technically, the IP was that because that's one of the reasons.

### Guest (2025-11-13T16:11:40.878Z)

I don't even have any claim to that. Because you guys did all that work, right? The only thing I have claimed to is that I was the one who actually physically did the paperwork on the llc. And just to get it done, I just used myself, because we didn't have an LLC agreement.

### You (2025-11-13T16:11:59.279Z)

Valid point that because there are no more signatures on that with both ours that's claimed to that and maybe we don't have to dissolve. But the regular question.

### Guest (2025-11-13T16:12:10.798Z)

I think I'm the only one who has. But, yes, these are questions we have to ask, and we have to go about like, what would Mark's legal, you know, and then what would his. Because there's going to be trashing of us verbally in the industry. And I really believe we can just. Get around that by saying people know Mark's temperament and just saying that, like, the. The culture that, you know, the working styles were not, you know, working out. And we had to. And it's true, like, we marry Mark and, like.

### You (2025-11-13T16:12:45.599Z)

And I did do some research in that. I think bringing llc is done. In the number nine, which actually would be a document where we just simply assign the IP to InnVestAI. There will be no reason for us to keep it between the two of us. We don't have a company with just two individuals. Talking to you, making sure everything's documented and cleaned. I think there are going to be ways that we could do this. But yeah. I think we need to talk to an attorney. And just say what? Repercussions. Could. Be way from there. And we need to start over with a new Ein. Or can we continue? With an sai. Since we don't have a kind llc.

### Guest (2025-11-13T16:13:43.278Z)

I just don't want to lose the name. Like the name is a good name.

### You (2025-11-13T16:13:47.519Z)

We. Got the website and remember. That. That's what I'm saying. Even if we would InnVestAI. Whatever.

### Guest (2025-11-13T16:13:58.158Z)

LLC or something like that. I mean, right?

### You (2025-11-13T16:14:00.719Z)

On the papers from the real papers. We were packing that in our emails, on our website. There's always going to be a bus. And mark. Would. Have no claim at all. To the. Name.

### Guest (2025-11-13T16:14:21.118Z)

And again, I hope Drew stays. Like, I. You guys. You know that, right? Like, I don't want Drew to leave. I just, like, think this is getting a little crazy about. Like, I just think he's being too negatively influenced.

### You (2025-11-13T16:14:35.519Z)

At the end of the day, do some new business. I think he's going to realize that walking away from it is. Going to be detrimental for your existence.

### Guest (2025-11-13T16:14:49.038Z)

He has good stuff going on is business, though. He could. Like, he's got this whole pilot with profit stored, right? And. But, like, we do need this. Like, if he stays, we got to figure out a way to roll his company. And this isn't feeling great to me that he has a completely separate company and. You guys worry about, like, 12,500amonth, me doing this work, but it's like, do you guys have any idea what Drew is doing with Profit Sword? Is it a competitive product that he's creating? Right. Like, we're totally in the dark. He never offers any insight whatsoever. He's working. He told me he's working with one of the hotel investment companies. That's Rock Bridge. In a pilot capacity with profit sword. What is that?

### You (2025-11-13T16:15:20.159Z)

I don't. Know.

### Guest (2025-11-13T16:15:41.518Z)

How competitive is it to what we're doing? Right? Why is it Drew get scot free? Not asking any of those questions. And yet I've. I'm literally. All I've done is say I'll help you with asset management work, and please help me, like, survive financially, Carlos, and then let us. Sit down and, like, you know, interview you on your CIA business. Could we be a customer of yours? Like, I. I just feel like the fairness between how I'm being treated with Driftwood and how he's being questioned. Nothing about hotel biz is inequitable.

### You (2025-11-13T16:16:20.559Z)

That's a very valid question. And that's also something we ll see. What bothered me. Is in reality, it states that the partners can have outside the interest. Even if they compete with InnVestAI. I thought that was really unusual.

### Guest (2025-11-13T16:16:41.118Z)

It was intended for Drew, and it was attended specifically for Drew.

### You (2025-11-13T16:16:44.399Z)

That question, I'm wondering.

### Guest (2025-11-13T16:16:45.998Z)

Yeah.

### You (2025-11-13T16:16:47.039Z)

I don't think that's right. In that case. Or go out. And beg enhancements. On, go out. And read those enhancements and all of a sudden go to market with a better product than. Why would we do that? Why would we have that in our llc? It just does not make sense. I forgot all about that until you just mention.

### Guest (2025-11-13T16:17:13.518Z)

I was trying to accommodate him because I knew he had his own company, right? I was trying to be a good, like, fair, reasonable partner. But.

### You (2025-11-13T16:17:24.079Z)

Yeah. How about that? Interesting. Allow them to create a compatible product. That should not be in that.

### Guest (2025-11-13T16:17:36.398Z)

We're going to cross an asset management. There's no way we don't cross. I mean, he's more operational and I'm focused more on the investment side, but it doesn't matter. It's like it's going to be. It's, it's, It'll need. To be used for operational asset management as well. And which is why I just thought, long term, we would try to buy Drew's company out, but.

### You (2025-11-13T16:18:01.199Z)

I'm just looking at my inbox and I do see the mode apply to. Your ap. Ologies thread. And investing. If we can do a quick meeting between three of us to discuss and accept.

### Guest (2025-11-13T16:18:18.638Z)

I did not see that yet.

### You (2025-11-13T16:18:20.079Z)

Yeah. No, I can't even log 10 o'clock.

### Guest (2025-11-13T16:18:20.318Z)

And I did send you. What time?

### You (2025-11-13T16:18:27.119Z)

Email just before 10:00.

### Guest (2025-11-13T16:18:29.198Z)

Oh, it was Senate type.

### You (2025-11-13T16:18:30.239Z)

Yeah.

### Guest (2025-11-13T16:18:30.398Z)

Thought. Yeah. Yeah, that's a good idea. Please understand, I'm under the gun today. I have. I didn't. I. I have budget reviews the entirety of next week. And if you understood how manual this process has been. And I'm working full time at Kroger trying to burn the midnight oil on, like, taking all this manual data to get through. These budget reviews, right? And then.

### You (2025-11-13T16:18:55.119Z)

All I know exactly the day you're going to. I oversaw the Buggy Bowel Partners, which is over 100 properties. Yeah, it sucks.

### Guest (2025-11-13T16:19:03.598Z)

Right. Right.

### You (2025-11-13T16:19:09.999Z)

Big time.

### Guest (2025-11-13T16:19:12.638Z)

And did you see I sent to you the email that I had sent to Driftwood with the original safe note and the the roadmap that you had done. And in there, I highlighted in yellow so you could see it where I told them how we would we would be allocating the funds. I have, obviously, I didn't say specifically 8500 to Diane, but, like, living expenses, which to me is what? 8500 is software. And I. What did I think I said marketing or something like that, but.

### You (2025-11-13T16:19:46.879Z)

I did see that. That when you asked me not to forward her, which is fine. I'm not going to do that.

### Guest (2025-11-13T16:19:50.078Z)

Right. So does that not show that I've, like, I have shared that information? They know what is happening here and they have no objection to it. So this whole concept that we're going to be audited over, that Driftwood is going to audit us over, it just, it's.

### You (2025-11-13T16:20:09.279Z)

It goes back to conversations that we had a long time. What about future investors? There are certain things that divide all this. I made a comment in that meeting about. Why can't we just different valuation for each stake now in both mom can do immediately because. No, we can't do that because we have to have consistent and growing valuations. And they will want to see. Some of these other items. I know who cared. Their pushback is on future fundraising. What can you agree to? With driftwood. And how will that affect what we agree to with others? I've never had. Any experience with that, so I don't know how valid that is or not, but that's the whole perspective is coming back. Not that this work will auto. Affect down the road.

### Guest (2025-11-13T16:21:11.598Z)

Okay, so where did we leave the LLC? Because we have a call 530. Right. And like, I'm sorry, like, today it's weak for me, has been so stressful that I, like, I can't blow up on a call at 5:30 because I have to still keep working through the night on budgets. And I can't, like, mentally go off the rails. Right. And be able to keep my. My mindset on showing Driftwood that I'm adding value to them. Because in my mind, they cover the next 75k too. Right. And then that takes my need for any money from InnVestAI off the table. Like then all future safe notes can go to start to cover you and Benode and Carrie and and like Drew and others. So how do we get through this call at 5:30?

### You (2025-11-13T16:22:03.919Z)

Actually would have no addition whatsoever. If you send out an email saying all the things that you have to do, be careful.

### Guest (2025-11-13T16:22:15.198Z)

Okay?

### You (2025-11-13T16:22:16.399Z)

I don't know what the agenda is going to be. I think. It will be going through Mark's objections. He took the email or what Mark said. I put in the comments. And while Mark took that and he added some under here so he didn't move, so you didn't have to document the show's buying correspondence. Pretty much. You agreed with what I had put down. I don't remember off the top of my head if there was anything, because people basically. Yeah. Negotiate the llc. Engulfing their budget. Like I said all this about. The details. I don't mind having. A few minutes. On the call pen. I can tell them what books are. I won't share the immoral. I will let them know. That well, they will score for six months. And if you do have documentation from Driftwood and if you are going to go back to them and try to get something that we can attach to Safe Mode that shows that. They have. That this can be used for funding. I mean, they just hold it at that.

### Guest (2025-11-13T16:23:45.038Z)

So should I just not be on the call in the four of you guys? Go forward with the call. I mean, it pays. If I could gain an hour today to like, and maybe. What are your thoughts on that?

### You (2025-11-13T16:23:56.719Z)

I will say this not to. Otherwise.

### Guest (2025-11-13T16:24:02.718Z)

Have me on the call.

### You (2025-11-13T16:24:04.479Z)

Because otherwise LARC's going to just dive right in. And probably not even worry about the difference. Going to get back to why. Work. Men consulted. Why didn't we have to do an approved and all the time. I can bring it up. And let them know that. I'm a simple name, and it's not going to happen again.

### Guest (2025-11-13T16:24:30.558Z)

And again, you. I just sent you the documentation. Right, because the safe note was signed and I sent to you and Drew on the date was.

### You (2025-11-13T16:24:30.559Z)

And.

### Guest (2025-11-13T16:24:43.198Z)

September 17th. 2025, September 17th. Right. I didn't sign that safe note until November 1st. That what I was proposing. Right. And it's. It's there. I didn't send it to Mark on purpose because of him blowing up. And then I also sent you, and please don't share it. But, like, when. I sent to and who these people are. It's Carlos. Mona is their like hr. Right. She's the person that's helped me, like, get onboarded and get in. Then George is the. He is their general counsel. Right. And so I've laid out that where our product stands and our team has been. Working on InnVestAI for about a year. So the 75k will go Howard helping our team with minimal living expenses, which I view 8,500. It's not exorbitant. It's like, not, you know. Right. Offshore development and ramping marketing. And they saw this and they signed a safe note, right? With, with all of this backup that explained where we were. And I could not have put Mark Andrew on this because they would have messed this up so bad. And they, and they just like, I'm on. I'm embarrassed to bring them on a call with, with Carlos, honestly, because of how negative and. How tense the relationship is between us all. So, like, I'm purposely not setting up a call with Driftwood right now because of the fact that I. I don't want markers gonna come off as too much of an asshole, and I don't want to ruin my relationship with Driftwood over that at this. Point.

### You (2025-11-13T16:26:40.079Z)

I. Agree. I think that's fine. So why don't you do 16 yourself from today's meeting? And we can meet for 15 minutes or whatever. While, let them know. Like I just said that you and I spoke about this in detail.

### Guest (2025-11-13T16:27:01.038Z)

Let them know that I'm just too underwater this week. Like, it's just. It's not like there's weeks where other people are underwater, Right? And this is a week when I have to do 50 budget reviews next week that I. I can't get caught up in a three hour discussion on. An LLC agreement.

### You (2025-11-13T16:27:18.719Z)

Right.

### Guest (2025-11-13T16:27:19.758Z)

And if you and Howard and I want. I mean, if you and Benoit and I want to talk for 15 minutes before that call.

### You (2025-11-13T16:27:27.039Z)

Why don't you go ahead and pick out a time that works for you? I will not be available between reply. I'm going to be gone from 13230 to the second of it. So at any time before or after.

### Guest (2025-11-13T16:27:43.118Z)

But he doesn't. He. He usually can't meet until 5:30, right?

### You (2025-11-13T16:27:47.279Z)

Well, if you don't see anything, Now. Between three of us. So let me reply to that real quick and then we can go ahead.

### Guest (2025-11-13T16:27:56.638Z)

Okay?

### You (2025-11-13T16:27:59.359Z)

It doesn't necessarily have to be before this meeting.

### Guest (2025-11-13T16:28:03.758Z)

I just don't want him to think like that. Like, I want him to have confidence too. Right? And my only conflict is 2 o'clock today for an hour. Otherwise I can meet with the three guys.

### You (2025-11-13T16:28:06.799Z)

Life. Yeah. So would I. Book not available. At the same time. Yeah, I just think. Ingwhere from you. What the thoughts are from Lark. What our potential. Backup plan would be. And. How we want to approach through. And how it affects the timing of the llc. Because. Like I said. Yeah, he's been pretty vocal about. Getting. That llc sign.

### Guest (2025-11-13T16:28:48.238Z)

You guys know, like, if the three of us want to sign that llc, right? And we want to sit down and work through it. I. I'm totally, like, I have a lot more trust that if there's something we haven't worked through, that the three of us are going to be able to, like, like, resolve it, like, in good faith and trying to be good partners to each other. I just. I can't sign it with Mark. Right now and the whole truth thing, until once Drew understands what's going to happen, he's going to have to make a decision, which. I mean, and we could sign it saying that we agree that there's the potential admission of, you know, two other very important. Roles, Right? One would be data. One would be like a gym alderman role. But it's unclear at this point, and I don't know, maybe that's not important, but. I'm sorry, Howard. I'm in a terrible mood today, and you're catching, like, the worst of me.

### You (2025-11-13T16:29:49.119Z)

Well done. That's why. Like I said, I like our relationship. We can. Sync. Tracker without. Angry people. Not a big deal. I think we're good.

### Guest (2025-11-13T16:30:12.078Z)

I can hear things when you say them that sometimes I can't hear when others say them. So I may have a negative reaction up front, but after I think about it, the way you present it, I can, like, try to mentally, like, adjust my mindset on it. When I can't do that when it's needs to be.

### You (2025-11-13T16:30:29.759Z)

Now I got it. Ok?

### Guest (2025-11-13T16:30:32.638Z)

I have one more question. When you talk to Mark, was it combative between the two of you, or how was the tone of the conversation?

### You (2025-11-13T16:30:43.359Z)

Yes, it will matter, but not loud. Because. He made a lot of statements such I just totally disagree with. You. He just kept telling well, ok, debate this. Now jump going back to his news of running and saying all these other things, which. Ok, so you've done that and yeah, I met one year unhappy about the llc. When I said. There was something about. I don't think. It was about the pay. But there's something in there that I said. Oh, no. I just simply remember that we had multiple calls. Where diane? Outlined. What was going on. Maybe it worked. I don't know. The pay either way. That's gotten really quiet. And I'm just. Like, ok, that's somehow went back and forth. And I think part of it was I didn't imply the fact that a lot of meetings, I kept saying, well, we had a meeting on this. I don't know if you're aware of that, but come back and forth like that. I think towards the end, I think he's starting to get a little bit more agitated. And if we had continued to call, he may have just gotten. Pretty loud, but. I think that that's cut it. Short.

### Guest (2025-11-13T16:32:23.438Z)

And it's just not good to have a bad. I mean, I've worked in companies where you have one bad actor and they ruin. Everything. They kill the culture. You think they're there because they're going to add tremendous value in some sort of business to. But their ego can't get out of the way. And it's. And that's why I didn't think he was that bad of an actor, but I was wrong in that.

### You (2025-11-13T16:32:46.879Z)

Yeah. Ok?

### Guest (2025-11-13T16:32:48.238Z)

Thank you for your patience with me. You'll send the note to Vinod seeing if there's a time between between now and the call at 5:30. And I'm going to send a note saying that I'm just too too crunched with budget reviews to join the call today. Ok, thank you. Bye.