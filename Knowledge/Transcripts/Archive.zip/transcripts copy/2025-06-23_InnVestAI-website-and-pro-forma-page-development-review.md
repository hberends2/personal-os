# InnVestAI website and pro forma page development review

**Date:** 2025-06-23 00:00:00 UTC
**Meeting ID:** b14ab4b8-cc66-457b-9634-3313e54a1b8e
**Synced:** 2026-02-05 14:46:48

---

# Transcript for: InnVestAI website and pro forma page development review

### You (2025-06-23T15:05:41.033Z)

No.

### Guest (2025-06-23T15:05:42.776Z)

Howard,

### You (2025-06-23T15:05:43.493Z)

Good morning.

### Guest (2025-06-23T15:05:44.666Z)

Sorry. I got lost in the other meeting.

### You (2025-06-23T15:05:44.843Z)

Good. Yeah. Thought we asked him if there's a meeting. No worries. Was your weekend? Weekend was good.

### Guest (2025-06-23T15:05:53.656Z)

Weekend was good. Weekend was good.

### You (2025-06-23T15:05:54.913Z)

Okay. That's good. Yes,

### Guest (2025-06-23T15:05:57.096Z)

Yourself?

### You (2025-06-23T15:05:57.223Z)

Yeah. It was good. Is it you get you're getting the heat wave there as well?

### Guest (2025-06-23T15:06:00.656Z)

Yeah. It's very, very odd. Yeah.

### You (2025-06-23T15:06:01.703Z)

Yeah. It's really, really hot. Yeah. Yeah. Yeah. I was pretty brutal over the weekend temperature wise, but

### Guest (2025-06-23T15:06:09.766Z)

Yep.

### You (2025-06-23T15:06:10.423Z)

Yep. Yep. So

### Guest (2025-06-23T15:06:12.756Z)

Yep.

### You (2025-06-23T15:06:14.243Z)

Cool. So he so I did get

### Guest (2025-06-23T15:06:15.246Z)

Cool. So he so I did get

### You (2025-06-23T15:06:17.273Z)

Go Ready access Oh, okay. As they are

### Guest (2025-06-23T15:06:18.486Z)

go ready access at Diane.

### You (2025-06-23T15:06:20.793Z)

for

### Guest (2025-06-23T15:06:21.956Z)

Forwarded me the code.

### You (2025-06-23T15:06:21.983Z)

code. And then I have put

### Guest (2025-06-23T15:06:24.296Z)

And then I have put one page

### You (2025-06-23T15:06:24.513Z)

one page I'm still

### Guest (2025-06-23T15:06:27.746Z)

I'm still kind of

### You (2025-06-23T15:06:28.333Z)

kind of trying to

### Guest (2025-06-23T15:06:30.316Z)

trying to

### You (2025-06-23T15:06:32.013Z)

modify

### Guest (2025-06-23T15:06:33.476Z)

modify it. But

### You (2025-06-23T15:06:33.633Z)

But this is like a free page that code that it provides.

### Guest (2025-06-23T15:06:35.476Z)

it's like a free page that GoDaddy provides.

### You (2025-06-23T15:06:37.963Z)

If we ever do anything apart from that, we'll have to

### Guest (2025-06-23T15:06:39.116Z)

We have to do anything apart from that, we'll have to

### You (2025-06-23T15:06:40.843Z)

pay. So if you go to s p p not as

### Guest (2025-06-23T15:06:42.076Z)

pay. So if you go to STTP,

### You (2025-06-23T15:06:45.013Z)

just HTTP,

### Guest (2025-06-23T15:06:45.186Z)

not as just HTTP,

### You (2025-06-23T15:06:46.263Z)

to column slash slash

### Guest (2025-06-23T15:06:47.486Z)

to colon//investai.com.

### You (2025-06-23T15:06:48.733Z)

invest a I dot com. So you said

### Guest (2025-06-23T15:06:51.936Z)

Not a mess.

### You (2025-06-23T15:06:52.803Z)

not an s, just h t t Not an s. Yes. That's an h t t. And then what was it?

### Guest (2025-06-23T15:06:56.836Z)

Yeah. Just an HTTP.

### You (2025-06-23T15:06:58.503Z)

Investai.com.

### Guest (2025-06-23T15:06:58.526Z)

Investai.com.

### You (2025-06-23T15:07:04.003Z)

Yeah. I can't get in. It just says contact owner. Is it?

### Guest (2025-06-23T15:07:08.726Z)

Is it?

### You (2025-06-23T15:07:10.603Z)

One second. Let me try.

### Guest (2025-06-23T15:07:12.026Z)

Second. Try.

### You (2025-06-23T15:07:12.373Z)

But the time because I was able to do that on my

### Guest (2025-06-23T15:07:13.686Z)

That to turn because I was able to do that on my

### You (2025-06-23T15:07:15.823Z)

mobile yesterday.

### Guest (2025-06-23T15:07:17.176Z)

mobile yesterday.

### You (2025-06-23T15:07:21.133Z)

Well, Yeah. Investigate.com. Yeah. Let let me share this again.

### Guest (2025-06-23T15:07:25.616Z)

Yeah. Investai.com. Yeah. Let let me share this. Okay?

### You (2025-06-23T15:07:28.253Z)

T

### Guest (2025-06-23T15:07:29.606Z)

Teams. Gonna take the sync.

### You (2025-06-23T15:07:34.353Z)

Send

### Guest (2025-06-23T15:07:35.786Z)

Send

### You (2025-06-23T15:07:37.293Z)

yeah. Could you please click on that one?

### Guest (2025-06-23T15:07:38.776Z)

Yeah. Could you please click on that one?

### You (2025-06-23T15:07:49.413Z)

Yeah. That one opens.

### Guest (2025-06-23T15:07:50.976Z)

That opened. Right?

### You (2025-06-23T15:07:51.843Z)

That opens. Right? Yeah. Yeah. I don't think it's It does have a yes.

### Guest (2025-06-23T15:07:56.276Z)

Yeah. I don't think this is

### You (2025-06-23T15:07:58.373Z)

That's that's why I was getting that. Okay.

### Guest (2025-06-23T15:07:59.836Z)

okay. Oh, it has s?

### You (2025-06-23T15:08:00.743Z)

Oh, it's address? Yeah. Okay. That's nice.

### Guest (2025-06-23T15:08:04.476Z)

Oh, okay. That's nice.

### You (2025-06-23T15:08:06.343Z)

Okay. I'll let it with just HTTP. So I thought

### Guest (2025-06-23T15:08:08.306Z)

Okay. I'll let it adjust HTTP. So I thought

### You (2025-06-23T15:08:11.153Z)

for s right? HTTPS, you need to pay what they are providing for

### Guest (2025-06-23T15:08:13.486Z)

for s, right, HTTPS, you need to pay, but they are providing it for free.

### You (2025-06-23T15:08:15.673Z)

free. So something like that. Yeah. But, yeah, we can modify it further.

### Guest (2025-06-23T15:08:18.276Z)

Nothing like that. But, yeah, we can modify it further.

### You (2025-06-23T15:08:21.513Z)

Or whatever. No. Yeah. I'll

### Guest (2025-06-23T15:08:23.816Z)

Or whatever.

### You (2025-06-23T15:08:24.453Z)

Yeah. Okay.

### Guest (2025-06-23T15:08:25.836Z)

I'll

### You (2025-06-23T15:08:25.913Z)

Wait list is functional.

### Guest (2025-06-23T15:08:26.866Z)

yeah.

### You (2025-06-23T15:08:29.073Z)

I'd have to check with Diane if she

### Guest (2025-06-23T15:08:32.196Z)

Have to check with Diane if she got an email.

### You (2025-06-23T15:08:33.183Z)

got an email. Okay. Yeah. No. This looks this looks sweet.

### Guest (2025-06-23T15:08:36.876Z)

So that

### You (2025-06-23T15:08:40.353Z)

Yeah. We I mean, just this changes whatever you feel like.

### Guest (2025-06-23T15:08:42.516Z)

yeah. We I mean, just suggest changes whatever you feel like.

### You (2025-06-23T15:08:44.143Z)

Even the content on the top, I think that's

### Guest (2025-06-23T15:08:46.456Z)

Even the content on the top, I think that's

### You (2025-06-23T15:08:47.443Z)

far in hospitality. This is we could

### Guest (2025-06-23T15:08:49.346Z)

empowering hospitality. This is we could

### You (2025-06-23T15:08:49.523Z)

probably Yeah. Ride more than that. Very cool.

### Guest (2025-06-23T15:08:51.926Z)

probably write more than that.

### You (2025-06-23T15:08:53.473Z)

Okay. Yeah. So that is that. And then I was able to do the

### Guest (2025-06-23T15:08:56.306Z)

So that is that. And then I was able to do the embed part. I

### You (2025-06-23T15:08:57.633Z)

embed part as well. So it works perfectly. All the navigation, everything works.

### Guest (2025-06-23T15:09:00.796Z)

well. So it works perfectly. All the navigation, everything works.

### You (2025-06-23T15:09:03.573Z)

K. It is still in my local

### Guest (2025-06-23T15:09:05.846Z)

It's it's still in my local. I still need to

### You (2025-06-23T15:09:05.973Z)

I still need to Yeah. Run that up. Yeah. So probably I'll show that

### Guest (2025-06-23T15:09:10.036Z)

run that up. So probably I'll show that

### You (2025-06-23T15:09:12.403Z)

you know, we can pay. Alright. Yeah. I don't have my laptop.

### Guest (2025-06-23T15:09:14.976Z)

our meeting today.

### You (2025-06-23T15:09:16.103Z)

Open right now.

### Guest (2025-06-23T15:09:16.296Z)

Yeah. I don't have my laptop open right now.

### You (2025-06-23T15:09:17.123Z)

Yeah. Cool. Alright. So I had a very busy weekend. Yeah. So I

### Guest (2025-06-23T15:09:29.106Z)

Yeah.

### You (2025-06-23T15:09:30.093Z)

bit the bullet and upgraded my subscription because I was burning through the credits too fast. And I still

### Guest (2025-06-23T15:09:37.666Z)

Yeah.

### You (2025-06-23T15:09:39.673Z)

within, like,

### Guest (2025-06-23T15:09:40.096Z)

Alright.

### You (2025-06-23T15:09:41.083Z)

I think my reset date is the nineteenth.

### Guest (2025-06-23T15:09:43.756Z)

Yeah.

### You (2025-06-23T15:09:44.403Z)

And so within three days, I burned through almost everything. Oh, man.

### Guest (2025-06-23T15:09:48.206Z)

Oh my goodness.

### You (2025-06-23T15:09:49.193Z)

Which one is that? Lovable? Lovable. Yeah.

### Guest (2025-06-23T15:09:52.326Z)

Which one is that lovable?

### You (2025-06-23T15:09:53.203Z)

But the good news is, I also have Bolt. Which connects to GitHub And so Okay.

### Guest (2025-06-23T15:10:01.126Z)

Okay.

### You (2025-06-23T15:10:02.043Z)

I can also start using Bolt for some of the modifications. And so far, they seem to play nice together. But let me share my screen real quick. And I've got a couple things. That we might wanna talk about here. Yeah. And you had also asked me to look into something

### Guest (2025-06-23T15:10:16.326Z)

Yeah. Yeah. You had also asked me to look into

### You (2025-06-23T15:10:20.093Z)

and I have one. I actually forgot which page was that.

### Guest (2025-06-23T15:10:21.916Z)

something that I have on. I actually forgot which page was there.

### You (2025-06-23T15:10:23.903Z)

Some navigation or something that Yeah.

### Guest (2025-06-23T15:10:26.886Z)

Some navigation or something. Right?

### You (2025-06-23T15:10:28.603Z)

Yeah. We have to think about that. Maybe maybe we'll touch on it here. So Sure.

### Guest (2025-06-23T15:10:36.286Z)

Sure.

### You (2025-06-23T15:10:37.413Z)

Alright. So property details, market comps, unchanged.

### Guest (2025-06-23T15:10:40.266Z)

Yeah.

### You (2025-06-23T15:10:42.743Z)

But I did meet with Drew last week, and we talked about how things should be grouped together. So now valuation

### Guest (2025-06-23T15:10:53.216Z)

Mhmm.

### You (2025-06-23T15:10:53.373Z)

is now called pro form a, which is Okay. Correct term for underwriting.

### Guest (2025-06-23T15:10:57.966Z)

Okay. Nice.

### You (2025-06-23T15:10:58.913Z)

Yep. And then in pro form a now, we just have three categories.

### Guest (2025-06-23T15:11:00.406Z)

Yep.

### You (2025-06-23T15:11:06.383Z)

Penetration analysis,

### Guest (2025-06-23T15:11:07.976Z)

Mhmm.

### You (2025-06-23T15:11:08.063Z)

revenue and expense. Okay. So penetration analysis is just

### Guest (2025-06-23T15:11:12.456Z)

That

### You (2025-06-23T15:11:13.893Z)

occupancy ADR, and RevPAR. So I I had already added those in and I then I thought

### Guest (2025-06-23T15:11:18.666Z)

Mhmm.

### You (2025-06-23T15:11:21.113Z)

a penetration was gonna be different page, but, you know, Drew said, no. They're they're all the same. So so penetration is done.

### Guest (2025-06-23T15:11:29.496Z)

Oh, okay.

### You (2025-06-23T15:11:30.453Z)

With that. Now we do need to make another thing here though. On occupancy, we do wanna make sure that we've got the market occupancy will be fed from this market comps page. So this is just made up data, but you know, we'll we'll get that in there too. So then on revenue, we no longer have that other subcategory. It's just basically, it's just rooms revenue food and beverage, other operated, and miscellaneous.

### Guest (2025-06-23T15:12:06.566Z)

Mhmm. Okay.

### You (2025-06-23T15:12:08.653Z)

So it turns out allocated is not something that you it's in the financial statement, but it's not something that you use for underwriting or valuation. Because basically one offsets the other.

### Guest (2025-06-23T15:12:20.926Z)

Got

### You (2025-06-23T15:12:22.953Z)

It's almost always a zero.

### Guest (2025-06-23T15:12:24.736Z)

Mhmm.

### You (2025-06-23T15:12:24.943Z)

So allocated was totally removed. Okay. We got that, and then we got our rooms expense.

### Guest (2025-06-23T15:12:29.606Z)

Got

### You (2025-06-23T15:12:33.733Z)

Now this is where the big change came. This is really where I burned up a lot of expense here. So now you've got your room's expense. You know, that's that's still there. It's based on the per occupied room But what Drew and Mark asked is that for the other expenses, food and beverage, other operated miscellaneous, Mhmm. Remember last time, I had one drop down

### Guest (2025-06-23T15:12:59.396Z)

Yeah.

### You (2025-06-23T15:13:01.283Z)

on the expense header. Which was accidentally removed. I'll add that back in. And you choose whether you want to use the POR or percentage of revenue. Okay.

### Guest (2025-06-23T15:13:12.196Z)

Okay.

### You (2025-06-23T15:13:13.923Z)

But they said there are many many people don't just use one method for everything. They may mix and match. Now there's three options, POR, percentage of revenue, and, of course, every time you change it, the header changes. But also manual input. Sometimes they wanna just plug in the number. So yeah. So here, you can see, you know, if I wanted to, you know, just food and beverage, you know, I can do, you know, 24. You know tab over 25 okay why isn't it okay know, etcetera. Percentage of revenue, I can do the same thing, but there's a glitch. And this is where I'm getting this where I'm getting a little frustrated. I went round and round with this. That for some reason when you use percentage of revenue, it's not calculating the total. And then down here, you know, I might just wanna say, you know, 58,000 fifty nine thousand. Right? So if I don't want to go through calculations and I just wanna ballpark it you know, I I can do any one of those three. But I have heard a lot of or read a lot of articles that said vibe coding works great. Until it doesn't. It's good for smaller files and smaller projects but when you get to a certain size it gets confused and that's what I noticed yesterday. So I would put in a prompt You know, I would include screenshots, and I would mock up those screenshots to show exactly what was going on. So, oh, I see the problem. It's because this isn't here, and that's not there, and it's looking for blah blah blah. I said, okay. Go ahead and fix it. Nothing would happen. And I'd kind of repeat the process and basically oh, it's like, oh, well, here's the problem. And it just, like, basically undid what it just last did and just completely going around in circles. And so I it was getting to the point where I was just burning up you know, 10 or 20 tokens trying to get this fixed. So this is where you and I might need to kinda tag team since you have access to this in GitHub. This is where maybe we want to use something like cursor or something way more powerful than lovable and just tell it, you know, go through and clean this thing up. You can do that in Lovable and I did There's a prompt that I learned where you just say, okay. You know, please review the entire code base. Find out, you know, what's wrong, what needs to be blah blah blah. And I did that and it helped. It did reduce the code base. But it still won't fix this. And the thing that pisses me off is this is working perfectly. And and no idea why it stopped. What did we do that made it, that broke it? So, it's not like it never worked and that it's just beyond the capabilities. But I think I might be getting to the point where I'm stressing it out. Now the good news is that typically that's only based that would only be the pro form a page. I can make changes on any of these other pages without a problem. But none of these other pages really have any calculations or anything. This is the only page that is really kind of going through and in working and calculating and huge amount of code dedicated to this But other than that, I mean, that's that's really kind of where it boiled down to is just kinda using Mark and Drew's direction to clean up the sidebar here and group these without having all these different same thing. Undistributed expenses, I don't think anything changed there. And then nonoperating expenses, we still have the management fees, everything over here. Capital expense. So so this is all pretty much the same, but just really spent a lot of time on these three categories over the weekend. So we are really close to being able to start sitting people in front of a screen and letting them start inputting numbers. And honestly, I don't think that the calculation is going to be terribly difficult Like I said, it's an easy formula. So So I am probably either later today or tomorrow going to go back and just say, you know, stop trying to overcomplicate this Let's go back to the very beginning. Here is the formula, which is basically whatever the percentage is, times the revenue up here. And basically, the revenue is just a very simple calculation, so I'm going to lay it out so that it can just calculate everything on the fly. The revenue, and then multiplying whatever the user inputs times that revenue to get the total expense. It should be able to be done e very easily. I mean, all these other all these other lines, you know, they're working fine. I can just input the number, and every time I input a digit, it's doing what it's supposed to do. So so good weekend and a frustrating weekend. I think you might be muted. There you go. Okay. You can hear me? I can hear you now. Oh, I can hear No. You know what it was? I I just realized when I was playing with the keyboard, I

### Guest (2025-06-23T15:19:42.406Z)

You can hear me? Oh, I can do anything. Okay.

### You (2025-06-23T15:19:46.123Z)

accidentally hit my mute button. No. Gotcha. Yeah. Yeah. I I could hear you fine, though. Because what I was

### Guest (2025-06-23T15:19:52.646Z)

Oh, gotcha. Yeah. I I could hear you fine, though.

### You (2025-06-23T15:19:53.483Z)

saying the only issue it has right now is on the pro form a revenue

### Guest (2025-06-23T15:19:57.556Z)

So what I was saying, the only issue it has right now is on that

### You (2025-06-23T15:19:58.003Z)

screen It is not able to Can't pull it.

### Guest (2025-06-23T15:20:01.986Z)

performer revenue screen where it is not able to

### You (2025-06-23T15:20:02.783Z)

Based on percentage. Right? Yeah. That's the only thing that I'm having an issue with.

### Guest (2025-06-23T15:20:06.926Z)

calculate based on percentage. Right?

### You (2025-06-23T15:20:07.553Z)

Yeah. Cool. So I'll learn data look at that. I think that should be Okay.

### Guest (2025-06-23T15:20:12.346Z)

Yeah. Cool. So I'll I'll take a

### You (2025-06-23T15:20:13.743Z)

Is it flexible? Yeah. I mean, I

### Guest (2025-06-23T15:20:16.026Z)

look at that. I think that should be easily fixable.

### You (2025-06-23T15:20:17.183Z)

I've known from day one that using a tool like this is only good for a POC You know? Everybody knows that it's not enterprise or production

### Guest (2025-06-23T15:20:26.616Z)

Yeah.

### You (2025-06-23T15:20:29.383Z)

level code. So

### Guest (2025-06-23T15:20:30.016Z)

Yeah.

### You (2025-06-23T15:20:31.593Z)

you know, at at some point, we're gonna have to go through this exercise anyway.

### Guest (2025-06-23T15:20:32.306Z)

Yeah.

### You (2025-06-23T15:20:34.693Z)

Of Yep. Yep. Yep. I think. Yep. So

### Guest (2025-06-23T15:20:36.586Z)

Yeah. Yep. Yep. Definitely.

### You (2025-06-23T15:20:38.943Z)

cool. Cool. Yeah. I'll just take a look at that, and then I'll show you guys

### Guest (2025-06-23T15:20:44.006Z)

Cool. Cool. Yeah. I'll take a look at that.

### You (2025-06-23T15:20:45.383Z)

how the team is working. So it's just

### Guest (2025-06-23T15:20:47.716Z)

And then I'll show you guys how that embedding is working. So it's just the entire application, whatever you have built.

### You (2025-06-23T15:20:50.773Z)

And one of the pages. So and and then

### Guest (2025-06-23T15:20:55.876Z)

One of the pages.

### You (2025-06-23T15:20:56.243Z)

everything will make the same. So Alright.

### Guest (2025-06-23T15:20:59.166Z)

And and then we can everything remains the same. So

### You (2025-06-23T15:20:59.223Z)

Alright. Cool. I don't know if you saw my note to Diane. Yeah. I think yeah. Well, that but but in Teams, I also pinged Diane and asked told her that

### Guest (2025-06-23T15:21:10.126Z)

Agentic AI

### You (2025-06-23T15:21:13.783Z)

I'll send out a video again today of what I've done, but I don't wanna spend any time on our call this afternoon.

### Guest (2025-06-23T15:21:16.316Z)

Yeah. Yeah.

### You (2025-06-23T15:21:19.693Z)

Doing a dog and pony show, I want

### Guest (2025-06-23T15:21:21.486Z)

Yep.

### You (2025-06-23T15:21:23.163Z)

we I we need to steer these weekly meetings toward the business. Now. It it's time to start working on that. Yeah. Certainly think we should show what you put together.

### Guest (2025-06-23T15:21:33.836Z)

Makes sense. Makes

### You (2025-06-23T15:21:35.353Z)

But, you know, that'll only take a couple minutes. I do

### Guest (2025-06-23T15:21:35.696Z)

Yep.

### You (2025-06-23T15:21:38.373Z)

not wanna start going through this and I mean, last couple times, it's taken forty five, fifty minutes to get through it with everybody. Asking questions and comments and stuff. And Yeah. Yeah. Yeah. Makes sense. Makes sense. You know, I could probably show you that in

### Guest (2025-06-23T15:21:53.496Z)

Yeah. Yeah. Yeah. Makes sense. Makes sense.

### You (2025-06-23T15:21:54.533Z)

thing right now, and then how

### Guest (2025-06-23T15:21:56.816Z)

You know what? I could probably show you that embedding thing right now, and then

### You (2025-06-23T15:21:57.793Z)

want to do it later that we can. Do once again. Let's see.

### Guest (2025-06-23T15:22:01.986Z)

however we want to do it later, we can do one second again. Let's see. I had that running. I'll switch my teams

### You (2025-06-23T15:22:32.153Z)

It's

### Guest (2025-06-23T15:22:36.306Z)

from my laptop.

### You (2025-06-23T15:22:42.643Z)

Yeah.

### Guest (2025-06-23T15:22:45.466Z)

This is a bad promise.

### You (2025-06-23T15:22:45.773Z)

Okay.

### Guest (2025-06-23T15:22:47.886Z)

Yeah. Okay.

### You (2025-06-23T15:22:51.403Z)

Okay. It's completely

### Guest (2025-06-23T15:22:57.656Z)

Okay. It's completely

### You (2025-06-23T15:23:03.363Z)

Alright. That's fine. I can see it now. Favor, but nothing wrong.

### Guest (2025-06-23T15:23:08.696Z)

The laptop is not working.

### You (2025-06-23T15:23:09.563Z)

Yeah. Yeah. I see it.

### Guest (2025-06-23T15:23:11.546Z)

Nothing move. I can see the login page, but nothing moves.

### You (2025-06-23T15:23:12.663Z)

Yeah. Like the. You something.

### Guest (2025-06-23T15:23:17.266Z)

Yeah. Oh, it moved.

### You (2025-06-23T15:23:17.773Z)

Cool. I'm gonna to switch to my

### Guest (2025-06-23T15:23:19.126Z)

Oh, something is moving there now.

### You (2025-06-23T15:23:20.653Z)

laptop. Okay.

### Guest (2025-06-23T15:23:22.006Z)

Okay. I see now. Cool. I'm gonna switch to my

### You (2025-06-23T15:23:23.113Z)

Teams.

### Guest (2025-06-23T15:23:25.026Z)

laptops team. Teams.

### You (2025-06-23T15:23:42.603Z)

Just do what I use.

### Guest (2025-06-23T15:23:47.896Z)

This device

### You (2025-06-23T15:23:48.493Z)

Okay. Let's see here.

### Guest (2025-06-23T15:23:50.736Z)

Okay. Let's see here. Super ice cream. Okay.

### You (2025-06-23T15:24:06.803Z)

It dot com.

### Guest (2025-06-23T15:24:13.986Z)

Investai.com.

### You (2025-06-23T15:24:16.053Z)

Okay.

### Guest (2025-06-23T15:24:21.646Z)

Okay. Alright. What's wrong there? That looks fine to me. That's the only use that I have.

### You (2025-06-23T15:24:34.903Z)

Fuck.

### Guest (2025-06-23T15:24:45.596Z)

Okay. Alright. I don't think anything was in here. Come on.

### You (2025-06-23T15:24:52.623Z)

Carefully, you're gonna get locked out of your own application there. Contact your administrator. Okay.

### Guest (2025-06-23T15:25:04.726Z)

Yeah.

### You (2025-06-23T15:25:07.763Z)

See. Panel. I've got the right edits.

### Guest (2025-06-23T15:25:12.476Z)

Let's see. This can work. I'll try that. It's 10 word later. Is it this? I think you did this since our labs. Save here database table otherwise. Last time. Oops. Okay. Let's see. Users. And we'll get the oh, activate the one user for you too.

### You (2025-06-23T15:25:52.153Z)

See. That you guys see it. That's good one.

### Guest (2025-06-23T15:26:00.556Z)

See, we know that InnVestAI, that's good one. Why don't I think this is not working?

### You (2025-06-23T15:26:16.053Z)

Okay. I'm gonna reach to fix that. I'm sorry. That's fine. We can take a look at it later.

### Guest (2025-06-23T15:26:21.046Z)

Okay. Our delivery should fix that. And so it

### You (2025-06-23T15:26:23.793Z)

Yeah. I would but it's like just a link on the website. It

### Guest (2025-06-23T15:26:25.086Z)

later in the meeting.

### You (2025-06-23T15:26:27.543Z)

click on that one and on the website, you just see that

### Guest (2025-06-23T15:26:28.396Z)

Yeah. I'm aware, but it's, like, just

### You (2025-06-23T15:26:30.403Z)

Yeah. Some hardware working.

### Guest (2025-06-23T15:26:31.446Z)

a link on the left side. You click on that and then on the right side, just see the entire

### You (2025-06-23T15:26:31.603Z)

K. Yeah. I mean, even if you wanna just shoot a video

### Guest (2025-06-23T15:26:35.956Z)

model working.

### You (2025-06-23T15:26:36.263Z)

over it as well, share a video or Okay. We can take Yeah. Edits. Okay. Yeah. Alright. Cool. Anything else

### Guest (2025-06-23T15:26:41.916Z)

Okay. Yeah. Okay.

### You (2025-06-23T15:26:44.503Z)

you

### Guest (2025-06-23T15:26:46.576Z)

That would suggest with that.

### You (2025-06-23T15:26:47.163Z)

gonna be at home all week or

### Guest (2025-06-23T15:26:49.836Z)

That is all. And

### You (2025-06-23T15:26:50.043Z)

Yeah. I'm be home. Home all day. I'm the side, so I have

### Guest (2025-06-23T15:26:52.316Z)

uh-huh,

### You (2025-06-23T15:26:53.493Z)

part. Properties. Yeah. Oh, I'm It's it's it's

### Guest (2025-06-23T15:26:54.606Z)

Yeah. I'm gonna be home all week unless I join that Morgan properties.

### You (2025-06-23T15:26:57.593Z)

shoot you an article. They are on the cover of

### Guest (2025-06-23T15:27:01.706Z)

This Wednesday.

### You (2025-06-23T15:27:02.403Z)

Multifamily Executive Magazine.

### Guest (2025-06-23T15:27:03.346Z)

Yeah.

### You (2025-06-23T15:27:05.903Z)

Yeah. Good article on them. I didn't read the whole thing yet, but it's a

### Guest (2025-06-23T15:27:08.846Z)

Oh, okay.

### You (2025-06-23T15:27:10.243Z)

just an article on the two brothers. So yeah. Got it. So, yeah, he wants hear that. I'll go with that.

### Guest (2025-06-23T15:27:17.836Z)

Oh, okay.

### You (2025-06-23T15:27:18.243Z)

So

### Guest (2025-06-23T15:27:20.696Z)

Yeah. If you could share, I'll go through that.

### You (2025-06-23T15:27:23.323Z)

Cool. So

### Guest (2025-06-23T15:27:23.846Z)

So, yeah, if that happens this week, then I'll join. Otherwise, I'm gonna stay back.

### You (2025-06-23T15:27:26.353Z)

that that. So to that the info data I have

### Guest (2025-06-23T15:27:29.006Z)

So what I'll do is I'll just shoot that link

### You (2025-06-23T15:27:29.383Z)

look at the website. Right? Yeah. And I'll try to

### Guest (2025-06-23T15:27:32.766Z)

the team, probably they can have a look at the website. Right?

### You (2025-06-23T15:27:34.103Z)

how do we video? Using?

### Guest (2025-06-23T15:27:36.846Z)

I'll try to how do you record a video using

### You (2025-06-23T15:27:37.063Z)

Things? I mean, on the left hand side,

### Guest (2025-06-23T15:27:42.666Z)

Teams?

### You (2025-06-23T15:27:43.623Z)

under the apps,

### Guest (2025-06-23T15:27:43.776Z)

History. Mhmm.

### You (2025-06-23T15:27:46.493Z)

you should find one called Stream. The Stream. Right. Yeah. And just use that.

### Guest (2025-06-23T15:27:51.336Z)

Mhmm. The stream. Right. Right.

### You (2025-06-23T15:27:52.403Z)

It's it's pretty straightforward. Okay. Gotcha.

### Guest (2025-06-23T15:27:56.676Z)

Oh, gotcha.

### You (2025-06-23T15:27:57.163Z)

Sounds good. Sounds good. So, yeah, I'm just do that so that it would be be same time. For a group meeting. Okay.

### Guest (2025-06-23T15:28:02.736Z)

Sounds good. Sounds good. So, yeah, I'll just do that so that, you know, we save time.

### You (2025-06-23T15:28:03.283Z)

Cool. Alright. Awesome. Alright. Thank you. We'll see you then. Yeah. I'll let you know

### Guest (2025-06-23T15:28:06.896Z)

For our group meeting. So Awesome. Alright. Thank you, Art. I'll see you later.

### You (2025-06-23T15:28:13.203Z)

I'll let I'll let you know if I'm able to get that. Calculation to work. But I'm just gonna go ahead and shoot out a video of what I've got so far, and we'll take it from Yeah. So I'll you can

### Guest (2025-06-23T15:28:28.066Z)

Yeah. I mean, yeah. Yeah.

### You (2025-06-23T15:28:30.153Z)

Alright.

### Guest (2025-06-23T15:28:31.596Z)

You can really leave it if you want. I'll have a look at that today.

### You (2025-06-23T15:28:32.513Z)

Okay? Alright. Yeah. Yep. That's true. Alright.

### Guest (2025-06-23T15:28:36.466Z)

It is frustrating to look at the same thing.

### You (2025-06-23T15:28:37.823Z)

Talk to you soon.

### Guest (2025-06-23T15:28:39.816Z)

For so long.

### You (2025-06-23T15:28:40.073Z)

Bye. Bye.

### Guest (2025-06-23T15:28:44.726Z)

Okay. Bye.