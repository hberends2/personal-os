# data structure

**Date:** 2025-04-23 00:00:00 UTC
**Meeting ID:** 1424d1d0-1a06-46af-b8e5-8e976a6fe453
**Synced:** 2026-02-05 14:46:48

---

# Transcript for: data structure

### You (2025-04-23T16:29:58.611Z)

This is slow.

### Guest (2025-04-23T16:30:00.901Z)

Hello?

### You (2025-04-23T16:30:01.221Z)

Hey. How are you?

### Guest (2025-04-23T16:30:04.941Z)

Hello? Good. Good. How are you?

### You (2025-04-23T16:30:05.281Z)

Good. Now there's a swarming up. I'm, right after this call, I'm gonna head up to the lake house and spend the night up there and

### Guest (2025-04-23T16:30:21.931Z)

No. Amazing. Is it your lake house or you are renting it?

### You (2025-04-23T16:30:22.681Z)

No. We bought one last summer.

### Guest (2025-04-23T16:30:26.981Z)

Uh-huh.

### You (2025-04-23T16:30:27.811Z)

Really, it's it's really small. It's nice. I mean, it's on a nice lake. And Yeah. It's

### Guest (2025-04-23T16:30:36.461Z)

Uh-huh.

### You (2025-04-23T16:30:36.611Z)

like India. India would be What's that? Do you view it on the Airbnb? Or

### Guest (2025-04-23T16:30:39.301Z)

And do you like ERP and B, or what do you do? Do you give it on Airbnb or

### You (2025-04-23T16:30:41.881Z)

No. No. Not yet. It it needs a little bit before we can do anything like that. But I

### Guest (2025-04-23T16:30:49.851Z)

Oh, so is it empty?

### You (2025-04-23T16:30:49.941Z)

empty it? No. No. It's just something my wife and I use. But it it is it is quite small. Was actually built, like, fifty years ago. Uh-huh. Actually, I don't need that firefly.

### Guest (2025-04-23T16:31:02.071Z)

Uh-huh.

### You (2025-04-23T16:31:04.131Z)

Okay. Send me the address, please. I'll be there. Probably next. Yeah.

### Guest (2025-04-23T16:31:09.391Z)

Sir. Send me the address, please. I'll be there.

### You (2025-04-23T16:31:10.871Z)

Yeah. Yeah. It's it's just it's a small it's like

### Guest (2025-04-23T16:31:13.701Z)

Probably next

### You (2025-04-23T16:31:15.401Z)

two bedroom

### Guest (2025-04-23T16:31:15.571Z)

next to next weekend.

### You (2025-04-23T16:31:17.151Z)

but the bedrooms are small. They don't have a closet. But yeah, it's one of those things where they spent the money on the deck.

### Guest (2025-04-23T16:31:24.711Z)

Mhmm.

### You (2025-04-23T16:31:26.031Z)

And so on the lakeside, it's got this nice multilevel deck and

### Guest (2025-04-23T16:31:30.271Z)

Now

### You (2025-04-23T16:31:32.721Z)

perfect view of the lake and everything. So the the the house or the cottage, I always refer to it, is is enough for two people. That's about it. Yeah. You can't really have more than that. But nice nice

### Guest (2025-04-23T16:31:48.551Z)

Yeah. There's something on

### You (2025-04-23T16:31:52.371Z)

No. No. It's, I'm I'm in Michigan. It's just

### Guest (2025-04-23T16:31:54.061Z)

on, like, linear? Like, up in the

### You (2025-04-23T16:31:56.381Z)

yeah. It's just a Lake Montcalm is the name of it. It's only forty five minutes from our house.

### Guest (2025-04-23T16:31:56.781Z)

that area? Oh, you're in Michigan.

### You (2025-04-23T16:32:01.261Z)

So it's not like a major trip. We can just pretty much go out there whenever we want. So I'm actually giving some thought

### Guest (2025-04-23T16:32:08.751Z)

Nice.

### You (2025-04-23T16:32:09.781Z)

to you you know, you can actually buy small houses on Amazon Right? The like, the mini houses and yeah. There are some there are some that are they're they're not really shipping

### Guest (2025-04-23T16:32:18.281Z)

Mhmm.

### You (2025-04-23T16:32:21.111Z)

containers, but they're kinda similar. And and you can do different designs. You can stack them on top of each other. You can go side by side. And I'm think you know, I'm I'm looking at these, and it's like, I can get something like that for less than it would cost for me to to rebuild or to renovate the existing structure and everything, you know, because it's it's 50 years old. You know, it's kinda funny. We when we first got it, we had to replace the flooring. And we found out there isn't a square wall in the entire house. It's like, whoever built this thing fifty years ago, I don't think they I they just kinda laid down the the frame and and put it up any way they want. But, yeah, it's crazy. But nice place to just go and hang out.

### Guest (2025-04-23T16:33:18.181Z)

Cool. Okay. Alright. Well, cool.

### You (2025-04-23T16:33:21.401Z)

Yeah. And I see this

### Guest (2025-04-23T16:33:23.281Z)

So

### You (2025-04-23T16:33:24.631Z)

Excel.

### Guest (2025-04-23T16:33:25.311Z)

The SMS screen today. Yeah.

### You (2025-04-23T16:33:25.311Z)

Kind of thing. Yeah. Okay. Cool. So this is the one.

### Guest (2025-04-23T16:33:28.081Z)

Do you see this Excel

### You (2025-04-23T16:33:30.101Z)

That was, you know, prepared by the end of the hour.

### Guest (2025-04-23T16:33:30.831Z)

kind of thing? Yeah. Okay. Cool. So this is the model that was, you know,

### You (2025-04-23T16:33:34.601Z)

So what thinking before, like,

### Guest (2025-04-23T16:33:36.451Z)

prepared by Dion and then Howard.

### You (2025-04-23T16:33:37.291Z)

know, so data.

### Guest (2025-04-23T16:33:39.291Z)

So what I was thinking, if you could, like, you know,

### You (2025-04-23T16:33:42.801Z)

Some.

### Guest (2025-04-23T16:33:43.271Z)

So these these are the entered values and

### You (2025-04-23T16:33:43.301Z)

Is kind of calculated. To get 50.

### Guest (2025-04-23T16:33:47.101Z)

then then there's some which is kind of calculated.

### You (2025-04-23T16:33:50.701Z)

Like this. Right?

### Guest (2025-04-23T16:33:51.591Z)

This is not these are the real values

### You (2025-04-23T16:33:51.601Z)

So if you put probably let's say,

### Guest (2025-04-23T16:33:54.821Z)

and there's some calculated values. Like this. Right? So if you could

### You (2025-04-23T16:33:58.561Z)

something.

### Guest (2025-04-23T16:33:59.961Z)

probably say

### You (2025-04-23T16:34:01.001Z)

Let's see.

### Guest (2025-04-23T16:34:03.061Z)

if we could make something

### You (2025-04-23T16:34:05.451Z)

Yeah.

### Guest (2025-04-23T16:34:05.951Z)

like see. Create a new one. Say,

### You (2025-04-23T16:34:14.541Z)

Address. And then what I'm

### Guest (2025-04-23T16:34:16.151Z)

I think we were

### You (2025-04-23T16:34:16.791Z)

what I would add on that would be

### Guest (2025-04-23T16:34:17.851Z)

trying to get some I unique IDs, so let's call that ID name, then

### You (2025-04-23T16:34:18.811Z)

need to train And

### Guest (2025-04-23T16:34:22.821Z)

address, and then whatever whatever numerical values we need. Right?

### You (2025-04-23T16:34:23.341Z)

and with this simple where, like, this. Then

### Guest (2025-04-23T16:34:28.571Z)

In in a very simple

### You (2025-04-23T16:34:28.591Z)

know, I would think what I I don't know how long they're full and then that will make it easier to just

### Guest (2025-04-23T16:34:33.541Z)

way like this. Then, you know, everything in one line, I don't know how long that would go. And then

### You (2025-04-23T16:34:38.611Z)

Freeze. Property.

### Guest (2025-04-23T16:34:40.771Z)

that would kinda make it easier to just

### You (2025-04-23T16:34:41.471Z)

Based You're thinking, like, is it best for the

### Guest (2025-04-23T16:34:43.991Z)

run a simple script to extract that data.

### You (2025-04-23T16:34:45.381Z)

data model we're trying to. Right?

### Guest (2025-04-23T16:34:46.711Z)

For each

### You (2025-04-23T16:34:47.391Z)

Yeah.

### Guest (2025-04-23T16:34:48.581Z)

property. Basically, you're thinking, like, this is this is for the the data model you're talking about. Right?

### You (2025-04-23T16:34:52.221Z)

Okay. And then, you know, once we extract that data,

### Guest (2025-04-23T16:34:54.861Z)

Yeah. Yeah. How this is gonna translate to the data model? Yeah.

### You (2025-04-23T16:34:59.511Z)

and you.

### Guest (2025-04-23T16:35:03.341Z)

And then, you know, once we extract that in data,

### You (2025-04-23T16:35:04.261Z)

You know, to be

### Guest (2025-04-23T16:35:06.361Z)

in the database and the user kind of

### You (2025-04-23T16:35:08.221Z)

and that why basically, send the query

### Guest (2025-04-23T16:35:09.641Z)

goes in, tries to you know, view the model or download the model. At that point, we'll basically send the query and, you know, we'll have the so this template already has

### You (2025-04-23T16:35:24.221Z)

like this one. These ones. Yeah. And then just do the calculation.

### Guest (2025-04-23T16:35:25.691Z)

the calculations. Right? We'd only need to fill

### You (2025-04-23T16:35:28.411Z)

Would get done

### Guest (2025-04-23T16:35:30.091Z)

this certain

### You (2025-04-23T16:35:30.641Z)

on the application side,

### Guest (2025-04-23T16:35:31.011Z)

fields. Like this one.

### You (2025-04-23T16:35:32.451Z)

we'll have

### Guest (2025-04-23T16:35:33.621Z)

These ones, and then rest of the calculation would

### You (2025-04-23T16:35:34.031Z)

to you know, write all this logic, which is fine.

### Guest (2025-04-23T16:35:37.131Z)

get done. But on the application side,

### You (2025-04-23T16:35:37.341Z)

Yeah. Vinod, can you open up the, the red tab?

### Guest (2025-04-23T16:35:40.641Z)

we'll probably have to, you know, write all this logic, which is fine.

### You (2025-04-23T16:35:42.411Z)

So, Drew, this is what I sent out to everybody. So you've got a copy of this? Yeah. So if you filter column

### Guest (2025-04-23T16:35:48.851Z)

Yeah.

### You (2025-04-23T16:35:51.671Z)

I I think it must be over

### Guest (2025-04-23T16:35:54.221Z)

Yeah. I I was looking at this. Yeah.

### You (2025-04-23T16:35:55.861Z)

somewhere. A b c d looks like it might be hidden. Oh, yeah. The whether the the column that's the header where it says input or derived Yeah. If you just filter to show the I, columns, Those are all of the input fields.

### Guest (2025-04-23T16:36:13.091Z)

Yeah. Input out there.

### You (2025-04-23T16:36:15.811Z)

And you can probably hopefully, you can tell by the name that I put in there what it is. I tried to be as clear as possible. And then over on the right hand side, there are some that I found I I was explaining to

### Guest (2025-04-23T16:36:30.271Z)

Mhmm.

### You (2025-04-23T16:36:33.151Z)

As I started to go through this, I noticed that there's a lot of worksheets that have a column for year one, column for year two, etc. And I so I started making a named range for each year. So it might, you know, room's year one, room's year two. And then I realized that we don't need to do that. We could just have a rooms or or something that's you know, basically not going to change or be calculated. So on the right hand side, in the notes column, there are some that are marked as not needed or duplicates maybe not so much for the inputs, but for the calculated. Right. But there are quite a few input fields, and this is the only the only tabs that I did right now are the summary, the op the operating cash flow, op cash flow, the cash flow summary, assumptions, and five year and penetration. So I should have pretty much all of the input fields from those tabs listed in that chart. So I I'm thinking a good place to start would just be to compare what you have to what we need for inputs. Right? Yeah.

### Guest (2025-04-23T16:38:04.981Z)

Mhmm.

### You (2025-04-23T16:38:05.161Z)

So

### Guest (2025-04-23T16:38:11.111Z)

Yeah. Well okay. So just before we go through so

### You (2025-04-23T16:38:11.231Z)

something

### Guest (2025-04-23T16:38:14.001Z)

okay. Because the data model needs

### You (2025-04-23T16:38:14.821Z)

to something in the Yes. Right? Yes. So

### Guest (2025-04-23T16:38:18.691Z)

to have something in the data model needs to correspond to

### You (2025-04-23T16:38:21.941Z)

so if you wanna see, you know, for example, top row there, purchase

### Guest (2025-04-23T16:38:23.711Z)

something in this this named range, essentially. Right?

### You (2025-04-23T16:38:25.621Z)

price method, obviously, yes, the purchase price method and you can find that in summary c 16. So if you go to summary c it'll show you where it is what it does. But it it is something that a user inputs and then it's based on what the user inputs then flows through the rest of the bar rest of the model. So Yeah. So what I did is look at the cell formulas and anything that refers to the purchase price.

### Guest (2025-04-23T16:38:56.141Z)

Yeah.

### You (2025-04-23T16:38:57.831Z)

Method, you know, I replace the cell reference with that named range. So ideally, when the user goes through at the very beginning of the process, and this is what I was talking about yesterday, is we have to have this input go in a logical flow. So when they input all that information, the model will then be calculated. There's very, you know, very little that they need to do. And then they can go back and change one of the inputs if they wanna see a different scenario or something. Right?

### Guest (2025-04-23T16:39:29.081Z)

Yeah. And something that is like, a

### You (2025-04-23T16:39:43.471Z)

Like, you know,

### Guest (2025-04-23T16:39:45.061Z)

that is calculated based on I mean, this

### You (2025-04-23T16:39:45.221Z)

it's helping all. Revenue.

### Guest (2025-04-23T16:39:48.911Z)

this is not a good example, but, like,

### You (2025-04-23T16:39:50.051Z)

Yeah. Right.

### Guest (2025-04-23T16:39:51.811Z)

like, know, in all of these things, you're gonna have revenues, expenses, and then you want profit.

### You (2025-04-23T16:39:56.691Z)

In the data model. Like, you know,

### Guest (2025-04-23T16:39:58.201Z)

Right? Are are all three I guess, all three of those need to be in the in the data model. Like, you don't gonna be calculated on like, the way I guess

### You (2025-04-23T16:40:09.261Z)

Yeah.

### Guest (2025-04-23T16:40:11.631Z)

system, there are certain things that are not in the data model. They're just calculated when you pull up when you ask for it, when you query it. I don't know if that is, like, don't know. I don't know if it what what I I think the advantages are, I guess, like, smaller data model.

### You (2025-04-23T16:40:23.871Z)

For I just did every every

### Guest (2025-04-23T16:40:27.971Z)

Is that the same here? Like or would are we I guess, is is every every

### You (2025-04-23T16:40:35.681Z)

like revenue.

### Guest (2025-04-23T16:40:36.251Z)

or is everything gonna be in the data model? Does that make sense?

### You (2025-04-23T16:40:39.821Z)

And the profit

### Guest (2025-04-23T16:40:41.041Z)

Like, revenue expense profit is a good one. Right? Like, they're like,

### You (2025-04-23T16:40:43.911Z)

You know?

### Guest (2025-04-23T16:40:44.281Z)

revenues and expenses are something that you would put that you would input.

### You (2025-04-23T16:40:44.771Z)

Result of revenue. Right? So Yeah. Yeah. But you would have all of the inputs

### Guest (2025-04-23T16:40:48.181Z)

And the profit derived from that is something that you would you know, that's the result of revenue minus expenses.

### You (2025-04-23T16:40:52.161Z)

to calculate the revenue.

### Guest (2025-04-23T16:40:54.721Z)

Right? So

### You (2025-04-23T16:40:54.971Z)

Right? You'd know know, with of all these inputs that we have here, And, actually, I think this is

### Guest (2025-04-23T16:41:02.421Z)

Yeah.

### You (2025-04-23T16:41:03.371Z)

filter or sorted by yeah. So it's sorted alphabetically. Right? So you've got all your assumptions page. So if you go to the assumptions there, see every one of these items, everything in blue is where somebody has to input something. Right? So you input what your inflation rate is going to be, your assumed inflation rate, and you know, all the different things that are if you scroll down there just a little bit Vinod, see. So you've got your assumptions for your food and beverage. You've got your occupancy assumptions. All of those go in there. And then eventually, you're gonna have your you know, what is what is my revenue now? It'll calculate everything out there. So if I understand your question correctly, 100% of what the user's gonna do will be in this model. So they input their assumptions for revenue. They input their expense assumptions. It'll calculate on a, you know, per per available room, you know, per occupied room, whatever metric you want to see it, as well as the total dollar amount. For the revenue. It'll do the same thing for the expenses. Your total profit, etcetera. I mean, everything will be done for the user. Yeah. Yeah. Okay. Yeah.

### Guest (2025-04-23T16:42:38.541Z)

Yeah.

### You (2025-04-23T16:42:39.601Z)

Yeah. Is, like,

### Guest (2025-04-23T16:42:43.481Z)

Okay.

### You (2025-04-23T16:42:43.661Z)

on the application. In this coming from.

### Guest (2025-04-23T16:42:46.571Z)

Yeah. Drew, quick question. Yeah. So these assumptions is the user inserting it

### You (2025-04-23T16:42:49.971Z)

Or Yeah. That's that's what we that's that's why I think we need Drew to go through that red tab.

### Guest (2025-04-23T16:42:52.021Z)

on the application, or is this coming from the data that Drew provides or

### You (2025-04-23T16:42:57.871Z)

Know? As as much as possible, determine, you know, what data

### Guest (2025-04-23T16:43:02.021Z)

mhmm.

### You (2025-04-23T16:43:04.871Z)

could we get from him and what will the user actually have to type in themselves? Right. Right? So it, basically, like, when you get it we get

### Guest (2025-04-23T16:43:17.841Z)

Right.

### You (2025-04-23T16:43:17.871Z)

revenue expenses

### Guest (2025-04-23T16:43:21.281Z)

So the way the data usually like, when when we get it,

### You (2025-04-23T16:43:24.161Z)

which is like available.

### Guest (2025-04-23T16:43:25.791Z)

we get

### You (2025-04-23T16:43:26.061Z)

In.

### Guest (2025-04-23T16:43:26.671Z)

revenues,

### You (2025-04-23T16:43:27.551Z)

And then

### Guest (2025-04-23T16:43:28.421Z)

expenses,

### You (2025-04-23T16:43:29.281Z)

there's other statistics as well, you know, like,

### Guest (2025-04-23T16:43:29.901Z)

like your rooms statistics, which is, like, rooms available.

### You (2025-04-23T16:43:31.921Z)

Yeah. You know, customer count in the restaurant,

### Guest (2025-04-23T16:43:34.801Z)

And rooms sold.

### You (2025-04-23T16:43:35.081Z)

and like, labor hours.

### Guest (2025-04-23T16:43:36.291Z)

And then

### You (2025-04-23T16:43:37.241Z)

Sometimes utility

### Guest (2025-04-23T16:43:38.051Z)

there's other statistics as well. Usually,

### You (2025-04-23T16:43:38.961Z)

consumption, you know. Like gallons.

### Guest (2025-04-23T16:43:40.841Z)

You know,

### You (2025-04-23T16:43:40.921Z)

Of

### Guest (2025-04-23T16:43:41.981Z)

customer account in the restaurant,

### You (2025-04-23T16:43:42.101Z)

water. That sort of thing. Yeah.

### Guest (2025-04-23T16:43:43.831Z)

and, like, labor hours

### You (2025-04-23T16:43:45.191Z)

So

### Guest (2025-04-23T16:43:46.031Z)

sometimes utility consumption. You know?

### You (2025-04-23T16:43:46.091Z)

and then from that, the system

### Guest (2025-04-23T16:43:48.601Z)

Like,

### You (2025-04-23T16:43:48.941Z)

you know,

### Guest (2025-04-23T16:43:49.011Z)

gallons of

### You (2025-04-23T16:43:49.441Z)

to go

### Guest (2025-04-23T16:43:50.831Z)

water, that sort of thing.

### You (2025-04-23T16:43:50.911Z)

of our ecosystems, possibly I think

### Guest (2025-04-23T16:43:53.621Z)

So and then from that,

### You (2025-04-23T16:43:55.831Z)

would be one of them. And they're not

### Guest (2025-04-23T16:43:56.791Z)

this is

### You (2025-04-23T16:43:57.441Z)

you know, there's many problems

### Guest (2025-04-23T16:43:57.711Z)

know, most in our system, most systems calculate

### You (2025-04-23T16:43:58.431Z)

Just for a summary profit,

### Guest (2025-04-23T16:44:01.761Z)

the things they need. So profit, would be one of them. And there's not you know, there's many profits. There's gross operating profit. EBITDA, net operating income,

### You (2025-04-23T16:44:10.101Z)

basically anything

### Guest (2025-04-23T16:44:10.951Z)

departmental profit. There's all kinds of profits. Right? But you I just those would be calculated.

### You (2025-04-23T16:44:11.361Z)

stop. I t a r basis. Which is basically the amount

### Guest (2025-04-23T16:44:15.791Z)

And then there's you you you'll notice that

### You (2025-04-23T16:44:16.181Z)

divided by per available the same period.

### Guest (2025-04-23T16:44:18.941Z)

basically, anything is done on a PAR basis.

### You (2025-04-23T16:44:19.761Z)

Yep. And then p o r, it says

### Guest (2025-04-23T16:44:22.631Z)

Is basically

### You (2025-04-23T16:44:23.081Z)

it the amount

### Guest (2025-04-23T16:44:23.731Z)

the amount

### You (2025-04-23T16:44:24.651Z)

divided by

### Guest (2025-04-23T16:44:25.041Z)

divided by

### You (2025-04-23T16:44:25.711Z)

for

### Guest (2025-04-23T16:44:26.181Z)

per available rooms for the same period. And then a POR basis is

### You (2025-04-23T16:44:28.641Z)

period. Right. You on

### Guest (2025-04-23T16:44:32.441Z)

the amount divided by per occupied rooms for the same period. So usually I mean, so, like, I guess, what I was imagining is that

### You (2025-04-23T16:44:42.721Z)

expected.

### Guest (2025-04-23T16:44:43.451Z)

we would provide rooms excuse me. We provide

### You (2025-04-23T16:44:45.061Z)

And

### Guest (2025-04-23T16:44:47.211Z)

revenues, expenses, rooms available, rooms sold, and and other statistics if they're available.

### You (2025-04-23T16:44:51.011Z)

profits.

### Guest (2025-04-23T16:44:54.051Z)

And then the system

### You (2025-04-23T16:44:55.181Z)

Percent of revenue.

### Guest (2025-04-23T16:44:55.931Z)

would calculate

### You (2025-04-23T16:44:56.351Z)

Right? Let's just say, like, let's do it on the screen now, like, in hotel comp, PAR,

### Guest (2025-04-23T16:44:57.611Z)

prop all the different profits We calculate anything PAR, POR, percent of revenue,

### You (2025-04-23T16:45:03.331Z)

Right.

### Guest (2025-04-23T16:45:05.381Z)

Right? Those are things. So, like, what's showing on the screen now, like, info and telecom, PAR, info and telecom percent of revenue. Right? Like, that would be that would be calculated. I mean, these are assumptions, so they're gonna be input by the user. But the historical data

### You (2025-04-23T16:45:20.651Z)

Yeah. So the question I have is

### Guest (2025-04-23T16:45:21.261Z)

it goes you know, it goes into this you know, it goes it goes prior to the assumptions

### You (2025-04-23T16:45:24.391Z)

is that at the deal level, or is that market data, aggregated market data?

### Guest (2025-04-23T16:45:27.151Z)

or that the assumptions are based on would would come from us.

### You (2025-04-23T16:45:31.821Z)

So if I wanna buy the Holiday Inn down the street, and you've got that Holiday Inn data, we could just ingest that at the deal level.

### Guest (2025-04-23T16:45:38.471Z)

At the deal level for a specific property.

### You (2025-04-23T16:45:40.431Z)

Yeah. Historical. Right? You said? Like, you're gonna go

### Guest (2025-04-23T16:45:47.431Z)

Yeah. Well, usually, that's how yeah, usually, that's how you do it. We don't

### You (2025-04-23T16:45:51.621Z)

Yeah. You could do. Back and now get

### Guest (2025-04-23T16:45:54.111Z)

like, if you're gonna go buy the Holiday Inn on the street, you go get

### You (2025-04-23T16:45:55.171Z)

you know, market in the whole thing. Right. But no

### Guest (2025-04-23T16:45:58.121Z)

financial statements for the holiday in down the street.

### You (2025-04-23T16:45:58.781Z)

No. Of course not.

### Guest (2025-04-23T16:46:00.641Z)

I mean,

### You (2025-04-23T16:46:00.851Z)

Of course not. But that that's what I'm wondering is, you know, from I'm thinking visually,

### Guest (2025-04-23T16:46:01.321Z)

yeah, you you could do backup napkin, you know, market analysis.

### You (2025-04-23T16:46:05.701Z)

I'm I'm a visual person. You can describe things to me all day long, but

### Guest (2025-04-23T16:46:05.871Z)

But no one's gonna buy anything just based on that.

### You (2025-04-23T16:46:09.531Z)

so I'm thinking if you've got so you would have historical data on the holiday and down the street. Right? So with your data, I can get that information historically, and then the user has input their assumptions based on what they see plus what they get from the broker or the seller. To come up with their assumptions. Right? Yeah.

### Guest (2025-04-23T16:46:38.321Z)

Yeah. I mean, the broker is going through the same process. I mean, usually, it's like the seller, the broker,

### You (2025-04-23T16:46:45.771Z)

The pictures like

### Guest (2025-04-23T16:46:46.481Z)

the buyer,

### You (2025-04-23T16:46:47.281Z)

market forecast.

### Guest (2025-04-23T16:46:47.651Z)

Right? We're all all doing the same thing. They're taking the historicals,

### You (2025-04-23T16:46:49.831Z)

Economic data, you know.

### Guest (2025-04-23T16:46:51.421Z)

They're putting them into a model. They are looking at other factors, like,

### You (2025-04-23T16:46:52.481Z)

Supply and demand, whatever it and they're coming up with their projections. Yeah. Yeah. Exact same as multifamily.

### Guest (2025-04-23T16:46:56.381Z)

market forecasts, economic data, you know, market supply and demand, whatever it is.

### You (2025-04-23T16:46:59.531Z)

Mean Yeah. Pretty much all real estate. Yeah. Yeah.

### Guest (2025-04-23T16:47:02.691Z)

And they're coming up with their projections, right, their assumptions. It's yeah. Exactly. That's what the buyer yes. That's what the buyer is doing here. So we I what I think what where we come is

### You (2025-04-23T16:47:15.401Z)

Yeah. Rather than

### Guest (2025-04-23T16:47:16.581Z)

come in is that

### You (2025-04-23T16:47:17.211Z)

it's it's there.

### Guest (2025-04-23T16:47:18.401Z)

there are hundreds and hundreds of management companies with all their different charts of accounts and they're not standard. So rather than and and it's a very, like, time intensive laborious exercise to standardize all of So rather than like, you we could spend, you know, mean, we have basically built a whole company based on that. Right? So rather than have you have us do that as well,

### You (2025-04-23T16:47:40.101Z)

Thank

### Guest (2025-04-23T16:47:41.481Z)

basically, just what we're proposing is we just run everything through us. So if somebody wants to go buy the Holiday Inn down the street,

### You (2025-04-23T16:47:47.501Z)

you know that way.

### Guest (2025-04-23T16:47:48.131Z)

go to the owner. They say, the financials through Hotel BIS.

### You (2025-04-23T16:47:48.601Z)

Way. Yeah. That I mean, that that's perfect.

### Guest (2025-04-23T16:47:52.651Z)

And then when it's processed and standardized,

### You (2025-04-23T16:47:55.101Z)

So, Vinod, I think what we need to do is we need to segregate

### Guest (2025-04-23T16:47:56.031Z)

then, you know, Invesque will will pull it, you know, from our system, and it'll populate the model.

### You (2025-04-23T16:47:58.841Z)

what the user will have to manually input. Name, address, you know, certain functions, how many years do I plan to to hold the deal, you know, cap rate assumptions, things like that. But for the financial data, the revenue and expenses, I think what we would wanna do is once they input that data, we know okay, that he's buying the Holiday Inn. Down the street. We get that data from Drew and then they go through a second portion or second step, where based on the historical data, they then would make their assumptions. I can see maybe where we'd even just want to ingest what the what the broker provides. So good.

### Guest (2025-04-23T16:48:58.151Z)

Yeah. I think that

### You (2025-04-23T16:49:00.721Z)

Yeah.

### Guest (2025-04-23T16:49:03.101Z)

that's because if we you go back to the beginning here, we talked about sort of two separate cases where people do underwriting. In this case. Right? People that own hotels

### You (2025-04-23T16:49:12.141Z)

Yeah.

### Guest (2025-04-23T16:49:13.171Z)

it's probably I think it's the same multifamily. Like, if you're a publicly traded company, you have to

### You (2025-04-23T16:49:16.041Z)

Yeah.

### Guest (2025-04-23T16:49:17.711Z)

quarterly update the value of your portfolio and publish it

### You (2025-04-23T16:49:17.731Z)

Right. Right. And that's

### Guest (2025-04-23T16:49:21.651Z)

straight. Right? So people do this underwriting exercise every quarter. And it's very time intensive. Right? And that's for assets they already own.

### You (2025-04-23T16:49:30.481Z)

Yeah.

### Guest (2025-04-23T16:49:30.531Z)

So theoretically, like, we have customers that have you know, they're doing this. They're not using our system for it right now, but they're doing this in Excel. They're taking data, you know, from our system and and running it through Excel and building a model on top of it.

### You (2025-04-23T16:49:42.491Z)

Right.

### Guest (2025-04-23T16:49:43.301Z)

Right? That's one use case, which would be very easy to to layer on to layer

### You (2025-04-23T16:49:44.671Z)

It it you know, to go buy. Hotel. And and that they don't

### Guest (2025-04-23T16:49:47.611Z)

the invest, you know, on top of because the data's already being run through our system.

### You (2025-04-23T16:49:48.771Z)

Okay. Have to go to seller.

### Guest (2025-04-23T16:49:52.281Z)

The other use case is for somebody that is you know, wants to go buy a new hotel and and that they don't own Then they have to go to the seller or the broker get the data. Right? And that's where

### You (2025-04-23T16:49:59.591Z)

Yeah.

### Guest (2025-04-23T16:50:02.751Z)

you know, I think that's when we start to talk about, you know, pulling data from PDFs or financial statements. Scraping data essentially. And it and it would be more summary

### You (2025-04-23T16:50:12.061Z)

That.

### Guest (2025-04-23T16:50:13.511Z)

level. But I and I I I have suggested that we not get bogged down in worrying about that. Because

### You (2025-04-23T16:50:18.731Z)

Yeah.

### Guest (2025-04-23T16:50:18.831Z)

again, like,

### You (2025-04-23T16:50:19.411Z)

So

### Guest (2025-04-23T16:50:20.091Z)

that's a there's a lot of ways to go about that that I think

### You (2025-04-23T16:50:21.571Z)

don't I

### Guest (2025-04-23T16:50:22.921Z)

and it will depend on kind of where we are when the time comes to do it. So I don't think we need to necessarily worry about that. I think getting the the model getting the data model, getting the

### You (2025-04-23T16:50:28.911Z)

Yeah.

### Guest (2025-04-23T16:50:33.361Z)

the model itself to, you know, do the inputs and all that is is what that's what the users are gonna see. Yeah. So do that quarterly model creation that you said

### You (2025-04-23T16:50:39.751Z)

So yeah.

### Guest (2025-04-23T16:50:43.321Z)

the hotel owners or the traded companies do. So instead of them doing themselves, now they'll

### You (2025-04-23T16:50:50.931Z)

What

### Guest (2025-04-23T16:50:52.181Z)

basically give us all the data, and we'll do that for them. Right? That's what Or they would use yeah. They would use our system. So, like, one of our customers is Sunstone Hotel REIT. A public REIT. They have 15 hotels. They the asset managers use our system for, like, monthly reporting and in-depth analysis. And then they have an acquisitions team that goes to underwrite new hotels. They wanna buy. As as well as, you know, anytime that one of their existing hotels wants to refinance, or they are looking at selling it, they're doing a buy hold sell analysis. Or every and then every quarter, they do this quarterly valuation analysis. And they do it all in Excel. Right? So that's something that you know, that's the way that, like, yeah, an owner would use our you know, this invest platform to do the the quarterly valuation updates rather than doing it in Excel.

### You (2025-04-23T16:51:42.271Z)

Yeah.

### Guest (2025-04-23T16:51:44.541Z)

Okay. Did that answer your question? Yeah. That does. That does. Yeah. I think when it comes to I guess, like, you how do you separate it out? Like, assumptions, inputs, Did you I guess, like, did you kind of categorize things based on because, like, again, historical data coming from, like, pulling from our system. It's not really I mean, it's an input sort of. But it's not

### You (2025-04-23T16:52:19.431Z)

Yeah. To to to a certain extent.

### Guest (2025-04-23T16:52:19.581Z)

it's not like I mean, I guess, I see it as, like, different from the

### You (2025-04-23T16:52:22.631Z)

You know, I I do think that there's going to be inputs that have to be come from

### Guest (2025-04-23T16:52:23.881Z)

putting in the assumptions or from the, you know, calculated outputs. Did you

### You (2025-04-23T16:52:27.091Z)

have to come from the user.

### Guest (2025-04-23T16:52:27.811Z)

are you separating those

### You (2025-04-23T16:52:30.451Z)

And and that's anything that they're looking forward. Their forward projections, what what do I think my inflation factor is gonna be? What what is the revenue growth assumptions the expense growth assumptions over the next seven years, if they have a seven year hold period, all of that has to come directly from the investor. And based on what I've heard right now, I I I think we have three personas that would be using the tool. We've got the investor, We've got the broker. And then we've the asset manager who has to do quarterly updates. So looking from the at at the investor, persona, they're the ones who are looking to buy a deal. The broker will provide information, including their own assumptions. Right? Whether they do it with Invest or whether they do it in their own Excel model, they are going to come up with some assumptions. So I am thinking if we can ingest the broker assumptions, then the investor wouldn't have to go through and put everything in. Right? They can just review. And if they find something they don't agree with, then they can make a change. You know, they can just tweak that information. Of course, a broker using Invest, they would be the ones who basically have to fill in every little detail to get the model if they wanna use invest to come up with their formulas. Then the asset manager, same thing. But even the asset manager you know, that's where we would be ingesting your data

### Guest (2025-04-23T16:54:00.681Z)

Yeah.

### You (2025-04-23T16:54:03.581Z)

so that they can take a look at what has happened historically and then compare it to their deal. And and then same thing. At that point, they they'll probably wanna make some revisions you know, change some past assumptions and update them. Yeah. But if for the asset manager, I think what they're going to be doing is comparing actual operations to you know, happening in the market.

### Guest (2025-04-23T16:54:28.351Z)

Yeah.

### You (2025-04-23T16:54:29.481Z)

And then kind of forecasting, quarterly re forecasting of what they did, which then they could go through and tweak. So so, yeah, I think I think your data would obviously be used in all three scenarios.

### Guest (2025-04-23T16:54:43.901Z)

Yeah.

### You (2025-04-23T16:54:46.491Z)

To to give the the user a starting point saying, okay. Here here's what we've got up until this point. And then you know, the asset manager would kinda keep it there. The investors and the brokers would be projecting forward. So so, yeah, I think I think this is gonna all come together. So the question is, what structure of your data what is the structure compared to in the model? Right? Because you mentioned something about how many gallons of water or something I remember. Which isn't in the model, but that would roll up to, you know, utilities. So that's where we need to do is is start mapping what you have to what's in the model and identify any potential gaps.

### Guest (2025-04-23T16:55:47.961Z)

Yeah. Okay. Let me show you here. Let me share my screen. Yeah. Sure.

### You (2025-04-23T16:56:07.061Z)

So

### Guest (2025-04-23T16:56:16.971Z)

So actually, I'll choose the deals.

### You (2025-04-23T16:56:37.091Z)

Yeah.

### Guest (2025-04-23T16:56:44.541Z)

The data we you know, we get and would provide is

### You (2025-04-23T16:57:03.521Z)

Yeah.

### Guest (2025-04-23T16:57:10.331Z)

I mean, we can put it all in columns. It doesn't have to be filtered. But like, this would be year end 2024. Then there's usually actual and budget, and then the kind of account and department hierarchy part of it. Actually, I'll click it here. Is there's revenue like, this income statement statistics revenues and expenses, and then it just gets more granular.

### You (2025-04-23T16:57:54.851Z)

It's

### Guest (2025-04-23T16:57:57.371Z)

Right? So this is the

### You (2025-04-23T16:57:59.921Z)

Right.

### Guest (2025-04-23T16:58:04.821Z)

This is the sort of account part of the hierarchy. We have room sales, revenues and expenses, and then statistics. And then

### You (2025-04-23T16:58:19.511Z)

Okay. Right.

### Guest (2025-04-23T16:58:21.461Z)

what I was saying about, like, there's kind of a it's a two sort of a two dimensional or, like, a two prong like, hierarchy because there's also department. And right. So department is Show. It's it's really totally separate.

### You (2025-04-23T16:58:57.591Z)

Stuff.

### Guest (2025-04-23T16:58:58.091Z)

So departments are gonna be operating departments, undistributed, nonoperating.

### You (2025-04-23T16:59:04.511Z)

Like, with

### Guest (2025-04-23T16:59:04.881Z)

Then there's gonna be, you know, different

### You (2025-04-23T16:59:07.921Z)

with

### Guest (2025-04-23T16:59:12.521Z)

Alright. Like, within within, like, rooms, you're gonna have again, kind of, like, a small select service property is not gonna like, all this stuff in there. It's gonna have really just, like, couple of these, but the big resort will have, like, different restaurants, things like catering. Right? This is all, like, different level. And as if if you think about the way that the model is laid out, they're sort of, like, a revenue revenues and expenses and statistics within each each of these departments. And they you know, so when you kind of layer them together, they they look like,

### You (2025-04-23T16:59:42.061Z)

Sorry.

### Guest (2025-04-23T16:59:49.971Z)

know, they look kinda like our summary. We call it a summary p and l, but it's basically, like, you know, operating departments, revenues, like, current amounts, so you'll start to see Alright. So you get revenues, rooms, F and B, other miscellaneous and expenses. Undistributed expenses, nonoperating, then there's, you know, different statistics, like rooms available, rooms sold, customers, labor, staff, etcetera. So so as far as, like, what what I was envisioning we would provide is the basic data. So revenues, expenses, and then the statistics. And then the like, on our end or, you know, on the invest

### You (2025-04-23T17:00:46.231Z)

Right.

### Guest (2025-04-23T17:00:49.251Z)

end, we calculate profits you know, anything PAR or POR percent of revenue. And and there is and it you know, what you said, we were talking about, like, how there's, like, year you know, there's a year one room revenue year two room revenue, year three room revenue, and then there's also gonna be historically. It's gonna be, like,

### You (2025-04-23T17:01:07.771Z)

That guess, like, I don't I'm not

### Guest (2025-04-23T17:01:11.391Z)

in 02/2019 room revenue. Right? 02/2020 room revenue. Right? So

### You (2025-04-23T17:01:13.851Z)

I know that the way things

### Guest (2025-04-23T17:01:15.881Z)

that I guess, like, you

### You (2025-04-23T17:01:16.841Z)

right? So I don't play

### Guest (2025-04-23T17:01:20.451Z)

I don't I'm not I'm not a tech technology person, but,

### You (2025-04-23T17:01:23.241Z)

In

### Guest (2025-04-23T17:01:25.061Z)

I know that you have the way things happen in columns or rows.

### You (2025-04-23T17:01:25.241Z)

I guess, I there are same thing over

### Guest (2025-04-23T17:01:28.251Z)

Right? So

### You (2025-04-23T17:01:29.241Z)

here. This is right. So I don't know that in a couple more

### Guest (2025-04-23T17:01:32.411Z)

I don't like,

### You (2025-04-23T17:01:33.881Z)

in the data model.

### Guest (2025-04-23T17:01:35.141Z)

I guess, like, there are, you know, there are

### You (2025-04-23T17:01:38.211Z)

Provided.

### Guest (2025-04-23T17:01:38.811Z)

the same thing over and over again for each year.

### You (2025-04-23T17:01:39.951Z)

No.

### Guest (2025-04-23T17:01:41.271Z)

Exists. Right? So I don't know if it makes us put that in a column or a row. In the data model. Like, I can provide it how however, I think, you were saying it makes sense

### You (2025-04-23T17:01:45.761Z)

Yeah. Here, I'll just put this in here. And the reason

### Guest (2025-04-23T17:01:49.301Z)

to provide it down a column because that's No. It's fine. I mean, either either way is fine. I'm just trying to oversimplify it.

### You (2025-04-23T17:01:55.041Z)

too much time. It's just

### Guest (2025-04-23T17:01:55.911Z)

Right. Here, I'll just put this in here.

### You (2025-04-23T17:01:57.321Z)

data extraction. But because that's just no.

### Guest (2025-04-23T17:02:03.331Z)

And the reason being because I I don't always spend

### You (2025-04-23T17:02:03.461Z)

I want some

### Guest (2025-04-23T17:02:06.341Z)

too much time in just data extraction part.

### You (2025-04-23T17:02:07.581Z)

data extraction.

### Guest (2025-04-23T17:02:09.901Z)

Because

### You (2025-04-23T17:02:10.121Z)

So

### Guest (2025-04-23T17:02:11.091Z)

that's just for our internal you know, data capturing. I wanna focus on the application development and

### You (2025-04-23T17:02:16.071Z)

Right? So and I

### Guest (2025-04-23T17:02:18.891Z)

the data extraction. Yeah.

### You (2025-04-23T17:02:18.991Z)

we discussed

### Guest (2025-04-23T17:02:21.241Z)

So which was slow? So, basically, like, you know,

### You (2025-04-23T17:02:24.871Z)

You know?

### Guest (2025-04-23T17:02:25.531Z)

this is the data by month. Right?

### You (2025-04-23T17:02:28.551Z)

On so long.

### Guest (2025-04-23T17:02:29.011Z)

So and I think we discussed like, I would provide it at a much more granular level

### You (2025-04-23T17:02:32.381Z)

On It's when we provide it.

### Guest (2025-04-23T17:02:35.911Z)

You know? And and, again, we can provide it rather than having the

### You (2025-04-23T17:02:36.271Z)

Right? So you're I'll do

### Guest (2025-04-23T17:02:39.741Z)

months along the columns. We can have it

### You (2025-04-23T17:02:40.891Z)

right. So now

### Guest (2025-04-23T17:02:42.431Z)

down the row. So it can look like this. When we provide it.

### You (2025-04-23T17:02:45.281Z)

it's

### Guest (2025-04-23T17:02:47.401Z)

Right? So here it's

### You (2025-04-23T17:02:48.061Z)

it's

### Guest (2025-04-23T17:02:50.021Z)

here. I'll do

### You (2025-04-23T17:02:51.541Z)

I'm on. From the data

### Guest (2025-04-23T17:02:55.021Z)

right. So now it's down down down the road. It's collapsed but there would be monthly, you know, as you get you or expand each of these, you'd get a whole ton of data.

### You (2025-04-23T17:03:00.721Z)

I don't know.

### Guest (2025-04-23T17:03:02.791Z)

By month, and we can do multiple years. From the data model, I this is the so what I'm getting what I'm ultimately getting to is

### You (2025-04-23T17:03:07.271Z)

You know, better to have growth. On

### Guest (2025-04-23T17:03:11.781Z)

I don't know if it makes sense. I don't know what the advantages and

### You (2025-04-23T17:03:12.401Z)

Reach bridge property.

### Guest (2025-04-23T17:03:14.891Z)

disadvantages are putting something in a row or a column.

### You (2025-04-23T17:03:15.541Z)

In the data model. Assuming there'll be a take

### Guest (2025-04-23T17:03:18.371Z)

You know, is it better to have

### You (2025-04-23T17:03:19.571Z)

Like,

### Guest (2025-04-23T17:03:20.221Z)

one really, really, really long row or multiple columns? For each

### You (2025-04-23T17:03:23.991Z)

you know, operating unit

### Guest (2025-04-23T17:03:24.731Z)

for each property.

### You (2025-04-23T17:03:25.761Z)

much operating unit.

### Guest (2025-04-23T17:03:26.681Z)

In the data model. I'm assuming there'll be a table for

### You (2025-04-23T17:03:29.101Z)

And then also, know, know,

### Guest (2025-04-23T17:03:34.021Z)

like, you know, operating unit and then a bunch of operating unit attributes

### You (2025-04-23T17:03:35.311Z)

put in

### Guest (2025-04-23T17:03:40.241Z)

And then also, again, like, the numbers, the historical data, the projections,

### You (2025-04-23T17:03:41.721Z)

You know, what on the road, column,

### Guest (2025-04-23T17:03:45.671Z)

that that are being put into the system that are saved. So I don't know if makes sense to have those down one, you know, in one long row or

### You (2025-04-23T17:03:49.411Z)

back

### Guest (2025-04-23T17:03:53.221Z)

you know, in one in in know, down the rows in one column. Or in a combination thereof.

### You (2025-04-23T17:03:59.201Z)

So

### Guest (2025-04-23T17:04:00.881Z)

That makes sense? Yeah. I mean, let's let's I mean, you you send me something. I'll

### You (2025-04-23T17:04:13.511Z)

Okay. Yeah.

### Guest (2025-04-23T17:04:14.631Z)

try to play around. Let's see how that works out. Also not, very sure what would be the easiest

### You (2025-04-23T17:04:19.991Z)

Yeah. Okay.

### Guest (2025-04-23T17:04:21.321Z)

way to extract it.

### You (2025-04-23T17:04:21.891Z)

And, Drew, for my purposes,

### Guest (2025-04-23T17:04:22.981Z)

But, yeah, I mean,

### You (2025-04-23T17:04:25.191Z)

you mentioned getting a little bit more granular in some of those

### Guest (2025-04-23T17:04:26.131Z)

send me a sample. I'll try to play around and see how that works out.

### You (2025-04-23T17:04:28.701Z)

areas. Do you have that available now, or is that something

### Guest (2025-04-23T17:04:31.401Z)

Okay.

### You (2025-04-23T17:04:32.351Z)

still need to work on? Okay. That's that's okay about the account numbers, but can you send me either a printout or or something that shows each

### Guest (2025-04-23T17:04:44.091Z)

No. No. I have that. I don't have account numbers yet. I have to ask about that.

### You (2025-04-23T17:04:46.561Z)

row. Yeah. Subcategory, etcetera? Yeah. I I I mean, I can look through some old emails, but if you've got something

### Guest (2025-04-23T17:04:58.821Z)

Yeah. So this is something I sent previously.

### You (2025-04-23T17:05:00.431Z)

yeah.

### Guest (2025-04-23T17:05:02.101Z)

Yeah. It's something I sent previously, which I'll send again. But basically, it has

### You (2025-04-23T17:05:07.111Z)

Yeah.

### Guest (2025-04-23T17:05:09.771Z)

that's fine. This has basically right, like, the different levels of our account hierarchy.

### You (2025-04-23T17:05:16.961Z)

Right. Like you know,

### Guest (2025-04-23T17:05:18.661Z)

So account type, account class,

### You (2025-04-23T17:05:21.901Z)

Yeah.

### Guest (2025-04-23T17:05:22.801Z)

account category, subcategory, and then this this one is kind of set up for select service. It's

### You (2025-04-23T17:05:24.451Z)

It's

### Guest (2025-04-23T17:05:27.621Z)

It's less right? It's like you know, it's not not the full level of detail, but

### You (2025-04-23T17:05:35.551Z)

Yeah.

### Guest (2025-04-23T17:05:36.411Z)

this one's more granular, which would be more for, like, a full service. And I think what we're talking the way we were

### You (2025-04-23T17:05:41.041Z)

Okay. Yeah. Because we're not

### Guest (2025-04-23T17:05:42.291Z)

talking about is, like, you would just use

### You (2025-04-23T17:05:42.811Z)

what I need to do is to compare the category and subcategory

### Guest (2025-04-23T17:05:44.091Z)

you just get the most granular data for everything.

### You (2025-04-23T17:05:46.971Z)

to the input fields in the model.

### Guest (2025-04-23T17:05:48.881Z)

So

### You (2025-04-23T17:05:50.411Z)

To see, you know, is there a one to one relationship? Are we gonna have to

### Guest (2025-04-23T17:05:50.531Z)

yeah, I I'll resend you this and you can look at it.

### You (2025-04-23T17:05:56.111Z)

yeah. No. I yeah. I can see that. So

### Guest (2025-04-23T17:06:03.281Z)

No. I can tell you right off the bat, it's not.

### You (2025-04-23T17:06:04.821Z)

Yes. Yeah.

### Guest (2025-04-23T17:06:09.431Z)

It it'll be more like the in the parts of the model are gonna be much higher up

### You (2025-04-23T17:06:15.101Z)

I could

### Guest (2025-04-23T17:06:16.071Z)

Right? So

### You (2025-04-23T17:06:17.201Z)

just play this.

### Guest (2025-04-23T17:06:17.371Z)

like, there's gonna be

### You (2025-04-23T17:06:18.841Z)

In Yep.

### Guest (2025-04-23T17:06:22.331Z)

I mean, at the at the right. Like, at the I guess, it's like the the the the first input level that we were talking about

### You (2025-04-23T17:06:26.921Z)

Like, basically,

### Guest (2025-04-23T17:06:31.811Z)

know, if don't consider any of these, like, breakout tabs we were talking about,

### You (2025-04-23T17:06:34.391Z)

Right.

### Guest (2025-04-23T17:06:36.271Z)

then, you know, you're gonna have, like, basically, like,

### You (2025-04-23T17:06:39.801Z)

Yeah. Right.

### Guest (2025-04-23T17:06:40.421Z)

you're only gonna be going almost down to, like, the where where is

### You (2025-04-23T17:06:40.811Z)

Yeah.

### Guest (2025-04-23T17:06:45.391Z)

it? Right. Account class level. Like, you're gonna be looking at, like,

### You (2025-04-23T17:06:47.101Z)

Yeah.

### Guest (2025-04-23T17:06:48.871Z)

rooms department, revenue. Right? That's you know? And then are you looking at on an amount basis, a POR basis? Or a PAR basis. Right? And then same for SMB, basically gonna be, like, SMB revenue. So you know, like, we can we can give you all the additional detail because it'll be

### You (2025-04-23T17:07:03.931Z)

No. Yeah.

### Guest (2025-04-23T17:07:07.511Z)

you know, relevant for for for break for, like, doing breakout tabs. Right? Like, down the road. But at in this initial phase, like, it's really gonna be just the the more high level

### You (2025-04-23T17:07:17.101Z)

Yeah. Yeah. So, yeah, what I'll do is I'll take a look at that and then

### Guest (2025-04-23T17:07:21.641Z)

that that is good that is gonna

### You (2025-04-23T17:07:21.931Z)

I'll work with Vinod to make sure that everything is mapped to

### Guest (2025-04-23T17:07:24.231Z)

match to what the users are are

### You (2025-04-23T17:07:25.591Z)

whatever the field name is in the database from Excel.

### Guest (2025-04-23T17:07:26.801Z)

you know, getting out and putting in.

### You (2025-04-23T17:07:30.961Z)

If there's something that needs to be rolled up into a single category, we'll take a look at that. But this will be extremely helpful. So Yeah. So

### Guest (2025-04-23T17:07:49.531Z)

Yeah. I'll actually, what I'll do is I'll provide So this tab right here, I'll just call it, like,

### You (2025-04-23T17:08:01.841Z)

Yeah. Right. Yeah.

### Guest (2025-04-23T17:08:11.291Z)

assumptions level detail,

### You (2025-04-23T17:08:12.471Z)

Right.

### Guest (2025-04-23T17:08:13.281Z)

Right? This is really gonna match with with your assumptions. Right? Vroom department, revenue, revenue for food and beverage, revenue for other operated, miscellaneous, then your various expenses. Right? You might look at it on a amount, POR, p p a r, you know, percent of revenue. Or, you know, I don't know if she had, like, per cover per cover

### You (2025-04-23T17:08:41.071Z)

Right.

### Guest (2025-04-23T17:08:42.891Z)

or what would be the other ones? Or yeah. That's probably it. Or maybe yeah. That's probably

### You (2025-04-23T17:08:47.711Z)

Yeah.

### Guest (2025-04-23T17:08:48.921Z)

it. But so that would basically be

### You (2025-04-23T17:08:52.441Z)

Right. Right.

### Guest (2025-04-23T17:08:52.831Z)

right. Like, POR is

### You (2025-04-23T17:08:53.861Z)

Right.

### Guest (2025-04-23T17:08:55.551Z)

is just gonna be like this. Divided by your by your occupancy statistic.

### You (2025-04-23T17:09:01.841Z)

Right.

### Guest (2025-04-23T17:09:03.781Z)

Right?

### You (2025-04-23T17:09:04.641Z)

This one.

### Guest (2025-04-23T17:09:05.811Z)

And then PAR is gonna be the same thing just divided by your available rooms.

### You (2025-04-23T17:09:12.751Z)

Well, you know, the the the model already has

### Guest (2025-04-23T17:09:14.611Z)

Right? And

### You (2025-04-23T17:09:15.801Z)

that in there. So if we knew the total

### Guest (2025-04-23T17:09:16.541Z)

this one is gonna be based on just

### You (2025-04-23T17:09:18.271Z)

and we knew we've already got the occupied rooms and the available rooms,

### Guest (2025-04-23T17:09:18.881Z)

well, you'd have to do total revenue, but you get the idea.

### You (2025-04-23T17:09:22.941Z)

It'll it'll we'll calculate that within the model.

### Guest (2025-04-23T17:09:23.221Z)

And and

### You (2025-04-23T17:09:25.421Z)

So No. No. Don't really need that right now.

### Guest (2025-04-23T17:09:34.691Z)

Okay. So you don't you don't okay. Good. So Yeah. Okay. So, yeah, I think if you use this, like, this will be again, like, if you look at this tab, it'll kind of match what you're gonna put it in the assumption or

### You (2025-04-23T17:09:49.221Z)

Okay.

### Guest (2025-04-23T17:09:51.191Z)

assumptions level detail, but then this will be I'll put in the sort of all the detail that we have in our system. And you can just again, like, match up the names of the hierarchy from here to over here, and you'll see that

### You (2025-04-23T17:10:05.321Z)

Right.

### Guest (2025-04-23T17:10:08.431Z)

it's basically just the stuff you know, account type, account class, department type, department class. That's really what I left over here. These four because that that is, like, the two top levels of the account hierarchy and the department hierarchy to get

### You (2025-04-23T17:10:21.741Z)

Regular.

### Guest (2025-04-23T17:10:23.541Z)

kinda your what you need at the summary level. And then there's all this additional detail for you know, more granularity, department category, department group, account category, account subcategory, account account. So that gets

### You (2025-04-23T17:10:31.771Z)

Got Perfect.

### Guest (2025-04-23T17:10:35.261Z)

you, you know, a whole ton more detail.

### You (2025-04-23T17:10:36.611Z)

That'll be very helpful.

### Guest (2025-04-23T17:10:38.881Z)

That yeah, we just get rolled up until you use it in a breakout tab.

### You (2025-04-23T17:10:45.131Z)

K.

### Guest (2025-04-23T17:10:45.781Z)

Cool. Yeah. So, Drew, so this is for one property. Suppose we have to do it for hundred properties. So there will be different file for each property, or will

### You (2025-04-23T17:10:58.361Z)

Yeah.

### Guest (2025-04-23T17:11:00.001Z)

have that data? Either. I we can do I think the way the API works

### You (2025-04-23T17:11:02.491Z)

Mean

### Guest (2025-04-23T17:11:05.981Z)

like, yeah. The way the way the a let me show you.

### You (2025-04-23T17:11:12.901Z)

So

### Guest (2025-04-23T17:11:13.731Z)

Mean, this the API we have that is being used right now is specific to one customer. So

### You (2025-04-23T17:11:32.781Z)

Okay. We have So

### Guest (2025-04-23T17:11:44.031Z)

Okay. The API we have now is specific to one customer. So it does have an account number

### You (2025-04-23T17:11:54.541Z)

like the department. And then

### Guest (2025-04-23T17:11:56.141Z)

It's a very long number, because it's not actually, like, a target account. It's actually using, a combination of ID codes And this is, like, the department. And then it has operating unit ID, and then the, you know, the month month, year, the amount. And then this transaction ID is, like, basically the unique identifier. For that row. Mhmm. And then this in the comments section, it includes it basically prints out the hierarchy. Right? So this is, like, income statement, revenue, operating department, food and beverage, minor, and the they were telling me exactly what this row is. Although, I think the way that they the system would use it is it just reads these numbers and maps it accordingly. Right? So this is really just for reference. It's actually just mapping based on these numbers. But in this case, it you know, this this is like I mean, this one's only 3,700 rows because it's only three or four properties.

### You (2025-04-23T17:12:55.101Z)

Yeah. Different.

### Guest (2025-04-23T17:12:56.221Z)

But the way it usually works is they

### You (2025-04-23T17:12:58.051Z)

Yeah. And and that reminds me

### Guest (2025-04-23T17:12:58.101Z)

it, you know, it it they pull all the all the properties at once. So it's

### You (2025-04-23T17:13:02.001Z)

know, we had talked in previous conversation about

### Guest (2025-04-23T17:13:02.711Z)

I think in some cases, it's hundreds of thousands of rows.

### You (2025-04-23T17:13:04.281Z)

making sure we have a industry wide unique ID. I think that was coming

### Guest (2025-04-23T17:13:06.731Z)

Yeah. And they're just differentiating the property by the ID number.

### You (2025-04-23T17:13:08.981Z)

was from the star report or some some organization out there. Right. Which

### Guest (2025-04-23T17:13:24.981Z)

Yeah. STR. They

### You (2025-04-23T17:13:26.661Z)

Yeah.

### Guest (2025-04-23T17:13:29.501Z)

they have

### You (2025-04-23T17:13:30.611Z)

Now.

### Guest (2025-04-23T17:13:31.521Z)

unique identifiers for every property. Which I think we can use. It's called a set they call it a census ID. So I'll include that

### You (2025-04-23T17:13:39.641Z)

Right.

### Guest (2025-04-23T17:13:40.191Z)

like, if it's here for reference for now.

### You (2025-04-23T17:13:40.901Z)

Okay.

### Guest (2025-04-23T17:13:42.551Z)

When I send know, when we start sending data, we can just use that Like, it's so, basically, it'll just be in another column. Right? So then it'll be, like, census ID here. And I'll we can put in anything else too, like, currency, year,

### You (2025-04-23T17:14:01.771Z)

Alright. Yeah. Because what I would love to do

### Guest (2025-04-23T17:14:03.101Z)

Again, there's act forecast and budget.

### You (2025-04-23T17:14:05.311Z)

you know, this is just one of the little wow factors that would

### Guest (2025-04-23T17:14:06.371Z)

Put all these things in the filters right now, but I think when we actually do the data, these would all be

### You (2025-04-23T17:14:08.981Z)

impress a lot of people is that

### Guest (2025-04-23T17:14:10.841Z)

columns.

### You (2025-04-23T17:14:10.881Z)

if if I'm an investor,

### Guest (2025-04-23T17:14:11.971Z)

So you'll have more columns.

### You (2025-04-23T17:14:12.971Z)

and I'm starting to create a deal and invest so that I can underwrite it, You know, I would like to have a smart search where I can start typing in, know, holiday in blah blah blah, and then all of a sudden, you know, and see, you know, isn't this holiday in, you know, when I start putting in the street address, you know, and then have that that census ID, that one ID, you know, then they can click yes, and then it can prepopulate all this information we would already have in the system. Yeah. Save a lot of time, a lot of things where they wouldn't have to go in there and manually and input. And we've that that way, we know consistently that if somebody else is underwriting it, they've got the

### Guest (2025-04-23T17:14:54.401Z)

Yeah.

### You (2025-04-23T17:14:55.691Z)

the same deal. So you know, what I'm looking at, and we've talked about all the time, is the data that we can be getting And so we know that we can we can do apples to apples comparison of all the data that we get out there know that it's there, have the historical rights. So ten years from now, somebody else wants to go and underwrite it. We've got all that same information going back, even though the current owner may only have know, five years. Yeah. So, yeah, that that'll that'll be huge. Alright. So

### Guest (2025-04-23T17:15:34.431Z)

Yeah.

### You (2025-04-23T17:15:34.881Z)

Yeah.

### Guest (2025-04-23T17:15:39.631Z)

Alright. Yeah. I'm just setting this up so it looks a little more like I think it will in the end. Then we're also in here. Alright. So end in fifteen minutes. Yeah, Drew, if you could resend, say,

### You (2025-04-23T17:16:34.101Z)

Stop.

### Guest (2025-04-23T17:16:37.931Z)

properties in the format, then

### You (2025-04-23T17:16:38.361Z)

Yeah. This will be very helpful. Appreciate it.

### Guest (2025-04-23T17:16:40.831Z)

you know, I think it's a table start playing around the extraction Alright. Yeah. I'll send a couple. Different sizes here. Let's see. Alright. This will be I don't know how many properties this is, but I think it's more than 10, probably close to, like, 20. Okay. Cool. And this is guess, do want me to send because I just sent twenty twenty five data right now, but I can pull maybe additional years as well. I mean, do you want me to send, like, additional years now, or do you wanna take a look at

### You (2025-04-23T17:18:11.391Z)

Okay. So

### Guest (2025-04-23T17:18:15.981Z)

at it for one year and then when you're ready, I can do more. Yeah. I think one year is fine now. Okay. So let me move this over.

### You (2025-04-23T17:18:33.211Z)

Okay. So

### Guest (2025-04-23T17:18:44.991Z)

Okay. So we'll just base it off on the ID. Right? That's what we were saying. Census ID. Yeah. Yeah. I'll put that in. Okay. And just so, like, the the the first, like, two columns will be version period and financial type. Okay. So that's gonna be version period. In this case, be twenty twenty five dash two, which means it's the actual it's basically the forecast from

### You (2025-04-23T17:19:09.801Z)

So

### Guest (2025-04-23T17:19:13.641Z)

from February. So it's actuals for for January, February, and then forecast for March to December. So and then, you know, like, each month, we get a new dataset that has one additional month of actuals and an updated forecast. And then, you know, there's also budget. Right? So

### You (2025-04-23T17:19:30.821Z)

So

### Guest (2025-04-23T17:19:32.981Z)

you'll see budget down here. At the bottom for all these properties. Right? So And is it possible to send couple of

### You (2025-04-23T17:19:46.981Z)

Did

### Guest (2025-04-23T17:19:47.331Z)

them from 2024 so that we can get the full year data? Yeah. This is so the way hotels work, if you get it, why this is hotels and being a lot more complicated than most family is this is full year. It is twelve months Every month, we get a new twelve month dataset. So it's because even the property the operators themselves, the hotels themselves do a forecast. So it is this is the forecast. Like, in this particular case, because it's version twenty twenty five dash two,

### You (2025-04-23T17:20:23.051Z)

So, like,

### Guest (2025-04-23T17:20:25.181Z)

January and February are actuals, and then

### You (2025-04-23T17:20:26.601Z)

does it

### Guest (2025-04-23T17:20:28.251Z)

the, you know, March through December are forecast.

### You (2025-04-23T17:20:29.831Z)

March

### Guest (2025-04-23T17:20:31.731Z)

And then come twenty twenty four dash three, so, like, when we get the next dataset, then it's three months of actuals. The the January, February won't change.

### You (2025-04-23T17:20:39.401Z)

I did not realize that it included forecast data that

### Guest (2025-04-23T17:20:40.811Z)

But but March will be actualized and will be an updated forecast for the rest of the year.

### You (2025-04-23T17:20:43.861Z)

is

### Guest (2025-04-23T17:20:45.571Z)

And this happens every month.

### You (2025-04-23T17:20:46.081Z)

very cool. Yeah. I thought

### Guest (2025-04-23T17:20:46.931Z)

So by the end of the year, you get 12 versions of a forecast of the forecast.

### You (2025-04-23T17:20:50.041Z)

lot with this data. Oh my gosh. Yeah. Every month, you know, for all

### Guest (2025-04-23T17:20:59.001Z)

Yeah. It's all it's yeah. That's why I mean, so we have every month's forecasts, you know, for for all the hotels. And, again, they send it every month. So what with the underwriters, like, when you're underwriting, usually, like, I was kinda saying, right, like, your current year, you know, you're you're gonna look back at you last five years of actuals. And then for your current year, you might wanna look at a t 12. You might wanna look at the current forecast, or you might wanna look at the current budget. Right? So that's sort of, like,

### You (2025-04-23T17:21:33.761Z)

Yeah.

### Guest (2025-04-23T17:21:34.561Z)

what what does the particular user that's doing the underwriting wanna

### You (2025-04-23T17:21:38.011Z)

Yeah.

### Guest (2025-04-23T17:21:38.091Z)

use as their current year

### You (2025-04-23T17:21:40.111Z)

That

### Guest (2025-04-23T17:21:40.341Z)

or maybe they wanna

### You (2025-04-23T17:21:40.791Z)

sort

### Guest (2025-04-23T17:21:41.441Z)

maybe they don't wanna use anything from the property for for that. Maybe they just wanna use the t 12 or the prior year actuals and then just do their own

### You (2025-04-23T17:21:42.791Z)

we can. Right. Work. Right.

### Guest (2025-04-23T17:21:49.281Z)

current year. Right? So that's sort of where

### You (2025-04-23T17:21:52.951Z)

Yeah.

### Guest (2025-04-23T17:21:54.421Z)

again, but you have to you have to have accounts for this in the data model. Right? You have to have that many rather than just having, like, a year and an actual and a budget. You're gonna have a year and 12 versions of the forecast and then a budget. So then there being a lot more a lot more data. Yeah, I'll I'll include 2024 as well. So probably I don't know how many rows. This probably be three or 400,000 rows, but Yeah. And when I the other thing in addition to, you know, how we're talking about, like, there's you know, room revenue for year one, revenue for year two, room revenue for year three. Right? I and I don't know if you wanna put that in all in one row or in you know, maybe there's row some something is in a row, something in a column. The other thing where there is sort of that row column dynamic

### You (2025-04-23T17:22:44.951Z)

Yeah.

### Guest (2025-04-23T17:22:45.011Z)

if you wanna take advantage of it, is in

### You (2025-04-23T17:22:47.941Z)

Right.

### Guest (2025-04-23T17:22:47.951Z)

separating out department from account. Right? So you have revenue for rooms, revenue for food and beverage, revenue for you know, other operated revenue for miscellaneous.

### You (2025-04-23T17:22:57.601Z)

So

### Guest (2025-04-23T17:23:00.111Z)

Right? It's all revenue. Just the same as, like, you know, room revenue for year one, room revenue for year two, room revenue three. It's all room revenue. Just for a different year. Right? So it's five different filter out for a different attribute. The same thing is for, like, account versus department. If you so I I don't know how you

### You (2025-04-23T17:23:16.051Z)

Yeah.

### Guest (2025-04-23T17:23:17.311Z)

or it like, how how you wanna put that into a data model. Yeah. I mean, well, it's kind of decide once we have this Then we kinda know. Easy to design that one. This is 362,000 rows.

### You (2025-04-23T17:23:32.701Z)

Yeah.

### Guest (2025-04-23T17:23:36.211Z)

I don't know But for, you know, maybe a dozen or so properties. Alright. I'll send this over and just you know, actually, I I really let me

### You (2025-04-23T17:23:46.011Z)

Yeah. Yeah. When I I didn't realize that that wasn't

### Guest (2025-04-23T17:23:49.821Z)

need to follow-up with Diane about the the maybe I'll just have the the NDA sent directly to you guys first rather than to Diane. So you guys can can review and sign.

### You (2025-04-23T17:24:01.381Z)

yeah. Yeah. Yeah. Yeah. I'll I'll go ahead and execute that as well. And and I also do

### Guest (2025-04-23T17:24:03.661Z)

She hasn't signed it yet, so it's gotten stuck with her. But, I know she's busy, so I'll audit

### You (2025-04-23T17:24:07.901Z)

have

### Guest (2025-04-23T17:24:08.491Z)

Is is it an online copy? Or Yeah. DocuSign. Yeah.

### You (2025-04-23T17:24:09.051Z)

an email to Diane I mean, I I can get the

### Guest (2025-04-23T17:24:12.691Z)

Online is good because my printer is not working. So

### You (2025-04-23T17:24:14.531Z)

Invest email account set up this afternoon if she replies back.

### Guest (2025-04-23T17:24:15.451Z)

yeah. Yeah.

### You (2025-04-23T17:24:18.511Z)

But I'll give her a nudge on the NDA as well. So make sure we're all set and ready to go. Alright.

### Guest (2025-04-23T17:24:33.831Z)

Yeah.

### You (2025-04-23T17:24:36.931Z)

Alright.

### Guest (2025-04-23T17:24:38.351Z)

Okay. Sounds good. Thank you very much.

### You (2025-04-23T17:24:38.551Z)

Yep. Thank you.

### Guest (2025-04-23T17:24:42.661Z)

Cool. Alright. Well, if you guys look through this, let me know if anything else comes up. Yeah. Alright. That's yeah. Thanks a lot, Alright. Thanks, guys. Bye.