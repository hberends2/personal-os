# Howard | Vinod

**Date:** 2025-04-21 00:00:00 UTC
**Meeting ID:** 9898164c-9c5e-4602-9eda-7d254d2dce72
**Synced:** 2026-02-05 14:46:48

---

# Transcript for: Howard | Vinod

### You (2025-04-21T20:01:45.545Z)

More hello. Good morning. Good afternoon. How are you doing? I've been Been doing alright. So how's the

### Guest (2025-04-21T20:01:56.985Z)

Hello. Hello.

### You (2025-04-21T20:01:57.785Z)

how's the gig gig going?

### Guest (2025-04-21T20:01:59.225Z)

Morning.

### You (2025-04-21T20:02:01.175Z)

Going fine.

### Guest (2025-04-21T20:02:02.305Z)

How you been?

### You (2025-04-21T20:02:03.055Z)

They haven't decided like,

### Guest (2025-04-21T20:02:08.075Z)

Okay. Going fine. They haven't decided

### You (2025-04-21T20:02:15.875Z)

what's going on. So

### Guest (2025-04-21T20:02:17.945Z)

like, which team they wanna

### You (2025-04-21T20:02:20.565Z)

if I apply to 10 Okay.

### Guest (2025-04-21T20:02:21.455Z)

keep me in. Initially, it was some other team other team and some other team. And I don't know what's

### You (2025-04-21T20:02:25.325Z)

That's weird. So the fast one they get

### Guest (2025-04-21T20:02:30.085Z)

going on. So there there are a lot of meetings and all that going on.

### You (2025-04-21T20:02:30.975Z)

me is to update the current network and all the microservices.

### Guest (2025-04-21T20:02:36.075Z)

Fireflies sits in between. Okay. So, I mean,

### You (2025-04-21T20:02:40.765Z)

And k. So so that update was

### Guest (2025-04-21T20:02:43.905Z)

so the first one they gave me is to update the dot net version of one of the microservices.

### You (2025-04-21T20:02:45.415Z)

done. I think the

### Guest (2025-04-21T20:02:48.875Z)

From dot net six to dot eight because they're using MuleSoft they wanna get rid of MuleSoft in between. So so that update was done.

### You (2025-04-21T20:02:59.225Z)

So kind of, getting started with that.

### Guest (2025-04-21T20:03:00.945Z)

And

### You (2025-04-21T20:03:01.785Z)

K.

### Guest (2025-04-21T20:03:02.205Z)

I think now

### You (2025-04-21T20:03:03.185Z)

That that different discussion on how

### Guest (2025-04-21T20:03:04.485Z)

the one me to do some what is that? AWS cloud formation works. So kind of getting started with that. But then then there are different discussion how

### You (2025-04-21T20:03:18.065Z)

contact thing. Oh, yeah. No. Nothing yet.

### Guest (2025-04-21T20:03:21.445Z)

far which team I'll be part on all that. So a few meetings going on regarding that. How how is your thing going on? Did you

### You (2025-04-21T20:03:26.835Z)

We met look. Ten days ago. And so

### Guest (2025-04-21T20:03:30.175Z)

Did something work out with

### You (2025-04-21T20:03:31.825Z)

you know, they are

### Guest (2025-04-21T20:03:32.125Z)

other thing you are telling me? Contract thing.

### You (2025-04-21T20:03:34.075Z)

he's putting together

### Guest (2025-04-21T20:03:35.635Z)

Nothing

### You (2025-04-21T20:03:36.725Z)

a financing package going back for another round. And he expects that to be completed

### Guest (2025-04-21T20:03:45.305Z)

Uh-huh.

### You (2025-04-21T20:03:46.885Z)

early to mid July. But there could be a possibility of doing some project or

### Guest (2025-04-21T20:03:53.065Z)

Okay.

### You (2025-04-21T20:03:54.695Z)

work between now and then, and I not quite sure. I kinda got the impression that if this financing round is approved, it would also include

### Guest (2025-04-21T20:04:02.425Z)

Mhmm. Oh,

### You (2025-04-21T20:04:05.635Z)

enough to maybe bring on a full time position. So don't think I'm gonna have anything definite from them until July, and that's assuming everything goes on time. So, you know, it could be August or September. But I might be able to pick up a couple of of you know, projects with them, but we'll see how it goes. So, yeah, I'm kind of the same boat you are. I know you mentioned on the call Friday that you know, you're kinda hoping that this turns into the full time gig and I'm kind of in the same boat. You know? I just

### Guest (2025-04-21T20:04:37.025Z)

Yeah.

### You (2025-04-21T20:04:39.475Z)

have not wanted any jobs out there. That I even find appealing, let alone ones that you know, because my entire career has been in commercial real estate. And

### Guest (2025-04-21T20:04:54.545Z)

Yeah.

### You (2025-04-21T20:04:55.695Z)

when I look at

### Guest (2025-04-21T20:04:56.015Z)

Right.

### You (2025-04-21T20:04:56.935Z)

opportunities outside of that, there's a lot of boxes that I don't check off. So I'm not surprised that I'm not getting any calls back. Now I I think I've only found one ad on Indeed that was for

### Guest (2025-04-21T20:05:13.355Z)

Yeah.

### You (2025-04-21T20:05:15.555Z)

a product manager in PropTech. And it was basically an entry level. Job. And plus, by the time I found the the ad, it was, like, three months old. So so, anyway, yeah, I'm I'm just I'm yeah, I don't know if I'm disappointed or not. You know? It's like I Yeah. Yeah. That's the single family.

### Guest (2025-04-21T20:05:44.925Z)

Yeah.

### You (2025-04-21T20:05:46.315Z)

Okay. Yeah. Okay. So, I mean, I could end up doing both. You know? I don't know if,

### Guest (2025-04-21T20:05:50.135Z)

So

### You (2025-04-21T20:05:52.325Z)

you know, I think you could

### Guest (2025-04-21T20:05:53.155Z)

one is the same one that you were talking about earlier? The

### You (2025-04-21T20:05:54.955Z)

have a full time

### Guest (2025-04-21T20:05:56.745Z)

I mean, the contract of contracting

### You (2025-04-21T20:05:57.575Z)

job with all the coding that needs to be done. But for me on the product side,

### Guest (2025-04-21T20:05:59.475Z)

Yeah. Same. Okay. Okay. Yeah.

### You (2025-04-21T20:06:03.955Z)

until we actually get something up and running, you know, I'd don't think I need to put in forty hours a week on this. You know? I definitely wanna meet with prospects or or potential clients, you know, get feedback from the users. But, you know, that's only, you know, one or two phone calls a week probably. So so, yeah, I've got I've got time to take on two gigs if what happens. But we'll see.

### Guest (2025-04-21T20:06:36.065Z)

Yeah. Yeah.

### You (2025-04-21T20:06:36.915Z)

That's Yeah. I don't I I don't know. He hasn't been on the last couple calls. I'm not sure exactly what his expectations are.

### Guest (2025-04-21T20:06:46.045Z)

Yeah. I think there's marketing sees all that sort of work. Right?

### You (2025-04-21T20:06:51.425Z)

Yeah.

### Guest (2025-04-21T20:06:52.385Z)

That's gonna need it.

### You (2025-04-21T20:06:54.705Z)

Have you had any conversations with them? Or Yeah.

### Guest (2025-04-21T20:07:04.935Z)

Oh, Mark. No. Mark's.

### You (2025-04-21T20:07:06.545Z)

Is it?

### Guest (2025-04-21T20:07:06.965Z)

Alright. Right.

### You (2025-04-21T20:07:07.375Z)

Poland Pass.

### Guest (2025-04-21T20:07:10.825Z)

No. I mean, I didn't have any conversations with anyone apart from those group meetings.

### You (2025-04-21T20:07:15.195Z)

Yeah. Yeah. Yeah.

### Guest (2025-04-21T20:07:17.915Z)

And then this job that I do is very, very inconvenient. Right?

### You (2025-04-21T20:07:19.795Z)

Yeah. Yeah.

### Guest (2025-04-21T20:07:21.885Z)

And Columbus. Away from family. I don't have a car there.

### You (2025-04-21T20:07:26.195Z)

Yeah. Yeah. I think if

### Guest (2025-04-21T20:07:27.625Z)

I don't have proper accommodation.

### You (2025-04-21T20:07:28.805Z)

I'm like So this.

### Guest (2025-04-21T20:07:31.595Z)

Yeah. No. Proper cooking arrangements.

### You (2025-04-21T20:07:34.645Z)

Yeah. And that's

### Guest (2025-04-21T20:07:35.825Z)

For all that. So this

### You (2025-04-21T20:07:36.255Z)

a that that's that

### Guest (2025-04-21T20:07:39.145Z)

very, very inconvenient.

### You (2025-04-21T20:07:39.225Z)

But the

### Guest (2025-04-21T20:07:41.155Z)

Yeah. My thing is I'm, like, getting stuck with this visa things. Right? Nobody is

### You (2025-04-21T20:07:46.375Z)

Yeah.

### Guest (2025-04-21T20:07:47.685Z)

to work with visa. Right now.

### You (2025-04-21T20:07:49.235Z)

So these

### Guest (2025-04-21T20:07:50.745Z)

And there's some there are jobs. There are a lot of jobs.

### You (2025-04-21T20:07:51.235Z)

guy is not going contracting friends, companies, or my

### Guest (2025-04-21T20:07:54.045Z)

But the first question they ask, do you require H and B sponsorship?

### You (2025-04-21T20:07:57.345Z)

thing. To work out.

### Guest (2025-04-21T20:07:59.505Z)

Like, yes. How did that gone?

### You (2025-04-21T20:08:04.805Z)

Well

### Guest (2025-04-21T20:08:05.065Z)

So with these guys, I'm doing contracting. One of my companies holding my visa.

### You (2025-04-21T20:08:10.515Z)

I don't

### Guest (2025-04-21T20:08:11.775Z)

The contracting thing

### You (2025-04-21T20:08:12.785Z)

So how long do you have?

### Guest (2025-04-21T20:08:13.555Z)

worked out. But, yeah, I almost feel like I don't want to go back, but I

### You (2025-04-21T20:08:18.405Z)

Project.

### Guest (2025-04-21T20:08:19.635Z)

think I'll have to go back. I don't have a choice.

### You (2025-04-21T20:08:19.855Z)

Okay.

### Guest (2025-04-21T20:08:22.375Z)

I don't know how go. And I know I don't know how to go.

### You (2025-04-21T20:08:22.895Z)

So I I just trying. Something. Yep. I I I knew you had something worked out because

### Guest (2025-04-21T20:08:31.105Z)

I believe they are saying this project is for one year.

### You (2025-04-21T20:08:33.265Z)

right at the at the time of the layoff, you said you had two months to find something. But so

### Guest (2025-04-21T20:08:38.355Z)

So

### You (2025-04-21T20:08:38.735Z)

this deal with your friend will carry you through

### Guest (2025-04-21T20:08:39.465Z)

I don't know. I mean, I'm just trying to find something

### You (2025-04-21T20:08:41.475Z)

potentially for another year?

### Guest (2025-04-21T20:08:43.145Z)

better

### You (2025-04-21T20:08:43.845Z)

Yes. Yeah. So Okay. So this but you can't afford find it. Client. Someone and transfer with each other. Okay.

### Guest (2025-04-21T20:08:58.115Z)

Yeah. So with my friend now, I have got visa till 2028.

### You (2025-04-21T20:08:58.705Z)

What what's required for that I mean, is it something that

### Guest (2025-04-21T20:09:02.995Z)

So the visa is good.

### You (2025-04-21T20:09:03.375Z)

potentially

### Guest (2025-04-21T20:09:05.135Z)

But then I need to find a

### You (2025-04-21T20:09:05.685Z)

we could do with Invest once we

### Guest (2025-04-21T20:09:06.805Z)

client which can, you know, probably client or they if someone can transfer

### You (2025-04-21T20:09:09.075Z)

make it official or

### Guest (2025-04-21T20:09:11.505Z)

Visa, that'll work out too.

### You (2025-04-21T20:09:11.585Z)

Yeah. I think so. The pandemic My wife has this extra AMB. Okay.

### Guest (2025-04-21T20:09:25.835Z)

Yeah. I believe so. Or there can be a workaround

### You (2025-04-21T20:09:27.525Z)

Something for.

### Guest (2025-04-21T20:09:31.385Z)

I think

### You (2025-04-21T20:09:32.005Z)

Cool. Well,

### Guest (2025-04-21T20:09:32.795Z)

we'll have to talk to that, Tony.

### You (2025-04-21T20:09:34.005Z)

mean, we'll hopefully make it work. It's Yeah.

### Guest (2025-04-21T20:09:34.705Z)

So either we can do contract the transfer. And my wife has this H4EAT Probably something will work out.

### You (2025-04-21T20:09:40.105Z)

Weekend. He got something. Last week. You know what? I haven't touched base with him in a while. I keep forgetting to to

### Guest (2025-04-21T20:09:44.865Z)

From that end. Yeah.

### You (2025-04-21T20:09:47.415Z)

to reach out. I'll have to do that. So Yeah. So I asked think Wednesday, Thursday.

### Guest (2025-04-21T20:09:52.125Z)

Yeah. I looked at text last week. I think he got something. Last week, he

### You (2025-04-21T20:10:01.625Z)

So

### Guest (2025-04-21T20:10:05.305Z)

Yeah. So last week, I think Wednesday or Thursday,

### You (2025-04-21T20:10:06.285Z)

Yeah. I'll ping them after our call and just check up on him as well.

### Guest (2025-04-21T20:10:10.275Z)

that was his first day, and I said it is comparatively he said it was

### You (2025-04-21T20:10:12.585Z)

I I spoke to Keith, but it's been about three weeks now.

### Guest (2025-04-21T20:10:14.325Z)

very comparatively very small company.

### You (2025-04-21T20:10:16.795Z)

Yeah.

### Guest (2025-04-21T20:10:17.565Z)

I don't know what he got. He didn't share any details.

### You (2025-04-21T20:10:17.595Z)

Know he was gonna go out of out of the country on vacation or something, so I haven't heard anything from him.

### Guest (2025-04-21T20:10:20.885Z)

But that's what he is saying.

### You (2025-04-21T20:10:25.445Z)

Yeah. But, really, besides other than yourself, know, those are about the only two that I've really kind of had any contact with.

### Guest (2025-04-21T20:10:31.265Z)

Yeah. Yeah.

### You (2025-04-21T20:10:33.525Z)

Since the playoffs. So Alright.

### Guest (2025-04-21T20:10:39.805Z)

Yeah.

### You (2025-04-21T20:10:42.215Z)

Yeah. Yeah. He last time I spoke to him, he kinda sounded like like I am. It's like, yeah. You know, I don't

### Guest (2025-04-21T20:10:52.095Z)

I had text Keith as well. I don't know when.

### You (2025-04-21T20:10:53.475Z)

know if I wanna find something right now, if I wanna do

### Guest (2025-04-21T20:10:57.035Z)

He hadn't found anything. Like, I'm still looking.

### You (2025-04-21T20:10:57.335Z)

consulting, if I yeah. So it's like, I think he had to take some time maybe to work that out and figure out what he wants. You know? Because I'm really kinda surprised because I still a lot of project management positions there. And he's worked for some really big companies. That's project manager. So it seems like he would be able to get a job fairly easily. But Yeah.

### Guest (2025-04-21T20:11:26.115Z)

Yeah.

### You (2025-04-21T20:11:28.375Z)

Yeah. I know who you're talking about, but I can't remember his name.

### Guest (2025-04-21T20:11:28.535Z)

Right. When I came

### You (2025-04-21T20:11:32.825Z)

Yeah.

### Guest (2025-04-21T20:11:32.895Z)

Yeah. Yeah.

### You (2025-04-21T20:11:36.285Z)

Since August here.

### Guest (2025-04-21T20:11:37.835Z)

Hey. You remember that guy we had in, Arcadia? What was his name?

### You (2025-04-21T20:11:37.985Z)

Really? Yeah. Yeah. Okay.

### Guest (2025-04-21T20:11:42.275Z)

The Muslim guy.

### You (2025-04-21T20:11:43.915Z)

Yeah. But, yeah,

### Guest (2025-04-21T20:11:44.435Z)

Project manager.

### You (2025-04-21T20:11:46.025Z)

Okay.

### Guest (2025-04-21T20:11:48.865Z)

I don't remember. He hadn't found anything, like,

### You (2025-04-21T20:11:50.145Z)

Yeah. Yeah.

### Guest (2025-04-21T20:11:51.225Z)

since then. Since August, he hadn't found anything.

### You (2025-04-21T20:11:51.785Z)

Yeah. I gotta I gotta get on the call with Nancy too. We had a good conversation about

### Guest (2025-04-21T20:11:54.685Z)

Yeah. Though he's a citizen, I think you're saying probably age factor and all that.

### You (2025-04-21T20:11:58.415Z)

three or four weeks ago, and

### Guest (2025-04-21T20:12:00.295Z)

But he found anything.

### You (2025-04-21T20:12:01.735Z)

she it was right after Aglaia and and others

### Guest (2025-04-21T20:12:04.695Z)

Tough and crazy.

### You (2025-04-21T20:12:07.865Z)

were let go. Yeah. I don't know. Know. Aglaia is no longer there, but I don't know if she was

### Guest (2025-04-21T20:12:15.275Z)

Okay.

### You (2025-04-21T20:12:17.255Z)

laid off at Yes. Yeah. Yeah. Or if I don't know if it's her choice. I don't know. But Yeah. I heard she was say, you

### Guest (2025-04-21T20:12:25.105Z)

Yeah. I don't know whether you the and who else?

### You (2025-04-21T20:12:25.675Z)

Yeah. Yeah. Yeah. I I don't know the full extent of how many people were were let go.

### Guest (2025-04-21T20:12:32.185Z)

She was laid off. Yeah.

### You (2025-04-21T20:12:33.375Z)

So I I heard it was I don't know.

### Guest (2025-04-21T20:12:36.225Z)

The I heard about no. I heard she was laid off.

### You (2025-04-21T20:12:38.345Z)

Quite a few. I mean, like, 20 something. Altogether. I some from India. Yeah. But, yeah, I need to figure out what's going on. That that's too bad. I mean, Berecadia seemed to be doing really well. You know, Justin was very proud of the

### Guest (2025-04-21T20:12:56.485Z)

Crazy.

### You (2025-04-21T20:12:57.115Z)

that they've never had a layoff. I

### Guest (2025-04-21T20:12:58.585Z)

I heard some from India team. That's what I heard. And they're glad.

### You (2025-04-21T20:12:59.165Z)

thought for sure that they would be okay, but I kinda got the impression that the Burkadia teams

### Guest (2025-04-21T20:13:06.085Z)

Okay.

### You (2025-04-21T20:13:07.945Z)

probably had more people than they needed even when Red IQ was there. Somewhat. Yeah. Yeah. But, anyway, so, yeah, that's that's about it. Nothing nothing has changed, unfortunately.

### Guest (2025-04-21T20:13:28.275Z)

Yeah. For modernization, definitely. The this I think it is all main I don't know. See.

### You (2025-04-21T20:13:35.885Z)

No. No. The only thing that I've seen are some LinkedIn posts. And it's all been about real rents.

### Guest (2025-04-21T20:13:42.595Z)

Okay.

### You (2025-04-21T20:13:44.405Z)

I think I saw one post

### Guest (2025-04-21T20:13:45.965Z)

And yeah, I don't know what's going on. Try it. Did you hear anything?

### You (2025-04-21T20:13:48.795Z)

like,

### Guest (2025-04-21T20:13:49.925Z)

They're doing surviving?

### You (2025-04-21T20:13:50.235Z)

maybe ten days or two weeks after we left that they did release the ValuationIQ for MAC. Okay. You know, I just kinda reached out to Michael and said congratulations and didn't

### Guest (2025-04-21T20:14:00.075Z)

Alright.

### You (2025-04-21T20:14:03.445Z)

really hear a whole lot back. So I don't know. If anybody's using it or not. Pretty much everything other than that has all been related to

### Guest (2025-04-21T20:14:11.665Z)

Okay.

### You (2025-04-21T20:14:15.845Z)

to the real rents. I did see also one more post that something that where they are now processing more operating statements using AI.

### Guest (2025-04-21T20:14:32.525Z)

Okay.

### You (2025-04-21T20:14:34.065Z)

Yeah. Yeah. So I think you know, they must have made some progress with some of the work they were doing there. But

### Guest (2025-04-21T20:14:46.615Z)

Yeah. I I saw that.

### You (2025-04-21T20:14:54.105Z)

Yeah. Yeah. I I still think they're just gonna keep the lights on. When things settle down. So I did see like, a a new addition. They do have another HR person now.

### Guest (2025-04-21T20:15:06.805Z)

Hope this trend one was fairly simple too. Right?

### You (2025-04-21T20:15:13.505Z)

Yeah. Veronica, number one. She was spread way too thin in number

### Guest (2025-04-21T20:15:15.775Z)

Yeah.

### You (2025-04-21T20:15:17.005Z)

two, she did a horrible job. So, I mean they pretty much had to get somebody else in there. But that's I I think that's the only other thing that I saw.

### Guest (2025-04-21T20:15:26.645Z)

No. Okay.

### You (2025-04-21T20:15:28.005Z)

So

### Guest (2025-04-21T20:15:28.705Z)

Well,

### You (2025-04-21T20:15:29.225Z)

Yeah.

### Guest (2025-04-21T20:15:29.465Z)

little. Yeah.

### You (2025-04-21T20:15:32.275Z)

Else. I

### Guest (2025-04-21T20:15:36.165Z)

Still still there? But

### You (2025-04-21T20:15:38.045Z)

got

### Guest (2025-04-21T20:15:38.235Z)

Right. Right.

### You (2025-04-21T20:15:38.535Z)

it. An

### Guest (2025-04-21T20:15:46.295Z)

I think we really have good opportunity here. The only thing is

### You (2025-04-21T20:15:46.395Z)

back. Think have more sharp

### Guest (2025-04-21T20:15:49.495Z)

I kind of lost the rhythm

### You (2025-04-21T20:15:50.055Z)

know.

### Guest (2025-04-21T20:15:51.785Z)

now. Right? I was really a good I really good rhythm in between.

### You (2025-04-21T20:15:55.205Z)

Yeah. Yeah. I think

### Guest (2025-04-21T20:15:58.055Z)

And now with all this going on, I kind of lost my rhythm. I need to

### You (2025-04-21T20:15:58.765Z)

you know, my the I think the best thing that's happening on my end is my wife is finally

### Guest (2025-04-21T20:16:02.645Z)

get back.

### You (2025-04-21T20:16:04.195Z)

okay with with what I'm doing.

### Guest (2025-04-21T20:16:04.985Z)

I think we have good shot here. I think this is a good niche.

### You (2025-04-21T20:16:07.535Z)

I tried to start my own kind of a

### Guest (2025-04-21T20:16:09.255Z)

The only thing is we have to get this thing out so that, you know, we could

### You (2025-04-21T20:16:11.825Z)

consulting business many years ago. After I was laid off. And I also had a

### Guest (2025-04-21T20:16:22.505Z)

Okay.

### You (2025-04-21T20:16:23.095Z)

business for it was more for multifamily analytics.

### Guest (2025-04-21T20:16:30.475Z)

Let

### You (2025-04-21T20:16:30.535Z)

Because there was a company out there that I was aware of that was

### Guest (2025-04-21T20:16:32.285Z)

Yeah.

### You (2025-04-21T20:16:34.965Z)

not a very good business plan And, you know, I worked out the numbers where you know, I could produce

### Guest (2025-04-21T20:16:43.005Z)

Mhmm.

### You (2025-04-21T20:16:44.855Z)

what they were producing at half the cost. I had an angel investor lined up. I mean, I was ready to pull the trigger. Okay. She is very risk averse. Could not she was like, no way. We we need to you need to have a steady job and income. And so I was a little bit leery about

### Guest (2025-04-21T20:17:05.855Z)

No.

### You (2025-04-21T20:17:06.985Z)

this, you know, with the hotel, but

### Guest (2025-04-21T20:17:08.625Z)

Amazing.

### You (2025-04-21T20:17:08.975Z)

the fact that Diane is talking about getting the funding, the work that we done up to this point, she's seen me sitting at the computer working on them also. She's okay now. So that if if if this is the what we end up doing and making it full time, you know, we're I I think we're

### Guest (2025-04-21T20:17:28.415Z)

Yeah.

### You (2025-04-21T20:17:28.435Z)

I won't get the pushback like I did last time. Yeah.

### Guest (2025-04-21T20:17:48.175Z)

I mean, yeah, if this can work full time,

### You (2025-04-21T20:17:48.845Z)

I know it's not a good time, and

### Guest (2025-04-21T20:17:51.735Z)

be great. I mean, I just love

### You (2025-04-21T20:17:53.595Z)

mean, everybody's still

### Guest (2025-04-21T20:17:54.875Z)

doing things which, you know, you own. Right?

### You (2025-04-21T20:17:55.195Z)

working on other things as well, including Diane. So but that's why I've kinda clamped down last

### Guest (2025-04-21T20:17:59.425Z)

But, yeah, I I would be very motivated if we can do this

### You (2025-04-21T20:18:01.645Z)

week and really forced myself to

### Guest (2025-04-21T20:18:03.825Z)

full time.

### You (2025-04-21T20:18:03.985Z)

go sell by sell through that

### Guest (2025-04-21T20:18:04.615Z)

Right now, I'm very distracted. I'm like,

### You (2025-04-21T20:18:06.675Z)

spreadsheet, try to get it

### Guest (2025-04-21T20:18:06.995Z)

and there and then

### You (2025-04-21T20:18:08.395Z)

done. So I'm curious to hear. I know you probably haven't had a chance but when you do, I'm really curious to see how AI or Claude did with the the database schema first.

### Guest (2025-04-21T20:18:31.515Z)

Yeah.

### You (2025-04-21T20:18:31.795Z)

No. No. Wide open.

### Guest (2025-04-21T20:18:36.055Z)

Yep. Yep. So I was looking at that, actually. Let me share my screen again. So let's, have a look at that. Model first. I don't know if you had any other plans. No? Let me share my screen. Please. Full screen or not full screen.

### You (2025-04-21T20:19:02.045Z)

It's loading. It's not there yet.

### Guest (2025-04-21T20:19:09.465Z)

And this weird button. Come on.

### You (2025-04-21T20:19:10.645Z)

So I office. Yeah. Yeah. I've heard of it.

### Guest (2025-04-21T20:19:14.405Z)

Should do better.

### You (2025-04-21T20:19:17.675Z)

No. It actually kinda I mean, I can see, like,

### Guest (2025-04-21T20:19:19.105Z)

Yes, sir. Easy win screen.

### You (2025-04-21T20:19:21.155Z)

colors and lines going across the screen, but okay, now it started to change. I think it's going to

### Guest (2025-04-21T20:19:24.895Z)

Yeah. Okay.

### You (2025-04-21T20:19:28.045Z)

Thanks a lot.

### Guest (2025-04-21T20:19:29.125Z)

I don't have Microsoft

### You (2025-04-21T20:19:31.485Z)

Yeah. No. It's it's only showing lines and colors whenever the background color is

### Guest (2025-04-21T20:19:34.475Z)

I use this open source called LibreOffice.

### You (2025-04-21T20:19:35.765Z)

So it's got Okay. Tan at the top and then

### Guest (2025-04-21T20:19:37.745Z)

Do you see that now?

### You (2025-04-21T20:19:38.315Z)

a blue where I think white is selecting rows. But yeah. I said in text, click

### Guest (2025-04-21T20:19:52.755Z)

That's a lot.

### You (2025-04-21T20:19:54.685Z)

Yeah. Same. It looks like it's only showing the top header of the screen.

### Guest (2025-04-21T20:20:03.085Z)

Oh, that's great. You're listening to my

### You (2025-04-21T20:20:03.855Z)

Below it was black.

### Guest (2025-04-21T20:20:05.265Z)

Oh, Mhmm. Okay. Let me try that again. I sent entire screen.

### You (2025-04-21T20:20:12.355Z)

No.

### Guest (2025-04-21T20:20:13.055Z)

To share the screen. Let me see if that helps. Oh, no. Okay. So let's

### You (2025-04-21T20:20:22.095Z)

I just saw something flash on the screen, though, that it looked like a thumbnail of the spreadsheet. I don't know how that came up. It was there, and then it just disappeared.

### Guest (2025-04-21T20:20:33.825Z)

Oh, no.

### You (2025-04-21T20:20:36.355Z)

So yeah.

### Guest (2025-04-21T20:20:39.095Z)

Okay. I don't know what's going on.

### You (2025-04-21T20:20:41.445Z)

Oh, wait. There again. Right when you switched it off.

### Guest (2025-04-21T20:20:43.915Z)

Sharing the window and not sharing. Okay. So

### You (2025-04-21T20:20:48.575Z)

No. I Yeah. But, you know, it is kinda funny because as soon as you push the button to shut it down, it displayed. Properly. And then So alright. Yeah. Let let me go ahead and open up

### Guest (2025-04-21T20:21:01.955Z)

So let's do one thing. Probably you try to share, and let's see if that helps.

### You (2025-04-21T20:21:02.385Z)

Excel here. Let me see. So you bought like, for three years. That's I did a monthly subscription instead of

### Guest (2025-04-21T20:21:14.425Z)

No. I dropped actually on this side.

### You (2025-04-21T20:21:15.075Z)

buying package because usually when you buy the package, you're locked into whatever version. So me see. Prints up. They both

### Guest (2025-04-21T20:21:25.875Z)

Okay.

### You (2025-04-21T20:21:30.025Z)

It is it it I close out this

### Guest (2025-04-21T20:21:32.355Z)

The blue bar Microsoft like,

### You (2025-04-21T20:21:33.345Z)

Yeah. And when I try to Yeah. See, that's the thing is I use Mac. And a MacBook, you can't enable the the macros MacBook don't use macros. So alright. Let me see if I can share this. What did I Wise. Wacker soft edge. There we go. Okay. So, can you see Excel?

### Guest (2025-04-21T20:22:14.785Z)

It is it says macros are disabled.

### You (2025-04-21T20:22:18.545Z)

Yep. I see it right into Okay.

### Guest (2025-04-21T20:22:21.175Z)

And when I try to

### You (2025-04-21T20:22:21.945Z)

Alright. The names? Well, yeah. No. I didn't have made anything. Oh, seriously. Some of the notes that we took when Diane and Drew were kinda walking through the model in which order they would do things. Okay. So the summary was originally the first, but I inserted the name ranges. So all of the name ranges ranges. Mhmm. And this is what I uploaded the title. So it was able to take all these named ranges, but it also went and took a look here. So one of the first things I wanna point out is notice, actually, you know, on five year projections, And on the assumptions page, I started to go through and create everything at year one or year two So if I go to the assumption page,

### Guest (2025-04-21T20:23:18.685Z)

Yep. I see it bright and clear.

### You (2025-04-21T20:23:18.905Z)

row d 13, So notice up here in the left corner, right up here,

### Guest (2025-04-21T20:23:21.405Z)

Okay. This it was

### You (2025-04-21T20:23:24.725Z)

can you see right above column a? E n one.

### Guest (2025-04-21T20:23:26.075Z)

adding the first

### You (2025-04-21T20:23:27.765Z)

Yeah. Year one days.

### Guest (2025-04-21T20:23:29.185Z)

quick

### You (2025-04-21T20:23:29.535Z)

That's the name of the cell that my cursor's in. But then I have year two days, year three days, year four days,

### Guest (2025-04-21T20:23:34.605Z)

What is the first one? Isn't it?

### You (2025-04-21T20:23:37.165Z)

And I did some research. That's also, Word document that I attached. Mhmm. It recommended that you would basically you don't need to have a separate year one, year two, year three field. Okay. That it would be you just need a days field or something. So if I go back here, I try to note that everything is the same as year one.

### Guest (2025-04-21T20:24:04.175Z)

Mhmm.

### You (2025-04-21T20:24:04.915Z)

So anytime like here, you've got a field year one rentals, This could just be rentals other income POR.

### Guest (2025-04-21T20:24:13.185Z)

Good.

### You (2025-04-21T20:24:14.355Z)

Right? So we start working on this. I'll I'll work with you to make it more clear. But when you take a look at the database schema, Yeah. You know? And it's we had the same thing in Red IQ. Right? We had all the different years. And that's all based on, you know, how many years were in the historical that was uploaded, and then when they create their deal details, there there's a holding period in Red IQ, and it's exactly the same thing here. So if they put in a five year holding period, you've got year one, two, three, four, and five. In your projections like in first pass. If they put in eight,

### Guest (2025-04-21T20:24:52.835Z)

Mhmm.

### You (2025-04-21T20:24:53.175Z)

you'll have year through eight. And you don't have to have a year one, a year two, year three table, etcetera.

### Guest (2025-04-21T20:24:59.485Z)

In year one days,

### You (2025-04-21T20:25:01.705Z)

But

### Guest (2025-04-21T20:25:02.905Z)

Yeah.

### You (2025-04-21T20:25:03.015Z)

in that word document, it explains how to handle that which I'm sure you're already familiar with, but I asked for clarifying. For myself. So that's something. So it might get confusing as you go through here.

### Guest (2025-04-21T20:25:17.145Z)

Mhmm.

### You (2025-04-21T20:25:18.315Z)

And then as I got I was about three quarters a week done, I realized I probably have to read all those fields. You can see, like, there's a ton of here that can probably be needed. Scroll down here. I think there's, yeah, all of these. This is the same as year one. So, you know, it it

### Guest (2025-04-21T20:25:26.085Z)

Okay.

### You (2025-04-21T20:25:29.435Z)

way more fields in here that we need. Of that, here's tier one. All these. So I would say if it doesn't have anything in the input and column, it's probably not something we need. Right? So then, you know, after I had all then I to go through these named ranges one to one. And went to, you know, here's the location of that named range. The worksheet and the cell. I put here d derived. It's a formula.

### Guest (2025-04-21T20:25:59.275Z)

Yeah.

### You (2025-04-21T20:26:00.395Z)

And then I put the form next to it. I is just an input. So that's where the user would just type in, you know, the number of units or the month that they're buying, things like that. It's gonna include that same information. So wait a minute. Yes. Yes. Possibly. I mean, the idea here is and and correct me if I'm wrong, but I took a class

### Guest (2025-04-21T20:26:29.125Z)

Yeah.

### You (2025-04-21T20:26:33.155Z)

in basic database work. Like probably eight or nine years ago. One thing that the instructor kept saying is that if you have any complicated calculations, it's best to do it in the database. And faster, you and you can prepopulate fields so that when it's displayed on the screen, it's instant. You don't have to do that. I don't have any of those here. So the question is, do we want to even have derived fields in the database? Or do we want to do it live on screen. You know? Because Yeah. Yeah. That's true. Yeah. So I probably put a lot more work into this than I needed.

### Guest (2025-04-21T20:27:32.575Z)

Mhmm.

### You (2025-04-21T20:27:35.005Z)

But, you know, for the code, this is what you would need as well. Right? Yeah. So rooms, yeah, rooms, keys is exactly what it sounds like. If you go to the summary tab, that's this field right here. The one eighty two. And I've named it that because it's called room's keys.

### Guest (2025-04-21T20:27:52.335Z)

Yeah.

### You (2025-04-21T20:27:55.025Z)

So the you know, that's pretty simple. You know? And you available rooms in a year it's number of rooms times the number of days. Right? Super That's not something that has to be creeped pre calculated. So yeah. Okay.

### Guest (2025-04-21T20:28:14.445Z)

So wherever it says d, that means we have to generate that field auto generate that field.

### You (2025-04-21T20:28:20.445Z)

Yeah. Can

### Guest (2025-04-21T20:28:22.735Z)

For the user. With the logic. Right?

### You (2025-04-21T20:28:23.505Z)

Yeah. Yeah. So in this formula, you know, rooms keys times year one days you will find over here, column a, z's. And year one days. So if you wanted to search filter up here, you can see exactly where room's keys is. K. So there will not be any named ranges in the formulas that aren't included in column A. Right? Does that make sense? K. So then, yes, over here, go to the summary tab. That basically anything's in black font is a calculated or derived field.

### Guest (2025-04-21T20:29:00.075Z)

Yeah.

### You (2025-04-21T20:29:01.765Z)

And so

### Guest (2025-04-21T20:29:02.145Z)

And

### You (2025-04-21T20:29:03.145Z)

you can see this is called I go back over here, the name of this field is loan dispersal amount right here above column A.

### Guest (2025-04-21T20:29:10.625Z)

Yeah. No. That's what I have. Like,

### You (2025-04-21T20:29:11.345Z)

Oh, sorry. And the dispersal amount is got a formula. So it's the loan amount

### Guest (2025-04-21T20:29:14.785Z)

the logic should go in somewhere in this little

### You (2025-04-21T20:29:16.885Z)

times one minus loan fees.

### Guest (2025-04-21T20:29:17.975Z)

logic in the code, not in the database. So database will

### You (2025-04-21T20:29:20.165Z)

Now if you're in Excel, you can go over here and say, okay, well,

### Guest (2025-04-21T20:29:22.225Z)

purely be just the data. Now whatever calculation we have to do, that will do in the code, whatever

### You (2025-04-21T20:29:24.175Z)

I don't know what loan amount is. If you click on this arrow, here is all of the named ranges. So I can scroll down here and say, oh,

### Guest (2025-04-21T20:29:28.465Z)

know, which is logic. Probably some some yeah.

### You (2025-04-21T20:29:32.365Z)

loan amount right there. And it'll jump up and put the cursor or put and select the field. So here's my loan amount.

### Guest (2025-04-21T20:29:39.645Z)

Yeah. Yeah. I think that's that would be helpful.

### You (2025-04-21T20:29:39.845Z)

Right? And the same thing. Loan fees are right here. Here's my loan fees.

### Guest (2025-04-21T20:29:43.935Z)

Yep.

### You (2025-04-21T20:29:45.285Z)

They're not always going be on the same tab. You're going to find a ton of formulas it's getting some data from the assumptions tab or the five year projections tab or the penetration tab. So

### Guest (2025-04-21T20:29:52.335Z)

Right.

### You (2025-04-21T20:29:57.745Z)

the way that this is set up, is there are some fields on here that are calculated within here. Like, this is a perfect example where it's

### Guest (2025-04-21T20:30:06.625Z)

Yeah.

### You (2025-04-21T20:30:07.265Z)

getting all of the data from summary tab, This loan dispersal amount is probably only in the summary tab. It's not used elsewhere.

### Guest (2025-04-21T20:30:13.405Z)

Okay. And

### You (2025-04-21T20:30:15.525Z)

But the way I've got it set up is you'll find a little bit of a comment here because you'll

### Guest (2025-04-21T20:30:20.155Z)

and and the other tabs are just same.

### You (2025-04-21T20:30:20.195Z)

see, like, these property level return metrics. These are all coming from different worksheets.

### Guest (2025-04-21T20:30:23.365Z)

But instead of

### You (2025-04-21T20:30:24.895Z)

Same thing with these property metrics. It's mix and match.

### Guest (2025-04-21T20:30:25.035Z)

direct formula, you kept the named ranges there, something like that.

### You (2025-04-21T20:30:28.725Z)

But what I did is the operating cash flow, almost anything that is a financial metric,

### Guest (2025-04-21T20:30:29.455Z)

Yeah.

### You (2025-04-21T20:30:33.815Z)

is based here. Right? So starting at the very top, here's my year one room revenue year two room revenue. So you can see that when I went through this originally, where I was doing it for individual years. But this is basically room revenue. And over here, everything in this column is a percentage of total operating Right? So here's my total operating revenue Very simple formulas. It's this divided by the total operating revenue.

### Guest (2025-04-21T20:31:02.575Z)

Gotcha. Yeah. Yeah.

### You (2025-04-21T20:31:04.295Z)

So it's math all down here. If I did this, any cell that's yellow is a named range. So you could

### Guest (2025-04-21T20:31:12.415Z)

Okay.

### You (2025-04-21T20:31:12.825Z)

find here's room expense. There's food and beverage expense. Other operating expense. You can see there it's changing as I go through here. And then this cash flow summary this is basically taking all the data for the operating cash flow and also bringing it down into the tools here. So you can see that the it's still referencing a cell, but up here in formula bus. Up here. It's just saying here's my year one other op, which if I go over here, is my

### Guest (2025-04-21T20:31:43.645Z)

Mhmm.

### You (2025-04-21T20:31:46.565Z)

year one other op. Right there. Right? The cash flow is just taking that over. Same to assumptions. Now most of these, you're not gonna see any yellow on here because pretty much everything on this page is coming from cells with the blue font. These are all inputs, right? So all we need is we'll need a modal And we'll say, okay, how many days in a year, which you shouldn't have to input three sixty five. This is something where I have a couple questions on here. Is is there a reason why these would change? So maybe we only need one input that says the number of rooms. Days in year, This would only change, I think, if they purchased it in any month other than December. So you might have less on this. Now this particular example, the closing date was December of twenty twenty four, so that's why it's all showing three sixty five.

### Guest (2025-04-21T20:32:38.195Z)

Yeah.

### You (2025-04-21T20:32:44.135Z)

But as I go through here, you can see there's my inflation my property tax inflation, my year one inflation, Actually, I do need to take this. I know it's not gonna show on yours, but these are actually named ranges as well for the video. Okay. So yeah. And then the five year predictions, they're not that's pretty ugly. But what it's doing is it's taking the total annual

### Guest (2025-04-21T20:33:12.945Z)

Yeah.

### You (2025-04-21T20:33:15.905Z)

and dividing it by a thousand So it's basically just reformatting the number as a k. Right? So instead of having all all the digits, there again, I don't think you have to have any type of a calculation. I think that could just be a display setting. Right, in the app. You wanna display it as thousands. And then same thing here. All of these are same basic

### Guest (2025-04-21T20:33:41.735Z)

Yeah.

### You (2025-04-21T20:33:42.815Z)

calculations where this is a percentage of total operating revenue. This is a percentage of the PAR. This is a rep rep or this is a per per average what is this? Annual room? Something or and then per occupied room or per available room. And then per occupied I don't know. Something. Oh, yeah. Okay. For the it is to complete. Right? Yeah. To move on. Expectation? Right? Think, what I'm supposed to complete.

### Guest (2025-04-21T20:34:28.575Z)

Okay.

### You (2025-04-21T20:34:28.605Z)

Certainly, I think we cannot we we we'll need to have all of these input fields. Available. We'll need to create some type of a modal where we can input that. So Alright. Yeah. A form. Where we just input the property name, address, and then we will need to get with Diane and Drew to determine, you know, what is the logical order of these. Because these are sorted alphabetically, not by order that you would input it. And then once we get that along with data from Drew, we should be able to get these high level summary metrics. This was the cash flow cash flow summary page. So, you know, the goal I'm I'm I'm hoping that we should be able to get all

### Guest (2025-04-21T20:35:16.355Z)

Right.

### You (2025-04-21T20:35:16.595Z)

three of these. There is a lot of redundancy. Right? So the data at least from this operating cash flow, you can see up here room revenue is $11,000,002.00 $6.05 55, which is the same as the cell, $11.02 $0.06 $5.55. So it's a mapping issue, not a formula or calculation. So once we get the inputs, a summary, page, the assumption page, want to get these. There's there's a few. You can see it goes all the way down. Is a hundred and hundred and something rows, but these are only the rows that are with a gray background.

### Guest (2025-04-21T20:35:52.415Z)

Okay.

### You (2025-04-21T20:35:52.875Z)

I don't think we need this because I think this underneath it, are formulas that can be done throughout the model and you know, that's one thing I don't do is that. You know, you might find this example, I'm just pulling this out of the air, but like this projected average rate

### Guest (2025-04-21T20:36:09.675Z)

Yeah.

### You (2025-04-21T20:36:09.715Z)

$215.50 that might be in two or three different places in the model. And each place, it's

### Guest (2025-04-21T20:36:12.975Z)

Right.

### You (2025-04-21T20:36:16.375Z)

using a formula. It's not referencing one single source of truth. So yeah, I don't think that that's anything that we need to concern ourselves with right now. Yeah. So that for the data base. Mhmm.

### Guest (2025-04-21T20:36:50.905Z)

Yeah.

### You (2025-04-21T20:36:55.105Z)

Yep. Yes. Well

### Guest (2025-04-21T20:36:58.225Z)

Yeah. Correct. Correct. Okay. Okay. This this is good. So for the

### You (2025-04-21T20:37:07.855Z)

Yep. Yep. We'll have to do the data mapping.

### Guest (2025-04-21T20:37:09.145Z)

initial project that we

### You (2025-04-21T20:37:10.505Z)

To make sure that it goes into the

### Guest (2025-04-21T20:37:11.325Z)

planning to complete. Right?

### You (2025-04-21T20:37:12.605Z)

proper table in the schema and

### Guest (2025-04-21T20:37:15.215Z)

So what's the expectation? Right? Like, what are we supposed to

### You (2025-04-21T20:37:15.335Z)

and then build a very basic UI

### Guest (2025-04-21T20:37:19.575Z)

complete?

### You (2025-04-21T20:37:22.285Z)

Nothing fancy. And just to show I would suspect at first we'll probably just have a handful of cells

### Guest (2025-04-21T20:37:30.455Z)

The form. Right?

### You (2025-04-21T20:37:33.495Z)

that we would change to show, like, for example, like, here in

### Guest (2025-04-21T20:37:35.595Z)

Mhmm.

### You (2025-04-21T20:37:36.695Z)

change the whole period maybe from five years to seven years. And then we numbers change. Right?

### Guest (2025-04-21T20:37:40.325Z)

Mhmm.

### You (2025-04-21T20:37:43.665Z)

And and we'd probably get into any type of role level detail

### Guest (2025-04-21T20:37:48.315Z)

Right.

### You (2025-04-21T20:37:50.195Z)

when go out to our first potential clients or even the investors. Right?

### Guest (2025-04-21T20:37:56.215Z)

Mhmm.

### You (2025-04-21T20:37:56.615Z)

Okay. What we have in the

### Guest (2025-04-21T20:38:05.575Z)

Mhmm.

### You (2025-04-21T20:38:06.395Z)

Yep. Okay. So get the data. This Yeah. Yeah. I can start working with Diane and Drew on form. Design. To go through here and get if I'm an analyst, what is my flow? What fields do I need first My assumption is you're to start on a summary page. Right here because most of these are just assumptions. My 65%, my interest rates, everything else here. I'm sorry there. And then, of course,

### Guest (2025-04-21T20:38:55.975Z)

Yeah.

### You (2025-04-21T20:38:56.075Z)

some of the assumptions here, maybe. I I don't know. You know, I'll show this right here on this and then the rest will be calculated based on the inputs here. And go from there. So let me do that, and I can probably put together a either a figment design or maybe even just use a no code tool to come up with a viable form and we can go from there. So it's right. Call

### Guest (2025-04-21T20:39:30.635Z)

Yeah.

### You (2025-04-21T20:39:30.905Z)

the Yeah.

### Guest (2025-04-21T20:39:42.665Z)

So from Drew, we get some data. Right? Say cash flows,

### You (2025-04-21T20:39:47.435Z)

Yep. In fact, if you wanna go to name range, I mean, this is where we added this tool. I can just go here. I wanna

### Guest (2025-04-21T20:39:48.425Z)

summary So we extract that data

### You (2025-04-21T20:39:52.245Z)

you know, filter by

### Guest (2025-04-21T20:39:53.165Z)

put it in the database,

### You (2025-04-21T20:39:54.445Z)

and there's there's all that will need a form. So I got quite a few of them. So

### Guest (2025-04-21T20:39:56.895Z)

And

### You (2025-04-21T20:39:58.215Z)

I'm just gonna to assumptions page.

### Guest (2025-04-21T20:39:59.415Z)

based on that, basically,

### You (2025-04-21T20:39:59.805Z)

You can see all these are. Those hundred rows. There's where there's three or four of them down there on the

### Guest (2025-04-21T20:40:02.445Z)

we'll have

### You (2025-04-21T20:40:05.675Z)

page.

### Guest (2025-04-21T20:40:05.845Z)

that data plotted

### You (2025-04-21T20:40:06.765Z)

I think you need to have

### Guest (2025-04-21T20:40:07.575Z)

on the application side.

### You (2025-04-21T20:40:07.805Z)

at least the beginning point.

### Guest (2025-04-21T20:40:09.285Z)

For a particular property.

### You (2025-04-21T20:40:09.865Z)

From summary to even know what input in that speech because all

### Guest (2025-04-21T20:40:11.075Z)

Then as far as this model goes, we'll

### You (2025-04-21T20:40:13.255Z)

basically financial based.

### Guest (2025-04-21T20:40:14.575Z)

generate

### You (2025-04-21T20:40:15.005Z)

Information.

### Guest (2025-04-21T20:40:15.315Z)

data based on what is input in the database

### You (2025-04-21T20:40:16.555Z)

Or from the data that we would get from Drew.

### Guest (2025-04-21T20:40:19.515Z)

in the model when the user downloads the model?

### You (2025-04-21T20:40:19.815Z)

So I would say just let's let's start on the summary and then you know, by that time, hopefully, I'll have an idea from Diane and Drew as to

### Guest (2025-04-21T20:40:33.025Z)

Yeah.

### You (2025-04-21T20:40:34.135Z)

what order. We would go through here. So Yeah.

### Guest (2025-04-21T20:40:43.315Z)

Mhmm.

### You (2025-04-21T20:40:43.665Z)

Yeah. Okay. I don't remember if Google gives forty five minutes or an hour, but I know we're getting up close to time here if we drop. Yeah. I think we got a couple minutes. Yeah.

### Guest (2025-04-21T20:41:07.705Z)

Yes.

### You (2025-04-21T20:41:08.135Z)

Yeah. No. No. I've got time. Cool. Cool. Yeah. If you wanna if you wanna fire one up and send it to me, then we can just keep going.

### Guest (2025-04-21T20:41:15.005Z)

Right. So all the

### You (2025-04-21T20:41:16.375Z)

Sure. Sure.

### Guest (2025-04-21T20:41:18.985Z)

logic is already in the model. We we're just populating few fields

### You (2025-04-21T20:41:19.255Z)

Okay. Okay. So this form.

### Guest (2025-04-21T20:41:23.445Z)

based on, what we have in the database.

### You (2025-04-21T20:41:23.705Z)

Say we can have

### Guest (2025-04-21T20:41:29.405Z)

Got it. So okay. So as as an any as an initial draft,

### You (2025-04-21T20:41:33.195Z)

end. We connect the data for data.

### Guest (2025-04-21T20:41:36.775Z)

it is the first priority that, you know, we complete the model. Like, we get the data put

### You (2025-04-21T20:41:37.125Z)

What

### Guest (2025-04-21T20:41:41.355Z)

the data in the tables, and then, you know, generate

### You (2025-04-21T20:41:43.655Z)

Right.

### Guest (2025-04-21T20:41:45.125Z)

this model. Mhmm.

### You (2025-04-21T20:41:51.385Z)

I'm I'm

### Guest (2025-04-21T20:41:53.365Z)

Yeah.

### You (2025-04-21T20:41:54.665Z)

time. You know,

### Guest (2025-04-21T20:41:56.155Z)

Yeah.

### You (2025-04-21T20:41:56.395Z)

it's come That's my assumption. If it comes directly from Drew, however, I I don't think

### Guest (2025-04-21T20:42:04.065Z)

Mhmm.

### You (2025-04-21T20:42:05.055Z)

you know, think it's gonna be just like Red IQ where you know, Drew has market data. But I don't know that he's got data on a particular hotel that's for sale. I think that's gonna go from the broker to the buyer just like it does with multifamily. So So we're gonna have to have a a document ingestion and parsing system just like we did at Red IQ. Now the good news is we only need it for financials. And the financials typically are formatted the same.

### Guest (2025-04-21T20:42:39.935Z)

Yeah.

### You (2025-04-21T20:42:42.835Z)

So for this

### Guest (2025-04-21T20:42:44.875Z)

Yeah. That makes sense. So suppose I'm an analyst, I come to invest

### You (2025-04-21T20:42:47.425Z)

two. Not yet.

### Guest (2025-04-21T20:42:49.605Z)

I create a new deal similar to we did in RedIQ.

### You (2025-04-21T20:42:50.415Z)

Not yet. I don't I don't think so. I I think we can market

### Guest (2025-04-21T20:42:54.055Z)

The name, address, all this.

### You (2025-04-21T20:42:54.625Z)

using Excel. Or the common

### Guest (2025-04-21T20:42:56.415Z)

And then on probably summary page, I put all these

### You (2025-04-21T20:42:56.845Z)

delimited files in any sample financial statements we have now.

### Guest (2025-04-21T20:43:00.035Z)

details which are in blue color. Right? And maybe I have that form. I punch in there. I've saved I saved those details.

### You (2025-04-21T20:43:02.985Z)

But you know, we'll wanna keep going. I mean, if we could get that,

### Guest (2025-04-21T20:43:07.255Z)

Saved those all in the database.

### You (2025-04-21T20:43:07.555Z)

by the time we're talking to investors,

### Guest (2025-04-21T20:43:10.065Z)

And then rest of the data we get from true.

### You (2025-04-21T20:43:11.525Z)

that would be fantastic. You know, I don't wanna

### Guest (2025-04-21T20:43:13.565Z)

Map that data against what the analyst put.

### You (2025-04-21T20:43:14.385Z)

sit in front of somebody and show vaporware. You know? But yeah, I I think, you know, let's let's get the UI the input forms, all that. Connection with Drew, and then we can start talking about the actual processing financials Okay. So Yeah. And data So then and then you know. But Yeah. Yeah. That's important I believe so. Yeah. Okay. I imagine we would need more than that. So So alright. Okay. That that thank you.

### Guest (2025-04-21T20:44:27.875Z)

So this summary, you mean we start creating the form. Okay.

### You (2025-04-21T20:44:31.285Z)

Yeah. She's got the domain.

### Guest (2025-04-21T20:44:34.175Z)

Okay.

### You (2025-04-21T20:44:34.345Z)

We still don't have the an actual website or email.

### Guest (2025-04-21T20:44:37.915Z)

Okay.

### You (2025-04-21T20:44:42.685Z)

And without an email, that's gonna hold us back on getting things like set up, like Jira, Confluence, and those

### Guest (2025-04-21T20:44:48.115Z)

Okay. Okay. Yeah. I don't know. Do you still have time or

### You (2025-04-21T20:44:54.925Z)

Yeah.

### Guest (2025-04-21T20:44:55.085Z)

we can hop on another meeting, but do you have time or you have to go somewhere?

### You (2025-04-21T20:44:55.575Z)

Nothing so far. Yeah. I don't know. I know she's been

### Guest (2025-04-21T20:45:01.095Z)

Oh, cool. Cool. So

### You (2025-04-21T20:45:02.615Z)

very busy. But

### Guest (2025-04-21T20:45:04.815Z)

sure. Yeah. If

### You (2025-04-21T20:45:05.215Z)

you know, my my concern is you know, I don't mind

### Guest (2025-04-21T20:45:07.955Z)

this ends, then I'll I'll send you another invite.

### You (2025-04-21T20:45:09.335Z)

putting something in my name, put it on a credit card, but

### Guest (2025-04-21T20:45:11.245Z)

Okay. So we create this form. Say, we have

### You (2025-04-21T20:45:12.655Z)

how would we handle transferring it over? Or

### Guest (2025-04-21T20:45:15.915Z)

React project up and running. Right?

### You (2025-04-21T20:45:17.175Z)

you know, if I get

### Guest (2025-04-21T20:45:17.995Z)

So we create this form summary form.

### You (2025-04-21T20:45:18.665Z)

my training, I'm just gonna take it up. So yeah.

### Guest (2025-04-21T20:45:21.285Z)

And then, in the back end, we grab the data, put it in the database.

### You (2025-04-21T20:45:21.785Z)

Yeah. Access to what?

### Guest (2025-04-21T20:45:26.255Z)

Then from Drew, what Drew was saying that he

### You (2025-04-21T20:45:28.485Z)

To the

### Guest (2025-04-21T20:45:30.655Z)

does not have

### You (2025-04-21T20:45:31.055Z)

Yeah. I I've got access to the domain.

### Guest (2025-04-21T20:45:32.645Z)

API or something. So he just

### You (2025-04-21T20:45:34.875Z)

Right?

### Guest (2025-04-21T20:45:34.895Z)

he's gonna give us data in Excel.

### You (2025-04-21T20:45:35.745Z)

Can set up email.

### Guest (2025-04-21T20:45:36.825Z)

We'll have to work something, find something which will kind of extract

### You (2025-04-21T20:45:36.995Z)

Yeah. Yeah. But it's well, it she sent it up through GoDaddy.

### Guest (2025-04-21T20:45:41.105Z)

the data. I'm I'm assuming that it will be in the same format all the times because

### You (2025-04-21T20:45:42.825Z)

But we don't have an email server set up. So

### Guest (2025-04-21T20:45:46.015Z)

you know, it's coming from a system.

### You (2025-04-21T20:45:47.155Z)

we need to go through it has, an option to go through Microsoft. And then so we would quite we register the domain with Microsoft, then we'll get all the DNS settings and all the stuff that we need.

### Guest (2025-04-21T20:46:00.815Z)

Mhmm.

### You (2025-04-21T20:46:03.565Z)

For the email. Right now, all she she only owns the domain name. And It's

### Guest (2025-04-21T20:46:12.515Z)

Yeah. That's why uploading those documents

### You (2025-04-21T20:46:17.195Z)

I'll I'll look. I'll look, but I

### Guest (2025-04-21T20:46:17.215Z)

from our platform.

### You (2025-04-21T20:46:21.355Z)

when when she gave me access and I looked around, the only thing that I

### Guest (2025-04-21T20:46:25.395Z)

Right.

### You (2025-04-21T20:46:25.815Z)

saw was a link to Microsoft

### Guest (2025-04-21T20:46:28.215Z)

Right.

### You (2025-04-21T20:46:29.515Z)

or Google Workspace. But Microsoft was running

### Guest (2025-04-21T20:46:32.645Z)

Right. So for this initial drop,

### You (2025-04-21T20:46:35.125Z)

a special where it was only, like, $4 a month compared to, like,

### Guest (2025-04-21T20:46:36.525Z)

the Do we need that or we need

### You (2025-04-21T20:46:39.475Z)

15.

### Guest (2025-04-21T20:46:40.245Z)

I

### You (2025-04-21T20:46:40.475Z)

A month. Let me check. Okay. Let me check and see. Yeah. The only thing is we did get agreement that

### Guest (2025-04-21T20:47:00.435Z)

Right.

### You (2025-04-21T20:47:01.625Z)

that they liked I forgot to which one. Very very simple

### Guest (2025-04-21T20:47:07.925Z)

Alright.

### You (2025-04-21T20:47:08.195Z)

straightforward. Have to go and pull up Mark's email to which one that he signaled I agreed with with what he said. So

### Guest (2025-04-21T20:47:14.115Z)

Yeah. Yep.

### You (2025-04-21T20:47:16.945Z)

Yeah.

### Guest (2025-04-21T20:47:21.975Z)

Sounds good. Sounds good. So okay. So that deal creation flow the form, data ingestion from Drew, and then that data population

### You (2025-04-21T20:47:38.205Z)

Hold on a sec.

### Guest (2025-04-21T20:47:39.525Z)

was a waste of fifteen minutes. Okay. Cool.

### You (2025-04-21T20:47:39.665Z)

I'm my chat was hidden behind.

### Guest (2025-04-21T20:47:41.815Z)

And then data ingestion from Drew's Excel and then generating the more data

### You (2025-04-21T20:47:49.295Z)

Oh, come on. Where did the the chat go?

### Guest (2025-04-21T20:47:51.605Z)

generating the model with the data that you know,

### You (2025-04-21T20:47:54.005Z)

Oh, okay. I found it here.

### Guest (2025-04-21T20:47:55.525Z)

for that particular property. Right?

### You (2025-04-21T20:47:58.385Z)

Yes.

### Guest (2025-04-21T20:47:58.515Z)

All we need for the initial draft.

### You (2025-04-21T20:47:59.075Z)

Yeah. Okay. So which one? The the Vinod bat

### Guest (2025-04-21T20:48:03.125Z)

Okay. Cool.

### You (2025-04-21T20:48:04.315Z)

83 GitHub? IO. Yeah. See

### Guest (2025-04-21T20:48:07.755Z)

Sounds good. Sounds good. So okay. And, I mean, that already have the domain name registered. Think the email is is still not set up yet. Fine. Okay.

### You (2025-04-21T20:48:24.725Z)

Okay. Let me let me back up. What else? So it should be yeah. There it is.

### Guest (2025-04-21T20:48:30.915Z)

Yeah. Yeah.

### You (2025-04-21T20:48:31.775Z)

K. It's mean, some kind of So Yeah. No. This is this is yeah. It it's very close to

### Guest (2025-04-21T20:48:39.455Z)

Yeah. What happened to that email? I think you are in discussion with

### You (2025-04-21T20:48:41.205Z)

what the other ones had. Now

### Guest (2025-04-21T20:48:44.375Z)

Diane about that.

### You (2025-04-21T20:48:44.475Z)

this would be

### Guest (2025-04-21T20:48:45.735Z)

Email tab.

### You (2025-04-21T20:48:45.995Z)

the actual app

### Guest (2025-04-21T20:48:46.535Z)

Okay.

### You (2025-04-21T20:48:48.565Z)

So what we would do is we would do a home page. Let me pull up that email real quick, and I'll pull up that one. Where did it come on?

### Guest (2025-04-21T20:48:54.555Z)

Yeah. Yeah.

### You (2025-04-21T20:49:02.975Z)

Let me see.

### Guest (2025-04-21T20:49:07.305Z)

But you do do match it.

### You (2025-04-21T20:49:09.915Z)

Okay.

### Guest (2025-04-21T20:49:10.625Z)

Yeah. You do have access to our GoDaddy. Right? Access to the code daddy where she booked the domain. So we can set up email on that. Right?

### You (2025-04-21T20:49:26.935Z)

Okay. So Mark says he likes the real estate labs. So

### Guest (2025-04-21T20:49:40.975Z)

Uh-huh. Well, go to this one. So Yeah. Yeah. I think I think you could we could just set up the email with code ID. They'll do everything. They'll have emails over.

### You (2025-04-21T20:50:06.555Z)

Okay. Yeah. So we I think those can see what's on there. So this is something that he makes we have a link page like this. And, I mean, it seems like almost everybody in ICDAs uses a very similar would just have something like this, and then, you know, we would have our login up here when they get over here.

### Guest (2025-04-21T20:50:29.675Z)

Okay. Okay.

### You (2025-04-21T20:50:30.785Z)

We could change the the blues. We everything else to be

### Guest (2025-04-21T20:50:33.065Z)

Okay. Okay.

### You (2025-04-21T20:50:33.965Z)

more consistent. But I would imagine, you know, this this is 40 inches. Key and simple. And Diane,

### Guest (2025-04-21T20:50:37.515Z)

And then there was I think you guys are making some

### You (2025-04-21T20:50:38.405Z)

this as well. So, you know, we'll need a logo. We'll need everything else. But

### Guest (2025-04-21T20:50:41.705Z)

development on the website. Right?

### You (2025-04-21T20:50:43.685Z)

yeah. Nothing at all. We have nothing to go on. Okay. Mean, we have mock ups or we we do some some mock ups to get up the preliminary screenshot on there, but you know, for that, we'll need a logo. We'll need a couple other things on there. So yeah.

### Guest (2025-04-21T20:51:08.265Z)

Yeah. Yeah. Could you please click on that link I just sent? That was the if you remember the last one.

### You (2025-04-21T20:51:12.895Z)

I would imagine. Yeah. Okay.

### Guest (2025-04-21T20:51:16.545Z)

I kinda like that

### You (2025-04-21T20:51:16.775Z)

Yeah. And I'll keep looking into the the email, see if

### Guest (2025-04-21T20:51:18.025Z)

color

### You (2025-04-21T20:51:19.715Z)

which is gonna be the quickest and easiest and cheapest.

### Guest (2025-04-21T20:51:19.775Z)

combination. I don't know whether liked it as well, but that blue particularly dark blue, just

### You (2025-04-21T20:51:25.675Z)

So

### Guest (2025-04-21T20:51:27.095Z)

probably should stick to that. I can send some more

### You (2025-04-21T20:51:29.995Z)

Yeah.

### Guest (2025-04-21T20:51:30.545Z)

combinations.

### You (2025-04-21T20:51:32.135Z)

Yep. He's he's had some data. I don't know if it's the data that we need. Because remember, we went through and

### Guest (2025-04-21T20:51:41.815Z)

Just here now? Oh, you don't see it?

### You (2025-04-21T20:51:44.625Z)

he went through and talked about you know, the level of granularity and how much he had and

### Guest (2025-04-21T20:51:48.975Z)

It yeah. Probably on my

### You (2025-04-21T20:51:50.775Z)

think he still had some things that he had to do that he couldn't get out of the system the way we wanted it, but he was gonna be some

### Guest (2025-04-21T20:51:53.715Z)

else. This is the

### You (2025-04-21T20:51:56.745Z)

power behind the back or something. So, yeah, we need to we need bring it out tomorrow.

### Guest (2025-04-21T20:51:58.135Z)

yeah. Yeah. Yeah.

### You (2025-04-21T20:52:00.845Z)

Find out exactly where he's at, So

### Guest (2025-04-21T20:52:03.465Z)

See if you remember the initial some draft I'm trying to create.

### You (2025-04-21T20:52:06.655Z)

Yeah.

### Guest (2025-04-21T20:52:13.575Z)

Employ that blue on the left bar. And looks might not be great,

### You (2025-04-21T20:52:17.105Z)

Yeah. Yeah. So But if you if you wanna go ahead I'm not sure what daily you'd want right off the bat. So you wanna take a lead on that, that would be great.

### Guest (2025-04-21T20:52:28.985Z)

Yeah.

### You (2025-04-21T20:52:30.035Z)

Bye. Yeah. And and I'll take lead, the forms.

### Guest (2025-04-21T20:52:34.105Z)

It's probably good.

### You (2025-04-21T20:52:35.975Z)

And then I can put something to do there.

### Guest (2025-04-21T20:52:36.515Z)

I use some color like that. Yeah. Mhmm. Sure. Logo

### You (2025-04-21T20:52:59.365Z)

I don't know. All I don't know. That's that's what's coldly. Almost taken up with Claude. Yeah.

### Guest (2025-04-21T20:53:10.415Z)

What was the other URL? I don't remember.

### You (2025-04-21T20:53:11.365Z)

Yeah. No. I mean, it it really it it took a while for us to go through all the model.

### Guest (2025-04-21T20:53:14.935Z)

Remember. The

### You (2025-04-21T20:53:16.355Z)

And and so by the time he went through

### Guest (2025-04-21T20:53:17.745Z)

productivity app. I created logo, and I don't know which all I use.

### You (2025-04-21T20:53:20.155Z)

I can't keep talking like a like a person. By the time it went through all all the tabs and then went and looked at all the name ranges, created a difference, that's that's the schema that it came up with. So and and, like, the best story, like, that's okay. Sorry. After subscription, yeah. Yeah.

### Guest (2025-04-21T20:53:41.335Z)

Okay. This is a labs.

### You (2025-04-21T20:53:42.615Z)

One thing you might wanna look at too, Google Gemini. Not brushing my door. It's a real fact

### Guest (2025-04-21T20:53:53.295Z)

On the website. Yeah. I they also

### You (2025-04-21T20:53:55.215Z)

Yeah.

### Guest (2025-04-21T20:53:56.595Z)

blue, but different blue.

### You (2025-04-21T20:53:59.485Z)

It's actually fire based studio.

### Guest (2025-04-21T20:54:01.565Z)

How it's actually looks very similar to that?

### You (2025-04-21T20:54:02.135Z)

Right here. You can see just And it is it's it's the fire base database. Aligned with Gemini. But it's free. And, also, the one I would high end that I haven't really tested out too much is the Google AI Studio. It's just a istudio.google.com I have been hearing this this only came out a couple weeks ago. And I've been hearing that this is the number one model for code. Okay. That Claude was the best and that this performing. I mean, it's almost neck and neck, really. But this this is free. Yes. So shelling out $20 a month. So Yeah. Cool. Yeah. The only only thing that's happened and I did try to build on the Firebase, is it doesn't do a good job with UI. So you might wanna you know, when it comes down to the UI, we'd probably use a different tool. But for the for the back end code,

### Guest (2025-04-21T20:55:13.825Z)

Okay.

### You (2025-04-21T20:55:14.955Z)

and especially since it's connected to Firebase, you know, you probably build the database right here.

### Guest (2025-04-21T20:55:20.845Z)

Okay.

### You (2025-04-21T20:55:21.095Z)

So Yeah. I'm I'm pretty much wide open tomorrow except for our call. So if you wanna have any if you have any questions in the morning or sometime between before our call, just let me know.

### Guest (2025-04-21T20:55:42.745Z)

So we have domain name.

### You (2025-04-21T20:55:45.295Z)

Yeah. Alright, sir.

### Guest (2025-04-21T20:55:47.215Z)

Okay. And then we'll have to see where do we want to post that website.

### You (2025-04-21T20:55:49.435Z)

We'll talk to you later.

### Guest (2025-04-21T20:55:51.025Z)

Probably just go on Google right now. Okay. Yeah. And then we have meeting at our group meeting tomorrow. I think Drew already sent some data. Right? Remember he sent something. Yeah. For any given property, I mean, data is specific to this model. Might make some progress by tomorrow. Yeah. Sure. Yeah. I can talk a minute here. Probably have something to look for that. Yeah. So which I mean, they look fine to me. Plot generated based on the model you uploaded. Okay. And that's I haven't looked. Deep, but that's all we need, just 10 tables. Okay. And you update Okay. Think Yeah. My three minds are Yeah. Okay. Might wrap up in three minutes. Near the Firebase. Yeah. Yeah. Right. Right. Mhmm. Okay. Yeah. Right. Okay. Okay. Good. Alright. Yep. Cool. I'll give this a try there. Sounds amazing. Sounds ama Oh, okay. Yep. Yeah. Quote. Quote. Quote. Sounds good. Sounds good. Amazing. I got got a lot of clarity from this, and I think I am kind ready to ready to go. They are digging. Sounds great. Sounds great. Appreciate it. Thank you. Bye bye. Bye bye.